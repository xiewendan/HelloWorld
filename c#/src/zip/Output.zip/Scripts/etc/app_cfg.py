# -*- coding: utf-8 -*-

CONFIG = {
    "debug": True,                                  # 正式环境一定要设置为False!!!!!!
    "debug_frame_detect": True,                     # 开启卡顿检查
    "redirect_stdout": True,                        # 是否对标准输出做重定向，False表示直接丢给stdout
    "save_stdout_to_file": True,                    # 是否将标准输出保存到文件，前提是 redirect_stdout 为True, 仅限Win
    "save_file": "Data/DB.json",                         # 本地保存文件
    "frame_cyc": 33,                                # 基础帧周期
    "encryption": True,                             # 是否启用通讯加密
    "loginkeypath": "Encryption/rsa.pub",           # 加密的公钥文件
    "auto_reload": False,                           # 文件自动reload
}
