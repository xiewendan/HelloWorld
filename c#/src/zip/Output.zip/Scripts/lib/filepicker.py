# -*- coding: utf-8 -*-

import json
import types
import httplib
import urlparse

__version__ = '1.1.0'


class ResponseError(Exception):
    """Exception class for FilePicker HTTP response errors.
    Its args is a 2-entry tuple like (status, body), where status
    is the HTTP response code and body is the HTTP response body.
    e.g. ResponseError(404, 'Project Not Found').
    """
    pass


class Client(object):
    def __init__(self, product, is_dev=False):
        self.product = product

        host = "fp-dev.webapp.163.com" if is_dev else "fp.ps.netease.com"
        # host = "fp.dev.webapp.163.com:8204" if is_dev else "fp.ps.netease.com"
        self.fp_post_url = "https://%s/%s/file/new/" % (host, self.product)

    def request(self, method, url, token, body=None, headers=None):
        """Perform a complete request to the server.
        Return a httplib.HTTPResponse instance.
        """
        scheme, netloc, path, query_string, fragment = urlparse.urlsplit(url)
        conn = httplib.HTTPConnection(netloc)
        # prepare headers
        headers = headers or {}
        headers['Authorization'] = token
        headers['User-Agent'] = 'FilePickerClient/%s' % __version__
        if method in ('POST', 'PUT') and 'Content-Length' not in headers:
            if isinstance(body, types.GeneratorType):
                headers['Transfer-Encoding'] = 'chunked'
            else:
                headers['Content-Length'] = body and len(body) or 0
        # send request line
        if len(query_string) > 0:
            path += '?' + query_string

        conn.putrequest(method, path)
        # send headers
        for key, val in headers.iteritems():
            conn.putheader(key, val)
        conn.endheaders()
        # send body if necessary
        if isinstance(body, types.GeneratorType):
            if 'Content-Length' in headers:
                for data in body:
                    conn.send(data)
            else:  # use chunked encoding
                for data in body:
                    conn.send('%x\r\n%s\r\n' % (len(data), data))
                conn.send('0\r\n\r\n')
        elif body:
            conn.send(body)
        # read response
        res = conn.getresponse()
        if res.status not in range(200, 300):
            raise ResponseError(res.status, res.read())
        return res.read()

    def upload(self, token, body, headers):
        """Upload new file.

        Return url of new file.
        """
        body = self.request('POST', self.fp_post_url, token, body=body, headers=headers)
        data = json.loads(body)
        return data['url']

    def delete(self, file_url, token):
        """Delete file.

        Return whether delete successfully.
        """
        body = self.request('DELETE', file_url, token)
        return True
