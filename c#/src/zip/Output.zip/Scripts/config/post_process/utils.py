# -*- coding: utf-8 -*-


def GetListItem(szItem, szSplit=","):
    if szItem is None:
        return []

    if szSplit == ",":
        szItem = szItem.replace("，", ",")
    elif szSplit == ";":
        szItem = szItem.replace("；", ";")

    listItem = szItem.split(szSplit)
    return listItem
