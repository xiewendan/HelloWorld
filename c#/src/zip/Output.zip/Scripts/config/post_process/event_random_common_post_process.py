# -*- coding: utf-8 -*-

import utils

def post_process(data):
    for nID,dictInfo in data.iteritems():
        # print("================",nID)
        for nEventID in xrange(1, 100):
            szEventName = "EventNum" + str(nEventID)
            nEventNum = dictInfo.get(szEventName)
            if nEventNum is None:
                # print("111111", szEventName, nEventNum)
                break

            if nEventNum == 0:
                continue

            szStageNumKey = "Event{}_Stage_Num".format(nEventID)
            szStageNum = dictInfo.get(szStageNumKey)
            if not szStageNum:
                continue

            if szStageNum == "":
                continue

            listStage = utils.GetListItem(szStageNum, ";")
            dictStageNum = {}
            for szStage in listStage:
                listInfo = utils.GetListItem(szStage, ",")
                nStage = int(listInfo[0])
                nStart = int(listInfo[1])
                nEnd = int(listInfo[2])
                dictStageNum[nStage] = [nStart, nEnd]
            # print("2222.",nEventID, szStageNumKey, dictStageNum)
            dictInfo[szStageNumKey] = dictStageNum

    return data
