# -*- coding: utf-8 -*-


# 常量类
class ConstMe(object):
    def __setattr__(self, name, value):
        if self.__dict__.has_key(name):
            raise ValueError, "Can't rebind const(%s)" % name
        self.__dict__[name] = value


# -----------------------------------------------------------------------------------------------------

# 连接状态
class EConnectionState(ConstMe):
    CONNECTED = 1
    CONNECTING = 2
    DISCONNECTING = 3
    DISCONNECTED = 4


# 消息类型
class EMsgType(ConstMe):
    CONN_CALL = 1  # 链接本身的调用 [methodName,lParam], connection层处理
    SELF_ENTITY_MSG = 2  # 链接本身绑定的entity 的msg, connection层处理

    # -------------客户端只关心以下消息--------------------
    GAC2GATE_FORWARD_GAS = 3
    GAS2GATE_FORWARD_GAC = 4
    GAC2GATE_FORWARD_BAT = 5
    BAT2GATE_FORWARD_GAC = 6
    GAS2GATE_FORWARD_GAC_ENTITY = 7
    GAS2GATE_BROAD_FORWARD_GAC_NORMAL = 8
    BAT2GATE_FORWARD_GAC_ENTITY = 9
    BAT2GATE_BROAD_FORWARD_GAC_NORMAL = 10
    SEND_SESSION_KEY = 11
    REG_STRING = 12
    CLEAR_REG_STRING = 13

    # ----------------------------------
    WORLD_ENTITY_CALL = 20  # 全世界消息，服务器用，普通模式
    ENGINE_WORLD_ENTITY_CALL = 21  # 全世界消息，服务器用，引擎模式
    GAC2COUNTRY_ENTITY_CALL = 22  # gac发到服务器消息，GAC2GATE_FORWARD_GAS会转成这个
    COUNTRY2GAC_ENTITY_CALL = 23  # 服务器对gac消息，GAS2GATE_FORWARD_GAC会转成这个

    # ----------------------------------
    GAS2GATE_BROAD_FORWARD_GAC = 30


# EntityAvatar消息类型
class EEntityAvatarMsgType(ConstMe):
    SCENEMSGSELF = 1
    GAMEOBJMSG = 2


# 登陆认证错误代码
class AuthErrorCode(ConstMe):
    ServerError = 500  # 服务器错误
    AuthFail = 401  # 验证失败
    UnActived = 404  # 账号未激活(限制账号登录时使用)


# 删除账号编码
class EDeleteAccount(ConstMe):
    eDeleteOK = 1       # 成功
    eDeleteFail = 2     # 失败


# 语言
class LanguageType(ConstMe):
    CN = "cn"  # 中文
    EN = "en"  # 英文


# 属性类型
class EPropertyType(ConstMe):
    GameObjType = "obj_type"  # 对象类型
    ComponentType = "cmp_type"  # 组件类型
    ComponentSubType = "cmp_sub_type"  # 组件子类型
    ComponentDict = "cmp_dict"  # 组件字典
    # 基础信息
    GID = "gid"  # 唯一ID
    Name = "name"  # 名称
    Pos = "pos"  # 位置
    Dir = "dir"  # 角度
    CampID = "camp_id"  # 所属势力
    CfgID = "cfg_id"  # 配置表id
    MasterID = "monster_id"  # 主人gid
    DieDestory = "die_destory"  # 死亡回收时间(这个属性最好由战斗属性接管)
    AreaID = "area_id"  # 区域id

    # 战斗属性
    PokemonType = "pokemon_type"  # 属性类型

    # AI组件
    AIInterval = "ai_interval"  # AI心跳间隔
    AIType = "ai_type"  # AI类型
    AIArg = "ai_arg"  # AI参数
    TargetSelectorType = "target_selector_type"  # 目标选择器
    TargetSelectorArg = "target_selector_arg"  # 目标选择器参数

    # 位置模型
    SceneTypeID = "scene_type"  # 场景类型
    SceneCopyID = "scene_copy"  # 副本类型
    ModelPath = "model_path"  # 模型文件
    ModelPath1 = "model_path1"  # 模型文件1
    ModelScale = "model_scale"  # 模型比例
    ViewRadius = "view_radius"  # 视野半径
    LostRadius = "lost_radius"  # 脱离半径
    ViewAngle = "view_angle"  # 视野角度
    SceneIdx = "scene_idx"  # 场景移动模块相关索引
    ModelRadius = "model_radius"  # 碰撞半径
    ModelHeight = "model_height"  # 模型高度
    BasicSpeed = "basic_speed"  # 初始速度
    DetourFilter = "detour_filter"  # 寻路类型
    IgnoreMove = "ignore_move"  # 忽略碰撞

    # 卡牌组件
    CardSpace = "card_space"  # 卡牌空间大小
    CardData = "card_data"  # 卡牌数据
    HardCard = "hard_card"  # 手牌

    # 鼠标点击组件
    MouseDetect = "mouse_detect"  # 鼠标点击

    eStr2Pro = {
        "对象类型": GameObjType,
        "名称": Name,
        "场景类型": SceneTypeID,
        "副本类型": SceneCopyID,
        "模型文件": ModelPath,
        "模型文件1": ModelPath1,
        "模型比例": ModelScale,
        "视野半径": ViewRadius,
        "脱离半径": LostRadius,
        "AI心跳间隔": AIInterval,
        "AI类型": AIType,
        "AI参数": AIArg,
        "目标选择器": TargetSelectorType,
        "目标选择器参数": TargetSelectorArg,
        "碰撞半径": ModelRadius,
        "模型高度": ModelHeight,
        "初始速度": BasicSpeed,
        "鼠标点击": MouseDetect,
        "寻路类型": DetourFilter,
        "死亡回收时间": DieDestory,
        "忽略碰撞": IgnoreMove,
    }


# AI类型
class EAIType(ConstMe):
    BT = 1
    FSM = 2
    ST = 3


# 目标选择器
class ETargetSelectorType(ConstMe):
    Common = "common"
    LockType = "lock_type"
    CareType = "care_type"


# 游戏对象类型
class EGameObjType(ConstMe):
    Player = 0  # 玩家
    Hero = 1  # 英雄
    Monster = 2  # 怪物
    KingTower = 3  # 主塔
    Trigger = 4  # 触发器
    AreaObj = 5  # 区域对象

    eType2Str = {
        Player: "Player",
        Hero: "Hero",
        Monster: "Monster",
        KingTower: "KingTower",
        Trigger: "Trigger",
        AreaObj: "AreaObj",
    }


# 游戏实体消息类型
class EEntityGameMessageType(ConstMe):
    # 游戏消息
    Undefine = 0
    # 初始化完成
    InitOK = 1
    # 死亡
    Die = 2
    # 销毁
    Destroy = 3


# DoFightSkill失败类型
class EDoSkillFailType(ConstMe):
    eNone = 0
    eForceControlling = 1
    eDead = 2  # 已经死亡
    eCD = 3


# 场景类型ID
class ESceneTypeID(ConstMe):
    # 登陆场景1000开始
    Login = 1001  # 登陆
    CreateRole = 1002  # 创建角色场景
    SelectRole = 1003  # 选择角色场景

    # 游戏大厅2000开始
    Lobby = 2001  # 大厅

    # 游戏场景3000开始
    NormalBattle = 3001  # 通用游戏场景


# 场景CopyID
class ECopyTypeID(ConstMe):
    NormalScene = 1  # 普通场景
    LobbyScene = 2  # 大厅场景
    BattleScene = 3  # 游戏场景


# 技能距离类型
class ESkillDisType(ConstMe):
    eNotDefine = 0  # 未定义
    eClose = 1  # 近战
    eFar = 2  # 远程


# 子弹攻击类型
class EBulletAttackType(ConstMe):
    eNormal = 0  # 普攻
    eSkill = 1  # 特攻

    dictStr2Type = {
        "普攻": eNormal,
        "特攻": eSkill,
    }

    @classmethod
    def Str2Type(cls, name):
        return cls.dictStr2Type.get(name)


# 子弹目标选择
class EBulletTargetType(ConstMe):
    eSingle = 0  # 单体
    eAreaCircle = 1  # 对地圆形

    dictStr2Type = {
        "单体": eSingle,
        "对地圆形": eAreaCircle,
    }

    @classmethod
    def Str2Type(cls, name):
        return cls.dictStr2Type.get(name)

# 宝可梦属性
class EPokemonType(ConstMe):
    eNormal = 0  # 一般系
    eFire = 1  # 火系
    eFighting = 2  # 格斗系
    eWater = 3  # 水系
    eFlying = 4  # 飞行系
    eGrass = 5  # 草系
    ePoison = 6  # 毒系
    eElectric = 7  # 电系
    eGround = 8  # 地上系
    ePsychic = 9  # 超能力系
    eRock = 10  # 岩石系
    eIce = 11  # 冰系
    eBug = 12  # 虫系
    eDragon = 13  # 龙系
    eGhost = 14  # 幽灵系
    eDark = 15  # 恶系
    eSteel = 16  # 钢系
    eFairy = 17  # 妖精系

    dictStr2Type = {
        "一般": eNormal,
        "火": eFire,
        "格斗": eFighting,
        "水": eWater,
        "飞行": eFlying,
        "草": eGrass,
        "毒": ePoison,
        "电": eElectric,
        "地面": eGround,
        "超能力": ePsychic,
        "岩石": eRock,
        "冰": eIce,
        "虫": eBug,
        "龙": eDragon,
        "幽灵": eGhost,
        "恶": eDark,
        "钢": eSteel,
        "妖精": eFairy,
    }

    @staticmethod
    def Str2Type(name):
        return EPokemonType.dictStr2Type.get(name, EPokemonType.eNormal)


# 游戏对象组件
class EComponentEntityType(ConstMe):
    # --------------------------游戏对象----------------------------------
    EntityInfoBase = "m_BaseInfoCmp"  # 游戏对象基本属性
    EntityPosition = "m_PositionCmp"  # 游戏对象位置属性
    EntityModel = "m_ModelCmp"  # 游戏对象模型
    EntityView = "m_ViewCmp"  # 游戏对象视野
    EntityAI = "m_AICmp"  # 游戏对象AI
    PlayMakerFSM = "m_PlayMakerFsm"
    EntityFightAttr = "m_FightAttr"  # 战斗属性
    EntitySkillSlot = "m_SkillSlot"  # 技能槽
    EntityDoSkill = "m_DoSkill"  # 技能组件
    EntityFireBullet = "m_FireBullet"  # 发射子弹组件
    EntityCard = "m_CardCmp"  # 卡牌组件
    EntityMouseDetect = "m_MouseDetect"  # 鼠标检测
    EntityUI = "m_UI"  # UI

    # ---------------------------玩家-----------------------------------
    PlayerBaseInfo = "m_PlayerBaseInfoCmp"          # 玩家基本信息属性
    PlayerSceneInfo = "m_PlayerSceneInfoCmp"        # 玩家场景信息属性

    eType2Str = {
        # --------------------------游戏对象----------------------------------
        EntityInfoBase: "属性组件",
        EntityPosition: "位置组件",
        EntityModel: "模型组件",
        EntityView: "视野组件",
        EntityAI: "AI组件",
        EntityFightAttr: "战斗属性组件",
        EntitySkillSlot: "技能槽组件",
        EntityDoSkill: "技能组件",
        EntityCard: "卡牌组件",
        EntityMouseDetect: "鼠标检测组件",
        EntityUI: "UI组件",

        # ---------------------------玩家-----------------------------------
        PlayerBaseInfo: "玩家基本信息组件",
        PlayerSceneInfo: "玩家场景信息组件",
    }

    eStr2Type = {
        # --------------------------游戏对象----------------------------------
        "属性组件": EntityInfoBase,
        "位置组件": EntityPosition,
        "模型组件": EntityModel,
        "视野组件": EntityView,
        "AI组件": EntityAI,
        "战斗属性组件": EntityFightAttr,
        "技能槽组件": EntitySkillSlot,
        "技能组件": EntityDoSkill,
        "卡牌组件": EntityCard,
        "鼠标检测组件": EntityMouseDetect,
        "UI组件": EntityUI,

        # ---------------------------玩家-----------------------------------
        "玩家基本信息组件": PlayerBaseInfo,
        "玩家场景信息组件": PlayerSceneInfo,
    }


# HP变化原因类型
class EHpChangedReason(ConstMe):
    eOtherType = 1
    eSkillHurt = 2
    eSkillCure = 3


# 视野类型
class EViewType(ConstMe):
    ECircle = "circle"  # 圆形
    ESector = "sector"  # 扇形


# 卡牌组件类型
class ECardType(ConstMe):
    ELobby = "lobby"  # 场外的
    EFight = "fight"  # 战场内用的


# 信息组件
class EInfoType(ConstMe):
    EBase = "base"  # 基础的
    ENpc = "npc"  # npc信息
    EHero = "hero"  # 英雄信息
    EArea = "area"  # 区域块信息


class EDetourParam(ConstMe):
    eExtWidth = 1.0
    eExtHeight = 2.0


class ECommonScriptParam(ConstMe):
    eGlobalScriptObj = "GlobalScriptsObj"


class EDetourFilterConfig(ConstMe):
    eWalking = 0x0040
    eFlying = 0x0010
    eElement = 0x0020
    eGrass = 0x002
    eWater = 0x004
    eFire = 0x008


class EDetourMovingConfig(ConstMe):
    eDefault = 0
    eAir = 1
    eGrass = 2
    eWater = 3
    eFire = 4

# 场景组件定义
class EComponentSceneType(ConstMe):
    # 末定义
    eUndefine = 0
    # 场景组件测试
    eTest = 1
    # 子弹管理器
    eBulletMgr = 2

# 动画类型
class ETransitionActionType(ConstMe):
    XY = 0
    Size = 1
    Scale = 2
    Pivot = 3
    Alpha = 4
    Rotation = 5
    Color = 6
    Animation = 7
    Visible = 8
    Sound = 9
    Transition = 10
    Shake = 11
    ColorFilter = 12
    Skew = 13
