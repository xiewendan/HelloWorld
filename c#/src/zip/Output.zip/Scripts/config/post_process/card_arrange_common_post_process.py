# -*- coding: utf-8 -*-

import utils

def post_process(data):
    newData = {}
    for nID, dictInfo in data.iteritems():
        dictItem = {}
        dictItem["LuckyType"] = dictInfo.get("LuckyType")
        szNormalCard = dictInfo.get("NormalCard")
        listTypeEvent = utils.GetListItem(szNormalCard, ";")
        dictNormalCard = {}
        for szEvent in listTypeEvent:
            if szEvent == "":
                continue
            listItem = utils.GetListItem(szEvent)
            dictNormalCard[int(listItem[0])] = int(listItem[1])

        dictItem["NormalCard"] = dictNormalCard

        szStaticCard = dictInfo.get("StaticCard")
        listTypeEvent = utils.GetListItem(szStaticCard, ";")
        dictStaticCard = {}
        for szEvent in listTypeEvent:
            if szEvent == "":
                continue
            listItem = utils.GetListItem(szEvent)
            dictStaticCard[int(listItem[0])] = int(listItem[1])

        dictItem["StaticCard"] = dictStaticCard

        # NumLimitCard

        newData[nID] = dictItem

    return newData
