# -*- coding: utf-8 -*-
from enum_def import EBulletAttackType, EBulletTargetType

dictAttackTypeName2Type = {
    '普攻': EBulletAttackType.eNormal,
    '特攻': EBulletAttackType.eSkill,
}

dictTargetTypeName2Type = {
    '单体': EBulletTargetType.eSingle,
    '对地圆形': EBulletTargetType.eAreaCircle,
}


def post_process(data):
    for nID, dictInfo in data.iteritems():
        dictInfo["攻击类型"] = dictAttackTypeName2Type[dictInfo.get('攻击类型', '普攻')]
        dictInfo["目标类型"] = dictTargetTypeName2Type[dictInfo.get('目标类型', '单体')]

    return data
