# -*- coding: utf-8 -*-

def post_process(data):
    for nGroupID, dictInfo in data.iteritems():
        value = dictInfo.get("目标选择器参数")
        if not value:
            continue

        if isinstance(value, str):
            dictInfo["目标选择器参数"] = map(int, value.split(","))
        else:
            dictInfo["目标选择器参数"] = [value]

    return data