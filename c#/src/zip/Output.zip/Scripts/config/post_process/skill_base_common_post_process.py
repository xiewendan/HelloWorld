# -*- coding: utf-8 -*-
from enum_def import ESkillDisType, EPokemonType

dictDisTypeName2DisType = {
    '未定义': ESkillDisType.eNotDefine,
    '近战': ESkillDisType.eClose,
    '远程': ESkillDisType.eFar,
}
def post_process(data):
    for nSkillID, dictSkillInfo in data.iteritems():
        #  距离类型
        szDisType = dictSkillInfo.get('距离类型', '未定义')
        dictSkillInfo["距离类型"] = dictDisTypeName2DisType[szDisType]

        # 技能伤害属性类型
        szElementType = dictSkillInfo.get("招式属性", "一般")
        if szElementType != "无":
            dictSkillInfo["招式属性"] = EPokemonType.Str2Type(szElementType)

    return data
