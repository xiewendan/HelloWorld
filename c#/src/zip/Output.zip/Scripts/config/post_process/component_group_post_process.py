# -*- coding: utf-8 -*-

def post_process(data):
    newdata = {}
    for nGroupID, dictGroup in data.iteritems():
        dictNew = {}
        for szKey, szVal in dictGroup.iteritems():
            if szVal == 0:
                szVal = None
            dictNew[szKey] = szVal

        newdata[nGroupID] = dictNew
    return newdata