# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'保留字段'
k2 = r'显示限制'
k3 = r'榜单上限'
k4 = r'存盘间隔'
k5 = r'排序间隔'
rank_server = TD({
    r'test': TD({
        k0: r'test',
        k1: r'_id,name,clusterid',
        k2: 100,
        k3: 10000,
        k4: 300000,
        k5: 10000,
    }),
})

def __onreload__(new_dict):
    global rank_server
    rank_server=new_dict.get('rank_server')
