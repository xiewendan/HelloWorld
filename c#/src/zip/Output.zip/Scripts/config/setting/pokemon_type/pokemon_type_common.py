# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'名称'
k3 = r'图标路径'
pokemon_type_common = TD({
    0: TD({
        k0: 0,
        k1: r'一般系',
        k2: 1100001,
    }),
    1: TD({
        k0: 1,
        k1: r'火系',
        k2: 1100002,
    }),
    2: TD({
        k0: 2,
        k1: r'格斗系',
        k2: 1100003,
    }),
    3: TD({
        k0: 3,
        k1: r'水系',
        k2: 1100004,
    }),
    4: TD({
        k0: 4,
        k1: r'飞行系',
        k2: 1100005,
    }),
    5: TD({
        k0: 5,
        k1: r'草系',
        k2: 1100006,
    }),
    6: TD({
        k0: 6,
        k1: r'毒系',
        k2: 1100007,
    }),
    7: TD({
        k0: 7,
        k1: r'电系',
        k2: 1100008,
    }),
    8: TD({
        k0: 8,
        k1: r'地上系',
        k2: 1100009,
    }),
    9: TD({
        k0: 9,
        k1: r'超能力系',
        k2: 1100010,
    }),
    10: TD({
        k0: 10,
        k1: r'岩石系',
        k2: 1100011,
    }),
    11: TD({
        k0: 11,
        k1: r'冰系',
        k2: 1100012,
    }),
    12: TD({
        k0: 12,
        k1: r'虫系',
        k2: 1100013,
    }),
    13: TD({
        k0: 13,
        k1: r'龙系',
        k2: 1100014,
    }),
    14: TD({
        k0: 14,
        k1: r'幽灵系',
        k2: 1100015,
    }),
    15: TD({
        k0: 15,
        k1: r'恶系',
        k2: 1100016,
    }),
    16: TD({
        k0: 16,
        k1: r'钢系',
        k2: 1100017,
    }),
    17: TD({
        k0: 17,
        k1: r'妖精系',
        k2: 1100018,
    }),
})

def __onreload__(new_dict):
    global pokemon_type_common
    pokemon_type_common=new_dict.get('pokemon_type_common')
