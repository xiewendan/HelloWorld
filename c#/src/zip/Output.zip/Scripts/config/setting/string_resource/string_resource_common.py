# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'表名'
k2 = r'首ID'
k3 = r'备注'
string_resource_common = TD({
    1: TD({
        k0: 1,
        k1: r'string_1_common',
        k2: 1000001,
        k3: r'谢老板',
    }),
})

def __onreload__(new_dict):
    global string_resource_common
    string_resource_common=new_dict.get('string_resource_common')
