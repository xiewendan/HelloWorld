# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'属性组件'
k3 = r'视野组件'
k4 = r'模型组件'
k5 = r'位置组件'
k6 = r'战斗属性组件'
k7 = r'技能槽组件'
k8 = r'技能组件'
k9 = r'卡牌组件'
k10 = r'AI组件'
k11 = r'鼠标检测组件'
k12 = r'UI组件'
component_group = TD({
    1001: TD({
        k0: 1001,
        k1: r'测试对象',
        k2: r'base',
        k3: r'circle',
        k4: None,
        k5: None,
        k11: None,
        k12: None,
    }),
    1002: TD({
        k0: 1002,
        k1: r'测试用移动对象',
        k2: r'npc',
        k3: r'circle',
        k4: None,
        k5: None,
        k6: None,
        k8: None,
        k11: None,
        k12: None,
    }),
    1003: TD({
        k0: 1003,
        k1: r'测试用hero对象',
        k2: r'hero',
        k3: r'circle',
        k9: r'fight',
    }),
    1004: TD({
        k0: 1004,
        k1: r'测试用神兽对象',
        k2: r'base',
        k3: r'circle',
        k4: None,
        k5: None,
        k6: None,
        k8: None,
        k11: None,
        k12: None,
    }),
    1005: TD({
        k0: 1005,
        k1: r'AI测试对象',
        k2: r'npc',
        k3: r'circle',
        k4: None,
        k5: None,
        k6: None,
        k8: None,
        k10: None,
        k11: None,
        k12: None,
    }),
    1006: TD({
        k0: 1006,
        k1: r'技能测试对象',
        k2: r'npc',
        k3: r'circle',
        k4: None,
        k5: None,
        k11: None,
        k12: None,
    }),
    1007: TD({
        k0: 1007,
        k1: r'场景区域对象',
        k2: r'area',
        k4: None,
        k5: None,
        k6: None,
        k8: None,
        k11: None,
        k12: None,
    }),
    1008: TD({
        k0: 1008,
        k1: r'空中移动测试对象',
        k2: r'npc',
        k3: r'circle',
        k4: None,
        k5: None,
        k6: None,
        k8: None,
        k10: None,
        k11: None,
        k12: None,
    }),
})

def __onreload__(new_dict):
    global component_group
    component_group=new_dict.get('component_group')
