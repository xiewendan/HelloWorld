# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'LuckyType'
k3 = r'NormalCard'
k4 = r'StaticCard'
k5 = r'NumLimitCard'
card_arrange_common = TD({
    1001: TD({
        k2: 1,
        k3: {1:20,2:5,3:7,4:3,5:4},
        k4: {9:6,10:7,19:6,20:7,29:6,30:7},
    }),
    1002: TD({
        k2: 2,
        k3: {1:17,2:6,3:8,4:4,5:4},
        k4: {9:6,10:7,19:6,20:7,29:6,30:7},
    }),
    1003: TD({
        k2: 3,
        k3: {1:14,2:7,3:9,4:5,5:4},
        k4: {9:6,10:7,19:6,20:7,29:6,30:7},
    }),
    1004: TD({
        k2: 4,
        k3: {1:11,2:8,3:10,4:6,5:4},
        k4: {9:6,10:7,19:6,20:7,29:6,30:7},
    }),
    1005: TD({
        k2: 5,
        k3: {3:25,4:10,5:4},
        k4: {9:6,10:7,19:6,20:7,29:6,30:7},
    }),
})

def __onreload__(new_dict):
    global card_arrange_common
    card_arrange_common=new_dict.get('card_arrange_common')
