# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'Type'
k3 = r'Name'
k4 = r'Rand'
lucky_common = TD({
    1001: TD({
        k0: 1001,
        k2: 1,
        k3: r'普通',
        k4: 3000,
    }),
    1002: TD({
        k0: 1002,
        k2: 2,
        k3: r'良好',
        k4: 4000,
    }),
    1003: TD({
        k0: 1003,
        k2: 3,
        k3: r'优秀',
        k4: 2500,
    }),
    1004: TD({
        k0: 1004,
        k2: 4,
        k3: r'极品',
        k4: 499,
    }),
    1005: TD({
        k0: 1005,
        k2: 5,
        k3: r'万中无一',
        k4: 1,
    }),
})

def __onreload__(new_dict):
    global lucky_common
    lucky_common=new_dict.get('lucky_common')
