# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'Type'
k3 = r'Name'
k4 = r'Level'
card_type_common = TD({
    1001: TD({
        k0: 1001,
        k2: 1,
        k3: r'普通战斗',
        k4: 1,
    }),
    1002: TD({
        k0: 1002,
        k2: 2,
        k3: r'精英战斗',
        k4: 2,
    }),
    1003: TD({
        k0: 1003,
        k2: 3,
        k3: r'奇遇',
        k4: 3,
    }),
    1004: TD({
        k0: 1004,
        k2: 4,
        k3: r'随机宝箱',
        k4: 4,
    }),
    1005: TD({
        k0: 1005,
        k2: 5,
        k3: r'随机商店',
        k4: 5,
    }),
    1006: TD({
        k0: 1006,
        k2: 6,
        k3: r'客栈',
        k4: 5,
    }),
    1007: TD({
        k0: 1007,
        k2: 7,
        k3: r'BOSS',
        k4: 100,
    }),
})

def __onreload__(new_dict):
    global card_type_common
    card_type_common=new_dict.get('card_type_common')
