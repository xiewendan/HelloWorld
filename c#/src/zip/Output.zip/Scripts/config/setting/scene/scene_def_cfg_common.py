# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'场景'
k2 = r'备注'
k3 = r'场景路径'
k4 = r'CopyType'
k5 = r'Boss血量倍数'
k6 = r'神兽位置1'
k7 = r'神兽位置2'
k8 = r'可放置区域阵营1'
k9 = r'可放置区域阵营2'
k10 = r'区域位置0'
k11 = r'区域位置1'
k12 = r'区域属性影响范围0'
k13 = r'区域属性影响范围1'
k14 = r'区域位置0范围'
k15 = r'区域位置1范围'
scene_def_cfg_common = TD({
    1001: TD({
        k0: 1001,
        k1: r'登录场景',
        k2: r'通用功能场景',
        k3: r'login',
        k4: 1,
    }),
    2001: TD({
        k0: 2001,
        k1: r'大厅场景',
        k2: r'通用功能场景',
        k3: r'demo_lobby',
        k4: 2,
    }),
    3001: TD({
        k0: 3001,
        k1: r'demo场景',
        k2: r'通用功能场景',
        k3: r'demo_scene_mb',
        k4: 3,
        k5: 3,
        k6: (-4.87, 1.2, -3.07),
        k7: (22.1, 1.0, -2.2),
        k8: (-8.0, -11, 8.0, 5.0),
        k9: (8.0, -11, 23, 5.0),
        k10: (7.8, 0.19, -8.1),
        k11: (7.8, 0.19, 2.2),
        k12: (7, -8, 9, -7),
        k13: (7, 1, 9, 3),
        k14: (0.7, -10, 14, -2),
        k15: (0.7, -2, 14, 4),
    }),
})

def __onreload__(new_dict):
    global scene_def_cfg_common
    scene_def_cfg_common=new_dict.get('scene_def_cfg_common')
