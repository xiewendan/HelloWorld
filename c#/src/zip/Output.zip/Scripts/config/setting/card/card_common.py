# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'名称'
k3 = r'怪物编号'
k4 = r'技能编号'
k5 = r'怪物数量'
k6 = r'图片路径'
k7 = r'摆放层级'
k8 = r'卡牌属性'
card_common = TD({
    1: TD({
        k0: 1,
        k1: r'卡蒂狗',
        k2: 1000002,
        k3: 7,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card1',
        k7: 0,
        k8: 1,
    }),
    2: TD({
        k0: 2,
        k1: r'小火龙',
        k2: 1000003,
        k3: 8,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card2',
        k7: 0,
        k8: 1,
    }),
    3: TD({
        k0: 3,
        k1: r'长翅鸥',
        k2: 1000004,
        k3: 9,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card3',
        k7: 0,
        k8: 3,
    }),
    4: TD({
        k0: 4,
        k1: r'杰尼龟',
        k2: 1000005,
        k3: 10,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card4',
        k7: 0,
        k8: 3,
    }),
    5: TD({
        k0: 5,
        k1: r'妙蛙种子',
        k2: 1000006,
        k3: 11,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card5',
        k7: 0,
        k8: 5,
    }),
    6: TD({
        k0: 6,
        k1: r'三地鼠',
        k2: 1000007,
        k3: 12,
        k4: 0,
        k5: 3,
        k6: r'CommonUI/Icon/Head/card6',
        k7: 0,
        k8: 0,
    }),
    7: TD({
        k0: 7,
        k1: r'可达鸭',
        k2: 1000008,
        k3: 13,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card7',
        k7: 0,
        k8: 3,
    }),
    8: TD({
        k0: 8,
        k1: r'六尾',
        k2: 1000009,
        k3: 14,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card8',
        k7: 0,
        k8: 1,
    }),
    9: TD({
        k0: 9,
        k1: r'大钳蟹',
        k2: 1000010,
        k3: 15,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card9',
        k7: 0,
        k8: 3,
    }),
    10: TD({
        k0: 10,
        k1: r'蚊香蝌蚪',
        k2: 1000011,
        k3: 16,
        k4: 0,
        k5: 2,
        k6: r'CommonUI/Icon/Head/card10',
        k7: 0,
        k8: 3,
    }),
    11: TD({
        k0: 11,
        k1: r'飞行测试怪',
        k2: 1000011,
        k3: 1002,
        k4: 0,
        k5: 1,
        k6: r'CommonUI/Icon/Head/card14',
        k7: 1,
        k8: 1,
    }),
})

def __onreload__(new_dict):
    global card_common
    card_common=new_dict.get('card_common')
