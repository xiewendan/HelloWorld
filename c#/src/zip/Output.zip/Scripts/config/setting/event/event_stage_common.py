# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'阶段开始'
k3 = r'阶段结束'
event_stage_common = TD({
    1: TD({
        k0: 1,
        k1: r'前期',
        k2: 1,
        k3: 15,
    }),
    2: TD({
        k0: 2,
        k1: r'中期',
        k2: 16,
        k3: 30,
    }),
    3: TD({
        k0: 3,
        k1: r'后期',
        k2: 31,
        k3: 45,
    }),
})

def __onreload__(new_dict):
    global event_stage_common
    event_stage_common=new_dict.get('event_stage_common')
