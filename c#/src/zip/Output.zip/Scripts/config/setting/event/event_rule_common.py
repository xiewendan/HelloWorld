# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'品级'
k3 = r'是否固定出现'
k4 = r'固定出现关卡'
k5 = r'最早出现关卡'
k6 = r'出现规则'
event_rule_common = TD({
    1: TD({
        k0: 1,
        k1: r'普通战斗',
        k2: 1,
    }),
    2: TD({
        k0: 2,
        k1: r'奇遇',
        k2: 2,
    }),
    3: TD({
        k0: 3,
        k1: r'精英战斗',
        k2: 3,
        k5: 3,
    }),
    4: TD({
        k0: 4,
        k1: r'宝藏',
        k2: 4,
    }),
    5: TD({
        k0: 5,
        k1: r'商店',
        k2: 5,
        k5: 5,
        k6: 1,
    }),
    6: TD({
        k0: 6,
        k1: r'客栈',
        k2: 6,
        k3: 1,
        k4: [14, 29, 44],
        k6: 1,
    }),
    7: TD({
        k0: 7,
        k1: r'Boss',
        k2: 7,
        k3: 1,
        k4: [15, 30, 45],
        k6: 2,
    }),
})

def __onreload__(new_dict):
    global event_rule_common
    event_rule_common=new_dict.get('event_rule_common')
