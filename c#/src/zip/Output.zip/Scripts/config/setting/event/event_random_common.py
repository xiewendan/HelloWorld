# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'备注'
k2 = r'幸运级别'
k3 = r'权重'
k4 = r'EventNum1'
k5 = r'Event1_Stage_Num'
k6 = r'EventNum2'
k7 = r'Event2_Stage_Num'
k8 = r'EventNum3'
k9 = r'Event3_Stage_Num'
k10 = r'EventNum4'
k11 = r'Event4_Stage_Num'
k12 = r'EventNum5'
k13 = r'Event5_Stage_Num'
k14 = r'EventNum6'
k15 = r'Event6_Stage_Num'
k16 = r'EventNum7'
k17 = r'Event7_Stage_Num'
k18 = r'事件总和'
event_random_common = TD({
    1: TD({
        k0: 1,
        k2: 1,
        k3: 3000,
        k4: 20,
        k6: 7,
        k7: {1:[0,1],2:[1,2]},
        k8: 5,
        k10: 3,
        k12: 4,
        k14: 3,
        k16: 3,
    }),
    2: TD({
        k0: 2,
        k2: 2,
        k3: 4000,
        k4: 17,
        k6: 8,
        k7: {1:[1,2],2:[2,3]},
        k8: 6,
        k10: 4,
        k12: 4,
        k14: 3,
        k16: 3,
    }),
    3: TD({
        k0: 3,
        k2: 3,
        k3: 2000,
        k4: 14,
        k6: 9,
        k7: {1:[1,2],2:[2,3]},
        k8: 7,
        k10: 5,
        k12: 4,
        k14: 3,
        k16: 3,
    }),
    4: TD({
        k0: 4,
        k2: 4,
        k3: 999,
        k4: 11,
        k6: 10,
        k7: {1:[2,2],2:[3,4]},
        k8: 8,
        k10: 6,
        k12: 4,
        k14: 3,
        k16: 3,
    }),
    5: TD({
        k0: 5,
        k2: 5,
        k3: 1,
        k4: 0,
        k6: 25,
        k7: {1:[2,2],2:[3,4]},
        k8: 0,
        k10: 10,
        k12: 4,
        k14: 3,
        k16: 3,
    }),
})

def __onreload__(new_dict):
    global event_random_common
    event_random_common=new_dict.get('event_random_common')
