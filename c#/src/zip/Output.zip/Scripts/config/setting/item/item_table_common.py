# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'TableName'
k2 = r'物品类型名'
k3 = r'BagSpaceType'
item_table_common = TD({
    1: TD({
        k0: 1,
        k1: r'com_item_common',
        k2: 4300016,
        k3: 1,
    }),
})

def __onreload__(new_dict):
    global item_table_common
    item_table_common=new_dict.get('item_table_common')
