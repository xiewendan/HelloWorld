# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ItemBagSpace'
k1 = r'Memo'
k2 = r'SpaceCount'
item_bag_common = TD({
    1: TD({
        k0: 1,
        k1: r'主背包空间',
        k2: 999,
    }),
})

def __onreload__(new_dict):
    global item_bag_common
    item_bag_common=new_dict.get('item_bag_common')
