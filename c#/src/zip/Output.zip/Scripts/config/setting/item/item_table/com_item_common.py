# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'Name'
k2 = r'Memo'
k3 = r'描述'
k4 = r'FoldLimit'
k5 = r'GridCount'
k6 = r'Extend1'
k7 = r'Extend2'
k8 = r'Icon'
k9 = r'Icon_head'
k10 = r'CBBigID'
k11 = r'CBIndex'
k12 = r'CBArg'
com_item_common = TD({
    10100001: TD({
        k0: 10100001,
        k1: 4300023,
        k2: r'测试物品',
        k3: 4300028,
        k4: 10,
        k5: 1,
        k8: r'ui/export/tex/tubiao/daoju2.png',
        k10: 7,
        k11: 0,
    }),
    10100002: TD({
        k0: 10100002,
        k1: 4300024,
        k2: r'测试物品',
        k3: 4300029,
        k4: 1,
        k5: 50,
        k8: r'ui/export/tex/tubiao/daoju2.png',
        k10: 7,
        k11: 0,
    }),
    10100003: TD({
        k0: 10100003,
        k1: 4300025,
        k2: r'测试物品',
        k3: 4300030,
        k4: 1,
        k5: 1,
        k8: r'ui/export/tex/tubiao/daoju2.png',
        k10: 7,
        k11: 0,
    }),
    10100004: TD({
        k0: 10100004,
        k1: 4300026,
        k2: r'测试物品',
        k3: 4300031,
        k4: 10,
        k5: 50,
        k8: r'ui/export/tex/tubiao/daoju2.png',
        k10: 7,
        k11: 0,
    }),
    10100005: TD({
        k0: 10100005,
        k1: 4300027,
        k2: r'测试物品',
        k3: 4300032,
        k4: 10,
        k5: 50,
        k8: r'ui/export/tex/tubiao/daoju2.png',
        k10: 7,
        k11: 0,
    }),
})

def __onreload__(new_dict):
    global com_item_common
    com_item_common=new_dict.get('com_item_common')
