# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'内容'
k2 = r'备注'
team_refuse = TD({
    1: TD({
        k0: 1,
        k1: 6041300,
        k2: r'现在不方便，加好友，下次约',
    }),
    2: TD({
        k0: 2,
        k1: 6041301,
        k2: r'你太强，拉高我们匹配难度了',
    }),
    3: TD({
        k0: 3,
        k1: 6041302,
        k2: r'抱歉，有约了',
    }),
    4: TD({
        k0: 4,
        k1: 6041303,
        k2: r'抱歉，我有固定车队',
    }),
})

def __onreload__(new_dict):
    global team_refuse
    team_refuse=new_dict.get('team_refuse')
