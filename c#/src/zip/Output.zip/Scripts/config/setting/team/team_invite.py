# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'ID'
k1 = r'内容'
k2 = r'备注'
team_invite = TD({
    1: TD({
        k0: 1,
        k1: 6041200,
        k2: r'听说你从不坑队友，我也是，约吗',
    }),
    2: TD({
        k0: 2,
        k1: 6041201,
        k2: r'大腿带队，来不及解释了快上车',
    }),
    3: TD({
        k0: 3,
        k1: 6041202,
        k2: r'萌妹求带，能语音，会卖萌',
    }),
    4: TD({
        k0: 4,
        k1: 6041203,
        k2: r'大神在此，来躺鸡选手',
    }),
    5: TD({
        k0: 5,
        k1: 6041402,
        k2: r'靠谱队友在此，让人头，送三级',
    }),
})

def __onreload__(new_dict):
    global team_invite
    team_invite=new_dict.get('team_invite')
