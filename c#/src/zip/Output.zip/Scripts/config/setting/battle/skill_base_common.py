# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'技能编号'
k1 = r'技能名称'
k2 = r'技能模板'
k3 = r'技能类型ID'
k4 = r'技能CD类型'
k5 = r'技能CD'
k6 = r'距离类型'
k7 = r'招式威力'
k8 = r'招式属性'
k9 = r'移动打断点'
k10 = r'后摇打断点'
k11 = r'能量消耗'
skill_base_common = TD({
    1: TD({
        k0: 1,
        k1: r'近战普攻',
        k2: r'NormalAttack',
        k3: 1,
        k4: 1,
        k6: 1,
        k8: 0,
    }),
    2: TD({
        k0: 2,
        k1: r'远程普攻',
        k2: r'FarAttack',
        k3: 2,
        k4: 2,
        k6: 2,
        k8: 0,
    }),
})

def __onreload__(new_dict):
    global skill_base_common
    skill_base_common=new_dict.get('skill_base_common')
