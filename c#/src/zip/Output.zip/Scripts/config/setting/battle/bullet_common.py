# -*- coding: utf-8 -*-

try:
    from taggeddict import taggeddict as TD
except ImportError:
    TD = dict

k0 = r'编号'
k1 = r'描述'
k2 = r'攻击类型'
k3 = r'目标选择'
k4 = r'子弹速度'
bullet_common = TD({
    1: TD({
        k0: 1,
        k1: r'普攻单体子弹',
        k2: 0,
        k3: r'单体',
        k4: 10,
        r'目标类型': 0,
    }),
    2: TD({
        k0: 2,
        k1: r'普攻AOE子弹',
        k2: 0,
        k3: r'AOE',
        k4: 10,
        r'目标类型': 0,
    }),
    3: TD({
        k0: 3,
        k1: r'特攻单体子弹',
        k2: 1,
        k3: r'单体',
        k4: 10,
        r'目标类型': 0,
    }),
    4: TD({
        k0: 4,
        k1: r'特攻AOE子弹',
        k2: 1,
        k3: r'AOE',
        k4: 10,
        r'目标类型': 0,
    }),
})

def __onreload__(new_dict):
    global bullet_common
    bullet_common=new_dict.get('bullet_common')
