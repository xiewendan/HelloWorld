# -*- coding: utf-8 -*-



class ToPythonTestModule(Object):

	def __init__(self):
		super(Object, self).__init__()

		pass

	@staticmethod
	def PrintMsg(szMsg):
		pass

	@staticmethod
	def CSharpCB(testObj):
		pass

	@staticmethod
	def CSharpCallPythonFun():
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class ToPythonTestObj(Object):

	def __init__(self):
		super(Object, self).__init__()

		pass

	def NewToPythonTestObj(self, szName, toPythonTestObj, testCallback):
		pass

	def PrintName(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass
