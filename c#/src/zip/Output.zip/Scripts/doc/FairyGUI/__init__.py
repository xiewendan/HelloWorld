# -*- coding: utf-8 -*-



class EventContext(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.sender = None
		self.initiator = None
		self.inputEvent = None
		self.isDefaultPrevented = None
		pass

	def StopPropagation(self):
		pass

	def PreventDefault(self):
		pass

	def CaptureTouch(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class DragDropManager(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.inst = None
		self.dragAgent = None
		self.dragging = None
		pass

	@staticmethod
	def get_inst():
		pass

	@staticmethod
	def GetInst():
		pass

	def StartDrag(self, source, icon, sourceData, touchPointID):
		pass

	def Cancel(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class EventDispatcher(Object):

	def __init__(self):
		super(Object, self).__init__()

		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class EventListener(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.owner = None
		self.type = None
		self.isEmpty = None
		self.isDispatching = None
		pass

	def AddCapture(self, callback):
		pass

	def RemoveCapture(self, callback):
		pass

	def Add(self, callback):
		pass

	def Remove(self, callback):
		pass

	def Add(self, callback):
		pass

	def AddCallBackZero(self, callback):
		pass

	def Remove(self, callback):
		pass

	def Set(self, callback):
		pass

	def Set(self, callback):
		pass

	def Clear(self):
		pass

	def Call(self):
		pass

	def Call(self, data):
		pass

	def BubbleCall(self, data):
		pass

	def BubbleCall(self):
		pass

	def BroadcastCall(self, data):
		pass

	def BroadcastCall(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class InputEvent(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.x = None
		self.y = None
		self.keyCode = None
		self.character = None
		self.modifiers = None
		self.mouseWheelDelta = None
		self.touchId = None
		self.button = None
		self.position = None
		self.isDoubleClick = None
		self.ctrl = None
		self.shift = None
		self.alt = None
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class DisplayObject(EventDispatcher):

	def __init__(self):
		super(EventDispatcher, self).__init__()

		self.parent = None
		self.gameObject = None
		self.cachedTransform = None
		self.graphics = None
		self.paintingGraphics = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onMouseWheel = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.alpha = None
		self.grayed = None
		self.visible = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.width = None
		self.height = None
		self.size = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.skew = None
		self.perspective = None
		self.focalLength = None
		self.pivot = None
		self.location = None
		self.material = None
		self.shader = None
		self.renderingOrder = None
		self.layer = None
		self.isDisposed = None
		self.topmost = None
		self.stage = None
		self.worldSpaceContainer = None
		self.touchable = None
		self.paintingMode = None
		self.cacheAsBitmap = None
		self.filter = None
		self.blendMode = None
		self.home = None
		pass

	def SetXY(self, xv, yv):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def SetSize(self, wv, hv):
		pass

	def EnsureSizeCorrect(self):
		pass

	def SetScale(self, xv, yv):
		pass

	def EnterPaintingMode(self, requestorId, margin):
		pass

	def LeavePaintingMode(self, requestorId):
		pass

	def GetBounds(self, targetSpace):
		pass

	def GlobalToLocal(self, point):
		pass

	def LocalToGlobal(self, point):
		pass

	def WorldToLocal(self, worldPoint, direction):
		pass

	def TransformPoint(self, point, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def RemoveFromParent(self):
		pass

	def InvalidateBatchingState(self):
		pass

	def Update(self, context):
		pass

	def Dispose(self):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Container(DisplayObject):

	def __init__(self):
		super(DisplayObject, self).__init__()

		self.numChildren = None
		self.clipRect = None
		self.mask = None
		self.touchable = None
		self.contentRect = None
		self.fairyBatching = None
		self.parent = None
		self.gameObject = None
		self.cachedTransform = None
		self.graphics = None
		self.paintingGraphics = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onMouseWheel = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.alpha = None
		self.grayed = None
		self.visible = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.width = None
		self.height = None
		self.size = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.skew = None
		self.perspective = None
		self.focalLength = None
		self.pivot = None
		self.location = None
		self.material = None
		self.shader = None
		self.renderingOrder = None
		self.layer = None
		self.isDisposed = None
		self.topmost = None
		self.stage = None
		self.worldSpaceContainer = None
		self.paintingMode = None
		self.cacheAsBitmap = None
		self.filter = None
		self.blendMode = None
		self.home = None
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def Contains(self, child):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetChildIndex(self, child):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def ChangeChildrenOrder(self, indice, objs):
		pass

	def GetBounds(self, targetSpace):
		pass

	def GetRenderCamera(self):
		pass

	def HitTest(self, stagePoint, forTouch):
		pass

	def GetHitTestLocalPoint(self):
		pass

	def IsAncestorOf(self, obj):
		pass

	def InvalidateBatchingState(self, childrenChanged):
		pass

	def SetChildrenLayer(self, value):
		pass

	def Update(self, context):
		pass

	def Dispose(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def SetSize(self, wv, hv):
		pass

	def EnsureSizeCorrect(self):
		pass

	def SetScale(self, xv, yv):
		pass

	def EnterPaintingMode(self, requestorId, margin):
		pass

	def LeavePaintingMode(self, requestorId):
		pass

	def GlobalToLocal(self, point):
		pass

	def LocalToGlobal(self, point):
		pass

	def WorldToLocal(self, worldPoint, direction):
		pass

	def TransformPoint(self, point, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def RemoveFromParent(self):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Stage(Container):

	def __init__(self):
		super(Container, self).__init__()

		self.stageHeight = None
		self.stageWidth = None
		self.soundVolume = None
		self.onStageResized = None
		self.inst = None
		self.touchScreen = None
		self.keyboardInput = None
		self.isTouchOnUI = None
		self.touchTarget = None
		self.focus = None
		self.touchPosition = None
		self.touchCount = None
		self.keyboard = None
		self.numChildren = None
		self.clipRect = None
		self.mask = None
		self.touchable = None
		self.contentRect = None
		self.fairyBatching = None
		self.parent = None
		self.gameObject = None
		self.cachedTransform = None
		self.graphics = None
		self.paintingGraphics = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onMouseWheel = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.alpha = None
		self.grayed = None
		self.visible = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.width = None
		self.height = None
		self.size = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.skew = None
		self.perspective = None
		self.focalLength = None
		self.pivot = None
		self.location = None
		self.material = None
		self.shader = None
		self.renderingOrder = None
		self.layer = None
		self.isDisposed = None
		self.topmost = None
		self.stage = None
		self.worldSpaceContainer = None
		self.paintingMode = None
		self.cacheAsBitmap = None
		self.filter = None
		self.blendMode = None
		self.home = None
		pass

	@staticmethod
	def get_inst():
		pass

	@staticmethod
	def get_touchScreen():
		pass

	@staticmethod
	def set_touchScreen(value):
		pass

	@staticmethod
	def get_keyboardInput():
		pass

	@staticmethod
	def set_keyboardInput(value):
		pass

	@staticmethod
	def get_isTouchOnUI():
		pass

	@staticmethod
	def GetInst():
		pass

	@staticmethod
	def Instantiate():
		pass

	def GetTouchPosition(self, touchId):
		pass

	def GetAllTouch(self, result):
		pass

	def ResetInputState(self):
		pass

	def CancelClick(self, touchId):
		pass

	def EnableSound(self):
		pass

	def DisableSound(self):
		pass

	def PlayOneShotSound(self, clip, volumeScale):
		pass

	def PlayOneShotSound(self, clip):
		pass

	def OpenKeyboard(self, text, autocorrection, multiline, secure, alert, textPlaceholder, keyboardType, hideInput):
		pass

	def CloseKeyboard(self):
		pass

	def InputString(self, value):
		pass

	def SetCustomInput(self, screenPos, buttonDown):
		pass

	def SetCustomInput(self, screenPos, buttonDown, buttonUp):
		pass

	def SetCustomInput(self, hit, buttonDown):
		pass

	def SetCustomInput(self, hit, buttonDown, buttonUp):
		pass

	def ApplyPanelOrder(self, target):
		pass

	def SortWorldSpacePanelsByZOrder(self, panelSortingOrder):
		pass

	def MonitorTexture(self, texture):
		pass

	def AddTouchMonitor(self, touchId, target):
		pass

	def RemoveTouchMonitor(self, target):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def Contains(self, child):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetChildIndex(self, child):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def ChangeChildrenOrder(self, indice, objs):
		pass

	def GetBounds(self, targetSpace):
		pass

	def GetRenderCamera(self):
		pass

	def HitTest(self, stagePoint, forTouch):
		pass

	def GetHitTestLocalPoint(self):
		pass

	def IsAncestorOf(self, obj):
		pass

	def InvalidateBatchingState(self, childrenChanged):
		pass

	def SetChildrenLayer(self, value):
		pass

	def Update(self, context):
		pass

	def Dispose(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def SetSize(self, wv, hv):
		pass

	def EnsureSizeCorrect(self):
		pass

	def SetScale(self, xv, yv):
		pass

	def EnterPaintingMode(self, requestorId, margin):
		pass

	def LeavePaintingMode(self, requestorId):
		pass

	def GlobalToLocal(self, point):
		pass

	def LocalToGlobal(self, point):
		pass

	def WorldToLocal(self, worldPoint, direction):
		pass

	def TransformPoint(self, point, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def RemoveFromParent(self):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Controller(EventDispatcher):

	def __init__(self):
		super(EventDispatcher, self).__init__()

		self.onChanged = None
		self.selectedIndex = None
		self.selectedPage = None
		self.previsousIndex = None
		self.previousPage = None
		self.pageCount = None
		pass

	def Dispose(self):
		pass

	def SetSelectedIndex(self, value):
		pass

	def SetSelectedPage(self, value):
		pass

	def GetPageName(self, index):
		pass

	def GetPageIdByName(self, aName):
		pass

	def AddPage(self, name):
		pass

	def AddPageAt(self, name, index):
		pass

	def RemovePage(self, name):
		pass

	def RemovePageAt(self, index):
		pass

	def ClearPages(self):
		pass

	def HasPage(self, aName):
		pass

	def RunActions(self):
		pass

	def Setup(self, xml):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GObject(EventDispatcher):

	def __init__(self):
		super(EventDispatcher, self).__init__()

		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.draggingObject = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	@staticmethod
	def get_draggingObject():
		pass

	@staticmethod
	def set_draggingObject(value):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def ConstructFromResource(self):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GGraph(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.color = None
		self.shape = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def ReplaceMe(self, target):
		pass

	def AddBeforeMe(self, target):
		pass

	def AddAfterMe(self, target):
		pass

	def SetNativeObject(self, obj):
		pass

	def DrawRect(self, aWidth, aHeight, lineSize, lineColor, fillColor):
		pass

	def DrawRoundRect(self, aWidth, aHeight, fillColor, corner):
		pass

	def DrawEllipse(self, aWidth, aHeight, fillColor):
		pass

	def DrawPolygon(self, aWidth, aHeight, points, fillColor):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def ConstructFromResource(self):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GGroup(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.layout = None
		self.lineGap = None
		self.columnGap = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def SetBoundsChangedFlag(self, childSizeChanged):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def ConstructFromResource(self):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GImage(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.color = None
		self.flip = None
		self.fillMethod = None
		self.fillOrigin = None
		self.fillClockwise = None
		self.fillAmount = None
		self.texture = None
		self.material = None
		self.shader = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def ConstructFromResource(self):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GLoader(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.url = None
		self.icon = None
		self.align = None
		self.verticalAlign = None
		self.fill = None
		self.autoSize = None
		self.playing = None
		self.frame = None
		self.material = None
		self.shader = None
		self.color = None
		self.fillMethod = None
		self.fillOrigin = None
		self.fillClockwise = None
		self.fillAmount = None
		self.image = None
		self.movieClip = None
		self.texture = None
		self.filter = None
		self.blendMode = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def Dispose(self):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def ConstructFromResource(self):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class PlayState(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.reachEnding = None
		self.reversed = None
		self.repeatedCount = None
		self.currrentFrame = None
		pass

	def Update(self, mc, context):
		pass

	def Rewind(self):
		pass

	def Reset(self):
		pass

	def Copy(self, src):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GMovieClip(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.onPlayEnd = None
		self.playing = None
		self.frame = None
		self.color = None
		self.flip = None
		self.material = None
		self.shader = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def SetPlaySettings(self, start, end, times, endAt):
		pass

	def ConstructFromResource(self):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class TextFormat(Object):

	def __init__(self):
		super(Object, self).__init__()

		pass

	def SetColor(self, value):
		pass

	def EqualStyle(self, aFormat):
		pass

	def CopyFrom(self, source):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GTextField(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.text = None
		self.textFormat = None
		self.color = None
		self.align = None
		self.verticalAlign = None
		self.singleLine = None
		self.stroke = None
		self.strokeColor = None
		self.shadowOffset = None
		self.UBBEnabled = None
		self.autoSize = None
		self.textWidth = None
		self.textHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def ConstructFromResource(self):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GRichTextField(GTextField):

	def __init__(self):
		super(GTextField, self).__init__()

		self.richTextField = None
		self.emojies = None
		self.text = None
		self.textFormat = None
		self.color = None
		self.align = None
		self.verticalAlign = None
		self.singleLine = None
		self.stroke = None
		self.strokeColor = None
		self.shadowOffset = None
		self.UBBEnabled = None
		self.autoSize = None
		self.textWidth = None
		self.textHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def ConstructFromResource(self):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GTextInput(GTextField):

	def __init__(self):
		super(GTextField, self).__init__()

		self.onFocusIn = None
		self.onFocusOut = None
		self.onChanged = None
		self.onSubmit = None
		self.inputTextField = None
		self.editable = None
		self.hideInput = None
		self.maxLength = None
		self.restrict = None
		self.displayAsPassword = None
		self.caretPosition = None
		self.promptText = None
		self.keyboardInput = None
		self.keyboardType = None
		self.emojies = None
		self.text = None
		self.textFormat = None
		self.color = None
		self.align = None
		self.verticalAlign = None
		self.singleLine = None
		self.stroke = None
		self.strokeColor = None
		self.shadowOffset = None
		self.UBBEnabled = None
		self.autoSize = None
		self.textWidth = None
		self.textHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def SetSelection(self, start, length):
		pass

	def ReplaceSelection(self, value):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Dispose(self):
		pass

	def ConstructFromResource(self):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GComponent(GObject):

	def __init__(self):
		super(GObject, self).__init__()

		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def ConstructFromXML(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GList(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.onClickItem = None
		self.onRightClickItem = None
		self.layout = None
		self.lineCount = None
		self.columnCount = None
		self.lineGap = None
		self.columnGap = None
		self.align = None
		self.verticalAlign = None
		self.autoResizeItem = None
		self.itemPool = None
		self.selectedIndex = None
		self.selectionController = None
		self.touchItem = None
		self.isVirtual = None
		self.numItems = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def Dispose(self):
		pass

	def SetItemRendererFunc(self, func):
		pass

	def GetFromPool(self, url):
		pass

	def AddItemFromPool(self):
		pass

	def AddItemFromPool(self, url):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildToPoolAt(self, index):
		pass

	def RemoveChildToPool(self, child):
		pass

	def RemoveChildrenToPool(self):
		pass

	def RemoveChildrenToPool(self, beginIndex, endIndex):
		pass

	def GetSelection(self):
		pass

	def AddSelection(self, index, scrollItToView):
		pass

	def RemoveSelection(self, index):
		pass

	def ClearSelection(self):
		pass

	def SelectAll(self):
		pass

	def SelectNone(self):
		pass

	def SelectReverse(self):
		pass

	def HandleArrowKey(self, dir):
		pass

	def ResizeToFit(self, itemCount):
		pass

	def ResizeToFit(self, itemCount, minSize):
		pass

	def HandleControllerChanged(self, c):
		pass

	def ScrollToView(self, index):
		pass

	def ScrollToView(self, index, ani):
		pass

	def ScrollToView(self, index, ani, setFirst):
		pass

	def GetFirstChildInView(self):
		pass

	def ChildIndexToItemIndex(self, index):
		pass

	def ItemIndexToChildIndex(self, index):
		pass

	def SetVirtual(self):
		pass

	def SetVirtualAndLoop(self):
		pass

	def RefreshVirtualList(self):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def ConstructFromXML(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GRoot(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.contentScaleFactor = None
		self.inst = None
		self.modalLayer = None
		self.hasModalWindow = None
		self.modalWaiting = None
		self.touchTarget = None
		self.hasAnyPopup = None
		self.focus = None
		self.soundVolume = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	@staticmethod
	def get_contentScaleFactor():
		pass

	@staticmethod
	def get_inst():
		pass

	@staticmethod
	def GetInst():
		pass

	def GetRayPoint(self, nX, nY):
		pass

	def SetContentScaleFactor(self, designResolutionX, designResolutionY):
		pass

	def SetContentScaleFactor(self, designResolutionX, designResolutionY, screenMatchMode):
		pass

	def ApplyContentScaleFactor(self):
		pass

	def ShowWindow(self, win):
		pass

	def HideWindow(self, win):
		pass

	def HideWindowImmediately(self, win):
		pass

	def HideWindowImmediately(self, win, dispose):
		pass

	def BringToFront(self, win):
		pass

	def ShowModalWait(self):
		pass

	def CloseModalWait(self):
		pass

	def CloseAllExceptModals(self):
		pass

	def CloseAllWindows(self):
		pass

	def GetTopWindow(self):
		pass

	def DisplayObjectToGObject(self, obj):
		pass

	def ShowPopup(self, popup):
		pass

	def ShowPopup(self, popup, target):
		pass

	def ShowPopup(self, popup, target, downward):
		pass

	def GetPoupPosition(self, popup, target, downward):
		pass

	def TogglePopup(self, popup):
		pass

	def TogglePopup(self, popup, target):
		pass

	def TogglePopup(self, popup, target, downward):
		pass

	def HidePopup(self):
		pass

	def HidePopup(self, popup):
		pass

	def ShowTooltips(self, msg):
		pass

	def ShowTooltipsWin(self, tooltipWin):
		pass

	def HideTooltips(self):
		pass

	def EnableSound(self):
		pass

	def DisableSound(self):
		pass

	def PlayOneShotSound(self, clip, volumeScale):
		pass

	def PlayOneShotSound(self, clip):
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def ConstructFromXML(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GLabel(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.icon = None
		self.title = None
		self.text = None
		self.editable = None
		self.titleColor = None
		self.titleFontSize = None
		self.color = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def ConstructFromXML(self, cxml):
		pass

	def Setup_AfterAdd(self, cxml):
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GButton(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.pageOption = None
		self.onChanged = None
		self.icon = None
		self.title = None
		self.text = None
		self.selectedIcon = None
		self.selectedTitle = None
		self.titleColor = None
		self.titleFontSize = None
		self.selected = None
		self.mode = None
		self.relatedController = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def FireClick(self, downEffect):
		pass

	def HandleControllerChanged(self, c):
		pass

	def ConstructFromXML(self, cxml):
		pass

	def Setup_AfterAdd(self, cxml):
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GComboBox(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.onChanged = None
		self.icon = None
		self.title = None
		self.text = None
		self.titleColor = None
		self.items = None
		self.icons = None
		self.values = None
		self.selectedIndex = None
		self.selectionController = None
		self.value = None
		self.popupDirection = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def AddItem(self, value, bDone):
		pass

	def ClearItem(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def Dispose(self):
		pass

	def ConstructFromXML(self, cxml):
		pass

	def Setup_AfterAdd(self, cxml):
		pass

	def UpdateDropdownList(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GProgressBar(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.titleType = None
		self.max = None
		self.value = None
		self.reverse = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def TweenValue(self, value, duration):
		pass

	def Update(self, newValue):
		pass

	def ConstructFromXML(self, cxml):
		pass

	def Setup_AfterAdd(self, cxml):
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GSlider(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.onChanged = None
		self.onGripTouchEnd = None
		self.titleType = None
		self.max = None
		self.value = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def ConstructFromXML(self, cxml):
		pass

	def Setup_AfterAdd(self, cxml):
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class PopupMenu(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.itemCount = None
		self.contentPane = None
		self.list = None
		pass

	def AddItem(self, caption, callback):
		pass

	def AddItem(self, caption, callback):
		pass

	def AddItemAt(self, caption, index, callback):
		pass

	def AddItemAt(self, caption, index, callback):
		pass

	def AddSeperator(self):
		pass

	def GetItemName(self, index):
		pass

	def SetItemText(self, name, caption):
		pass

	def SetItemVisible(self, name, visible):
		pass

	def SetItemGrayed(self, name, grayed):
		pass

	def SetItemCheckable(self, name, checkable):
		pass

	def SetItemChecked(self, name, check):
		pass

	def isItemChecked(self, name):
		pass

	def RemoveItem(self, name):
		pass

	def ClearItems(self):
		pass

	def Dispose(self):
		pass

	def Show(self):
		pass

	def Show(self, target, downward):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class ScrollPane(EventDispatcher):

	def __init__(self):
		super(EventDispatcher, self).__init__()

		self.onScroll = None
		self.onScrollEnd = None
		self.onPullDownRelease = None
		self.onPullUpRelease = None
		self.draggingPane = None
		self.owner = None
		self.hzScrollBar = None
		self.vtScrollBar = None
		self.header = None
		self.footer = None
		self.bouncebackEffect = None
		self.touchEffect = None
		self.inertiaDisabled = None
		self.softnessOnTopOrLeftSide = None
		self.scrollStep = None
		self.snapToItem = None
		self.pageMode = None
		self.pageController = None
		self.mouseWheelEnabled = None
		self.decelerationRate = None
		self.percX = None
		self.percY = None
		self.posX = None
		self.posY = None
		self.isBottomMost = None
		self.isRightMost = None
		self.currentPageX = None
		self.currentPageY = None
		self.scrollingPosX = None
		self.scrollingPosY = None
		self.contentWidth = None
		self.contentHeight = None
		self.viewWidth = None
		self.viewHeight = None
		pass

	@staticmethod
	def get_draggingPane():
		pass

	@staticmethod
	def set_draggingPane(value):
		pass

	def Dispose(self):
		pass

	def SetPercX(self, value, ani):
		pass

	def SetPercY(self, value, ani):
		pass

	def SetPosX(self, value, ani):
		pass

	def SetPosY(self, value, ani):
		pass

	def SetCurrentPageX(self, value, ani):
		pass

	def SetCurrentPageY(self, value, ani):
		pass

	def ScrollTop(self):
		pass

	def ScrollTop(self, ani):
		pass

	def ScrollBottom(self):
		pass

	def ScrollBottom(self, ani):
		pass

	def ScrollUp(self):
		pass

	def ScrollUp(self, ratio, ani):
		pass

	def ScrollDown(self):
		pass

	def ScrollDown(self, ratio, ani):
		pass

	def ScrollLeft(self):
		pass

	def ScrollLeft(self, ratio, ani):
		pass

	def ScrollRight(self):
		pass

	def ScrollRight(self, ratio, ani):
		pass

	def ScrollToView(self, obj):
		pass

	def ScrollToView(self, obj, ani):
		pass

	def ScrollToView(self, obj, ani, setFirst):
		pass

	def ScrollToView(self, rect, ani, setFirst):
		pass

	def IsChildInView(self, obj):
		pass

	def CancelDragging(self):
		pass

	def LockHeader(self, size):
		pass

	def LockFooter(self, size):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Transition(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.name = None
		self.autoPlay = None
		self.playing = None
		self.timeScale = None
		pass

	def Play(self):
		pass

	def Play(self, onComplete):
		pass

	def Play(self, times, delay, onComplete):
		pass

	def PlayZy(self, times, delay, onComplete):
		pass

	def PlayReverse(self):
		pass

	def PlayReverse(self, onComplete):
		pass

	def PlayReverse(self, times, delay, onComplete):
		pass

	def ChangeRepeat(self, value):
		pass

	def Stop(self):
		pass

	def Stop(self, setToComplete, processCallback):
		pass

	def Dispose(self):
		pass

	def SetValue(self, label, aParams):
		pass

	def SetHook(self, label, callback):
		pass

	def ClearHooks(self):
		pass

	def SetTarget(self, label, newTarget):
		pass

	def SetDuration(self, label, value):
		pass

	def Setup(self, xml):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class UIPackage(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.id = None
		self.name = None
		self.assetPath = None
		self.customId = None
		pass

	@staticmethod
	def GetById(id):
		pass

	@staticmethod
	def GetByName(name):
		pass

	@staticmethod
	def AddPackage(bundle):
		pass

	@staticmethod
	def AddPackage(desc, res):
		pass

	@staticmethod
	def AddPackage(desc, res, mainAssetName):
		pass

	@staticmethod
	def AddPackage(bundle, unloadBundleAfterLoaded):
		pass

	@staticmethod
	def AddPackage(desc, res, unloadBundleAfterLoaded):
		pass

	@staticmethod
	def AddPackage(desc, res, mainAssetName, unloadBundleAfterLoaded):
		pass

	@staticmethod
	def AddPackage(descFilePath):
		pass

	@staticmethod
	def AddPackage(assetPath, loadFunc):
		pass

	@staticmethod
	def AddPackage(descData, assetNamePrefix, loadFunc):
		pass

	@staticmethod
	def RemovePackage(packageIdOrName):
		pass

	@staticmethod
	def RemovePackage(packageIdOrName, allowDestroyingAssets):
		pass

	@staticmethod
	def RemoveAllPackages():
		pass

	@staticmethod
	def RemoveAllPackages(allowDestroyAssets):
		pass

	@staticmethod
	def GetPackages():
		pass

	@staticmethod
	def CreateObject(pkgName, resName):
		pass

	@staticmethod
	def CreateObject(pkgName, resName, userClass):
		pass

	@staticmethod
	def CreateObjectFromURL(url):
		pass

	@staticmethod
	def CreateObjectFromURL(url, userClass):
		pass

	@staticmethod
	def CreateObjectAsync(pkgName, resName, callback):
		pass

	@staticmethod
	def CreateObjectFromURL(url, callback):
		pass

	@staticmethod
	def GetItemAsset(pkgName, resName):
		pass

	@staticmethod
	def GetItemAssetByURL(url):
		pass

	@staticmethod
	def GetItemURL(pkgName, resName):
		pass

	@staticmethod
	def GetItemByURL(url):
		pass

	@staticmethod
	def NormalizeURL(url):
		pass

	@staticmethod
	def SetStringsSource(source):
		pass

	def GetPixelHitTestData(self, itemId):
		pass

	def CreateObject(self, resName):
		pass

	def CreateObject(self, resName, userClass):
		pass

	def CreateObjectAsync(self, resName, callback):
		pass

	def GetItemAsset(self, resName):
		pass

	def GetItems(self):
		pass

	def GetItem(self, itemId):
		pass

	def GetItemByName(self, itemName):
		pass

	def GetItemAsset(self, item):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Window(GComponent):

	def __init__(self):
		super(GComponent, self).__init__()

		self.bringToFontOnClick = None
		self.contentPane = None
		self.frame = None
		self.closeButton = None
		self.dragArea = None
		self.contentArea = None
		self.modalWaitingPane = None
		self.isShowing = None
		self.isTop = None
		self.modal = None
		self.modalWaiting = None
		self.rootContainer = None
		self.container = None
		self.scrollPane = None
		self.onDrop = None
		self.fairyBatching = None
		self.opaque = None
		self.margin = None
		self.childrenRenderOrder = None
		self.apexIndex = None
		self.numChildren = None
		self.Controllers = None
		self.clipSoftness = None
		self.mask = None
		self.reversedMask = None
		self.viewWidth = None
		self.viewHeight = None
		self.id = None
		self.relations = None
		self.parent = None
		self.displayObject = None
		self.onClick = None
		self.onRightClick = None
		self.onTouchBegin = None
		self.onTouchMove = None
		self.onTouchEnd = None
		self.onRollOver = None
		self.onRollOut = None
		self.onAddedToStage = None
		self.onRemovedFromStage = None
		self.onKeyDown = None
		self.onClickLink = None
		self.onPositionChanged = None
		self.onSizeChanged = None
		self.onDragStart = None
		self.onDragMove = None
		self.onDragEnd = None
		self.OnGearStop = None
		self.x = None
		self.y = None
		self.z = None
		self.xy = None
		self.position = None
		self.pixelSnapping = None
		self.width = None
		self.height = None
		self.size = None
		self.actualWidth = None
		self.actualHeight = None
		self.xMin = None
		self.yMin = None
		self.scaleX = None
		self.scaleY = None
		self.scale = None
		self.skew = None
		self.pivotX = None
		self.pivotY = None
		self.pivot = None
		self.pivotAsAnchor = None
		self.touchable = None
		self.grayed = None
		self.enabled = None
		self.rotation = None
		self.rotationX = None
		self.rotationY = None
		self.alpha = None
		self.visible = None
		self.sortingOrder = None
		self.focusable = None
		self.focused = None
		self.tooltips = None
		self.filter = None
		self.blendMode = None
		self.gameObjectName = None
		self.inContainer = None
		self.onStage = None
		self.resourceURL = None
		self.gearXY = None
		self.gearSize = None
		self.gearLook = None
		self.group = None
		self.root = None
		self.text = None
		self.icon = None
		self.draggable = None
		self.dragging = None
		self.asImage = None
		self.asCom = None
		self.asButton = None
		self.asLabel = None
		self.asProgress = None
		self.asSlider = None
		self.asComboBox = None
		self.asTextField = None
		self.asRichTextField = None
		self.asTextInput = None
		self.asLoader = None
		self.asList = None
		self.asGraph = None
		self.asGroup = None
		self.asMovieClip = None
		pass

	def AddUISource(self, source):
		pass

	def Show(self):
		pass

	def ShowOn(self, r):
		pass

	def Hide(self):
		pass

	def HideImmediately(self):
		pass

	def CenterOn(self, r, restraint):
		pass

	def ToggleStatus(self):
		pass

	def BringToFront(self):
		pass

	def ShowModalWait(self):
		pass

	def ShowModalWait(self, requestingCmd):
		pass

	def CloseModalWait(self):
		pass

	def CloseModalWait(self, requestingCmd):
		pass

	def Init(self):
		pass

	def Dispose(self):
		pass

	def InvalidateBatchingState(self, childChanged):
		pass

	def AddChild(self, child):
		pass

	def AddChildAt(self, child, index):
		pass

	def RemoveChild(self, child):
		pass

	def RemoveChild(self, child, dispose):
		pass

	def RemoveChildAt(self, index):
		pass

	def RemoveChildAt(self, index, dispose):
		pass

	def RemoveChildren(self):
		pass

	def RemoveChildren(self, beginIndex, endIndex, dispose):
		pass

	def GetChildAt(self, index):
		pass

	def GetChild(self, name):
		pass

	def GetVisibleChild(self, name):
		pass

	def GetChildInGroup(self, group, name):
		pass

	def GetChildren(self):
		pass

	def GetChildIndex(self, child):
		pass

	def SetChildIndex(self, child, index):
		pass

	def SetChildIndexBefore(self, child, index):
		pass

	def SwapChildren(self, child1, child2):
		pass

	def SwapChildrenAt(self, index1, index2):
		pass

	def IsAncestorOf(self, obj):
		pass

	def AddController(self, controller):
		pass

	def GetControllerAt(self, index):
		pass

	def GetController(self, name):
		pass

	def RemoveController(self, c):
		pass

	def GetTransitionAt(self, index):
		pass

	def GetTransition(self, name):
		pass

	def IsChildInView(self, child):
		pass

	def GetFirstChildInView(self):
		pass

	def HandleControllerChanged(self, c):
		pass

	def SetBoundsChangedFlag(self):
		pass

	def EnsureBoundsCorrect(self):
		pass

	def ConstructFromResource(self):
		pass

	def ConstructFromXML(self, xml):
		pass

	def Setup_AfterAdd(self, xml):
		pass

	def SetXY(self, xv, yv):
		pass

	def SetXY(self, xv, yv, topLeftValue):
		pass

	def SetPosition(self, xv, yv, zv):
		pass

	def Center(self):
		pass

	def Center(self, restraint):
		pass

	def MakeFullScreen(self):
		pass

	def SetSize(self, wv, hv):
		pass

	def SetSize(self, wv, hv, ignorePivot):
		pass

	def SetScale(self, wv, hv):
		pass

	def SetPivot(self, xv, yv):
		pass

	def SetPivot(self, xv, yv, asAnchor):
		pass

	def RequestFocus(self):
		pass

	def SetHome(self, obj):
		pass

	def GetGear(self, index):
		pass

	def InvalidateBatchingState(self):
		pass

	def AddRelation(self, target, relationType):
		pass

	def AddRelation(self, target, relationType, usePercent):
		pass

	def RemoveRelation(self, target, relationType):
		pass

	def RemoveFromParent(self):
		pass

	def StartDrag(self):
		pass

	def StartDrag(self, touchId):
		pass

	def StopDrag(self):
		pass

	def LocalToGlobal(self, pt):
		pass

	def GlobalToLocal(self, pt):
		pass

	def LocalToGlobal(self, rect):
		pass

	def GlobalToLocal(self, rect):
		pass

	def LocalToRoot(self, pt, r):
		pass

	def RootToLocal(self, pt, r):
		pass

	def WorldToLocal(self, pt):
		pass

	def WorldToLocal(self, pt, camera):
		pass

	def TransformPoint(self, pt, targetSpace):
		pass

	def TransformRect(self, rect, targetSpace):
		pass

	def Setup_BeforeAdd(self, xml):
		pass

	def TweenMove(self, endValue, duration):
		pass

	def TweenMoveX(self, endValue, duration):
		pass

	def TweenMoveY(self, endValue, duration):
		pass

	def TweenScale(self, endValue, duration):
		pass

	def TweenScaleX(self, endValue, duration):
		pass

	def TweenScaleY(self, endValue, duration):
		pass

	def TweenResize(self, endValue, duration):
		pass

	def TweenFade(self, endValue, duration):
		pass

	def TweenRotate(self, endValue, duration):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def AddEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListener(self, strType, callback):
		pass

	def RemoveEventListeners(self):
		pass

	def RemoveEventListeners(self, strType):
		pass

	def DispatchEvent(self, strType):
		pass

	def DispatchEvent(self, strType, data):
		pass

	def DispatchEvent(self, strType, data, initiator):
		pass

	def DispatchEvent(self, context):
		pass

	def BubbleEvent(self, strType, data):
		pass

	def BroadcastEvent(self, strType, data):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class GObjectPool(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.count = None
		pass

	def Clear(self):
		pass

	def GetObject(self, url):
		pass

	def ReturnObject(self, obj):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Relations(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.isEmpty = None
		pass

	def Add(self, target, relationType):
		pass

	def Add(self, target, relationType, usePercent):
		pass

	def Remove(self, target, relationType):
		pass

	def Contains(self, target):
		pass

	def ClearFor(self, target):
		pass

	def ClearAll(self):
		pass

	def CopyFrom(self, source):
		pass

	def Dispose(self):
		pass

	def OnOwnerSizeChanged(self, dWidth, dHeight, applyPivot):
		pass

	def Setup(self, xml):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class RelationType(Enum):

	def __init__(self):
		super(Enum, self).__init__()

		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def ToString(self):
		pass

	def CompareTo(self, target):
		pass

	def ToString(self, format):
		pass

	def HasFlag(self, flag):
		pass

	def GetTypeCode(self):
		pass

	def GetType(self):
		pass


class Timers(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.inst = None
		pass

	@staticmethod
	def get_inst():
		pass

	def Add(self, interval, repeat, callback):
		pass

	def Add(self, interval, repeat, callback, callbackParam):
		pass

	def CallLater(self, callback):
		pass

	def CallLater(self, callback, callbackParam):
		pass

	def AddUpdate(self, callback):
		pass

	def AddUpdate(self, callback, callbackParam):
		pass

	def StartCoroutine(self, routine):
		pass

	def Exists(self, callback):
		pass

	def Remove(self, callback):
		pass

	def Update(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass
