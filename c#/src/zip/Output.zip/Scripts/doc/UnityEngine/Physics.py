# -*- coding: utf-8 -*-


def get_minPenetrationForPenalty():
	pass


def set_minPenetrationForPenalty(value):
	pass


def get_gravity():
	pass


def set_gravity(value):
	pass


def get_defaultContactOffset():
	pass


def set_defaultContactOffset(value):
	pass


def get_sleepThreshold():
	pass


def set_sleepThreshold(value):
	pass


def get_queriesHitTriggers():
	pass


def set_queriesHitTriggers(value):
	pass


def get_queriesHitBackfaces():
	pass


def set_queriesHitBackfaces(value):
	pass


def get_bounceThreshold():
	pass


def set_bounceThreshold(value):
	pass


def get_defaultSolverIterations():
	pass


def set_defaultSolverIterations(value):
	pass


def get_defaultSolverVelocityIterations():
	pass


def set_defaultSolverVelocityIterations(value):
	pass


def get_bounceTreshold():
	pass


def set_bounceTreshold(value):
	pass


def get_sleepVelocity():
	pass


def set_sleepVelocity(value):
	pass


def get_sleepAngularVelocity():
	pass


def set_sleepAngularVelocity(value):
	pass


def get_maxAngularVelocity():
	pass


def set_maxAngularVelocity(value):
	pass


def get_solverIterationCount():
	pass


def set_solverIterationCount(value):
	pass


def get_solverVelocityIterationCount():
	pass


def set_solverVelocityIterationCount(value):
	pass


def get_penetrationPenaltyForce():
	pass


def set_penetrationPenaltyForce(value):
	pass


def IgnoreCollision(collider1, collider2, ignore):
	pass


def IgnoreCollision(collider1, collider2):
	pass


def IgnoreLayerCollision(layer1, layer2, ignore):
	pass


def IgnoreLayerCollision(layer1, layer2):
	pass


def GetIgnoreLayerCollision(layer1, layer2):
	pass


def Raycast(origin, direction, maxDistance, layerMask, queryTriggerInteraction):
	pass


def Raycast(origin, direction, maxDistance, layerMask):
	pass


def Raycast(origin, direction, maxDistance):
	pass


def Raycast(origin, direction):
	pass


def Raycast(origin, direction, hitInfo, maxDistance, layerMask, queryTriggerInteraction):
	pass


def Raycast(origin, direction, hitInfo, maxDistance, layerMask):
	pass


def Raycast(origin, direction, hitInfo, maxDistance):
	pass


def Raycast(origin, direction, hitInfo):
	pass


def Raycast(ray, maxDistance, layerMask, queryTriggerInteraction):
	pass


def Raycast(ray, maxDistance, layerMask):
	pass


def Raycast(ray, maxDistance):
	pass


def Raycast(ray):
	pass


def Raycast(ray, hitInfo, maxDistance, layerMask, queryTriggerInteraction):
	pass


def Raycast(ray, hitInfo, maxDistance, layerMask):
	pass


def Raycast(ray, hitInfo, maxDistance):
	pass


def Raycast(ray, hitInfo):
	pass


def Linecast(start, end, layerMask, queryTriggerInteraction):
	pass


def Linecast(start, end, layerMask):
	pass


def Linecast(start, end):
	pass


def Linecast(start, end, hitInfo, layerMask, queryTriggerInteraction):
	pass


def Linecast(start, end, hitInfo, layerMask):
	pass


def Linecast(start, end, hitInfo):
	pass


def CapsuleCast(point1, point2, radius, direction, maxDistance, layerMask, queryTriggerInteraction):
	pass


def CapsuleCast(point1, point2, radius, direction, maxDistance, layerMask):
	pass


def CapsuleCast(point1, point2, radius, direction, maxDistance):
	pass


def CapsuleCast(point1, point2, radius, direction):
	pass


def CapsuleCast(point1, point2, radius, direction, hitInfo, maxDistance, layerMask, queryTriggerInteraction):
	pass


def CapsuleCast(point1, point2, radius, direction, hitInfo, maxDistance, layerMask):
	pass


def CapsuleCast(point1, point2, radius, direction, hitInfo, maxDistance):
	pass


def CapsuleCast(point1, point2, radius, direction, hitInfo):
	pass


def SphereCast(origin, radius, direction, hitInfo, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCast(origin, radius, direction, hitInfo, maxDistance, layerMask):
	pass


def SphereCast(origin, radius, direction, hitInfo, maxDistance):
	pass


def SphereCast(origin, radius, direction, hitInfo):
	pass


def SphereCast(ray, radius, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCast(ray, radius, maxDistance, layerMask):
	pass


def SphereCast(ray, radius, maxDistance):
	pass


def SphereCast(ray, radius):
	pass


def SphereCast(ray, radius, hitInfo, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCast(ray, radius, hitInfo, maxDistance, layerMask):
	pass


def SphereCast(ray, radius, hitInfo, maxDistance):
	pass


def SphereCast(ray, radius, hitInfo):
	pass


def BoxCast(center, halfExtents, direction, orientation, maxDistance, layerMask, queryTriggerInteraction):
	pass


def BoxCast(center, halfExtents, direction, orientation, maxDistance, layerMask):
	pass


def BoxCast(center, halfExtents, direction, orientation, maxDistance):
	pass


def BoxCast(center, halfExtents, direction, orientation):
	pass


def BoxCast(center, halfExtents, direction):
	pass


def BoxCast(center, halfExtents, direction, hitInfo, orientation, maxDistance, layerMask, queryTriggerInteraction):
	pass


def BoxCast(center, halfExtents, direction, hitInfo, orientation, maxDistance, layerMask):
	pass


def BoxCast(center, halfExtents, direction, hitInfo, orientation, maxDistance):
	pass


def BoxCast(center, halfExtents, direction, hitInfo, orientation):
	pass


def BoxCast(center, halfExtents, direction, hitInfo):
	pass


def RaycastAll(origin, direction, maxDistance, layerMask, queryTriggerInteraction):
	pass


def RaycastAll(origin, direction, maxDistance, layerMask):
	pass


def RaycastAll(origin, direction, maxDistance):
	pass


def RaycastAll(origin, direction):
	pass


def RaycastAll(ray, maxDistance, layerMask, queryTriggerInteraction):
	pass


def RaycastAll(ray, maxDistance, layerMask):
	pass


def RaycastAll(ray, maxDistance):
	pass


def RaycastAll(ray):
	pass


def CapsuleCastAll(point1, point2, radius, direction, maxDistance, layerMask, queryTriggerInteraction):
	pass


def CapsuleCastAll(point1, point2, radius, direction, maxDistance, layerMask):
	pass


def CapsuleCastAll(point1, point2, radius, direction, maxDistance):
	pass


def CapsuleCastAll(point1, point2, radius, direction):
	pass


def SphereCastAll(origin, radius, direction, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCastAll(origin, radius, direction, maxDistance, layerMask):
	pass


def SphereCastAll(origin, radius, direction, maxDistance):
	pass


def SphereCastAll(origin, radius, direction):
	pass


def SphereCastAll(ray, radius, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCastAll(ray, radius, maxDistance, layerMask):
	pass


def SphereCastAll(ray, radius, maxDistance):
	pass


def SphereCastAll(ray, radius):
	pass


def OverlapCapsule(point0, point1, radius, layerMask, queryTriggerInteraction):
	pass


def OverlapCapsule(point0, point1, radius, layerMask):
	pass


def OverlapCapsule(point0, point1, radius):
	pass


def OverlapSphere(position, radius, layerMask, queryTriggerInteraction):
	pass


def OverlapSphere(position, radius, layerMask):
	pass


def OverlapSphere(position, radius):
	pass


def Simulate(step):
	pass


def get_autoSimulation():
	pass


def set_autoSimulation(value):
	pass


def SyncTransforms():
	pass


def get_autoSyncTransforms():
	pass


def set_autoSyncTransforms(value):
	pass


def ComputePenetration(colliderA, positionA, rotationA, colliderB, positionB, rotationB, direction, distance):
	pass


def ClosestPoint(point, collider, position, rotation):
	pass


def get_interCollisionDistance():
	pass


def set_interCollisionDistance(value):
	pass


def get_interCollisionStiffness():
	pass


def set_interCollisionStiffness(value):
	pass


def get_interCollisionSettingsToggle():
	pass


def set_interCollisionSettingsToggle(value):
	pass


def RaycastNonAlloc(ray, results, maxDistance, layerMask, queryTriggerInteraction):
	pass


def RaycastNonAlloc(ray, results, maxDistance, layerMask):
	pass


def RaycastNonAlloc(ray, results, maxDistance):
	pass


def RaycastNonAlloc(ray, results):
	pass


def RaycastNonAlloc(origin, direction, results, maxDistance, layerMask, queryTriggerInteraction):
	pass


def RaycastNonAlloc(origin, direction, results, maxDistance, layerMask):
	pass


def RaycastNonAlloc(origin, direction, results, maxDistance):
	pass


def RaycastNonAlloc(origin, direction, results):
	pass


def OverlapSphereNonAlloc(position, radius, results, layerMask, queryTriggerInteraction):
	pass


def OverlapSphereNonAlloc(position, radius, results, layerMask):
	pass


def OverlapSphereNonAlloc(position, radius, results):
	pass


def CheckSphere(position, radius, layerMask, queryTriggerInteraction):
	pass


def CheckSphere(position, radius, layerMask):
	pass


def CheckSphere(position, radius):
	pass


def CapsuleCastNonAlloc(point1, point2, radius, direction, results, maxDistance, layerMask, queryTriggerInteraction):
	pass


def CapsuleCastNonAlloc(point1, point2, radius, direction, results, maxDistance, layerMask):
	pass


def CapsuleCastNonAlloc(point1, point2, radius, direction, results, maxDistance):
	pass


def CapsuleCastNonAlloc(point1, point2, radius, direction, results):
	pass


def SphereCastNonAlloc(origin, radius, direction, results, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCastNonAlloc(origin, radius, direction, results, maxDistance, layerMask):
	pass


def SphereCastNonAlloc(origin, radius, direction, results, maxDistance):
	pass


def SphereCastNonAlloc(origin, radius, direction, results):
	pass


def SphereCastNonAlloc(ray, radius, results, maxDistance, layerMask, queryTriggerInteraction):
	pass


def SphereCastNonAlloc(ray, radius, results, maxDistance, layerMask):
	pass


def SphereCastNonAlloc(ray, radius, results, maxDistance):
	pass


def SphereCastNonAlloc(ray, radius, results):
	pass


def CheckCapsule(start, end, radius, layerMask, queryTriggerInteraction):
	pass


def CheckCapsule(start, end, radius, layerMask):
	pass


def CheckCapsule(start, end, radius):
	pass


def CheckBox(center, halfExtents, orientation, layermask, queryTriggerInteraction):
	pass


def CheckBox(center, halfExtents, orientation, layerMask):
	pass


def CheckBox(center, halfExtents, orientation):
	pass


def CheckBox(center, halfExtents):
	pass


def OverlapBox(center, halfExtents, orientation, layerMask, queryTriggerInteraction):
	pass


def OverlapBox(center, halfExtents, orientation, layerMask):
	pass


def OverlapBox(center, halfExtents, orientation):
	pass


def OverlapBox(center, halfExtents):
	pass


def OverlapBoxNonAlloc(center, halfExtents, results, orientation, mask, queryTriggerInteraction):
	pass


def OverlapBoxNonAlloc(center, halfExtents, results, orientation, mask):
	pass


def OverlapBoxNonAlloc(center, halfExtents, results, orientation):
	pass


def OverlapBoxNonAlloc(center, halfExtents, results):
	pass


def BoxCastNonAlloc(center, halfExtents, direction, results, orientation, maxDistance, layerMask, queryTriggerInteraction):
	pass


def BoxCastNonAlloc(center, halfExtents, direction, results, orientation):
	pass


def BoxCastNonAlloc(center, halfExtents, direction, results, orientation, maxDistance):
	pass


def BoxCastNonAlloc(center, halfExtents, direction, results, orientation, maxDistance, layerMask):
	pass


def BoxCastNonAlloc(center, halfExtents, direction, results):
	pass


def BoxCastAll(center, halfExtents, direction, orientation, maxDistance, layerMask, queryTriggerInteraction):
	pass


def BoxCastAll(center, halfExtents, direction, orientation, maxDistance, layerMask):
	pass


def BoxCastAll(center, halfExtents, direction, orientation, maxDistance):
	pass


def BoxCastAll(center, halfExtents, direction, orientation):
	pass


def BoxCastAll(center, halfExtents, direction):
	pass


def OverlapCapsuleNonAlloc(point0, point1, radius, results, layerMask, queryTriggerInteraction):
	pass


def OverlapCapsuleNonAlloc(point0, point1, radius, results, layerMask):
	pass


def OverlapCapsuleNonAlloc(point0, point1, radius, results):
	pass


def RebuildBroadphaseRegions(worldBounds, subdivisions):
	pass
