# -*- coding: utf-8 -*-


def FindObjectsOfTypeAll(type):
	pass


def FindObjectsOfTypeAll():
	pass


def Load(path):
	pass


def Load(path):
	pass


def Load(path, systemTypeInstance):
	pass


def LoadAsync(path):
	pass


def LoadAsync(path):
	pass


def LoadAsync(path, type):
	pass


def LoadAll(path, systemTypeInstance):
	pass


def LoadAll(path):
	pass


def LoadAll(path):
	pass


def GetBuiltinResource(type, path):
	pass


def GetBuiltinResource(path):
	pass


def UnloadAsset(assetToUnload):
	pass


def UnloadUnusedAssets():
	pass
