# -*- coding: utf-8 -*-


def IncreaseLevel(applyExpensiveChanges):
	pass


def DecreaseLevel(applyExpensiveChanges):
	pass


def SetQualityLevel(index):
	pass


def IncreaseLevel():
	pass


def DecreaseLevel():
	pass


def get_currentLevel():
	pass


def set_currentLevel(value):
	pass


def get_pixelLightCount():
	pass


def set_pixelLightCount(value):
	pass


def get_shadows():
	pass


def set_shadows(value):
	pass


def get_shadowProjection():
	pass


def set_shadowProjection(value):
	pass


def get_shadowCascades():
	pass


def set_shadowCascades(value):
	pass


def get_shadowDistance():
	pass


def set_shadowDistance(value):
	pass


def get_shadowResolution():
	pass


def set_shadowResolution(value):
	pass


def get_shadowmaskMode():
	pass


def set_shadowmaskMode(value):
	pass


def get_shadowNearPlaneOffset():
	pass


def set_shadowNearPlaneOffset(value):
	pass


def get_shadowCascade2Split():
	pass


def set_shadowCascade2Split(value):
	pass


def get_shadowCascade4Split():
	pass


def set_shadowCascade4Split(value):
	pass


def get_lodBias():
	pass


def set_lodBias(value):
	pass


def get_anisotropicFiltering():
	pass


def set_anisotropicFiltering(value):
	pass


def get_masterTextureLimit():
	pass


def set_masterTextureLimit(value):
	pass


def get_maximumLODLevel():
	pass


def set_maximumLODLevel(value):
	pass


def get_particleRaycastBudget():
	pass


def set_particleRaycastBudget(value):
	pass


def get_softParticles():
	pass


def set_softParticles(value):
	pass


def get_softVegetation():
	pass


def set_softVegetation(value):
	pass


def get_vSyncCount():
	pass


def set_vSyncCount(value):
	pass


def get_antiAliasing():
	pass


def set_antiAliasing(value):
	pass


def get_asyncUploadTimeSlice():
	pass


def set_asyncUploadTimeSlice(value):
	pass


def get_asyncUploadBufferSize():
	pass


def set_asyncUploadBufferSize(value):
	pass


def get_realtimeReflectionProbes():
	pass


def set_realtimeReflectionProbes(value):
	pass


def get_billboardsFaceCameraPosition():
	pass


def set_billboardsFaceCameraPosition(value):
	pass


def get_resolutionScalingFixedDPIFactor():
	pass


def set_resolutionScalingFixedDPIFactor(value):
	pass


def get_blendWeights():
	pass


def set_blendWeights(value):
	pass


def get_streamingMipmapsActive():
	pass


def set_streamingMipmapsActive(value):
	pass


def get_streamingMipmapsMemoryBudget():
	pass


def set_streamingMipmapsMemoryBudget(value):
	pass


def get_streamingMipmapsRenderersPerFrame():
	pass


def set_streamingMipmapsRenderersPerFrame(value):
	pass


def get_streamingMipmapsMaxLevelReduction():
	pass


def set_streamingMipmapsMaxLevelReduction(value):
	pass


def get_streamingMipmapsAddAllCameras():
	pass


def set_streamingMipmapsAddAllCameras(value):
	pass


def get_streamingMipmapsMaxFileIORequests():
	pass


def set_streamingMipmapsMaxFileIORequests(value):
	pass


def get_maxQueuedFrames():
	pass


def set_maxQueuedFrames(value):
	pass


def GetQualityLevel():
	pass


def SetQualityLevel(index, applyExpensiveChanges):
	pass


def get_names():
	pass


def get_desiredColorSpace():
	pass


def get_activeColorSpace():
	pass
