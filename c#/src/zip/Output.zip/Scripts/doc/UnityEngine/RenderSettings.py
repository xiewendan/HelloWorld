# -*- coding: utf-8 -*-


def get_ambientSkyboxAmount():
	pass


def set_ambientSkyboxAmount(value):
	pass


def get_fog():
	pass


def set_fog(value):
	pass


def get_fogStartDistance():
	pass


def set_fogStartDistance(value):
	pass


def get_fogEndDistance():
	pass


def set_fogEndDistance(value):
	pass


def get_fogMode():
	pass


def set_fogMode(value):
	pass


def get_fogColor():
	pass


def set_fogColor(value):
	pass


def get_fogDensity():
	pass


def set_fogDensity(value):
	pass


def get_ambientMode():
	pass


def set_ambientMode(value):
	pass


def get_ambientSkyColor():
	pass


def set_ambientSkyColor(value):
	pass


def get_ambientEquatorColor():
	pass


def set_ambientEquatorColor(value):
	pass


def get_ambientGroundColor():
	pass


def set_ambientGroundColor(value):
	pass


def get_ambientIntensity():
	pass


def set_ambientIntensity(value):
	pass


def get_ambientLight():
	pass


def set_ambientLight(value):
	pass


def get_subtractiveShadowColor():
	pass


def set_subtractiveShadowColor(value):
	pass


def get_skybox():
	pass


def set_skybox(value):
	pass


def get_sun():
	pass


def set_sun(value):
	pass


def get_ambientProbe():
	pass


def set_ambientProbe(value):
	pass


def get_customReflection():
	pass


def set_customReflection(value):
	pass


def get_reflectionIntensity():
	pass


def set_reflectionIntensity(value):
	pass


def get_reflectionBounces():
	pass


def set_reflectionBounces(value):
	pass


def get_defaultReflectionMode():
	pass


def set_defaultReflectionMode(value):
	pass


def get_defaultReflectionResolution():
	pass


def set_defaultReflectionResolution(value):
	pass


def get_haloStrength():
	pass


def set_haloStrength(value):
	pass


def get_flareStrength():
	pass


def set_flareStrength(value):
	pass


def get_flareFadeSpeed():
	pass


def set_flareFadeSpeed(value):
	pass
