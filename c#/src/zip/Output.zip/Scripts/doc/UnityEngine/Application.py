# -*- coding: utf-8 -*-


def Quit():
	pass


def Unload():
	pass


def get_isLoadingLevel():
	pass


def get_streamedBytes():
	pass


def get_webSecurityEnabled():
	pass


def CanStreamedLevelBeLoaded(levelIndex):
	pass


def CanStreamedLevelBeLoaded(levelName):
	pass


def get_isPlaying():
	pass


def get_isFocused():
	pass


def get_platform():
	pass


def GetBuildTags():
	pass


def SetBuildTags(buildTags):
	pass


def get_buildGUID():
	pass


def get_isMobilePlatform():
	pass


def get_isConsolePlatform():
	pass


def get_runInBackground():
	pass


def set_runInBackground(value):
	pass


def HasProLicense():
	pass


def get_isBatchMode():
	pass


def get_dataPath():
	pass


def get_streamingAssetsPath():
	pass


def get_persistentDataPath():
	pass


def get_temporaryCachePath():
	pass


def get_absoluteURL():
	pass


def get_unityVersion():
	pass


def get_version():
	pass


def get_installerName():
	pass


def get_identifier():
	pass


def get_installMode():
	pass


def get_sandboxType():
	pass


def get_productName():
	pass


def get_companyName():
	pass


def get_cloudProjectId():
	pass


def RequestAdvertisingIdentifierAsync(delegateMethod):
	pass


def OpenURL(url):
	pass


def get_targetFrameRate():
	pass


def set_targetFrameRate(value):
	pass


def get_systemLanguage():
	pass


def get_stackTraceLogType():
	pass


def set_stackTraceLogType(value):
	pass


def GetStackTraceLogType(logType):
	pass


def SetStackTraceLogType(logType, stackTraceType):
	pass


def get_backgroundLoadingPriority():
	pass


def set_backgroundLoadingPriority(value):
	pass


def get_internetReachability():
	pass


def get_genuine():
	pass


def get_genuineCheckAvailable():
	pass


def RequestUserAuthorization(mode):
	pass


def HasUserAuthorization(mode):
	pass


def get_isShowingSplashScreen():
	pass


def get_isPlayer():
	pass


def get_isEditor():
	pass


def get_levelCount():
	pass


def get_loadedLevel():
	pass


def get_loadedLevelName():
	pass


def lowMemory():
	pass


def logMessageReceived():
	pass


def logMessageReceivedThreaded():
	pass


def onBeforeRender():
	pass


def wantsToQuit():
	pass


def quitting():
	pass
