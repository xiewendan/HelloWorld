# -*- coding: utf-8 -*-


def GetAxis(axisName):
	pass


def GetAxisRaw(axisName):
	pass


def GetButton(buttonName):
	pass


def get_compensateSensors():
	pass


def set_compensateSensors(value):
	pass


def get_isGyroAvailable():
	pass


def get_gyro():
	pass


def GetButtonDown(buttonName):
	pass


def GetButtonUp(buttonName):
	pass


def GetKey(name):
	pass


def GetKey(key):
	pass


def GetKeyDown(name):
	pass


def GetKeyDown(key):
	pass


def GetKeyUp(name):
	pass


def GetKeyUp(key):
	pass


def GetJoystickNames():
	pass


def GetMouseButton(button):
	pass


def GetMouseButtonDown(button):
	pass


def GetMouseButtonUp(button):
	pass


def ResetInputAxes():
	pass


def get_mousePosition():
	pass


def get_mouseScrollDelta():
	pass


def get_mousePresent():
	pass


def get_simulateMouseWithTouches():
	pass


def set_simulateMouseWithTouches(value):
	pass


def get_anyKey():
	pass


def get_anyKeyDown():
	pass


def get_inputString():
	pass


def get_acceleration():
	pass


def get_accelerationEvents():
	pass


def GetAccelerationEvent(index):
	pass


def get_accelerationEventCount():
	pass


def get_touches():
	pass


def GetTouch(index):
	pass


def get_touchCount():
	pass


def get_eatKeyPressOnTextFieldFocus():
	pass


def set_eatKeyPressOnTextFieldFocus(value):
	pass


def get_touchPressureSupported():
	pass


def get_stylusTouchSupported():
	pass


def get_touchSupported():
	pass


def get_multiTouchEnabled():
	pass


def set_multiTouchEnabled(value):
	pass


def get_location():
	pass


def get_compass():
	pass


def get_deviceOrientation():
	pass


def get_imeCompositionMode():
	pass


def set_imeCompositionMode(value):
	pass


def get_compositionString():
	pass


def get_imeIsSelected():
	pass


def get_compositionCursorPos():
	pass


def set_compositionCursorPos(value):
	pass


def get_backButtonLeavesApp():
	pass


def set_backButtonLeavesApp(value):
	pass
