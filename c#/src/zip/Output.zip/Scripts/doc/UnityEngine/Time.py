# -*- coding: utf-8 -*-


def get_time():
	pass


def get_timeSinceLevelLoad():
	pass


def get_deltaTime():
	pass


def get_fixedTime():
	pass


def get_unscaledTime():
	pass


def get_fixedUnscaledTime():
	pass


def get_unscaledDeltaTime():
	pass


def get_fixedUnscaledDeltaTime():
	pass


def get_fixedDeltaTime():
	pass


def set_fixedDeltaTime(value):
	pass


def get_maximumDeltaTime():
	pass


def set_maximumDeltaTime(value):
	pass


def get_smoothDeltaTime():
	pass


def get_maximumParticleDeltaTime():
	pass


def set_maximumParticleDeltaTime(value):
	pass


def get_timeScale():
	pass


def set_timeScale(value):
	pass


def get_frameCount():
	pass


def get_renderedFrameCount():
	pass


def get_realtimeSinceStartup():
	pass


def get_captureFramerate():
	pass


def set_captureFramerate(value):
	pass


def get_inFixedTimeStep():
	pass
