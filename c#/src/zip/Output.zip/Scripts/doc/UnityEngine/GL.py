# -*- coding: utf-8 -*-


def Vertex3(x, y, z):
	pass


def Vertex(v):
	pass


def TexCoord3(x, y, z):
	pass


def TexCoord(v):
	pass


def TexCoord2(x, y):
	pass


def MultiTexCoord3(unit, x, y, z):
	pass


def MultiTexCoord(unit, v):
	pass


def MultiTexCoord2(unit, x, y):
	pass


def Color(c):
	pass


def get_wireframe():
	pass


def set_wireframe(value):
	pass


def get_sRGBWrite():
	pass


def set_sRGBWrite(value):
	pass


def get_invertCulling():
	pass


def set_invertCulling(value):
	pass


def Flush():
	pass


def RenderTargetBarrier():
	pass


def get_modelview():
	pass


def set_modelview(value):
	pass


def MultMatrix(m):
	pass


def PushMatrix():
	pass


def PopMatrix():
	pass


def LoadIdentity():
	pass


def LoadOrtho():
	pass


def LoadPixelMatrix():
	pass


def LoadProjectionMatrix(mat):
	pass


def InvalidateState():
	pass


def GetGPUProjectionMatrix(proj, renderIntoTexture):
	pass


def LoadPixelMatrix(left, right, bottom, top):
	pass


def IssuePluginEvent(callback, eventID):
	pass


def Begin(mode):
	pass


def End():
	pass


def Clear(clearDepth, clearColor, backgroundColor, depth):
	pass


def Clear(clearDepth, clearColor, backgroundColor):
	pass


def Viewport(pixelRect):
	pass


def ClearWithSkybox(clearDepth, camera):
	pass
