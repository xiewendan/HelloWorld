# -*- coding: utf-8 -*-


__all__ = ["Application", "Time", "Screen", "SleepTimeout", "Input", "Resources", "Physics", "RenderSettings", "QualitySettings", "GL", "Debug", ]


class Object(object):

	def __init__(self):
		super(object, self).__init__()

		self.name = None
		self.hideFlags = None
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	@staticmethod
	def Instantiate(original, position, rotation):
		pass

	@staticmethod
	def Instantiate(original, position, rotation, parent):
		pass

	@staticmethod
	def Instantiate(original):
		pass

	@staticmethod
	def Instantiate(original, parent):
		pass

	@staticmethod
	def Instantiate(original, parent, instantiateInWorldSpace):
		pass

	@staticmethod
	def Instantiate(original):
		pass

	@staticmethod
	def Instantiate(original, position, rotation):
		pass

	@staticmethod
	def Instantiate(original, position, rotation, parent):
		pass

	@staticmethod
	def Instantiate(original, parent):
		pass

	@staticmethod
	def Instantiate(original, parent, worldPositionStays):
		pass

	@staticmethod
	def Destroy(obj, t):
		pass

	@staticmethod
	def Destroy(obj):
		pass

	@staticmethod
	def DestroyImmediate(obj, allowDestroyingAssets):
		pass

	@staticmethod
	def DestroyImmediate(obj):
		pass

	@staticmethod
	def FindObjectsOfType(type):
		pass

	@staticmethod
	def DontDestroyOnLoad(target):
		pass

	@staticmethod
	def FindObjectsOfType():
		pass

	@staticmethod
	def FindObjectOfType():
		pass

	@staticmethod
	def FindObjectOfType(type):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Component(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Transform(Component):

	def __init__(self):
		super(Component, self).__init__()

		self.position = None
		self.localPosition = None
		self.eulerAngles = None
		self.localEulerAngles = None
		self.right = None
		self.up = None
		self.forward = None
		self.rotation = None
		self.localRotation = None
		self.localScale = None
		self.parent = None
		self.worldToLocalMatrix = None
		self.localToWorldMatrix = None
		self.root = None
		self.childCount = None
		self.lossyScale = None
		self.hasChanged = None
		self.hierarchyCapacity = None
		self.hierarchyCount = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def SetParent(self, p):
		pass

	def SetParent(self, parent, worldPositionStays):
		pass

	def SetPositionAndRotation(self, position, rotation):
		pass

	def Translate(self, translation, relativeTo):
		pass

	def Translate(self, translation):
		pass

	def Translate(self, x, y, z, relativeTo):
		pass

	def Translate(self, x, y, z):
		pass

	def Translate(self, translation, relativeTo):
		pass

	def Translate(self, x, y, z, relativeTo):
		pass

	def Rotate(self, eulers, relativeTo):
		pass

	def Rotate(self, eulers):
		pass

	def Rotate(self, xAngle, yAngle, zAngle, relativeTo):
		pass

	def Rotate(self, xAngle, yAngle, zAngle):
		pass

	def Rotate(self, axis, angle, relativeTo):
		pass

	def Rotate(self, axis, angle):
		pass

	def RotateAround(self, point, axis, angle):
		pass

	def LookAt(self, target, worldUp):
		pass

	def LookAt(self, target):
		pass

	def LookAt(self, worldPosition, worldUp):
		pass

	def LookAt(self, worldPosition):
		pass

	def TransformDirection(self, direction):
		pass

	def TransformDirection(self, x, y, z):
		pass

	def InverseTransformDirection(self, direction):
		pass

	def InverseTransformDirection(self, x, y, z):
		pass

	def TransformVector(self, vector):
		pass

	def TransformVector(self, x, y, z):
		pass

	def InverseTransformVector(self, vector):
		pass

	def InverseTransformVector(self, x, y, z):
		pass

	def TransformPoint(self, position):
		pass

	def TransformPoint(self, x, y, z):
		pass

	def InverseTransformPoint(self, position):
		pass

	def InverseTransformPoint(self, x, y, z):
		pass

	def DetachChildren(self):
		pass

	def SetAsFirstSibling(self):
		pass

	def SetAsLastSibling(self):
		pass

	def SetSiblingIndex(self, index):
		pass

	def GetSiblingIndex(self):
		pass

	def Find(self, n):
		pass

	def IsChildOf(self, parent):
		pass

	def GetEnumerator(self):
		pass

	def GetChild(self, index):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Material(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.shader = None
		self.color = None
		self.mainTexture = None
		self.mainTextureOffset = None
		self.mainTextureScale = None
		self.renderQueue = None
		self.globalIlluminationFlags = None
		self.doubleSidedGI = None
		self.enableInstancing = None
		self.passCount = None
		self.shaderKeywords = None
		self.name = None
		self.hideFlags = None
		pass

	def GetTexturePropertyNames(self):
		pass

	def GetTexturePropertyNameIDs(self):
		pass

	def GetTexturePropertyNames(self, outNames):
		pass

	def GetTexturePropertyNameIDs(self, outNames):
		pass

	def HasProperty(self, nameID):
		pass

	def HasProperty(self, name):
		pass

	def EnableKeyword(self, keyword):
		pass

	def DisableKeyword(self, keyword):
		pass

	def IsKeywordEnabled(self, keyword):
		pass

	def SetShaderPassEnabled(self, passName, enabled):
		pass

	def GetShaderPassEnabled(self, passName):
		pass

	def GetPassName(self, pass_):
		pass

	def FindPass(self, passName):
		pass

	def SetOverrideTag(self, tag, val):
		pass

	def GetTag(self, tag, searchFallbacks, defaultValue):
		pass

	def GetTag(self, tag, searchFallbacks):
		pass

	def Lerp(self, start, end, t):
		pass

	def SetPass(self, pass_):
		pass

	def CopyPropertiesFromMaterial(self, mat):
		pass

	def SetFloat(self, name, value):
		pass

	def SetFloat(self, nameID, value):
		pass

	def SetInt(self, name, value):
		pass

	def SetInt(self, nameID, value):
		pass

	def SetColor(self, name, value):
		pass

	def SetColor(self, nameID, value):
		pass

	def SetVector(self, name, value):
		pass

	def SetVector(self, nameID, value):
		pass

	def SetMatrix(self, name, value):
		pass

	def SetMatrix(self, nameID, value):
		pass

	def SetTexture(self, name, value):
		pass

	def SetTexture(self, nameID, value):
		pass

	def SetBuffer(self, name, value):
		pass

	def SetBuffer(self, nameID, value):
		pass

	def SetFloatArray(self, name, values):
		pass

	def SetFloatArray(self, nameID, values):
		pass

	def SetFloatArray(self, name, values):
		pass

	def SetFloatArray(self, nameID, values):
		pass

	def SetColorArray(self, name, values):
		pass

	def SetColorArray(self, nameID, values):
		pass

	def SetColorArray(self, name, values):
		pass

	def SetColorArray(self, nameID, values):
		pass

	def SetVectorArray(self, name, values):
		pass

	def SetVectorArray(self, nameID, values):
		pass

	def SetVectorArray(self, name, values):
		pass

	def SetVectorArray(self, nameID, values):
		pass

	def SetMatrixArray(self, name, values):
		pass

	def SetMatrixArray(self, nameID, values):
		pass

	def SetMatrixArray(self, name, values):
		pass

	def SetMatrixArray(self, nameID, values):
		pass

	def GetFloat(self, name):
		pass

	def GetFloat(self, nameID):
		pass

	def GetInt(self, name):
		pass

	def GetInt(self, nameID):
		pass

	def GetColor(self, name):
		pass

	def GetColor(self, nameID):
		pass

	def GetVector(self, name):
		pass

	def GetVector(self, nameID):
		pass

	def GetMatrix(self, name):
		pass

	def GetMatrix(self, nameID):
		pass

	def GetTexture(self, name):
		pass

	def GetTexture(self, nameID):
		pass

	def GetFloatArray(self, name):
		pass

	def GetFloatArray(self, nameID):
		pass

	def GetColorArray(self, name):
		pass

	def GetColorArray(self, nameID):
		pass

	def GetVectorArray(self, name):
		pass

	def GetVectorArray(self, nameID):
		pass

	def GetMatrixArray(self, name):
		pass

	def GetMatrixArray(self, nameID):
		pass

	def GetFloatArray(self, name, values):
		pass

	def GetFloatArray(self, nameID, values):
		pass

	def GetColorArray(self, name, values):
		pass

	def GetColorArray(self, nameID, values):
		pass

	def GetVectorArray(self, name, values):
		pass

	def GetVectorArray(self, nameID, values):
		pass

	def GetMatrixArray(self, name, values):
		pass

	def GetMatrixArray(self, nameID, values):
		pass

	def SetTextureOffset(self, name, value):
		pass

	def SetTextureOffset(self, nameID, value):
		pass

	def SetTextureScale(self, name, value):
		pass

	def SetTextureScale(self, nameID, value):
		pass

	def GetTextureOffset(self, name):
		pass

	def GetTextureOffset(self, nameID):
		pass

	def GetTextureScale(self, name):
		pass

	def GetTextureScale(self, nameID):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Light(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.shadows = None
		self.shadowStrength = None
		self.shadowResolution = None
		self.layerShadowCullDistances = None
		self.cookieSize = None
		self.cookie = None
		self.renderMode = None
		self.areaSize = None
		self.lightmapBakeType = None
		self.commandBufferCount = None
		self.type = None
		self.spotAngle = None
		self.color = None
		self.colorTemperature = None
		self.intensity = None
		self.bounceIntensity = None
		self.shadowCustomResolution = None
		self.shadowBias = None
		self.shadowNormalBias = None
		self.shadowNearPlane = None
		self.range = None
		self.flare = None
		self.bakingOutput = None
		self.cullingMask = None
		self.lightShadowCasterMode = None
		self.shadowRadius = None
		self.shadowAngle = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def SetLightDirty(self):
		pass

	def AddCommandBuffer(self, evt, buffer):
		pass

	def AddCommandBuffer(self, evt, buffer, shadowPassMask):
		pass

	def AddCommandBufferAsync(self, evt, buffer, queueType):
		pass

	def AddCommandBufferAsync(self, evt, buffer, shadowPassMask, queueType):
		pass

	def RemoveCommandBuffer(self, evt, buffer):
		pass

	def RemoveCommandBuffers(self, evt):
		pass

	def RemoveAllCommandBuffers(self):
		pass

	def GetCommandBuffers(self, evt):
		pass

	@staticmethod
	def GetLights(type, layer):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Rigidbody(Component):

	def __init__(self):
		super(Component, self).__init__()

		self.velocity = None
		self.angularVelocity = None
		self.drag = None
		self.angularDrag = None
		self.mass = None
		self.useGravity = None
		self.maxDepenetrationVelocity = None
		self.isKinematic = None
		self.freezeRotation = None
		self.constraints = None
		self.collisionDetectionMode = None
		self.centerOfMass = None
		self.worldCenterOfMass = None
		self.inertiaTensorRotation = None
		self.inertiaTensor = None
		self.detectCollisions = None
		self.position = None
		self.rotation = None
		self.interpolation = None
		self.solverIterations = None
		self.sleepThreshold = None
		self.maxAngularVelocity = None
		self.solverVelocityIterations = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def SetDensity(self, density):
		pass

	def MovePosition(self, position):
		pass

	def MoveRotation(self, rot):
		pass

	def Sleep(self):
		pass

	def IsSleeping(self):
		pass

	def WakeUp(self):
		pass

	def ResetCenterOfMass(self):
		pass

	def ResetInertiaTensor(self):
		pass

	def GetRelativePointVelocity(self, relativePoint):
		pass

	def GetPointVelocity(self, worldPoint):
		pass

	def AddForce(self, force, mode):
		pass

	def AddForce(self, force):
		pass

	def AddForce(self, x, y, z, mode):
		pass

	def AddForce(self, x, y, z):
		pass

	def AddRelativeForce(self, force, mode):
		pass

	def AddRelativeForce(self, force):
		pass

	def AddRelativeForce(self, x, y, z, mode):
		pass

	def AddRelativeForce(self, x, y, z):
		pass

	def AddTorque(self, torque, mode):
		pass

	def AddTorque(self, torque):
		pass

	def AddTorque(self, x, y, z, mode):
		pass

	def AddTorque(self, x, y, z):
		pass

	def AddRelativeTorque(self, torque, mode):
		pass

	def AddRelativeTorque(self, torque):
		pass

	def AddRelativeTorque(self, x, y, z, mode):
		pass

	def AddRelativeTorque(self, x, y, z):
		pass

	def AddForceAtPosition(self, force, position, mode):
		pass

	def AddForceAtPosition(self, force, position):
		pass

	def AddExplosionForce(self, explosionForce, explosionPosition, explosionRadius, upwardsModifier, mode):
		pass

	def AddExplosionForce(self, explosionForce, explosionPosition, explosionRadius, upwardsModifier):
		pass

	def AddExplosionForce(self, explosionForce, explosionPosition, explosionRadius):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def SweepTest(self, direction, hitInfo, maxDistance, queryTriggerInteraction):
		pass

	def SweepTest(self, direction, hitInfo, maxDistance):
		pass

	def SweepTest(self, direction, hitInfo):
		pass

	def SweepTestAll(self, direction, maxDistance, queryTriggerInteraction):
		pass

	def SweepTestAll(self, direction, maxDistance):
		pass

	def SweepTestAll(self, direction):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Camera(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.nearClipPlane = None
		self.farClipPlane = None
		self.fieldOfView = None
		self.renderingPath = None
		self.actualRenderingPath = None
		self.allowHDR = None
		self.allowMSAA = None
		self.allowDynamicResolution = None
		self.forceIntoRenderTexture = None
		self.orthographicSize = None
		self.orthographic = None
		self.opaqueSortMode = None
		self.transparencySortMode = None
		self.transparencySortAxis = None
		self.depth = None
		self.aspect = None
		self.velocity = None
		self.cullingMask = None
		self.eventMask = None
		self.layerCullSpherical = None
		self.cameraType = None
		self.layerCullDistances = None
		self.useOcclusionCulling = None
		self.cullingMatrix = None
		self.backgroundColor = None
		self.clearFlags = None
		self.depthTextureMode = None
		self.clearStencilAfterLightingPass = None
		self.usePhysicalProperties = None
		self.sensorSize = None
		self.lensShift = None
		self.focalLength = None
		self.rect = None
		self.pixelRect = None
		self.pixelWidth = None
		self.pixelHeight = None
		self.scaledPixelWidth = None
		self.scaledPixelHeight = None
		self.targetTexture = None
		self.activeTexture = None
		self.targetDisplay = None
		self.cameraToWorldMatrix = None
		self.worldToCameraMatrix = None
		self.projectionMatrix = None
		self.nonJitteredProjectionMatrix = None
		self.useJitteredProjectionMatrixForTransparentRendering = None
		self.previousViewProjectionMatrix = None
		self.main = None
		self.current = None
		self.scene = None
		self.stereoEnabled = None
		self.stereoSeparation = None
		self.stereoConvergence = None
		self.areVRStereoViewMatricesWithinSingleCullTolerance = None
		self.stereoTargetEye = None
		self.stereoActiveEye = None
		self.allCamerasCount = None
		self.allCameras = None
		self.commandBufferCount = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def get_main():
		pass

	@staticmethod
	def get_current():
		pass

	@staticmethod
	def get_allCamerasCount():
		pass

	@staticmethod
	def get_allCameras():
		pass

	def GetCommandBuffers(self, evt):
		pass

	def Reset(self):
		pass

	def ResetTransparencySortSettings(self):
		pass

	def ResetAspect(self):
		pass

	def ResetCullingMatrix(self):
		pass

	def SetReplacementShader(self, shader, replacementTag):
		pass

	def ResetReplacementShader(self):
		pass

	def SetTargetBuffers(self, colorBuffer, depthBuffer):
		pass

	def SetTargetBuffers(self, colorBuffer, depthBuffer):
		pass

	def ResetWorldToCameraMatrix(self):
		pass

	def ResetProjectionMatrix(self):
		pass

	def CalculateObliqueMatrix(self, clipPlane):
		pass

	def WorldToScreenPoint(self, position, eye):
		pass

	def WorldToViewportPoint(self, position, eye):
		pass

	def ViewportToWorldPoint(self, position, eye):
		pass

	def ScreenToWorldPoint(self, position, eye):
		pass

	def WorldToScreenPoint(self, position):
		pass

	def WorldToViewportPoint(self, position):
		pass

	def ViewportToWorldPoint(self, position):
		pass

	def ScreenToWorldPoint(self, position):
		pass

	def ScreenToViewportPoint(self, position):
		pass

	def ViewportToScreenPoint(self, position):
		pass

	def ViewportPointToRay(self, pos, eye):
		pass

	def ViewportPointToRay(self, pos):
		pass

	def ScreenPointToRay(self, pos, eye):
		pass

	def ScreenPointToRay(self, pos):
		pass

	def CalculateFrustumCorners(self, viewport, z, eye, outCorners):
		pass

	@staticmethod
	def FocalLengthToFOV(focalLength, sensorSize):
		pass

	@staticmethod
	def FOVToFocalLength(fov, sensorSize):
		pass

	def GetStereoNonJitteredProjectionMatrix(self, eye):
		pass

	def GetStereoViewMatrix(self, eye):
		pass

	def CopyStereoDeviceProjectionMatrixToNonJittered(self, eye):
		pass

	def GetStereoProjectionMatrix(self, eye):
		pass

	def SetStereoProjectionMatrix(self, eye, matrix):
		pass

	def ResetStereoProjectionMatrices(self):
		pass

	def SetStereoViewMatrix(self, eye, matrix):
		pass

	def ResetStereoViewMatrices(self):
		pass

	@staticmethod
	def GetAllCameras(cameras):
		pass

	def RenderToCubemap(self, cubemap, faceMask):
		pass

	def RenderToCubemap(self, cubemap):
		pass

	def RenderToCubemap(self, cubemap, faceMask):
		pass

	def RenderToCubemap(self, cubemap):
		pass

	def RenderToCubemap(self, cubemap, faceMask, stereoEye):
		pass

	def Render(self):
		pass

	def RenderWithShader(self, shader, replacementTag):
		pass

	def RenderDontRestore(self):
		pass

	@staticmethod
	def SetupCurrent(cur):
		pass

	def CopyFrom(self, other):
		pass

	def RemoveCommandBuffers(self, evt):
		pass

	def RemoveAllCommandBuffers(self):
		pass

	def AddCommandBuffer(self, evt, buffer):
		pass

	def AddCommandBufferAsync(self, evt, buffer, queueType):
		pass

	def RemoveCommandBuffer(self, evt, buffer):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class AudioSource(AudioBehaviour):

	def __init__(self):
		super(AudioBehaviour, self).__init__()

		self.volume = None
		self.pitch = None
		self.time = None
		self.timeSamples = None
		self.clip = None
		self.outputAudioMixerGroup = None
		self.isPlaying = None
		self.isVirtual = None
		self.loop = None
		self.ignoreListenerVolume = None
		self.playOnAwake = None
		self.ignoreListenerPause = None
		self.velocityUpdateMode = None
		self.panStereo = None
		self.spatialBlend = None
		self.spatialize = None
		self.spatializePostEffects = None
		self.reverbZoneMix = None
		self.bypassEffects = None
		self.bypassListenerEffects = None
		self.bypassReverbZones = None
		self.dopplerLevel = None
		self.spread = None
		self.priority = None
		self.mute = None
		self.minDistance = None
		self.maxDistance = None
		self.rolloffMode = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def Play(self, delay):
		pass

	def Play(self):
		pass

	def PlayDelayed(self, delay):
		pass

	def PlayScheduled(self, time):
		pass

	def SetScheduledStartTime(self, time):
		pass

	def SetScheduledEndTime(self, time):
		pass

	def Stop(self):
		pass

	def Pause(self):
		pass

	def UnPause(self):
		pass

	def PlayOneShot(self, clip):
		pass

	def PlayOneShot(self, clip, volumeScale):
		pass

	@staticmethod
	def PlayClipAtPoint(clip, position):
		pass

	@staticmethod
	def PlayClipAtPoint(clip, position, volume):
		pass

	def SetCustomCurve(self, type, curve):
		pass

	def GetCustomCurve(self, type):
		pass

	def GetOutputData(self, samples, channel):
		pass

	def GetSpectrumData(self, samples, channel, window):
		pass

	def SetSpatializerFloat(self, index, value):
		pass

	def GetSpatializerFloat(self, index, value):
		pass

	def SetAmbisonicDecoderFloat(self, index, value):
		pass

	def GetAmbisonicDecoderFloat(self, index, value):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class MonoBehaviour(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.useGUILayout = None
		self.runInEditMode = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def IsInvoking(self):
		pass

	def CancelInvoke(self):
		pass

	def Invoke(self, methodName, time):
		pass

	def InvokeRepeating(self, methodName, time, repeatRate):
		pass

	def CancelInvoke(self, methodName):
		pass

	def IsInvoking(self, methodName):
		pass

	def StartCoroutine(self, methodName):
		pass

	def StartCoroutine(self, methodName, value):
		pass

	def StartCoroutine(self, routine):
		pass

	def StopCoroutine(self, routine):
		pass

	def StopCoroutine(self, routine):
		pass

	def StopCoroutine(self, methodName):
		pass

	def StopAllCoroutines(self):
		pass

	@staticmethod
	def print(message):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class GameObject(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.transform = None
		self.layer = None
		self.activeSelf = None
		self.activeInHierarchy = None
		self.isStatic = None
		self.tag = None
		self.scene = None
		self.gameObject = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def CreatePrimitive(type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, type, includeInactive):
		pass

	def GetComponentInChildren(self, type):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInParent(self, type):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponentsInChildren(self, type):
		pass

	def GetComponentsInChildren(self, type, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, results):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentsInParent(self, type):
		pass

	def GetComponentsInParent(self, type, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self):
		pass

	@staticmethod
	def FindWithTag(tag):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def AddComponent(self, componentType):
		pass

	def AddComponent(self):
		pass

	def SetActive(self, value):
		pass

	def CompareTag(self, tag):
		pass

	@staticmethod
	def FindGameObjectWithTag(tag):
		pass

	@staticmethod
	def FindGameObjectsWithTag(tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	@staticmethod
	def Find(name):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Collider(Component):

	def __init__(self):
		super(Component, self).__init__()

		self.enabled = None
		self.attachedRigidbody = None
		self.isTrigger = None
		self.contactOffset = None
		self.bounds = None
		self.sharedMaterial = None
		self.material = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def ClosestPoint(self, position):
		pass

	def Raycast(self, ray, hitInfo, maxDistance):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Collision(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.relativeVelocity = None
		self.rigidbody = None
		self.collider = None
		self.transform = None
		self.gameObject = None
		self.contacts = None
		self.impulse = None
		pass

	def GetEnumerator(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Joint(Component):

	def __init__(self):
		super(Component, self).__init__()

		self.connectedBody = None
		self.axis = None
		self.anchor = None
		self.connectedAnchor = None
		self.autoConfigureConnectedAnchor = None
		self.breakForce = None
		self.breakTorque = None
		self.enableCollision = None
		self.enablePreprocessing = None
		self.massScale = None
		self.connectedMassScale = None
		self.currentForce = None
		self.currentTorque = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Collider2D(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.density = None
		self.isTrigger = None
		self.usedByEffector = None
		self.usedByComposite = None
		self.composite = None
		self.offset = None
		self.attachedRigidbody = None
		self.shapeCount = None
		self.bounds = None
		self.sharedMaterial = None
		self.friction = None
		self.bounciness = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def IsTouching(self, collider):
		pass

	def IsTouching(self, collider, contactFilter):
		pass

	def IsTouching(self, contactFilter):
		pass

	def IsTouchingLayers(self):
		pass

	def IsTouchingLayers(self, layerMask):
		pass

	def OverlapPoint(self, point):
		pass

	def Distance(self, collider):
		pass

	def OverlapCollider(self, contactFilter, results):
		pass

	def GetContacts(self, contacts):
		pass

	def GetContacts(self, contactFilter, contacts):
		pass

	def GetContacts(self, colliders):
		pass

	def GetContacts(self, contactFilter, colliders):
		pass

	def Cast(self, direction, results):
		pass

	def Cast(self, direction, results, distance):
		pass

	def Cast(self, direction, results, distance, ignoreSiblingColliders):
		pass

	def Cast(self, direction, contactFilter, results):
		pass

	def Cast(self, direction, contactFilter, results, distance):
		pass

	def Cast(self, direction, contactFilter, results, distance, ignoreSiblingColliders):
		pass

	def Raycast(self, direction, results):
		pass

	def Raycast(self, direction, results, distance):
		pass

	def Raycast(self, direction, results, distance, layerMask):
		pass

	def Raycast(self, direction, results, distance, layerMask, minDepth):
		pass

	def Raycast(self, direction, results, distance, layerMask, minDepth, maxDepth):
		pass

	def Raycast(self, direction, contactFilter, results):
		pass

	def Raycast(self, direction, contactFilter, results, distance):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Collision2D(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.collider = None
		self.otherCollider = None
		self.rigidbody = None
		self.otherRigidbody = None
		self.transform = None
		self.gameObject = None
		self.relativeVelocity = None
		self.enabled = None
		self.contacts = None
		self.contactCount = None
		pass

	def GetContact(self, index):
		pass

	def GetContacts(self, contacts):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Joint2D(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.attachedRigidbody = None
		self.connectedBody = None
		self.enableCollision = None
		self.breakForce = None
		self.breakTorque = None
		self.reactionForce = None
		self.reactionTorque = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def GetReactionForce(self, timeStep):
		pass

	def GetReactionTorque(self, timeStep):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class ControllerColliderHit(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.controller = None
		self.collider = None
		self.rigidbody = None
		self.gameObject = None
		self.transform = None
		self.point = None
		self.normal = None
		self.moveDirection = None
		self.moveLength = None
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class Texture(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.masterTextureLimit = None
		self.anisotropicFiltering = None
		self.width = None
		self.height = None
		self.dimension = None
		self.wrapMode = None
		self.wrapModeU = None
		self.wrapModeV = None
		self.wrapModeW = None
		self.filterMode = None
		self.anisoLevel = None
		self.mipMapBias = None
		self.texelSize = None
		self.updateCount = None
		self.imageContentsHash = None
		self.totalTextureMemory = None
		self.desiredTextureMemory = None
		self.targetTextureMemory = None
		self.currentTextureMemory = None
		self.nonStreamingTextureMemory = None
		self.streamingMipmapUploadCount = None
		self.streamingRendererCount = None
		self.streamingTextureCount = None
		self.nonStreamingTextureCount = None
		self.streamingTexturePendingLoadCount = None
		self.streamingTextureLoadingCount = None
		self.streamingTextureForceLoadAll = None
		self.streamingTextureDiscardUnusedMips = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def get_masterTextureLimit():
		pass

	@staticmethod
	def set_masterTextureLimit(value):
		pass

	@staticmethod
	def get_anisotropicFiltering():
		pass

	@staticmethod
	def set_anisotropicFiltering(value):
		pass

	@staticmethod
	def get_totalTextureMemory():
		pass

	@staticmethod
	def get_desiredTextureMemory():
		pass

	@staticmethod
	def get_targetTextureMemory():
		pass

	@staticmethod
	def get_currentTextureMemory():
		pass

	@staticmethod
	def get_nonStreamingTextureMemory():
		pass

	@staticmethod
	def get_streamingMipmapUploadCount():
		pass

	@staticmethod
	def get_streamingRendererCount():
		pass

	@staticmethod
	def get_streamingTextureCount():
		pass

	@staticmethod
	def get_nonStreamingTextureCount():
		pass

	@staticmethod
	def get_streamingTexturePendingLoadCount():
		pass

	@staticmethod
	def get_streamingTextureLoadingCount():
		pass

	@staticmethod
	def get_streamingTextureForceLoadAll():
		pass

	@staticmethod
	def set_streamingTextureForceLoadAll(value):
		pass

	@staticmethod
	def get_streamingTextureDiscardUnusedMips():
		pass

	@staticmethod
	def set_streamingTextureDiscardUnusedMips(value):
		pass

	@staticmethod
	def SetGlobalAnisotropicFilteringLimits(forcedMin, globalMax):
		pass

	def GetNativeTexturePtr(self):
		pass

	def IncrementUpdateCount(self):
		pass

	@staticmethod
	def SetStreamingTextureMaterialDebugProperties():
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Texture2D(Texture):

	def __init__(self):
		super(Texture, self).__init__()

		self.alphaIsTransparency = None
		self.mipmapCount = None
		self.format = None
		self.whiteTexture = None
		self.blackTexture = None
		self.streamingMipmaps = None
		self.streamingMipmapsPriority = None
		self.requestedMipmapLevel = None
		self.desiredMipmapLevel = None
		self.loadingMipmapLevel = None
		self.loadedMipmapLevel = None
		self.width = None
		self.height = None
		self.dimension = None
		self.wrapMode = None
		self.wrapModeU = None
		self.wrapModeV = None
		self.wrapModeW = None
		self.filterMode = None
		self.anisoLevel = None
		self.mipMapBias = None
		self.texelSize = None
		self.updateCount = None
		self.imageContentsHash = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def get_whiteTexture():
		pass

	@staticmethod
	def get_blackTexture():
		pass

	def UpdateExternalTexture(self, nativeTex):
		pass

	def SetPixels32(self, colors):
		pass

	def SetPixels32(self, colors, miplevel):
		pass

	def SetPixels32(self, x, y, blockWidth, blockHeight, colors):
		pass

	def SetPixels32(self, x, y, blockWidth, blockHeight, colors, miplevel):
		pass

	def GetRawTextureData(self):
		pass

	def GetPixels(self):
		pass

	def GetPixels(self, miplevel):
		pass

	def GetPixels(self, x, y, blockWidth, blockHeight, miplevel):
		pass

	def GetPixels(self, x, y, blockWidth, blockHeight):
		pass

	def GetPixels32(self, miplevel):
		pass

	def GetPixels32(self):
		pass

	def PackTextures(self, textures, padding, maximumAtlasSize, makeNoLongerReadable):
		pass

	def PackTextures(self, textures, padding, maximumAtlasSize):
		pass

	def PackTextures(self, textures, padding):
		pass

	def Compress(self, highQuality):
		pass

	def ClearRequestedMipmapLevel(self):
		pass

	def IsRequestedMipmapLevelLoaded(self):
		pass

	@staticmethod
	def CreateExternalTexture(width, height, format, mipChain, linear, nativeTex):
		pass

	def SetPixel(self, x, y, color):
		pass

	def SetPixels(self, x, y, blockWidth, blockHeight, colors, miplevel):
		pass

	def SetPixels(self, x, y, blockWidth, blockHeight, colors):
		pass

	def SetPixels(self, colors, miplevel):
		pass

	def SetPixels(self, colors):
		pass

	def GetPixel(self, x, y):
		pass

	def GetPixelBilinear(self, x, y):
		pass

	def LoadRawTextureData(self, data, size):
		pass

	def LoadRawTextureData(self, data):
		pass

	def LoadRawTextureData(self, data):
		pass

	def GetRawTextureData(self):
		pass

	def Apply(self, updateMipmaps, makeNoLongerReadable):
		pass

	def Apply(self, updateMipmaps):
		pass

	def Apply(self):
		pass

	def Resize(self, width, height):
		pass

	def Resize(self, width, height, format, hasMipMap):
		pass

	def ReadPixels(self, source, destX, destY, recalculateMipMaps):
		pass

	def ReadPixels(self, source, destX, destY):
		pass

	@staticmethod
	def GenerateAtlas(sizes, padding, atlasSize, results):
		pass

	def GetNativeTexturePtr(self):
		pass

	def IncrementUpdateCount(self):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Shader(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.maximumLOD = None
		self.globalMaximumLOD = None
		self.isSupported = None
		self.globalRenderPipeline = None
		self.renderQueue = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def get_globalMaximumLOD():
		pass

	@staticmethod
	def set_globalMaximumLOD(value):
		pass

	@staticmethod
	def get_globalRenderPipeline():
		pass

	@staticmethod
	def set_globalRenderPipeline(value):
		pass

	@staticmethod
	def Find(name):
		pass

	@staticmethod
	def EnableKeyword(keyword):
		pass

	@staticmethod
	def DisableKeyword(keyword):
		pass

	@staticmethod
	def IsKeywordEnabled(keyword):
		pass

	@staticmethod
	def WarmupAllShaders():
		pass

	@staticmethod
	def PropertyToID(name):
		pass

	@staticmethod
	def SetGlobalFloat(name, value):
		pass

	@staticmethod
	def SetGlobalFloat(nameID, value):
		pass

	@staticmethod
	def SetGlobalInt(name, value):
		pass

	@staticmethod
	def SetGlobalInt(nameID, value):
		pass

	@staticmethod
	def SetGlobalVector(name, value):
		pass

	@staticmethod
	def SetGlobalVector(nameID, value):
		pass

	@staticmethod
	def SetGlobalColor(name, value):
		pass

	@staticmethod
	def SetGlobalColor(nameID, value):
		pass

	@staticmethod
	def SetGlobalMatrix(name, value):
		pass

	@staticmethod
	def SetGlobalMatrix(nameID, value):
		pass

	@staticmethod
	def SetGlobalTexture(name, value):
		pass

	@staticmethod
	def SetGlobalTexture(nameID, value):
		pass

	@staticmethod
	def SetGlobalBuffer(name, value):
		pass

	@staticmethod
	def SetGlobalBuffer(nameID, value):
		pass

	@staticmethod
	def SetGlobalFloatArray(name, values):
		pass

	@staticmethod
	def SetGlobalFloatArray(nameID, values):
		pass

	@staticmethod
	def SetGlobalFloatArray(name, values):
		pass

	@staticmethod
	def SetGlobalFloatArray(nameID, values):
		pass

	@staticmethod
	def SetGlobalVectorArray(name, values):
		pass

	@staticmethod
	def SetGlobalVectorArray(nameID, values):
		pass

	@staticmethod
	def SetGlobalVectorArray(name, values):
		pass

	@staticmethod
	def SetGlobalVectorArray(nameID, values):
		pass

	@staticmethod
	def SetGlobalMatrixArray(name, values):
		pass

	@staticmethod
	def SetGlobalMatrixArray(nameID, values):
		pass

	@staticmethod
	def SetGlobalMatrixArray(name, values):
		pass

	@staticmethod
	def SetGlobalMatrixArray(nameID, values):
		pass

	@staticmethod
	def GetGlobalFloat(name):
		pass

	@staticmethod
	def GetGlobalFloat(nameID):
		pass

	@staticmethod
	def GetGlobalInt(name):
		pass

	@staticmethod
	def GetGlobalInt(nameID):
		pass

	@staticmethod
	def GetGlobalVector(name):
		pass

	@staticmethod
	def GetGlobalVector(nameID):
		pass

	@staticmethod
	def GetGlobalColor(name):
		pass

	@staticmethod
	def GetGlobalColor(nameID):
		pass

	@staticmethod
	def GetGlobalMatrix(name):
		pass

	@staticmethod
	def GetGlobalMatrix(nameID):
		pass

	@staticmethod
	def GetGlobalTexture(name):
		pass

	@staticmethod
	def GetGlobalTexture(nameID):
		pass

	@staticmethod
	def GetGlobalFloatArray(name):
		pass

	@staticmethod
	def GetGlobalFloatArray(nameID):
		pass

	@staticmethod
	def GetGlobalVectorArray(name):
		pass

	@staticmethod
	def GetGlobalVectorArray(nameID):
		pass

	@staticmethod
	def GetGlobalMatrixArray(name):
		pass

	@staticmethod
	def GetGlobalMatrixArray(nameID):
		pass

	@staticmethod
	def GetGlobalFloatArray(name, values):
		pass

	@staticmethod
	def GetGlobalFloatArray(nameID, values):
		pass

	@staticmethod
	def GetGlobalVectorArray(name, values):
		pass

	@staticmethod
	def GetGlobalVectorArray(nameID, values):
		pass

	@staticmethod
	def GetGlobalMatrixArray(name, values):
		pass

	@staticmethod
	def GetGlobalMatrixArray(nameID, values):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Renderer(Component):

	def __init__(self):
		super(Component, self).__init__()

		self.bounds = None
		self.enabled = None
		self.isVisible = None
		self.shadowCastingMode = None
		self.receiveShadows = None
		self.motionVectorGenerationMode = None
		self.lightProbeUsage = None
		self.reflectionProbeUsage = None
		self.renderingLayerMask = None
		self.sortingLayerName = None
		self.sortingLayerID = None
		self.sortingOrder = None
		self.allowOcclusionWhenDynamic = None
		self.isPartOfStaticBatch = None
		self.worldToLocalMatrix = None
		self.localToWorldMatrix = None
		self.lightProbeProxyVolumeOverride = None
		self.probeAnchor = None
		self.lightmapIndex = None
		self.realtimeLightmapIndex = None
		self.lightmapScaleOffset = None
		self.realtimeLightmapScaleOffset = None
		self.materials = None
		self.material = None
		self.sharedMaterial = None
		self.sharedMaterials = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def HasPropertyBlock(self):
		pass

	def SetPropertyBlock(self, properties):
		pass

	def SetPropertyBlock(self, properties, materialIndex):
		pass

	def GetPropertyBlock(self, properties):
		pass

	def GetPropertyBlock(self, properties, materialIndex):
		pass

	def GetMaterials(self, m):
		pass

	def GetSharedMaterials(self, m):
		pass

	def GetClosestReflectionProbes(self, result):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class WWW(CustomYieldInstruction):

	def __init__(self):
		super(CustomYieldInstruction, self).__init__()

		self.assetBundle = None
		self.bytes = None
		self.bytesDownloaded = None
		self.error = None
		self.isDone = None
		self.progress = None
		self.responseHeaders = None
		self.text = None
		self.texture = None
		self.textureNonReadable = None
		self.threadPriority = None
		self.uploadProgress = None
		self.url = None
		self.keepWaiting = None
		self.Current = None
		pass

	@staticmethod
	def EscapeURL(s):
		pass

	@staticmethod
	def EscapeURL(s, e):
		pass

	@staticmethod
	def UnEscapeURL(s):
		pass

	@staticmethod
	def UnEscapeURL(s, e):
		pass

	@staticmethod
	def LoadFromCacheOrDownload(url, version):
		pass

	@staticmethod
	def LoadFromCacheOrDownload(url, version, crc):
		pass

	@staticmethod
	def LoadFromCacheOrDownload(url, hash):
		pass

	@staticmethod
	def LoadFromCacheOrDownload(url, hash, crc):
		pass

	@staticmethod
	def LoadFromCacheOrDownload(url, cachedBundle, crc):
		pass

	def LoadImageIntoTexture(self, texture):
		pass

	def Dispose(self):
		pass

	def GetAudioClip(self):
		pass

	def GetAudioClip(self, threeD):
		pass

	def GetAudioClip(self, threeD, stream):
		pass

	def GetAudioClip(self, threeD, stream, audioType):
		pass

	def GetAudioClipCompressed(self):
		pass

	def GetAudioClipCompressed(self, threeD):
		pass

	def GetAudioClipCompressed(self, threeD, audioType):
		pass

	def MoveNext(self):
		pass

	def Reset(self):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class AudioClip(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.length = None
		self.samples = None
		self.channels = None
		self.frequency = None
		self.loadType = None
		self.preloadAudioData = None
		self.ambisonic = None
		self.loadState = None
		self.loadInBackground = None
		self.name = None
		self.hideFlags = None
		pass

	def LoadAudioData(self):
		pass

	def UnloadAudioData(self):
		pass

	def GetData(self, data, offsetSamples):
		pass

	def SetData(self, data, offsetSamples):
		pass

	@staticmethod
	def Create(name, lengthSamples, channels, frequency, stream):
		pass

	@staticmethod
	def Create(name, lengthSamples, channels, frequency, stream, pcmreadercallback):
		pass

	@staticmethod
	def Create(name, lengthSamples, channels, frequency, stream, pcmreadercallback, pcmsetpositioncallback):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class AssetBundle(Object):

	def __init__(self):
		super(Object, self).__init__()

		self.mainAsset = None
		self.isStreamedSceneAssetBundle = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def UnloadAllAssetBundles(unloadAllObjects):
		pass

	@staticmethod
	def GetAllLoadedAssetBundles():
		pass

	@staticmethod
	def LoadFromFileAsync(path):
		pass

	@staticmethod
	def LoadFromFileAsync(path, crc):
		pass

	@staticmethod
	def LoadFromFileAsync(path, crc, offset):
		pass

	@staticmethod
	def LoadFromFile(path):
		pass

	@staticmethod
	def LoadFromFile(path, crc):
		pass

	@staticmethod
	def LoadFromFile(path, crc, offset):
		pass

	@staticmethod
	def LoadFromMemoryAsync(binary):
		pass

	@staticmethod
	def LoadFromMemoryAsync(binary, crc):
		pass

	@staticmethod
	def LoadFromMemory(binary):
		pass

	@staticmethod
	def LoadFromMemory(binary, crc):
		pass

	@staticmethod
	def LoadFromStreamAsync(stream, crc, managedReadBufferSize):
		pass

	@staticmethod
	def LoadFromStreamAsync(stream, crc):
		pass

	@staticmethod
	def LoadFromStreamAsync(stream):
		pass

	@staticmethod
	def LoadFromStream(stream, crc, managedReadBufferSize):
		pass

	@staticmethod
	def LoadFromStream(stream, crc):
		pass

	@staticmethod
	def LoadFromStream(stream):
		pass

	def Contains(self, name):
		pass

	def LoadAsset(self, name):
		pass

	def LoadAsset(self, name):
		pass

	def LoadAsset(self, name, type):
		pass

	def LoadAssetAsync(self, name):
		pass

	def LoadAssetAsync(self, name):
		pass

	def LoadAssetAsync(self, name, type):
		pass

	def LoadAssetWithSubAssets(self, name):
		pass

	def LoadAssetWithSubAssets(self, name):
		pass

	def LoadAssetWithSubAssets(self, name, type):
		pass

	def LoadAssetWithSubAssetsAsync(self, name):
		pass

	def LoadAssetWithSubAssetsAsync(self, name):
		pass

	def LoadAssetWithSubAssetsAsync(self, name, type):
		pass

	def LoadAllAssets(self):
		pass

	def LoadAllAssets(self):
		pass

	def LoadAllAssets(self, type):
		pass

	def LoadAllAssetsAsync(self):
		pass

	def LoadAllAssetsAsync(self):
		pass

	def LoadAllAssetsAsync(self, type):
		pass

	def Unload(self, unloadAllLoadedObjects):
		pass

	def GetAllAssetNames(self):
		pass

	def GetAllScenePaths(self):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class ParticleSystem(Component):

	def __init__(self):
		super(Component, self).__init__()

		self.isPlaying = None
		self.isEmitting = None
		self.isStopped = None
		self.isPaused = None
		self.time = None
		self.particleCount = None
		self.randomSeed = None
		self.useAutoRandomSeed = None
		self.automaticCullingEnabled = None
		self.main = None
		self.emission = None
		self.shape = None
		self.velocityOverLifetime = None
		self.limitVelocityOverLifetime = None
		self.inheritVelocity = None
		self.forceOverLifetime = None
		self.colorOverLifetime = None
		self.colorBySpeed = None
		self.sizeOverLifetime = None
		self.sizeBySpeed = None
		self.rotationOverLifetime = None
		self.rotationBySpeed = None
		self.externalForces = None
		self.noise = None
		self.collision = None
		self.trigger = None
		self.subEmitters = None
		self.textureSheetAnimation = None
		self.lights = None
		self.trails = None
		self.customData = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def SetParticles(self, particles, size):
		pass

	def GetParticles(self, particles):
		pass

	def SetCustomParticleData(self, customData, streamIndex):
		pass

	def GetCustomParticleData(self, customData, streamIndex):
		pass

	def Simulate(self, t, withChildren, restart, fixedTimeStep):
		pass

	def Simulate(self, t, withChildren, restart):
		pass

	def Simulate(self, t, withChildren):
		pass

	def Simulate(self, t):
		pass

	def Play(self, withChildren):
		pass

	def Play(self):
		pass

	def Pause(self, withChildren):
		pass

	def Pause(self):
		pass

	def Stop(self, withChildren, stopBehavior):
		pass

	def Stop(self, withChildren):
		pass

	def Stop(self):
		pass

	def Clear(self, withChildren):
		pass

	def Clear(self):
		pass

	def IsAlive(self, withChildren):
		pass

	def IsAlive(self):
		pass

	def Emit(self, count):
		pass

	def Emit(self, emitParams, count):
		pass

	def TriggerSubEmitter(self, subEmitterIndex):
		pass

	def TriggerSubEmitter(self, subEmitterIndex, particle):
		pass

	def TriggerSubEmitter(self, subEmitterIndex, particles):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Animator(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.isOptimizable = None
		self.isHuman = None
		self.hasRootMotion = None
		self.humanScale = None
		self.isInitialized = None
		self.deltaPosition = None
		self.deltaRotation = None
		self.velocity = None
		self.angularVelocity = None
		self.rootPosition = None
		self.rootRotation = None
		self.applyRootMotion = None
		self.linearVelocityBlending = None
		self.updateMode = None
		self.hasTransformHierarchy = None
		self.gravityWeight = None
		self.bodyPosition = None
		self.bodyRotation = None
		self.stabilizeFeet = None
		self.layerCount = None
		self.parameters = None
		self.parameterCount = None
		self.feetPivotActive = None
		self.pivotWeight = None
		self.pivotPosition = None
		self.isMatchingTarget = None
		self.speed = None
		self.targetPosition = None
		self.targetRotation = None
		self.cullingMode = None
		self.playbackTime = None
		self.recorderStartTime = None
		self.recorderStopTime = None
		self.recorderMode = None
		self.runtimeAnimatorController = None
		self.hasBoundPlayables = None
		self.avatar = None
		self.playableGraph = None
		self.layersAffectMassCenter = None
		self.leftFeetBottomHeight = None
		self.rightFeetBottomHeight = None
		self.logWarnings = None
		self.fireEvents = None
		self.keepAnimatorControllerStateOnDisable = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def GetFloat(self, name):
		pass

	def GetFloat(self, id):
		pass

	def SetFloat(self, name, value):
		pass

	def SetFloat(self, name, value, dampTime, deltaTime):
		pass

	def SetFloat(self, id, value):
		pass

	def SetFloat(self, id, value, dampTime, deltaTime):
		pass

	def GetBool(self, name):
		pass

	def GetBool(self, id):
		pass

	def SetBool(self, name, value):
		pass

	def SetBool(self, id, value):
		pass

	def GetInteger(self, name):
		pass

	def GetInteger(self, id):
		pass

	def SetInteger(self, name, value):
		pass

	def SetInteger(self, id, value):
		pass

	def SetTrigger(self, name):
		pass

	def SetTrigger(self, id):
		pass

	def ResetTrigger(self, name):
		pass

	def ResetTrigger(self, id):
		pass

	def IsParameterControlledByCurve(self, name):
		pass

	def IsParameterControlledByCurve(self, id):
		pass

	def GetIKPosition(self, goal):
		pass

	def SetIKPosition(self, goal, goalPosition):
		pass

	def GetIKRotation(self, goal):
		pass

	def SetIKRotation(self, goal, goalRotation):
		pass

	def GetIKPositionWeight(self, goal):
		pass

	def SetIKPositionWeight(self, goal, value):
		pass

	def GetIKRotationWeight(self, goal):
		pass

	def SetIKRotationWeight(self, goal, value):
		pass

	def GetIKHintPosition(self, hint):
		pass

	def SetIKHintPosition(self, hint, hintPosition):
		pass

	def GetIKHintPositionWeight(self, hint):
		pass

	def SetIKHintPositionWeight(self, hint, value):
		pass

	def SetLookAtPosition(self, lookAtPosition):
		pass

	def SetLookAtWeight(self, weight):
		pass

	def SetLookAtWeight(self, weight, bodyWeight):
		pass

	def SetLookAtWeight(self, weight, bodyWeight, headWeight):
		pass

	def SetLookAtWeight(self, weight, bodyWeight, headWeight, eyesWeight):
		pass

	def SetLookAtWeight(self, weight, bodyWeight, headWeight, eyesWeight, clampWeight):
		pass

	def SetBoneLocalRotation(self, humanBoneId, rotation):
		pass

	def GetBehaviour(self):
		pass

	def GetBehaviours(self):
		pass

	def GetBehaviours(self, fullPathHash, layerIndex):
		pass

	def GetLayerName(self, layerIndex):
		pass

	def GetLayerIndex(self, layerName):
		pass

	def GetLayerWeight(self, layerIndex):
		pass

	def SetLayerWeight(self, layerIndex, weight):
		pass

	def GetCurrentAnimatorStateInfo(self, layerIndex):
		pass

	def GetNextAnimatorStateInfo(self, layerIndex):
		pass

	def GetAnimatorTransitionInfo(self, layerIndex):
		pass

	def GetCurrentAnimatorClipInfoCount(self, layerIndex):
		pass

	def GetNextAnimatorClipInfoCount(self, layerIndex):
		pass

	def GetCurrentAnimatorClipInfo(self, layerIndex):
		pass

	def GetNextAnimatorClipInfo(self, layerIndex):
		pass

	def GetCurrentAnimatorClipInfo(self, layerIndex, clips):
		pass

	def GetNextAnimatorClipInfo(self, layerIndex, clips):
		pass

	def IsInTransition(self, layerIndex):
		pass

	def GetParameter(self, index):
		pass

	def MatchTarget(self, matchPosition, matchRotation, targetBodyPart, weightMask, startNormalizedTime):
		pass

	def MatchTarget(self, matchPosition, matchRotation, targetBodyPart, weightMask, startNormalizedTime, targetNormalizedTime):
		pass

	def InterruptMatchTarget(self):
		pass

	def InterruptMatchTarget(self, completeMatch):
		pass

	def CrossFadeInFixedTime(self, stateName, fixedTransitionDuration):
		pass

	def CrossFadeInFixedTime(self, stateName, fixedTransitionDuration, layer):
		pass

	def CrossFadeInFixedTime(self, stateName, fixedTransitionDuration, layer, fixedTimeOffset):
		pass

	def CrossFadeInFixedTime(self, stateName, fixedTransitionDuration, layer, fixedTimeOffset, normalizedTransitionTime):
		pass

	def CrossFadeInFixedTime(self, stateHashName, fixedTransitionDuration, layer, fixedTimeOffset):
		pass

	def CrossFadeInFixedTime(self, stateHashName, fixedTransitionDuration, layer):
		pass

	def CrossFadeInFixedTime(self, stateHashName, fixedTransitionDuration):
		pass

	def CrossFadeInFixedTime(self, stateHashName, fixedTransitionDuration, layer, fixedTimeOffset, normalizedTransitionTime):
		pass

	def CrossFade(self, stateName, normalizedTransitionDuration, layer, normalizedTimeOffset):
		pass

	def CrossFade(self, stateName, normalizedTransitionDuration, layer):
		pass

	def CrossFade(self, stateName, normalizedTransitionDuration):
		pass

	def CrossFade(self, stateName, normalizedTransitionDuration, layer, normalizedTimeOffset, normalizedTransitionTime):
		pass

	def CrossFade(self, stateHashName, normalizedTransitionDuration, layer, normalizedTimeOffset, normalizedTransitionTime):
		pass

	def CrossFade(self, stateHashName, normalizedTransitionDuration, layer, normalizedTimeOffset):
		pass

	def CrossFade(self, stateHashName, normalizedTransitionDuration, layer):
		pass

	def CrossFade(self, stateHashName, normalizedTransitionDuration):
		pass

	def PlayInFixedTime(self, stateName, layer):
		pass

	def PlayInFixedTime(self, stateName):
		pass

	def PlayInFixedTime(self, stateName, layer, fixedTime):
		pass

	def PlayInFixedTime(self, stateNameHash, layer, fixedTime):
		pass

	def PlayInFixedTime(self, stateNameHash, layer):
		pass

	def PlayInFixedTime(self, stateNameHash):
		pass

	def Play(self, stateName, layer):
		pass

	def Play(self, stateName):
		pass

	def Play(self, stateName, layer, normalizedTime):
		pass

	def Play(self, stateNameHash, layer, normalizedTime):
		pass

	def Play(self, stateNameHash, layer):
		pass

	def Play(self, stateNameHash):
		pass

	def SetTarget(self, targetIndex, targetNormalizedTime):
		pass

	def GetBoneTransform(self, humanBoneId):
		pass

	def StartPlayback(self):
		pass

	def StopPlayback(self):
		pass

	def StartRecording(self, frameCount):
		pass

	def StopRecording(self):
		pass

	def HasState(self, layerIndex, stateID):
		pass

	@staticmethod
	def StringToHash(name):
		pass

	def Update(self, deltaTime):
		pass

	def Rebind(self):
		pass

	def ApplyBuiltinRootMotion(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class SkinnedMeshRenderer(Renderer):

	def __init__(self):
		super(Renderer, self).__init__()

		self.quality = None
		self.updateWhenOffscreen = None
		self.rootBone = None
		self.bones = None
		self.sharedMesh = None
		self.skinnedMotionVectors = None
		self.localBounds = None
		self.bounds = None
		self.enabled = None
		self.isVisible = None
		self.shadowCastingMode = None
		self.receiveShadows = None
		self.motionVectorGenerationMode = None
		self.lightProbeUsage = None
		self.reflectionProbeUsage = None
		self.renderingLayerMask = None
		self.sortingLayerName = None
		self.sortingLayerID = None
		self.sortingOrder = None
		self.allowOcclusionWhenDynamic = None
		self.isPartOfStaticBatch = None
		self.worldToLocalMatrix = None
		self.localToWorldMatrix = None
		self.lightProbeProxyVolumeOverride = None
		self.probeAnchor = None
		self.lightmapIndex = None
		self.realtimeLightmapIndex = None
		self.lightmapScaleOffset = None
		self.realtimeLightmapScaleOffset = None
		self.materials = None
		self.material = None
		self.sharedMaterial = None
		self.sharedMaterials = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def GetBlendShapeWeight(self, index):
		pass

	def SetBlendShapeWeight(self, index, value):
		pass

	def BakeMesh(self, mesh):
		pass

	def HasPropertyBlock(self):
		pass

	def SetPropertyBlock(self, properties):
		pass

	def SetPropertyBlock(self, properties, materialIndex):
		pass

	def GetPropertyBlock(self, properties):
		pass

	def GetPropertyBlock(self, properties, materialIndex):
		pass

	def GetMaterials(self, m):
		pass

	def GetSharedMaterials(self, m):
		pass

	def GetClosestReflectionProbes(self, result):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class MeshRenderer(Renderer):

	def __init__(self):
		super(Renderer, self).__init__()

		self.additionalVertexStreams = None
		self.subMeshStartIndex = None
		self.bounds = None
		self.enabled = None
		self.isVisible = None
		self.shadowCastingMode = None
		self.receiveShadows = None
		self.motionVectorGenerationMode = None
		self.lightProbeUsage = None
		self.reflectionProbeUsage = None
		self.renderingLayerMask = None
		self.sortingLayerName = None
		self.sortingLayerID = None
		self.sortingOrder = None
		self.allowOcclusionWhenDynamic = None
		self.isPartOfStaticBatch = None
		self.worldToLocalMatrix = None
		self.localToWorldMatrix = None
		self.lightProbeProxyVolumeOverride = None
		self.probeAnchor = None
		self.lightmapIndex = None
		self.realtimeLightmapIndex = None
		self.lightmapScaleOffset = None
		self.realtimeLightmapScaleOffset = None
		self.materials = None
		self.material = None
		self.sharedMaterial = None
		self.sharedMaterials = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def HasPropertyBlock(self):
		pass

	def SetPropertyBlock(self, properties):
		pass

	def SetPropertyBlock(self, properties, materialIndex):
		pass

	def GetPropertyBlock(self, properties):
		pass

	def GetPropertyBlock(self, properties, materialIndex):
		pass

	def GetMaterials(self, m):
		pass

	def GetSharedMaterials(self, m):
		pass

	def GetClosestReflectionProbes(self, result):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class BoxCollider(Collider):

	def __init__(self):
		super(Collider, self).__init__()

		self.center = None
		self.size = None
		self.enabled = None
		self.attachedRigidbody = None
		self.isTrigger = None
		self.contactOffset = None
		self.bounds = None
		self.sharedMaterial = None
		self.material = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def ClosestPoint(self, position):
		pass

	def Raycast(self, ray, hitInfo, maxDistance):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class MeshCollider(Collider):

	def __init__(self):
		super(Collider, self).__init__()

		self.sharedMesh = None
		self.convex = None
		self.inflateMesh = None
		self.cookingOptions = None
		self.skinWidth = None
		self.enabled = None
		self.attachedRigidbody = None
		self.isTrigger = None
		self.contactOffset = None
		self.bounds = None
		self.sharedMaterial = None
		self.material = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def ClosestPoint(self, position):
		pass

	def Raycast(self, ray, hitInfo, maxDistance):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class SphereCollider(Collider):

	def __init__(self):
		super(Collider, self).__init__()

		self.center = None
		self.radius = None
		self.enabled = None
		self.attachedRigidbody = None
		self.isTrigger = None
		self.contactOffset = None
		self.bounds = None
		self.sharedMaterial = None
		self.material = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def ClosestPoint(self, position):
		pass

	def Raycast(self, ray, hitInfo, maxDistance):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class CharacterController(Collider):

	def __init__(self):
		super(Collider, self).__init__()

		self.velocity = None
		self.isGrounded = None
		self.collisionFlags = None
		self.radius = None
		self.height = None
		self.center = None
		self.slopeLimit = None
		self.stepOffset = None
		self.skinWidth = None
		self.minMoveDistance = None
		self.detectCollisions = None
		self.enableOverlapRecovery = None
		self.enabled = None
		self.attachedRigidbody = None
		self.isTrigger = None
		self.contactOffset = None
		self.bounds = None
		self.sharedMaterial = None
		self.material = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def SimpleMove(self, speed):
		pass

	def Move(self, motion):
		pass

	def ClosestPoint(self, position):
		pass

	def Raycast(self, ray, hitInfo, maxDistance):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class CapsuleCollider(Collider):

	def __init__(self):
		super(Collider, self).__init__()

		self.center = None
		self.radius = None
		self.height = None
		self.direction = None
		self.enabled = None
		self.attachedRigidbody = None
		self.isTrigger = None
		self.contactOffset = None
		self.bounds = None
		self.sharedMaterial = None
		self.material = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def ClosestPoint(self, position):
		pass

	def Raycast(self, ray, hitInfo, maxDistance):
		pass

	def ClosestPointOnBounds(self, position):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Color(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.red = None
		self.green = None
		self.blue = None
		self.white = None
		self.black = None
		self.yellow = None
		self.cyan = None
		self.magenta = None
		self.gray = None
		self.grey = None
		self.clear = None
		self.grayscale = None
		self.linear = None
		self.gamma = None
		self.maxColorComponent = None
		self.Item = None
		pass

	@staticmethod
	def get_red():
		pass

	@staticmethod
	def get_green():
		pass

	@staticmethod
	def get_blue():
		pass

	@staticmethod
	def get_white():
		pass

	@staticmethod
	def get_black():
		pass

	@staticmethod
	def get_yellow():
		pass

	@staticmethod
	def get_cyan():
		pass

	@staticmethod
	def get_magenta():
		pass

	@staticmethod
	def get_gray():
		pass

	@staticmethod
	def get_grey():
		pass

	@staticmethod
	def get_clear():
		pass

	def ToString(self):
		pass

	def ToString(self, format):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def Equals(self, other):
		pass

	@staticmethod
	def Lerp(a, b, t):
		pass

	@staticmethod
	def LerpUnclamped(a, b, t):
		pass

	@staticmethod
	def RGBToHSV(rgbColor, H, S, V):
		pass

	@staticmethod
	def HSVToRGB(H, S, V):
		pass

	@staticmethod
	def HSVToRGB(H, S, V, hdr):
		pass

	def GetType(self):
		pass


class Animation(Behaviour):

	def __init__(self):
		super(Behaviour, self).__init__()

		self.clip = None
		self.playAutomatically = None
		self.wrapMode = None
		self.isPlaying = None
		self.Item = None
		self.animatePhysics = None
		self.cullingType = None
		self.localBounds = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def Stop(self):
		pass

	def Stop(self, name):
		pass

	def Rewind(self, name):
		pass

	def Rewind(self):
		pass

	def Sample(self):
		pass

	def IsPlaying(self, name):
		pass

	def Play(self):
		pass

	def Play(self, mode):
		pass

	def Play(self, animation, mode):
		pass

	def Play(self, animation):
		pass

	def CrossFade(self, animation, fadeLength, mode):
		pass

	def CrossFade(self, animation, fadeLength):
		pass

	def CrossFade(self, animation):
		pass

	def Blend(self, animation, targetWeight, fadeLength):
		pass

	def Blend(self, animation, targetWeight):
		pass

	def Blend(self, animation):
		pass

	def CrossFadeQueued(self, animation, fadeLength, queue, mode):
		pass

	def CrossFadeQueued(self, animation, fadeLength, queue):
		pass

	def CrossFadeQueued(self, animation, fadeLength):
		pass

	def CrossFadeQueued(self, animation):
		pass

	def PlayQueued(self, animation, queue, mode):
		pass

	def PlayQueued(self, animation, queue):
		pass

	def PlayQueued(self, animation):
		pass

	def AddClip(self, clip, newName):
		pass

	def AddClip(self, clip, newName, firstFrame, lastFrame, addLoopFrame):
		pass

	def AddClip(self, clip, newName, firstFrame, lastFrame):
		pass

	def RemoveClip(self, clip):
		pass

	def RemoveClip(self, clipName):
		pass

	def GetClipCount(self):
		pass

	def SyncLayer(self, layer):
		pass

	def GetEnumerator(self):
		pass

	def GetClip(self, name):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class AnimationClip(Motion):

	def __init__(self):
		super(Motion, self).__init__()

		self.events = None
		self.length = None
		self.frameRate = None
		self.wrapMode = None
		self.localBounds = None
		self.legacy = None
		self.humanMotion = None
		self.empty = None
		self.averageDuration = None
		self.averageAngularSpeed = None
		self.averageSpeed = None
		self.apparentSpeed = None
		self.isLooping = None
		self.isHumanMotion = None
		self.name = None
		self.hideFlags = None
		pass

	def AddEvent(self, evt):
		pass

	def SampleAnimation(self, go, time):
		pass

	def SetCurve(self, relativePath, type, propertyName, curve):
		pass

	def EnsureQuaternionContinuity(self):
		pass

	def ClearCurves(self):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class AnimationState(TrackedReference):

	def __init__(self):
		super(TrackedReference, self).__init__()

		self.enabled = None
		self.weight = None
		self.wrapMode = None
		self.time = None
		self.normalizedTime = None
		self.speed = None
		self.normalizedSpeed = None
		self.length = None
		self.layer = None
		self.clip = None
		self.name = None
		self.blendMode = None
		pass

	def AddMixingTransform(self, mix, recursive):
		pass

	def AddMixingTransform(self, mix):
		pass

	def RemoveMixingTransform(self, mix):
		pass

	def Equals(self, o):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass

	def ToString(self):
		pass


class AnimatorStateInfo(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.fullPathHash = None
		self.shortNameHash = None
		self.normalizedTime = None
		self.length = None
		self.speed = None
		self.speedMultiplier = None
		self.tagHash = None
		self.loop = None
		pass

	def IsName(self, name):
		pass

	def IsTag(self, tag):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class RenderTexture(Texture):

	def __init__(self):
		super(Texture, self).__init__()

		self.depth = None
		self.width = None
		self.height = None
		self.dimension = None
		self.useMipMap = None
		self.sRGB = None
		self.format = None
		self.vrUsage = None
		self.memorylessMode = None
		self.autoGenerateMips = None
		self.volumeDepth = None
		self.antiAliasing = None
		self.bindTextureMS = None
		self.enableRandomWrite = None
		self.useDynamicScale = None
		self.isPowerOfTwo = None
		self.active = None
		self.colorBuffer = None
		self.depthBuffer = None
		self.descriptor = None
		self.wrapMode = None
		self.wrapModeU = None
		self.wrapModeV = None
		self.wrapModeW = None
		self.filterMode = None
		self.anisoLevel = None
		self.mipMapBias = None
		self.texelSize = None
		self.updateCount = None
		self.imageContentsHash = None
		self.name = None
		self.hideFlags = None
		pass

	@staticmethod
	def get_active():
		pass

	@staticmethod
	def set_active(value):
		pass

	@staticmethod
	def ReleaseTemporary(temp):
		pass

	def GetNativeDepthBufferPtr(self):
		pass

	def DiscardContents(self, discardColor, discardDepth):
		pass

	def MarkRestoreExpected(self):
		pass

	def DiscardContents(self):
		pass

	def ResolveAntiAliasedSurface(self):
		pass

	def ResolveAntiAliasedSurface(self, target):
		pass

	def SetGlobalShaderProperty(self, propertyName):
		pass

	def Create(self):
		pass

	def Release(self):
		pass

	def IsCreated(self):
		pass

	def GenerateMips(self):
		pass

	def ConvertToEquirect(self, equirect, eye):
		pass

	@staticmethod
	def SupportsStencil(rt):
		pass

	@staticmethod
	def GetTemporary(desc):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer, format, readWrite, antiAliasing, memorylessMode, vrUsage, useDynamicScale):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer, format, readWrite, antiAliasing, memorylessMode, vrUsage):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer, format, readWrite, antiAliasing, memorylessMode):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer, format, readWrite, antiAliasing):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer, format, readWrite):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer, format):
		pass

	@staticmethod
	def GetTemporary(width, height, depthBuffer):
		pass

	@staticmethod
	def GetTemporary(width, height):
		pass

	def GetNativeTexturePtr(self):
		pass

	def IncrementUpdateCount(self):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Vector2(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.Item = None
		self.normalized = None
		self.magnitude = None
		self.sqrMagnitude = None
		self.zero = None
		self.one = None
		self.up = None
		self.down = None
		self.left = None
		self.right = None
		self.positiveInfinity = None
		self.negativeInfinity = None
		pass

	@staticmethod
	def get_zero():
		pass

	@staticmethod
	def get_one():
		pass

	@staticmethod
	def get_up():
		pass

	@staticmethod
	def get_down():
		pass

	@staticmethod
	def get_left():
		pass

	@staticmethod
	def get_right():
		pass

	@staticmethod
	def get_positiveInfinity():
		pass

	@staticmethod
	def get_negativeInfinity():
		pass

	def Set(self, newX, newY):
		pass

	@staticmethod
	def Lerp(a, b, t):
		pass

	@staticmethod
	def LerpUnclamped(a, b, t):
		pass

	@staticmethod
	def MoveTowards(current, target, maxDistanceDelta):
		pass

	@staticmethod
	def Scale(a, b):
		pass

	def Scale(self, scale):
		pass

	def Normalize(self):
		pass

	def ToString(self):
		pass

	def ToString(self, format):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def Equals(self, other):
		pass

	@staticmethod
	def Reflect(inDirection, inNormal):
		pass

	@staticmethod
	def Perpendicular(inDirection):
		pass

	@staticmethod
	def Dot(lhs, rhs):
		pass

	@staticmethod
	def Angle(from, to):
		pass

	@staticmethod
	def SignedAngle(from, to):
		pass

	@staticmethod
	def Distance(a, b):
		pass

	@staticmethod
	def ClampMagnitude(vector, maxLength):
		pass

	@staticmethod
	def SqrMagnitude(a):
		pass

	def SqrMagnitude(self):
		pass

	@staticmethod
	def Min(lhs, rhs):
		pass

	@staticmethod
	def Max(lhs, rhs):
		pass

	@staticmethod
	def SmoothDamp(current, target, currentVelocity, smoothTime, maxSpeed):
		pass

	@staticmethod
	def SmoothDamp(current, target, currentVelocity, smoothTime):
		pass

	@staticmethod
	def SmoothDamp(current, target, currentVelocity, smoothTime, maxSpeed, deltaTime):
		pass

	def GetType(self):
		pass


class Ray(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.origin = None
		self.direction = None
		pass

	def GetPoint(self, distance):
		pass

	def ToString(self):
		pass

	def ToString(self, format):
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def GetType(self):
		pass


class RaycastHit(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.collider = None
		self.point = None
		self.normal = None
		self.barycentricCoordinate = None
		self.distance = None
		self.triangleIndex = None
		self.textureCoord = None
		self.textureCoord2 = None
		self.transform = None
		self.rigidbody = None
		self.lightmapCoord = None
		pass

	def Equals(self, obj):
		pass

	def GetHashCode(self):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class Vector3(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.Item = None
		self.normalized = None
		self.magnitude = None
		self.sqrMagnitude = None
		self.zero = None
		self.one = None
		self.forward = None
		self.back = None
		self.up = None
		self.down = None
		self.left = None
		self.right = None
		self.positiveInfinity = None
		self.negativeInfinity = None
		pass

	@staticmethod
	def get_zero():
		pass

	@staticmethod
	def get_one():
		pass

	@staticmethod
	def get_forward():
		pass

	@staticmethod
	def get_back():
		pass

	@staticmethod
	def get_up():
		pass

	@staticmethod
	def get_down():
		pass

	@staticmethod
	def get_left():
		pass

	@staticmethod
	def get_right():
		pass

	@staticmethod
	def get_positiveInfinity():
		pass

	@staticmethod
	def get_negativeInfinity():
		pass

	@staticmethod
	def Slerp(a, b, t):
		pass

	@staticmethod
	def SlerpUnclamped(a, b, t):
		pass

	@staticmethod
	def OrthoNormalize(normal, tangent):
		pass

	@staticmethod
	def OrthoNormalize(normal, tangent, binormal):
		pass

	@staticmethod
	def RotateTowards(current, target, maxRadiansDelta, maxMagnitudeDelta):
		pass

	@staticmethod
	def Lerp(a, b, t):
		pass

	@staticmethod
	def LerpUnclamped(a, b, t):
		pass

	@staticmethod
	def MoveTowards(current, target, maxDistanceDelta):
		pass

	@staticmethod
	def SmoothDamp(current, target, currentVelocity, smoothTime, maxSpeed):
		pass

	@staticmethod
	def SmoothDamp(current, target, currentVelocity, smoothTime):
		pass

	@staticmethod
	def SmoothDamp(current, target, currentVelocity, smoothTime, maxSpeed, deltaTime):
		pass

	def Set(self, newX, newY, newZ):
		pass

	@staticmethod
	def Scale(a, b):
		pass

	def Scale(self, scale):
		pass

	@staticmethod
	def Cross(lhs, rhs):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def Equals(self, other):
		pass

	@staticmethod
	def Reflect(inDirection, inNormal):
		pass

	@staticmethod
	def Normalize(value):
		pass

	def Normalize(self):
		pass

	@staticmethod
	def Dot(lhs, rhs):
		pass

	@staticmethod
	def Project(vector, onNormal):
		pass

	@staticmethod
	def ProjectOnPlane(vector, planeNormal):
		pass

	@staticmethod
	def Angle(from, to):
		pass

	@staticmethod
	def SignedAngle(from, to, axis):
		pass

	@staticmethod
	def Distance(a, b):
		pass

	@staticmethod
	def ClampMagnitude(vector, maxLength):
		pass

	@staticmethod
	def Magnitude(vector):
		pass

	@staticmethod
	def SqrMagnitude(vector):
		pass

	@staticmethod
	def Min(lhs, rhs):
		pass

	@staticmethod
	def Max(lhs, rhs):
		pass

	def ToString(self):
		pass

	def ToString(self, format):
		pass

	def GetType(self):
		pass
