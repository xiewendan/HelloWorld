# -*- coding: utf-8 -*-


def get_width():
	pass


def get_height():
	pass


def get_dpi():
	pass


def get_orientation():
	pass


def set_orientation(value):
	pass


def get_sleepTimeout():
	pass


def set_sleepTimeout(value):
	pass


def get_autorotateToPortrait():
	pass


def set_autorotateToPortrait(value):
	pass


def get_autorotateToPortraitUpsideDown():
	pass


def set_autorotateToPortraitUpsideDown(value):
	pass


def get_autorotateToLandscapeLeft():
	pass


def set_autorotateToLandscapeLeft(value):
	pass


def get_autorotateToLandscapeRight():
	pass


def set_autorotateToLandscapeRight(value):
	pass


def get_currentResolution():
	pass


def get_fullScreen():
	pass


def set_fullScreen(value):
	pass


def get_fullScreenMode():
	pass


def set_fullScreenMode(value):
	pass


def get_safeArea():
	pass


def SetResolution(width, height, fullscreenMode, preferredRefreshRate):
	pass


def SetResolution(width, height, fullscreenMode):
	pass


def SetResolution(width, height, fullscreen, preferredRefreshRate):
	pass


def SetResolution(width, height, fullscreen):
	pass


def get_resolutions():
	pass


def get_GetResolution():
	pass


def get_showCursor():
	pass


def set_showCursor(value):
	pass


def get_lockCursor():
	pass


def set_lockCursor(value):
	pass
