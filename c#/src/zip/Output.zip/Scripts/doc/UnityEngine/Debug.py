# -*- coding: utf-8 -*-


def get_unityLogger():
	pass


def DrawLine(start, end, color, duration):
	pass


def DrawLine(start, end, color):
	pass


def DrawLine(start, end):
	pass


def DrawLine(start, end, color, duration, depthTest):
	pass


def DrawRay(start, dir, color, duration):
	pass


def DrawRay(start, dir, color):
	pass


def DrawRay(start, dir):
	pass


def DrawRay(start, dir, color, duration, depthTest):
	pass


def Break():
	pass


def DebugBreak():
	pass


def Log(message):
	pass


def Log(message, context):
	pass


def LogFormat(format, args):
	pass


def LogFormat(context, format, args):
	pass


def LogError(message):
	pass


def LogError(message, context):
	pass


def LogErrorFormat(format, args):
	pass


def LogErrorFormat(context, format, args):
	pass


def ClearDeveloperConsole():
	pass


def get_developerConsoleVisible():
	pass


def set_developerConsoleVisible(value):
	pass


def LogException(exception):
	pass


def LogException(exception, context):
	pass


def LogWarning(message):
	pass


def LogWarning(message, context):
	pass


def LogWarningFormat(format, args):
	pass


def LogWarningFormat(context, format, args):
	pass


def Assert(condition):
	pass


def Assert(condition, context):
	pass


def Assert(condition, message):
	pass


def Assert(condition, message):
	pass


def Assert(condition, message, context):
	pass


def Assert(condition, message, context):
	pass


def AssertFormat(condition, format, args):
	pass


def AssertFormat(condition, context, format, args):
	pass


def LogAssertion(message):
	pass


def LogAssertion(message, context):
	pass


def LogAssertionFormat(format, args):
	pass


def LogAssertionFormat(context, format, args):
	pass


def get_isDebugBuild():
	pass


def get_logger():
	pass
