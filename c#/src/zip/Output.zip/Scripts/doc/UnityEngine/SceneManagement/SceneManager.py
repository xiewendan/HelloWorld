# -*- coding: utf-8 -*-


def get_sceneCount():
	pass


def get_sceneCountInBuildSettings():
	pass


def GetActiveScene():
	pass


def SetActiveScene(scene):
	pass


def GetSceneByPath(scenePath):
	pass


def GetSceneByName(name):
	pass


def GetSceneByBuildIndex(buildIndex):
	pass


def GetSceneAt(index):
	pass


def CreateScene(sceneName):
	pass


def MergeScenes(sourceScene, destinationScene):
	pass


def MoveGameObjectToScene(go, scene):
	pass


def LoadScene(sceneName, mode):
	pass


def LoadScene(sceneName):
	pass


def LoadScene(sceneBuildIndex, mode):
	pass


def LoadScene(sceneBuildIndex):
	pass


def LoadSceneAsync(sceneBuildIndex, mode):
	pass


def LoadSceneAsync(sceneBuildIndex):
	pass


def LoadSceneAsync(sceneName, mode):
	pass


def LoadSceneAsync(sceneName):
	pass


def UnloadSceneAsync(sceneBuildIndex):
	pass


def UnloadSceneAsync(sceneName):
	pass


def UnloadSceneAsync(scene):
	pass


def sceneLoaded():
	pass


def sceneUnloaded():
	pass


def activeSceneChanged():
	pass
