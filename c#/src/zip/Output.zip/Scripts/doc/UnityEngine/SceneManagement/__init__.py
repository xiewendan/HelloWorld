# -*- coding: utf-8 -*-


__all__ = ["SceneManager", ]


class Scene(ValueType):

	def __init__(self):
		super(ValueType, self).__init__()

		self.path = None
		self.name = None
		self.isLoaded = None
		self.buildIndex = None
		self.isDirty = None
		self.rootCount = None
		pass

	def IsValid(self):
		pass

	def GetRootGameObjects(self):
		pass

	def GetRootGameObjects(self, rootGameObjects):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass
