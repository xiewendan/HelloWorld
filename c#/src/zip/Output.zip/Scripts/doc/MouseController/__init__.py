# -*- coding: utf-8 -*-



class MouseDetectCollider(MonoBehaviour):

	def __init__(self):
		super(MonoBehaviour, self).__init__()

		self.useGUILayout = None
		self.runInEditMode = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def SetupData(self, strGlobalID, fWidth, fHeight):
		pass

	def Highlighting(self, bShow):
		pass

	def IsInvoking(self):
		pass

	def CancelInvoke(self):
		pass

	def Invoke(self, methodName, time):
		pass

	def InvokeRepeating(self, methodName, time, repeatRate):
		pass

	def CancelInvoke(self, methodName):
		pass

	def IsInvoking(self, methodName):
		pass

	def StartCoroutine(self, methodName):
		pass

	def StartCoroutine(self, methodName, value):
		pass

	def StartCoroutine(self, routine):
		pass

	def StopCoroutine(self, routine):
		pass

	def StopCoroutine(self, routine):
		pass

	def StopCoroutine(self, methodName):
		pass

	def StopAllCoroutines(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass


class MouseDetect(MonoBehaviour):

	def __init__(self):
		super(MonoBehaviour, self).__init__()

		self.useGUILayout = None
		self.runInEditMode = None
		self.enabled = None
		self.isActiveAndEnabled = None
		self.transform = None
		self.gameObject = None
		self.tag = None
		self.name = None
		self.hideFlags = None
		pass

	def EnableDetectSky(self, bEnable):
		pass

	def IsInvoking(self):
		pass

	def CancelInvoke(self):
		pass

	def Invoke(self, methodName, time):
		pass

	def InvokeRepeating(self, methodName, time, repeatRate):
		pass

	def CancelInvoke(self, methodName):
		pass

	def IsInvoking(self, methodName):
		pass

	def StartCoroutine(self, methodName):
		pass

	def StartCoroutine(self, methodName, value):
		pass

	def StartCoroutine(self, routine):
		pass

	def StopCoroutine(self, routine):
		pass

	def StopCoroutine(self, routine):
		pass

	def StopCoroutine(self, methodName):
		pass

	def StopAllCoroutines(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponent(self):
		pass

	def GetComponent(self, type):
		pass

	def GetComponentInChildren(self, t, includeInactive):
		pass

	def GetComponentInChildren(self, t):
		pass

	def GetComponentInChildren(self, includeInactive):
		pass

	def GetComponentInChildren(self):
		pass

	def GetComponentsInChildren(self, t, includeInactive):
		pass

	def GetComponentsInChildren(self, t):
		pass

	def GetComponentsInChildren(self, includeInactive):
		pass

	def GetComponentsInChildren(self, includeInactive, result):
		pass

	def GetComponentsInChildren(self):
		pass

	def GetComponentsInChildren(self, results):
		pass

	def GetComponentInParent(self, t):
		pass

	def GetComponentInParent(self):
		pass

	def GetComponentsInParent(self, t, includeInactive):
		pass

	def GetComponentsInParent(self, t):
		pass

	def GetComponentsInParent(self, includeInactive):
		pass

	def GetComponentsInParent(self, includeInactive, results):
		pass

	def GetComponentsInParent(self):
		pass

	def GetComponents(self, type):
		pass

	def GetComponents(self, type, results):
		pass

	def GetComponents(self, results):
		pass

	def GetComponents(self):
		pass

	def CompareTag(self, tag):
		pass

	def SendMessageUpwards(self, methodName, value, options):
		pass

	def SendMessageUpwards(self, methodName, value):
		pass

	def SendMessageUpwards(self, methodName):
		pass

	def SendMessageUpwards(self, methodName, options):
		pass

	def SendMessage(self, methodName, value):
		pass

	def SendMessage(self, methodName):
		pass

	def SendMessage(self, methodName, value, options):
		pass

	def SendMessage(self, methodName, options):
		pass

	def BroadcastMessage(self, methodName, parameter, options):
		pass

	def BroadcastMessage(self, methodName, parameter):
		pass

	def BroadcastMessage(self, methodName):
		pass

	def BroadcastMessage(self, methodName, options):
		pass

	def GetInstanceID(self):
		pass

	def GetHashCode(self):
		pass

	def Equals(self, other):
		pass

	def ToString(self):
		pass

	def GetType(self):
		pass
