# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.connection.protocol_converter as protocol_converter
from gac_gas.common.enum_def import EMsgType
from connection_wrapper import connection_client


class GateConnection(connection_client.ConnectionClient):
    def __init__(self, ConnectionMgr, nConnID):
        super(GateConnection, self).__init__(ConnectionMgr, nConnID)
        self.m_ProtoColConverter = protocol_converter.ProtoColConverter(self)

    def OnDestroy(self, bNow=False):
        if self.m_ProtoColConverter:
            self.m_ProtoColConverter.Destroy()
            self.m_ProtoColConverter = None

        super(GateConnection, self).OnDestroy(bNow)

    def DumpRpc(self):
        self.m_Logger.info(self.m_ProtoColConverter.Dump())

    def OnConnect(self):
        import logic.common_pkg.utils as utils
        if utils.IsInternal():
            self.EnableDebug()

        self.SendSessionKey()

    def OnDisConnected(self, nReason, bRemote):
        self.DisableDebug()

    # 发送数据
    def Send(self, nMsgID, data):
        self.m_ProtoColConverter.ConvertString2IndexBySendData(nMsgID, data)
        super(GateConnection, self).Send(nMsgID, data)

    # 分发协议包
    def Dispatch(self, nMsgID, data):
        if not self.m_ProtoColConverter:
            self.m_Logger.error("连接已经断开：{}, {}".format(nMsgID, data))
            return

        if nMsgID == EMsgType.CLEAR_REG_STRING:
            self.m_ProtoColConverter.ClearRecv()
            return

        if nMsgID == EMsgType.REG_STRING:
            self.m_ProtoColConverter.DispatchRegString(nMsgID, data)
            return

        self.m_ProtoColConverter.ConvertIndex2StringByRecvData(nMsgID, data)

        super(GateConnection, self).Dispatch(nMsgID, data)

    # 分发协议包
    def OnDispatch(self, nMsgID, data):
        if nMsgID == EMsgType.GAS2GATE_FORWARD_GAC:
            self.OnRecvGas2GacMsg(data)
        elif nMsgID == EMsgType.BAT2GATE_FORWARD_GAC:
            self.OnRecvBat2GacMsg(data)
        else:
            self.m_Logger.error("非法链接rpc啊,踢掉: {}".format(nMsgID))
            raise ValueError("OnDispatch Error: {}".format(nMsgID))

    def OnRecvGas2GacMsg(self, data):
        GasInGacObj = theApp.GetGasInGac()
        if GasInGacObj:
            GasInGacObj.OnPbxMsg(data)
        else:
            raise RuntimeError("OnRecvGas2GacEntityMsg")

    def OnRecvBat2GacMsg(self, data):
        BatInGacObj = theApp.GetBatInGac()
        if BatInGacObj:
            BatInGacObj.OnPbxMsg(data)
        else:
            raise RuntimeError("OnRecvGas2GacEntityMsg")
