# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from connection_wrapper import connection_client

class LoginConnection(connection_client.ConnectionClient):
    def OnConnect(self):
        self.SendSessionKey()
