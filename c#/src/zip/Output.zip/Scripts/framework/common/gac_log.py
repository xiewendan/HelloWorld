# -*- coding: utf-8 -*-

import os
import logging
import traceback
from gac_gas.log.record_var import RecordVar


class MyStreamHandler(logging.StreamHandler):
    def __init__(self, stream=None):
        logging.StreamHandler.__init__(self, stream)

    def emit(self, record):
        try:
            msg = self.format(record)
            print(msg)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(record)


# Logger
class ExLogger(logging.Logger):
    def log_last_except(self):
        szTrace = traceback.format_exc()
        try:
            szVar = RecordVar.recordvar()
        except:
            # 如果获取变量失败，则直接跳过
            szVar = ""
        self.error('\n'.join([szTrace, szVar]))

        theApp.GetLogger().error(szTrace, szVar)


def InitLog(szPathLog, szLogFileName):
    logging.setLoggerClass(ExLogger)

    # 第一步，创建一个logger
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # 第二步，创建一个handler，用于写入日志文件
    if not os.path.exists(szPathLog):
        os.makedirs(szPathLog)
    logfile = "{}/{}-log.txt".format(szPathLog, szLogFileName)
    fh = logging.FileHandler(logfile, mode="w")
    fh.setLevel(logging.DEBUG)   # 输出到file的log等级的开关

    # 第三步，再创建一个handler，用于输出到控制台
    ch = MyStreamHandler()
    ch.setLevel(logging.DEBUG)

    # 第四步，定义handler的输出格式
    formatter = logging.Formatter("%(name)s - %(levelname)s - %(message)s")
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    # 第五步，将logger添加到handler里面
    logger.addHandler(fh)
    logger.addHandler(ch)

    logger.info("完成logger初始化")
