# -*- coding: utf-8 -*-

import gac_gas.common.rpc_wrapper as rpc_wrapper
from gac_gas.common.enum_def import EMsgType

# noinspection PyUnresolvedReferences
from gac_gas.common.rpc_wrapper import RpcWrapperConnection

# noinspection PyUnresolvedReferences
from gac_gas.common.rpc_wrapper import RpcWrapperPeerEntity


# --------------------------------------------Gac2Gas--------------------------------------------------
class RpcWrapperGac2GasEntity(rpc_wrapper.BaseRpcWrapper):
    s_eMsgType = EMsgType.GAC2GATE_FORWARD_GAS

    def __init__(self, Parent=None):
        super(RpcWrapperGac2GasEntity, self).__init__(Parent)

    def _GenRpcFunc(self, szMethodName, listSubMethodName):
        def Func(*args):
            self.Send(self.s_eMsgType, [szMethodName, list(args), list(listSubMethodName)])
        return Func

    def _Clone(self):
        return self.__class__(self)

    def _DoSend(self, *args):
        assert self.m_Parent is None, "必须没有父"

        ConnObj = theApp.GetGateConn()
        if ConnObj:
            ConnObj.Send(*args)
        else:
            self.m_Logger.error("RpcWrapperGac2GasEntity:连接为空(%s)".format(args))

# --------------------------------------------Gac2Bat--------------------------------------------------
class RpcWrapperGac2BatEntity(RpcWrapperGac2GasEntity):
    s_eMsgType = EMsgType.GAC2GATE_FORWARD_BAT

# ---------------------------------------account rpc-----------------------------------------------------

class RpcWrapperAccount(object):
    def __init__(self, OwnerObj):
        self.m_OwnerObj = OwnerObj
        self.m_bDestroy = False

    def __getattr__(self, szMethodName):
        if self.m_bDestroy:
            return None

        def func(*args):
            self.m_OwnerObj.m_AvatarObj.SendAccountMsg(szMethodName, args)

        setattr(self, szMethodName, func)
        return getattr(self, szMethodName)

    def Destroy(self):
        if not self.m_bDestroy:
            self.__dict__.clear()
            self.m_bDestroy = True
