# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.entity.base_entity as base_entity
import framework.tick_mgr as tick_mgr
import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
from logic.game_state.state_def import EGameEvent


# 等待服务器回应的最长时间(单位：秒)
MAX_WAIT_TIME = 15


class LoginInGac(base_entity.BaseEntity):
    def __init__(self):
        super(LoginInGac, self).__init__()

        self.m_TickCountTime = None
        self.m_nCountTime = 0

    def OnConnCome(self):
        self.m_Logger.info("LoginInGac come.")
        theApp.OnLoginConnected(self)
        self.CheckConfirm()

    def OnConnLost(self):
        self.m_Logger.info("LoginInGac lost.")

    def CheckConfirm(self):
        # 连上后需要调用这个rpc发送消息给服务器，然后继续走流程，否则会被踢
        self.m_Logger.info("向login发送确认")
        self.RegisterCountTimeTick()
        self.GetPeerEntityRpc().CheckConfirm()

    def ConnectLoginSuccess(self):
        self.m_Logger.info("login返回确认成功")
        self.UnRegisterCountTimeTick()

        game_state_machine_mgr.ProcessEvent(EGameEvent.LOGIN_CONNECT_SUCCESS)

    def SendAccountLoginInfo(self, szLoginUid):
        self.m_Logger.info("向login发送帐号验证")
        self.RegisterCountTimeTick()
        self.GetPeerEntityRpc().CheckAccountLoginInfo(szLoginUid)

    def WaitGasRet(self):
        self.m_Logger.info("等待gas认证")
        self.RegisterCountTimeTick()

    def AccountCheckSuccess(self, szGateIP, nPort, szTargetServerName, szToken):
        self.m_Logger.info("服务器返回账号验证成功: {},{}".format(szGateIP, nPort))
        self.UnRegisterCountTimeTick()
        theApp.SetGateInfo(szGateIP, nPort, szTargetServerName, szToken)

        game_state_machine_mgr.ProcessEvent(EGameEvent.CHECK_ACCOUNT_SUCCESS)

        # 登陆成功事件
        import gac_gas.event_system.event_dispatcher as event_dispatcher
        from gac_gas.event_system.event_def import EEventType
        event_dispatcher.Notify(EEventType.LoginSuccess)

    def AccountCheckFail(self, nCode):
        self.m_Logger.info("服务器返回账号验证失败: {}".format(nCode))
        self.UnRegisterCountTimeTick()
        game_state_machine_mgr.ProcessEvent(EGameEvent.CHECK_ACCOUNT_FAILED, nCode)

    def RegisterCountTimeTick(self):
        self.UnRegisterCountTimeTick()
        self.m_TickCountTime = tick_mgr.RegisterTick("LoginInGac.RegisterCountTimeTick", 1000, self.OnCountTimeout)
        self.OnCountTimeout()

    def UnRegisterCountTimeTick(self):
        if self.m_TickCountTime:
            tick_mgr.UnRegisterTick(self.m_TickCountTime)
            self.m_TickCountTime = None
            self.m_nCountTime = 0

    def OnCountTimeout(self):
        self.m_nCountTime += 1
        if self.m_nCountTime >= MAX_WAIT_TIME:
            self.UnRegisterCountTimeTick()
            game_state_machine_mgr.ProcessEvent(EGameEvent.WAIT_RET_TIMEOUT)
        else:
            # TODO
            print("更新UI")

    def ServerNotReady(self):
        self.m_Logger.info("服务器还没准备好")
        self.UnRegisterCountTimeTick()
        game_state_machine_mgr.ProcessEvent(EGameEvent.SERVER_NOT_READY)