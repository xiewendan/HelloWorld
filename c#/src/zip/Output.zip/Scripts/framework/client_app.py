# -*- coding: utf-8 -*-

import __builtin__
import asyncore
import logging
import os
import sys
import traceback


class ClientApp(object):
    def __init__(self):
        __builtin__.theApp = self

        self.Init()

    def Init(self):
        # login信息
        self.m_LoginInGac = None
        self.m_szTokenLogin = None
        self.m_szTargetServerName = None
        self.m_LoginConnectionMgr = None

        # gate信息
        self.m_GateInGac = None
        self.m_szGateIP = None
        self.m_nGatePort = None
        self.m_ConnGateObj = None
        self.m_GateConnectionMgr = None
        self.m_bCanAutoReconnect = True

        # gas
        self.m_GasInGac = None

        # battle
        self.m_BatInGac = None

        # 初始化编码
        self.InitDefaultEncode()

        # 配置表
        import etc.app_cfg as app_cfg
        self.m_dictConfig = app_cfg.CONFIG

        # 调试
        self.m_bDebug = self.m_dictConfig.get("debug", False)
        self.m_bEnableDelayFrameDetect = self.m_dictConfig.get("debug_frame_detect", False)

        # 基础帧周期
        self.m_nFrameStandard = self.m_dictConfig["frame_cyc"]

        # 初始化路径
        self.InitPath()
        # 初始化日志
        self.InitLog()
        # 初始化文件保存
        self.InitFileSave()
        # 初始化多语言
        self.InitStringResourceMgr()
        # 初始化加密
        self.InitEncryption()
        # 初始化login连接
        self.InitLoginNetWork()
        # 初始化gate连接
        self.InitGateNetWork()
        # 自动reload
        self.InitAutoReload()

        # 登陆信息
        self.m_szLoginUid = ""

        # 场景管理器
        import logic.game_scene.gac_scene_mgr as gac_scene_mgr
        self.m_SceneMgr = gac_scene_mgr.GacSceneMgr()

        # 组队管理器
        import logic.gac_team.gac_team_mgr as gac_team_mgr
        self.m_TeamMgr = gac_team_mgr.GacTeamMgr()

        # 排行榜管理器
        import logic.gac_rank.gac_rank_mgr as gac_rank_mgr
        self.m_RankMgr = gac_rank_mgr.GacRankMgr()

        self.m_Logger.info("App初始化完成")

    # 初始化编码
    def InitDefaultEncode(self):
        print("**********************InitDefaultEncode****************")
        # reload(sys)
        # sys.setdefaultencoding("utf-8")
        sys.excepthook = lambda tp, val, tb: self.OnTraceback(tp, val, tb)

    # 初始化路径
    def InitPath(self):
        print("**********************InitPath****************")
        import YTGameFramework
        szRootPath = YTGameFramework.YTUtils.GetCWD()

        print("当前路径:{}".format(szRootPath))
        self.m_szPathReloadTimeFile = os.path.join(szRootPath, "Var")
        self.m_szReloadTimeFileName = "leader_auto_reload_time.ini"
        self.m_szPathScript = os.path.join(szRootPath, "Scripts")
        self.m_szPathLoginkey = os.path.join(szRootPath, "Data")
        self.m_szPathLog = os.path.join(szRootPath, "Log")

    # 初始化log
    def InitLog(self):
        print("**********************InitLog****************")
        import framework.common.gac_log as log
        log.InitLog(self.m_szPathLog, "client")
        self.m_Logger = logging.getLogger(self.__class__.__name__)

    # 初始化文件保存
    def InitFileSave(self):
        self.m_Logger.info("初始化文件保存")
        import framework.file_save.file_save_mgr as file_save_mgr
        self.m_FileSaveMgr = file_save_mgr.FileSaveMgr()
        self.m_FileSaveMgr.Init(self.m_dictConfig)

    # 初始化多语言
    def InitStringResourceMgr(self):
        self.m_Logger.info("初始化多语言")
        import framework.local_language.string_resource_mgr as string_resource_mgr
        string_resource_mgr.Init()

    # 初始化加密
    def InitEncryption(self):
        self.m_Logger.info("初始化加密")

        # 初始化加密信息，创建加解密对象
        self.m_bNeedEncryption = self.m_dictConfig.get("encryption", False)

        self.m_Logger.info("client encryption is {}.".format(self.m_bNeedEncryption))

        # 初始化加密信息，创建加解密对象
        if self.m_bNeedEncryption:
            import gac_gas.encryption.encryption_mgr as encryption_mgr
            import framework.encryption.session_encrypter as session_encrypter
            szLoginKeyPath = self.m_dictConfig.get('loginkeypath', None)

            if not szLoginKeyPath:
                raise ValueError("错误! 配置了加密，但配置文件中没有定义loginkeypath.")

            szLoginKeyPath = os.path.join(self.m_szPathLoginkey, szLoginKeyPath)
            if not os.path.isfile(szLoginKeyPath):
                raise RuntimeError("错误! loginkeypath 对应的密钥文件不存在.")

            funCreateSesssionKey = session_encrypter.GetSesssionKey
            LoginKeyEncrypterClass = session_encrypter.LoginKeyEncrypterNokeyczar
            LoginKeyDecrypterClass = None
            ARC4CrypterClass = session_encrypter.ARC4Crypter
            encryption_mgr.Init(szLoginKeyPath, funCreateSesssionKey, LoginKeyEncrypterClass, LoginKeyDecrypterClass, ARC4CrypterClass)

    # 初始化reload
    def InitAutoReload(self):
        self.m_Logger.info("初始化reload")
        if self.m_dictConfig.get("auto_reload", False):
            import gac_gas.reload.auto_reload_mgr as auto_reload_mgr
            self.m_AutoReloadMgr = auto_reload_mgr.AutoReloadMgr(self.GetReloadPath(), self.m_szPathReloadTimeFile, self.m_szReloadTimeFileName, bLeaderApp=True, bAutoReload=True)
            self.m_AutoReloadMgr.Init()
        else:
            self.m_AutoReloadMgr = None

    # 获取reload路径
    def GetReloadPath(self):
        return [self.m_szPathScript, ]

    def InitLoginNetWork(self):
        import framework.login_connection_mgr as login_connection_mgr
        self.m_LoginConnectionMgr = login_connection_mgr.LoginConnectionMgr()
        self.m_LoginConnectionMgr.Init(self.IsNeedEncryption())

    def InitGateNetWork(self):
        import framework.gate_connection_mgr as gate_connection_mgr
        self.m_GateConnectionMgr = gate_connection_mgr.GateConnectionMgr()
        self.m_GateConnectionMgr.Init(self.IsNeedEncryption())

    def ConnectLogin(self):
        if self.m_LoginInGac:
            self.m_Logger.info("已经存在Login链接")
            return

        import login_mgr as login_mgr
        szIP, nPort = login_mgr.GetLoginAddr()
        if not szIP or not nPort:
            self.m_Logger.warn("login的IP地址或端口出错: {} {}".format(szIP, nPort))
            return

        self.m_Logger.info("连接login: {} {}".format(szIP, nPort))
        self.m_LoginConnectionMgr.Connect(szIP, nPort)

    def SetAccountLoginInfo(self, szUid):
        self.m_szLoginUid = szUid

    def SetAccountUid(self, szUid):
        # 设置账号名，注意，这个是登陆验证后的uid， 手游拿不到最原始的登陆账号
        self.m_Logger.info("SetAccountUid from %s to %s.", self.m_szLoginUid, szUid)
        self.m_szLoginUid = szUid

    def GetAccountUid(self):
        # 返回账号的UID（账号名），注意，这个是登陆验证后的uid， 手游拿不到最原始的登陆账号
        return self.m_szLoginUid

    def LoginConnectSuccess(self):
        self.m_LoginInGac.SendAccountLoginInfo(self.m_szLoginUid)

    def GetAccountLoginInfo(self):
        return self.m_szLoginUid, self.m_szTokenLogin

    def OnLoginConnected(self, LoginInGacObj):
        self.m_Logger.info("login连接")
        self.m_LoginInGac = LoginInGacObj

    def OnLoginDisconnected(self):
        self.m_Logger.info("login断开")
        self.m_LoginInGac = None

    def ConnectGate(self):
        if self.m_ConnGateObj:
            self.m_Logger.info("已经存在Gate链接")
            return

        self.m_Logger.info("连接Gate: {} {}".format(self.m_szGateIP, self.m_nGatePort))
        self.m_GateConnectionMgr.Connect(self.m_szGateIP, self.m_nGatePort)

    def SetGateConn(self, ConnObj):
        self.m_ConnGateObj = ConnObj
        self.m_Logger.info("设置gate连接: {}".format(ConnObj))

    def OnGateCome(self, GateInGacObj):
        self.m_Logger.info("gate连接")
        self.m_GateInGac = GateInGacObj
        self.m_bCanAutoReconnect = True

        import gas_in_gac as gas_in_gac
        import bat_in_gac as bat_in_gac
        self.m_GasInGac = gas_in_gac.GasInGac()
        self.m_BatInGac = bat_in_gac.BatInGac()

    def CanAutoReconnect(self, bValue):
        self.m_bCanAutoReconnect = bValue

    def IsNeedToAutoReconnect(self):
        return self.m_bCanAutoReconnect

    def OnGateOut(self, GateInGacObj):
        self.m_Logger.info("gate断开")

        self.m_GateInGac = None

        if self.m_GasInGac:
            self.m_GasInGac.Destroy()
            self.m_GasInGac = None

        if self.m_BatInGac:
            self.m_BatInGac.Destroy()
            self.m_BatInGac = None

    # 发生traceback的回调接口 t, value, tb = sys.exc_info()
    def OnTraceback(self, t, value, tb):
        if issubclass(t, SyntaxError):
            self.m_Logger.error("Type: {}".format(t))
            self.m_Logger.error("Value: {}".format(value))
            self.m_Logger.error("Error Detail:", exc_info=(t, value, tb))
            return

        sys.last_type = t
        sys.last_value = value
        sys.last_traceback = tb

        try:
            szTraceback = ''.join(traceback.format_exception(t, value, tb))
            if szTraceback:
                self.OnScriptError(szTraceback)

                szLocal = "\n local: {}".format(tb.tb_next.tb_frame.f_locals)
                self.m_Logger.error(szTraceback + szLocal)
        except:
            if self.IsDebug():
                traceback.print_exception(t, value, tb)
            else:
                pass

    def OnScriptError(self, error):
        # 暂时只上传一次dump
        import logic.common_pkg.sys_vars as sys_vars
        if sys_vars.bHaveReportDmp:
            return

        # 上传dump

        sys_vars.bHaveReportDmp = True

    def GetLogger(self):
        return self.m_Logger

    # 获取配置表
    def GetConfig(self):
        return self.m_dictConfig

    def GetFileSaveMgr(self):
        return self.m_FileSaveMgr

    def IsDebug(self):
        return self.m_bDebug

    # 是否加密
    def IsNeedEncryption(self):
        return self.m_bNeedEncryption

    def GetGateConn(self):
        if self.m_GateInGac is not None:
            return self.m_GateInGac.GetConn()
        return None

    def GetGasRpc(self):
        if self.m_GasInGac:
            return self.m_GasInGac.GetGasRpc()

    def GetGasInGac(self):
        return self.m_GasInGac

    def GetBatRpc(self):
        if self.m_BatInGac:
            return self.m_BatInGac.GetBatRpc()

    def GetBatInGac(self):
        return self.m_BatInGac

    def ShutDownByClient(self):
        if self.m_LoginInGac:
            self.m_LoginInGac.Destroy()
            self.m_LoginInGac = None

        if self.m_GateInGac:
            self.m_GateInGac.Destroy()
            self.m_GateInGac = None

        if self.m_ConnGateObj:
            self.m_ConnGateObj.Destroy()
            self.m_ConnGateObj = None

    def SetGateInfo(self, szIP, nPort,szTargetServerName, szToken):
        self.m_Logger.info("设置gate信息: {}, {}, {}, {}".format(szIP, nPort, szTargetServerName, szToken))
        self.m_szTokenLogin = szToken
        self.m_szTargetServerName = szTargetServerName
        self.m_szGateIP = szIP
        self.m_nGatePort = nPort

    def GetGateDelayMs(self):
        ConnObj = self.GetGateConn()
        if ConnObj is not None:
            return ConnObj.GetDelayMs()
        return 0

    def Update(self):
        # 更新网络
        asyncore.loop(0, True, None, 1)

    def Unit(self):
        if self.m_AutoReloadMgr:
            self.m_AutoReloadMgr.Uinit()

        self.ShutDownByClient()

        if self.m_GateConnectionMgr:
            self.m_GateConnectionMgr.Destroy()
            self.m_GateConnectionMgr = None

        if self.m_LoginConnectionMgr:
            self.m_LoginConnectionMgr.Destroy()
            self.m_LoginConnectionMgr = None

    # -----------------------------------------------------------------------------------

    def GetSceneMgr(self):
        return self.m_SceneMgr

    def GetTeamMgr(self):
        return self.m_TeamMgr

    def GetRankMgr(self):
        return self.m_RankMgr

# --------------------------------------------------------------------------------------------------------------

ClientAppObj = None


# 获取app
def GetApp():
    global ClientAppObj
    if ClientAppObj is None:
        ClientAppObj = ClientApp()
    return ClientAppObj


# 客户端关闭
def ShutDownByClient():
    global ClientAppObj
    if ClientAppObj is not None:
        ClientAppObj.ShutDownByClient()
