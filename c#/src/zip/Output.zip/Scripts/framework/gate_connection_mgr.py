# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
from connection.connection_wrapper import client


# 客户端连接管理器
class GateConnectionMgr(object):
    def __init__(self):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_GateClientObj = None

    def Init(self, bNeedEncryption):
        def OnConnectCallback(ConnObj):
            self.m_Logger.info("gate连接成功:{}".format(ConnObj.GetRemoteInfo()))
            theApp.SetGateConn(ConnObj)

            from logic.game_state.state_def import EGameEvent
            import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
            game_state_machine_mgr.ProcessEvent(EGameEvent.GATE_CONNECT_SUCCESS)

        def OnConnectFailedCallback(ConnObj):
            self.m_Logger.info("gate连接失败:{}".format(ConnObj and ConnObj.GetRemoteInfo()))
            theApp.SetGateConn(None)

            from logic.game_state.state_def import EGameEvent
            import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
            game_state_machine_mgr.ProcessEvent(EGameEvent.GATE_CONNECT_FAILED)

        def OnDisConnectedCallback(ConnObj):
            self.m_Logger.info("gate连接断开:{}".format(ConnObj and ConnObj.GetRemoteInfo()))
            theApp.SetGateConn(None)

            from logic.game_state.state_def import EGameEvent
            import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
            game_state_machine_mgr.ProcessEvent(EGameEvent.GATE_DISCONNECT)

        import gate_in_gac as gate_in_gac
        import connection.gate_connection as gate_connection
        import gac_gas.connection.connection_help as connection_help
        dictConnectionArgs = connection_help.CreateConnectionArgs(
            szConnectionName="gac for gate",
            nConnMaxOutBufSize=2 * 1024 * 1024,
            nConnMaxInBufSize=2 * 1024 * 1024,
            bKeepAlive=True,
            nCheckAliveInterval=10000,
            nCheckAliveTimeout=-1,
            funConnectCallback=OnConnectCallback,
            funConnectFailCallback=OnConnectFailedCallback,
            funDisConnectCallback=OnDisConnectedCallback,
            EntityClass=gate_in_gac.GateInGac,
            ConnectionClass=gate_connection.GateConnection,
            bNeedEncryption=bNeedEncryption
        )
        self.m_GateClientObj = client.Client(dictConnectionArgs)

    def Connect(self, szIP, nPort):
        self.m_Logger.info("连接gate:{},{}".format(szIP, nPort))

        try:
            self.m_GateClientObj.Connect(szIP, nPort)
        except:
            self.m_Logger.error("连接gate失败:({}:{})".format(szIP, nPort))

    def Destroy(self):
        if self.m_GateClientObj:
            self.m_GateClientObj.Destroy()
            self.m_GateClientObj = None
