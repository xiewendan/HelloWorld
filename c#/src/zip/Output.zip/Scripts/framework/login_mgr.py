# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

g_szCurIP = None
g_nCurPort = None


def SetLoginAddr(szIP, nPort):
    global g_szCurIP, g_nCurPort
    g_szCurIP = szIP
    g_nCurPort = nPort

    print("设置登陆服务器地地址:({}:{})".format(szIP, nPort))


def GetLoginAddr():
    return g_szCurIP, g_nCurPort
