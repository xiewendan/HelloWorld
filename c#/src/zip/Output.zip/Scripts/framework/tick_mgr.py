# -*- coding: utf-8 -*-

import tick
import random
import time

g_dictTickID2Callback = {} # id->[engineTickID,callback,tParam,dParam]
g_dictEngineID2TickID = {} # engineid ->id

g_FastTimeTickInMs = 0
g_FastTimeTickInSecFloat = 0.0
g_FastUTCTimeInSec = 0
g_FastUTCTimeInMS = 0

g_bDebug = False
g_dictDebugTickName2Count = {}
g_dictDebugTickID2Name = {}
g_dictDebugTickName2CountOnCurFrame = {}

g_nAutoID = 0


def _AddTick(nEngineTickID, CallBack, tParam, dParam, nRunCount, szTickDesc):
    global g_dictTickID2Callback, g_dictEngineID2TickID
    nTickID = _GetAutoID()
    assert nTickID not in g_dictTickID2Callback, "RegisterTick  assert nTickID not in g_dictTickID2Callback"
    g_dictTickID2Callback[nTickID] = (nEngineTickID, CallBack, tParam, dParam, nRunCount, szTickDesc)
    g_dictEngineID2TickID[nEngineTickID] = nTickID
    return nTickID


def _DelTickByTickID(nTickID):
    global g_dictTickID2Callback, g_dictEngineID2TickID
    if nTickID in g_dictTickID2Callback:
        nEngineTickID = g_dictTickID2Callback[nTickID][0]
        del g_dictTickID2Callback[nTickID]
        del g_dictEngineID2TickID[nEngineTickID]
        return nEngineTickID
    return None


def _GetTickID(nEngineTickID):
    global g_dictEngineID2TickID
    return g_dictEngineID2TickID.get(nEngineTickID)


def _GetTickContent(nTickID):
    global g_dictTickID2Callback, g_dictEngineID2TickID
    if nTickID in g_dictTickID2Callback:
        return g_dictTickID2Callback[nTickID]
    return (None, None, None, None, None, None)


def GetZcTestTickInfo():
    listRetInfo = []
    for nTickID, listInfo in g_dictTickID2Callback.iteritems():
        listRetInfo.append((listInfo[1], listInfo[5]))
    return listRetInfo


def _GetAutoID():
    global g_nAutoID
    g_nAutoID += 1
    return g_nAutoID


def DumpDebugTick(limit):
    global g_bDebug
    if g_bDebug:
        global g_dictDebugTickName2Count
        l = sorted(g_dictDebugTickName2Count.iteritems(), key=lambda d: d[1], reverse=True)
        l = l[:1]
        theApp.m_Logger.info("jmjmjm DumpDebugTick %s", l)


def DumpDebugLastFrameTick():
    global g_bDebug
    if g_bDebug:
        nTotalTime = 0
        l = sorted(g_dictDebugTickName2CountOnCurFrame.iteritems(), key=lambda d: d[1][1], reverse=True)
        theApp.m_Logger.info(">>>>>>>>>>jmjmjm DumpDebugFrameTick begin<<<<<<<<<<")
        for k in l:
            nTotalTime += k[1][1]
            theApp.m_Logger.info("jmjmjm DumpDebugFrameTick (%.4f,%s,%s)", k[1][1], k[0], k[1][0])
        theApp.m_Logger.info("-----jmjmjm DumpDebugFrameTick end总时间%.4f\n", nTotalTime)


def OnDebugRegisterTick(szTickDesc, nTickID):
    global g_dictDebugTickName2Count, g_dictDebugTickID2Name
    if szTickDesc not in g_dictDebugTickName2Count:
        g_dictDebugTickName2Count[szTickDesc] = 0
    g_dictDebugTickName2Count[szTickDesc] += 1
    g_dictDebugTickID2Name[nTickID] = szTickDesc


def OnDebugUnRegisterTick(nTickID):
    global g_dictDebugTickName2Count, g_dictDebugTickID2Name
    if nTickID not in g_dictDebugTickID2Name:
        return
    g_dictDebugTickName2Count[g_dictDebugTickID2Name[nTickID]] -= 1
    del g_dictDebugTickID2Name[nTickID]


def OnDebugOnTick(szTickDesc, nTime):
    if szTickDesc not in g_dictDebugTickName2CountOnCurFrame:
        g_dictDebugTickName2CountOnCurFrame[szTickDesc] = [0, 0]
    g_dictDebugTickName2CountOnCurFrame[szTickDesc][0] += 1
    g_dictDebugTickName2CountOnCurFrame[szTickDesc][1] += nTime


def RegisterNotFixTick(szTickDesc, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    nEngineTickID = tick.RegisterNotFixTick(int(nInternvalMs), szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 0, szTickDesc)

    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)

    return nTickID


# 注册Tick，要自己手动取消
def RegisterTick(szTickDesc, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    nEngineTickID = tick.RegisterTick(int(nInternvalMs), szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 0, szTickDesc)

    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)

    return nTickID


# 注册Tick，要自己手动取消
def RegisterTickEx(szTickDesc, uBeginTime, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    nEngineTickID = tick.RegisterTickEx(uBeginTime, int(nInternvalMs), szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 0, szTickDesc)
    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)

    return nTickID


def RegisterNotFixTickEx(szTickDesc, uBeginTime, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    nEngineTickID = tick.RegisterNotFixTickEx(uBeginTime, int(nInternvalMs), szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 0, szTickDesc)
    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)

    return nTickID


def RegisterRandTickEx(szTickDesc, uBeginRandTime, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    uBeginRandTime = random.randint(1, uBeginRandTime)
    return RegisterTickEx(szTickDesc, uBeginRandTime, int(nInternvalMs), CallBack, *tParam, **dParam)


def RegisterNotFixRandTickEx(szTickDesc, uBeginRandTime, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    uBeginRandTime = random.randint(1, uBeginRandTime)
    return RegisterNotFixTickEx(szTickDesc, uBeginRandTime, int(nInternvalMs), CallBack, *tParam, **dParam)


def UnRegisterTick(nTickID):
    # app = ModApp.GetApp()
    #    ModApp.GetLogger("tick").debug("UnRegisterTick:%s,%s",nTickID,g_dictTickID2Callback[nTickID][0])
    if nTickID not in g_dictTickID2Callback:
        return

    nEngineTickID = _DelTickByTickID(nTickID)
    if nEngineTickID:
        tick.UnRegisterTick(nEngineTickID)

        global g_bDebug
        if g_bDebug:
            OnDebugUnRegisterTick(nTickID)

            # 注册一个一次性的Tick，回调后自动取消

def RegisterNotFixOnceTick(szTickDesc, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    nEngineTickID = tick.RegisterNotFixTick(int(nInternvalMs), szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 1, szTickDesc)
    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)
    return nTickID

def RegisterOnceTick(szTickDesc, nInternvalMs, CallBack, *tParam, **dParam):
    nInternvalMs = max(nInternvalMs, 1)
    # print (szTickDesc, nInternvalMs, CallBack)
    nEngineTickID = tick.RegisterTick(int(nInternvalMs), szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 1, szTickDesc)
    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)
    return nTickID


def RegisterOnceRandTick(szTickDesc, uBeginRandTime, CallBack, *tParam, **dParam):
    uBeginRandTime = random.randint(1, uBeginRandTime)
    # print (szTickDesc, nInternvalMs, CallBack)
    nEngineTickID = tick.RegisterTickEx(uBeginRandTime, 100000, szTickDesc)
    nTickID = _AddTick(nEngineTickID, CallBack, tParam, dParam, 1, szTickDesc)
    global g_bDebug
    if g_bDebug:
        OnDebugRegisterTick(szTickDesc, nTickID)
    return nTickID


def OnTickNormal(nEngineTickID):
    global g_dictEngineID2TickID
    global g_dictTickID2Callback
    nTickID = g_dictEngineID2TickID[nEngineTickID]
    if nTickID in g_dictTickID2Callback:
        nEngineTickID2, callback, tParam, dParam, nRepeat, szDescript = g_dictTickID2Callback[nTickID]
        try:
            if nRepeat == 1:
                UnRegisterTick(nTickID)
            callback(*tParam, **dParam)

        except Exception as e:
            print("************************")
            print(e)
            # ModApp.GetApp().OnGameTraceback()
    else:
        assert False, "Tick Is None"


def OnTickDebug(nEngineTickID):
    global g_dictEngineID2TickID
    global g_dictTickID2Callback
    nTickID = g_dictEngineID2TickID[nEngineTickID]
    if nTickID in g_dictTickID2Callback:
        nEngineTickID2, callback, tParam, dParam, nRepeat, szDescript = g_dictTickID2Callback[nTickID]
        try:
            if nRepeat == 1:
                UnRegisterTick(nTickID)

            bT = time.clock()
            callback(*tParam, **dParam)
            eT = time.clock()
            OnDebugOnTick(szDescript, (eT - bT) * 1000)

        except:
            theApp.OnGameTraceback()
    else:
        assert False, "Tick Is None"


def EnableDebugTick():
    global g_bDebug, OnTick
    global g_dictDebugTickName2Count
    if not g_bDebug:
        g_bDebug = True
        g_dictDebugTickName2Count.clear()
        g_dictDebugTickID2Name.clear()
        g_dictDebugTickName2CountOnCurFrame.clear()


def DisableDebugTick(nDumpLimit=100):
    global g_bDebug, g_dictDebugTickID2Name,OnTick
    if g_bDebug:
        DumpDebugTick(nDumpLimit)
        g_dictDebugTickName2Count.clear()
        g_dictDebugTickID2Name.clear()
        g_dictDebugTickName2CountOnCurFrame.clear()
        g_bDebug = False


def OnTick(nEngineTickID):
    # print("------OnTick", nEngineTickID, id(OnTick))
    if g_bDebug:
        OnTickDebug(nEngineTickID)
    else:
        OnTickNormal(nEngineTickID)


# -----------------------------------------------
def _GetFastTimeTickInMs():
    return tick._GetFastTimeTickInMs()


def _GetFastUTCTimeInSec():
    return tick._GetFastUTCTimeInSec()


def _GetFastUTCTimeInMS():
    return tick._GetFastUTCTimeInMS()


def _GetFastTimeTickInSecFloat():
    return tick._GetFastTimeTickInMs() / 1000.0


def OnUpdateFastTime():
    global g_FastTimeTickInMs, g_FastTimeTickInSecFloat, g_FastUTCTimeInSec, g_FastUTCTimeInMS
    nLastFastTimeTickInMs = g_FastTimeTickInMs
    g_FastTimeTickInMs = _GetFastTimeTickInMs()
    g_FastTimeTickInSecFloat = _GetFastTimeTickInSecFloat()
    g_FastUTCTimeInSec = _GetFastUTCTimeInSec()
    g_FastUTCTimeInMS = _GetFastUTCTimeInMS()

    return g_FastTimeTickInMs - nLastFastTimeTickInMs


def ClearDebugData():
    global g_bDebug, g_dictDebugTickName2CountOnCurFrame
    if g_bDebug:
        g_dictDebugTickName2CountOnCurFrame.clear()


# -----------------------------------------------------------------------
# 返回：从UTC时间1970年1月1日午夜(00:00:00)起累计的时间
def GetUTCTimeInSec():
    return tick._GetUTCTimeInSec()


def GetUTCTimeInMS():
    return tick._GetUTCTimeInMS()


# 获取程序启动到现在所经过的时间
def GetTimeTickInMS():
    return tick._GetTimeTickInMS()


# --------------------------------------
# fast time
def GetFastTimeTickInMs():
    # assert g_FastTimeTickInMs==_GetFastTimeTickInMs()
    return g_FastTimeTickInMs


def GetFastUTCTimeInSec():
    # assert g_FastUTCTimeInSec==_GetFastUTCTimeInSec()
    return g_FastUTCTimeInSec


def GetFastUTCTimeInMS():
    # assert g_FastUTCTimeInMS == _GetFastUTCTimeInMS()
    return g_FastUTCTimeInMS


def GetFastTimeTickInSecFloat():
    # assert  g_FastTimeTickInSecFloat == _GetFastTimeTickInSecFloat()
    return g_FastTimeTickInSecFloat

def Init():
    nFramRatio = 30
    bInit = tick.InitTickMgr(OnTick, OnUpdateFastTime, nFramRatio)
    print("---------tick_mgr Init---------", bInit)

Init()

