# -*- coding: utf-8 -*-

import __builtin__
import sys
import types
from gac_gas.common.singleton import singleton
from gac_gas.common.enum_def import LanguageType

# 默认语言
DEFAULT_LANG = LanguageType.CN

# 默认字符串
DEFAULT_STRING = "missing:{}"

# 字符串配置表路径
STRING_RESOURCE_CONFIG_PATH = "config.setting.string_resource.{}"


# 字符串管理器
@singleton
class StringResourceMgr(object):
    def __init__(self):
        self.m_dictID2String = {}
        self.m_szLocalLang = DEFAULT_LANG

    def Init(self):
        self.m_szLocalLang = self.GetCfgLang()
        self.CacheAllTable()

    def GetLocalLang(self):
        return self.m_szLocalLang

    def GetCfgLang(self):
        return theApp.m_FileSaveMgr.GetClientData("local_lang", DEFAULT_LANG)

    def SaveCfgLang(self):
        theApp.m_FileSaveMgr.SaveClientData("local_lang", self.m_szLocalLang)

    def CacheAllTable(self):
        self.m_dictID2String = {}

        import config.setting.string_resource.string_resource_common as string_resource_common
        for dictCfgInfo in string_resource_common.string_resource_common.itervalues():
            szTableName = dictCfgInfo["表名"]
            szTablePath = STRING_RESOURCE_CONFIG_PATH.format(szTableName)

            module = sys.modules.get(szTablePath, None)
            if not module:
                __import__(szTablePath)
            else:
                reload(module)

            module = sys.modules[szTablePath]
            if not module:
                continue

            dictTableCfgInfo = getattr(module, szTableName)
            if not dictTableCfgInfo:
                continue

            for nStringID, dictInfo in dictTableCfgInfo.iteritems():
                assert nStringID not in self.m_dictID2String, "配置字符串ID重复:{}:{}".format(szTableName, nStringID)
                self.m_dictID2String[nStringID] = dictInfo.get(self.m_szLocalLang, DEFAULT_STRING.format(nStringID))

    def UpdateLocalLang(self, szLocalLang):
        if self.m_szLocalLang == szLocalLang:
            return False

        self.m_szLocalLang = szLocalLang
        self.SaveCfgLang()
        self.CacheAllTable()
        return True

    def GetString(self, nStringID, *args):
        if isinstance(nStringID, types.StringTypes):
            szContent = self.m_dictID2String.get(nStringID, nStringID)
        else:
            szContent = self.m_dictID2String.get(nStringID, DEFAULT_STRING.format(nStringID))

        if isinstance(szContent, unicode):
            szContent = szContent.encode("utf-8")

        if args:
            largs = list(args)
            for i in xrange(len(largs)):
                if isinstance(largs[i], unicode):
                    largs[i] = largs[i].encode("utf-8")
                elif isinstance(largs[i], list):
                    largs[i] = self.GetString(largs[i][0])
            try:
                szContent = szContent.format(*largs)
            except:
                print("提示消息出错:{}, {}, {}".format(nStringID, szContent, args))
                assert False, "msg_id error:{}".format(nStringID)

        return szContent

# --------------------------------------------------------------------------------------------------
# 导出函数
StringResourceMgrObj = StringResourceMgr()
Init = StringResourceMgrObj.Init
UpdateLocalLang = StringResourceMgrObj.UpdateLocalLang
CacheAllTable = StringResourceMgrObj.CacheAllTable
GetLocalLang = StringResourceMgrObj.GetLocalLang


# 注册T_函数
__builtin__.T_ = StringResourceMgrObj.GetString
