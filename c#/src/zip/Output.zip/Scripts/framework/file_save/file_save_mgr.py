# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
from gac_gas.common.singleton import singleton


@singleton
class FileSaveMgr(object):
    def __init__(self):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_szSavePath = "db.json"

    def Init(self, dictConfig):
        import YTGameFramework
        self.m_szSavePath = YTGameFramework.YTUtils.GetCWD() + "/" + dictConfig["save_file"]

    # 加载数据
    def LoadData(self, szTable, szSearchKey, check_value):
        from tinydb import TinyDB, where
        db = TinyDB(self.m_szSavePath)
        tbl_setting = db.table(szTable)
        listData = tbl_setting.search(where(szSearchKey) == check_value)
        tbl_setting.close()
        db.close()
        db._table_cache.clear()
        return listData

    # 获取玩家数据
    def GetPlayerData(self, nID, szKey, default=None):
        listData = self.LoadData("tbl_player_setting", "id", nID)
        if listData:
            return listData[0].get(szKey, default)
        return default

    # 获取客户端数据
    def GetClientData(self, szKey, default=None):
        listData = self.LoadData("tbl_client_setting", "client", "client")
        if listData:
            return listData[0].get(szKey, default)
        return default

    # 保存数据
    def SaveData(self, szTable, szSearchKey, check_value, szKey, data):
        from tinydb import TinyDB, where
        db = TinyDB(self.m_szSavePath)
        tbl_setting = db.table(szTable)
        listData = tbl_setting.search(where(szSearchKey) == check_value)
        if listData:
            tbl_setting.update({szKey: data}, where(szSearchKey) == check_value)
            self.m_Logger.info("SaveData update:{},{},{},{}".format(szTable, check_value, szKey, data))
        else:
            tbl_setting.insert({szSearchKey: check_value, szKey: data})
            self.m_Logger.info("SaveData insert:{},{},{},{}".format(szTable, check_value, szKey, data))
        tbl_setting.close()
        db.close()
        db._table_cache.clear()

    # 保存玩家数据
    def SavePlayerData(self, nID, szKey, data):
        self.SaveData("tbl_player_setting", "id", nID, szKey, data)

    # 保存客户端数据
    def SaveClientData(self, szKey, data):
        self.SaveData("tbl_client_setting", "client", "client", szKey, data)
