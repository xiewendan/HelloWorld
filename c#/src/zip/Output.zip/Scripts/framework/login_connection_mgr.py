# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
from connection.connection_wrapper import client


# 客户端连接管理器
class LoginConnectionMgr(object):
    def __init__(self):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_LoginClientObj = None

    def Init(self, bNeedEncryption):
        def OnConnectCallback(ConnObj):
            self.m_Logger.info("login连接成功:{}".format(ConnObj.GetRemoteInfo()))

        def OnConnectFailedCallback(ConnObj):
            self.m_Logger.info("login连接失败:{}".format(ConnObj and ConnObj.GetRemoteInfo()))

            from logic.game_state.state_def import EGameEvent
            import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
            game_state_machine_mgr.ProcessEvent(EGameEvent.LOGIN_CONNECT_FAILED)

        def OnDisConnectedCallback(ConnObj):
            self.m_Logger.info("login连接断开:{}".format(ConnObj and ConnObj.GetRemoteInfo()))

            from logic.game_state.state_def import EGameEvent
            import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
            game_state_machine_mgr.ProcessEvent(EGameEvent.LOGIN_DISCONNECT)

            theApp.OnLoginDisconnected()

        import login_in_gac as login_in_gac
        import connection.login_connection as login_connection
        import gac_gas.connection.connection_help as connection_help
        dictConnectionArgs = connection_help.CreateConnectionArgs(
            szConnectionName="gac for login",
            nConnMaxOutBufSize=2 * 1024 * 1024,
            nConnMaxInBufSize=2 * 1024 * 1024,
            bKeepAlive=True,
            nCheckAliveInterval=10000,
            nCheckAliveTimeout=-1,
            funConnectCallback=OnConnectCallback,
            funConnectFailCallback=OnConnectFailedCallback,
            funDisConnectCallback=OnDisConnectedCallback,
            EntityClass=login_in_gac.LoginInGac,
            ConnectionClass=login_connection.LoginConnection,
            bNeedEncryption=bNeedEncryption
        )
        self.m_LoginClientObj = client.Client(dictConnectionArgs)

    def Connect(self, szIP, nPort):
        self.m_Logger.info("连接login:{},{}".format(szIP, nPort))

        try:
            self.m_LoginClientObj.Connect(szIP, nPort)
        except:
            self.m_Logger.error("登陆失败:({}:{})".format(szIP, nPort))

    def Destroy(self):
        if self.m_LoginClientObj:
            self.m_LoginClientObj.Destroy()
            self.m_LoginClientObj = None