# -*- coding: utf-8 -*-

import client_rpc_wrapper as client_rpc_wrapper
import gac_gas.entity.base_entity as base_entity
import logic.game_entity.gac_game_entity_mgr as gac_game_entity_mgr
import gac_gas.entity.entity_interface as entity_interface
from gac_gas.common.enum_def import EEntityAvatarMsgType


class BatInGac(base_entity.BaseEntity):
    def __init__(self):
        super(BatInGac, self).__init__()
        self.m_BatRpcObj = client_rpc_wrapper.RpcWrapperGac2BatEntity()

    def Destroy(self, bNow=False):
        if self.m_BatRpcObj:
            self.m_BatRpcObj.Destroy()
            self.m_BatRpcObj = None

        super(BatInGac, self).Destroy(bNow=bNow)

    def GetBatRpc(self):
        return self.m_BatRpcObj

    def GAMEOBJMSG(self, _, szMethodName, args, szGID, listSubMethodName):
        if theApp.GetSceneMgr().IsLoading():
            theApp.GetSceneMgr().OnOBJMSG(self.GAMEOBJMSG, (_, szMethodName, args, szGID, listSubMethodName))
            return

        Obj = gac_game_entity_mgr.GetObjByGlobalID(szGID)
        if Obj:
            if listSubMethodName:
                for szSubMethodName in listSubMethodName:
                    Obj = getattr(Obj, szSubMethodName)()
                getattr(Obj, szMethodName)(*args)
            else:
                getattr(Obj, szMethodName)(*args)
        else:
            if gac_game_entity_mgr.GetMainPlayer() is None:
                self.m_Logger.error("miss rpc :%s,%s,%s", szMethodName, szGID, args)

    def SCENEMSGSELF(self, _, szMethodName, args):
        getattr(self, szMethodName)(*args)

    def RecvMsgCache(self, listMsgCache):
        for szMsg in listMsgCache:
            if szMsg[0] is EEntityAvatarMsgType.GAMEOBJMSG:
                self.GAMEOBJMSG(*szMsg)
            elif szMsg[0] is EEntityAvatarMsgType.SCENEMSGSELF:
                self.SCENEMSGSELF(*szMsg)

    def RRpcGetPlayer(self):
        return gac_game_entity_mgr.GetMainPlayer()

    def RRpcGetScene(self):
        Player = gac_game_entity_mgr.GetMainPlayer()
        if Player:
            return entity_interface.InfoCmp_GetScene(Player)

    # qc使用, 打印
    def QcPrint(self, szMsg):
        print szMsg

    # ---------------------------------------对象系统------------------------------------------------------
    def CreateGameObj(self, dictData, szGID):
        if theApp.GetSceneMgr().IsLoading():
            theApp.GetSceneMgr().OnOBJMSG(self.CreateGameObj, (dictData, szGID))
            # theApp.GetSceneMgr().OnCreateGameObj(dictData, szGID)
            return

        import logic.game_entity.gac_game_entity_factory as gac_game_entity_factory
        Obj = gac_game_entity_mgr.GetObjByGlobalID(szGID)
        if Obj:
            # TODO: 如果存在,先不处理了
            return

        if not Obj:
            gac_game_entity_factory.CreateEntity(dictData)

    def DeleteGameObj(self, szGID):
        if theApp.GetSceneMgr().IsLoading():
            # theApp.GetSceneMgr().OnDeleteGameObj(szGID)
            theApp.GetSceneMgr().OnOBJMSG(self.DeleteGameObj, (szGID))
            return

        Obj = gac_game_entity_mgr.GetObjByGlobalID(szGID)
        if Obj:
            Obj.Destroy()
