# -*- coding: utf-8 -*-

import client_rpc_wrapper as client_rpc_wrapper
import gac_gas.entity.base_entity as base_entity
import framework.tick_mgr as tick_mgr
import logic.game_state.game_state_machine_mgr as game_state_machine_mgr
import logic.game_entity.gac_game_entity_mgr as gac_game_entity_mgr
import gac_gas.entity.entity_interface as entity_interface
from gac_gas.common.enum_def import EEntityAvatarMsgType
from logic.game_state.state_def import EGameEvent


class GasInGac(base_entity.BaseEntity):
    def __init__(self):
        super(GasInGac, self).__init__()
        self.m_GasRpcObj = client_rpc_wrapper.RpcWrapperGac2GasEntity()

        self.m_AccountEntity = None

        self.RequestHotFix()

    def Destroy(self, bNow=False):
        if self.m_AccountEntity:
            self.m_AccountEntity.Destroy(bNow)
            self.m_AccountEntity = None

        if self.m_GasRpcObj:
            self.m_GasRpcObj.Destroy()
            self.m_GasRpcObj = None

        # 清除玩家
        Player = gac_game_entity_mgr.GetMainPlayer()
        if Player:
            Player.Destroy()

        super(GasInGac, self).Destroy(bNow=bNow)

    def GetGasRpc(self):
        return self.m_GasRpcObj

    # region Description : 登陆相关 --------------------------------------------------------------------------------------

    def GetAccount(self):
        return self.m_AccountEntity

    def RequestHotFix(self):
        self.GetGasRpc().RequestHotFix(1)

    def OnRequestHotFix(self):
        self.CheckDevice()

    def CheckDevice(self):
        # 在login之前先检查设备是否被拉黑
        self.GetGasRpc().RequestCheckDevice(theApp.GetAccountUid(), "", "")

    def OnDeviceOK(self):
        self.m_Logger.info("设置检查通过。")
        self.RequestLogin()

    def OnDeviceError(self):
        self.m_Logger.info("该设备当前已被禁止登录，详情登陆客服专区咨询。")
        print("该设备当前已被禁止登录，详情登陆客服专区咨询。")

    def LoginSuccess(self):
        self.m_Logger.info("登陆成功")
        game_state_machine_mgr.ProcessEvent(EGameEvent.CHECK_ACCOUNT_SUCCESS)

    def LoginFailed(self, szMessage):
        self.m_Logger.error("登陆失败: {}".format(szMessage))
        game_state_machine_mgr.ProcessEvent(EGameEvent.CHECK_ACCOUNT_FAILED)

    def WaitQueueIsFull(self):
        self.m_Logger.info("排队队列已满")
        game_state_machine_mgr.ProcessEvent(EGameEvent.WAITQUEUE_FULL)

    def IntoWaitQueue(self):
        # 进入排队状态
        game_state_machine_mgr.ProcessEvent(EGameEvent.INTO_WAITQUEUE)

    def UpdateWaitOrder(self, nPos, szGMMsg=None):
        print("你正处于排队系统的第{0}位，请耐心等待。".format(nPos))

    def WaitQueueInRepet(self):
        self.m_Logger.info("排队中还被顶号鸟")
        game_state_machine_mgr.ProcessEvent(EGameEvent.WAITQUEUE_REPET)

    def AccountInRepet(self):
        # 被顶号啦
        self.m_Logger.info("该账号已在其他地方登陆.")
        game_state_machine_mgr.ProcessEvent(EGameEvent.IN_REPET)

    def AccountRepetSuccess(self):
        # 服务器通知旧登陆已经退出，顶号成功
        self.m_Logger.info("收到顶号成功的通知，继续走登陆流程")
        game_state_machine_mgr.ProcessEvent(EGameEvent.REPET_SUCCESS)

    def AccountRepetFailed(self):
        # 登陆出现顶号，但顶号失败
        self.m_Logger.info("服务器回复顶号失败.")
        game_state_machine_mgr.ProcessEvent(EGameEvent.REPET_FAILED)

    def ToWaitReptCallBack(self):
        # 等待旧登陆退出
        self.m_Logger.info("顶号啦，等待旧登陆退出.")
        game_state_machine_mgr.ProcessEvent(EGameEvent.WAIT_REPET)

    def RequestLogin(self):
        self.m_Logger.info("向服务发送上线请求")
        szUid, szToken = theApp.GetAccountLoginInfo()
        self.GetGasRpc().RequestLogin(szUid, szToken)

    def CreateAccount(self, szEntityID, dictData):
        import logic.game_entity.gac_account as gac_account
        self.m_AccountEntity = gac_account.GacAccount(self, szEntityID)
        self.m_AccountEntity.init_from_dict(dictData)

        # 这里上传客户端的额外信息给服务器
        self.UploadClientInfo()

        game_state_machine_mgr.ProcessEvent(EGameEvent.FINISH_CREATE_ACCOUNT)

    def UploadClientInfo(self):
        # 上传客户端的相关信息给服务器
        self.GetGasRpc().UploadClientInfo({})

    def SendAccountMsg(self, szMethodName, args):
        self.GetGasRpc().ProxyMsg4Account(szMethodName, args)

    def ReceiveAccountMsg(self, data):
        self.m_AccountEntity.OnPbxMsg(data)

    def CanAutoReconnect(self, bValue):
        theApp.CanAutoReconnect(bValue)

    # endregion

    def GAMEOBJMSG(self, _, szMethodName, args, szGID, listSubMethodName):
        if theApp.GetSceneMgr().IsLoading():
            theApp.GetSceneMgr().OnOBJMSG(self.GAMEOBJMSG, (_, szMethodName, args, szGID, listSubMethodName))
            return

        Obj = gac_game_entity_mgr.GetObjByGlobalID(szGID)
        if Obj:
            if listSubMethodName:
                for szSubMethodName in listSubMethodName:
                    Obj = getattr(Obj, szSubMethodName)()
                getattr(Obj, szMethodName)(*args)
            else:
                getattr(Obj, szMethodName)(*args)
        else:
            if gac_game_entity_mgr.GetMainPlayer() is None:
                self.m_Logger.error("miss rpc :%s,%s,%s", szMethodName, szGID, args)

    def SCENEMSGSELF(self, _, szMethodName, args):
        getattr(self, szMethodName)(*args)

    def RecvMsgCache(self, listMsgCache):
        for szMsg in listMsgCache:
            if szMsg[0] is EEntityAvatarMsgType.GAMEOBJMSG:
                self.GAMEOBJMSG(*szMsg)
            elif szMsg[0] is EEntityAvatarMsgType.SCENEMSGSELF:
                self.SCENEMSGSELF(*szMsg)

    def CreateMainPlayer(self, dictData):
        self.m_Logger.info("服务通知创建玩家角色")
        import logic.game_entity.gac_game_entity_factory as gac_game_entity_factory
        gac_game_entity_factory.CreateEntity(dictData)

    def RRpcGetPlayer(self):
        return gac_game_entity_mgr.GetMainPlayer()

    def RRpcGetScene(self):
        Player = gac_game_entity_mgr.GetMainPlayer()
        if Player:
            return entity_interface.InfoCmp_GetScene(Player)

    # qc使用, 打印
    def QcPrint(self, szMsg):
        print szMsg

    # ---------------------------------------测试gas------------------------------------------------------

    def Test(self):
        self.m_Logger.info("发送测试RPC")
        self.GetGasRpc().GacTest(1, 3, 4)

    def GasTest(self, a, b, c):
        self.m_Logger.info("GasTest {}, {}, {}".format(a, b, c))

    def TestTick(self):
        self.m_TickTest = tick_mgr.RegisterTick("xxxxx", 3000, self.OnTestTick)
        self.m_nCount = 0

    def OnTestTick(self):
        self.m_nCount += 1
        if self.m_nCount >= 10:
            if self.m_TickTest:
                tick_mgr.UnRegisterTick(self.m_TickTest)
                self.m_TickTest = None
        else:
            self.m_Logger.info("发送测试RPC")
            self.GetGasRpc().GacTest(1, 3, self.m_nCount)
