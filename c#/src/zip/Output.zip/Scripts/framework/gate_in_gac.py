# -*- coding: utf-8 -*-

import gac_gas.entity.base_entity as base_entity


class GateInGac(base_entity.BaseEntity):
    def __init__(self):
        super(GateInGac, self).__init__()
        self.m_szGacInGateID = None

    def OnConnCome(self):
        self.m_Logger.info("GateInGac come.")
        self.CheckConfirm()

    def OnConnLost(self):
        self.m_Logger.info("GateInGac lost.")

        theApp.OnGateOut(self)

    def OnCheckConfirm(self, szID):
        self.m_szGacInGateID = szID

        theApp.OnGateCome(self)

    def CheckConfirm(self):
        # 连上后需要调用这个rpc发送消息给服务器，然后继续走流程，否则会被踢
        self.m_Logger.info("向gate发送确认")
        self.GetPeerEntityRpc().CheckConfirm(theApp.m_szTargetServerName)

    def RegGasInGac(self, szServerName):
        self.m_Logger.info("RegGasInGac {}".format(szServerName))
        theApp.GetGasRpc().UnBlock()
        self.GetPeerEntityRpc().OnRegGasInGac(szServerName)

    def UnRegGasInGac(self, szServerName):
        self.m_Logger.info("UnRegGasInGac {}".format(szServerName))
        self.GetPeerEntityRpc().OnUnRegGasInGac(szServerName)
        theApp.GetGasRpc().Block()

    def RegBatInGac(self, szServerName):
        self.m_Logger.info("RegBatInGac {}".format(szServerName))
        theApp.GetBatRpc().UnBlock()
        self.GetPeerEntityRpc().OnRegBatInGac(szServerName)

    def UnRegBatInGac(self, szServerName):
        self.m_Logger.info("UnRegBatInGac {}".format(szServerName))
        self.GetPeerEntityRpc().OnUnRegBatInGac(szServerName)
        theApp.GetBatRpc().Block()

    # ---------------------------------------测试gate------------------------------------------------------
    def Test(self):
        self.m_Logger.info("发送测试RPC")
        self.GetPeerEntityRpc().GacTest(1, 3, 4)

    def GateTest(self, a, b, c):
        self.m_Logger.info("GateTest {}, {}, {}".format(a, b, c))

    # ---------------------------------------测试gas------------------------------------------------------
    def TryGasTest(self):
        theApp.GetGasInGac().Test()

    # ---------------------------------------测试Tick------------------------------------------------------
    def TryTickTest(self):
        theApp.GetGasInGac().TestTick()
