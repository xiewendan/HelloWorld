# -*- coding: utf-8 -*-

import math
import math3d

# 三角形变换公式
# 根据点A和点B，和点P，求出点P到线段AB的垂线距离
# 如果是锐角三角形和直角三角形，则返回垂线距离，如果是钝角三角形，则返回None
# A.B = |A||B|cos x, x 是A和B之间的夹角
'''
        A-------------O---------------B
                      |
                      |   （返回值PO：垂线距离）
                      |
                      P
'''


def GetVerticalLineDist(PointA, PointB, PointP):
    VecBA = (PointB - PointA)
    VecPA = (PointP - PointA)
    VecPB = (PointP - PointB)

    if VecBA.length <= 2:
        return (PointA - PointP).length
    if VecPA.length <= 2:
        return 0
    if VecPB.length <= 2:
        return 0

    nPALen = VecPA.length
    VecBA.normalize()
    VecPA.normalize()

    # VecBA = ( PointB - PointA ).normalize()
    # VecPA = ( PointP - PointA ).normalize()
    # print(VecBA, VecPA, ( PointB - PointA ) )

    fAngle1 = VecBA.dot(VecPA)
    if fAngle1 > 1:
        fAngle1 = 1
    elif fAngle1 < -1:
        fAngle1 = -1
    nAngle1 = math.acos(fAngle1)
    if nAngle1 > math.pi / 2:
        return None

    VecAB = VecBA * -1

    VecPB.normalize()

    fAngle2 = VecAB.dot(VecPB)
    if fAngle2 > 1:
        fAngle2 = 1
    elif fAngle2 < -1:
        fAngle2 = -1
    nAngle2 = math.acos(fAngle2)
    if nAngle2 > math.pi / 2:
        return None

    tRetCos = VecBA.cross(VecPA)
    nRetCross = tRetCos.y
    if nRetCross < 0:
        nRetCross = -1
    elif nRetCross > 0:
        nRetCross = 1
    # ！！！ 如果点P在线段AB的左边就返回负数，否则返回正数
    return math.sin(nAngle1) * nPALen * nRetCross


# Pos1绕着原点旋转nRotateAngle后的坐标
# 1 采用右手坐标系，逆时针方向为正
# 2 nRotateAngle位0~360度
def GetVectorByRotate(Pos1, nRotateAngle):
    NewPos = math3d.vector(0, 0, 0)

    nRotateRadius = math.radians(nRotateAngle)
    NewPos.x = Pos1.x * math.cos(nRotateRadius) - Pos1.z * math.sin(nRotateRadius)
    NewPos.z = Pos1.x * math.sin(nRotateRadius) + Pos1.z * math.cos(nRotateRadius)
    return NewPos


# 等比缩放某个区域的对象放到另外一个区域
# 返回值：DefPos从Rect1映射到Rect2的坐标
#      `^`       |````````````````````````````|                                         _
#       |        |     O1(DefPos)             |              |``o1````````````|         |
#  Rect1SideLen  ·(AtkPos)          O3       |      ------> |           o3   |     Rect2SideLen
#       |        |                            |              |        o2      |         |
#       |        |              O2            |              ``````````````````         -
#      ___       ``````````````````````````````
#                <----------Rect1FrontLen----->              <--Rect2FrontLen->
#                <--------------------HitBackDist----------->|

#             p4                               p3
#               |``````````````````````````````|
#               |                              |
#               |                              |
#               |______________________________|
#              p1                              p2
def ScaleRectObj2AnotherRect(AtkPos, nFrontDir, DefPos, nHitBackDist, nRect1SideLen, nRect1FrontLen, nRect2SideLen, nRect2FrontLen):
    nHitBackDist, nRect1SideLen, nRect1FrontLen, nRect2SideLen, nRect2FrontLen = float(nHitBackDist), float(nRect1SideLen), float(nRect1FrontLen), float(
            nRect2SideLen), float(nRect2FrontLen)
    # CalcPos 是将AtkPos作为原点，DefPos相对于AtkPos进行计算的点
    CalcPos = DefPos - AtkPos
    CalcPos = GetVectorByRotate(CalcPos, -nFrontDir)
    # print ("1111111111",AtkPos, nFrontDir, DefPos, nHitBackDist, nRect1SideLen, nRect1FrontLen, nRect2SideLen, nRect2FrontLen)
    Rect1_p1 = math3d.vector(0, 0, -nRect1SideLen / 2)
    Rect1_p2 = math3d.vector(nRect1FrontLen, 0, -nRect1SideLen / 2)
    Rect1_p4 = math3d.vector(0, 0, nRect1SideLen / 2)

    if GetVerticalLineDist(Rect1_p1, Rect1_p2, CalcPos) is None or GetVerticalLineDist(Rect1_p1, Rect1_p4, CalcPos) is None:
        return None, None
    # print ("22222222",CalcPos)
    NewAtkPos = math3d.vector(nHitBackDist, 0, 0)
    MapPoint = math3d.vector(0, 0, 0)
    MapPoint.x = CalcPos.x / nRect1FrontLen * nRect2FrontLen
    MapPoint.z = CalcPos.z / nRect1SideLen * nRect2SideLen
    # print ("333333333333",MapPoint)
    MapPoint = GetVectorByRotate(MapPoint + NewAtkPos, nFrontDir)
    NewAtkPos = MapPoint + AtkPos
    return NewAtkPos, CalcPos


def ScaleCircleObj2AnotherCircle(AtkPos, nFrontDir, DefPos, nHitBackDist, nCircleRadius1, nCircleRadius2):
    CalcPos = DefPos - AtkPos
    CalcPos = GetVectorByRotate(CalcPos, -nFrontDir)
    # print("1111111111'", DefPos, AtkPos, CalcPos)
    MapPoint = CalcPos * (float(nCircleRadius2) / nCircleRadius1)
    MapPoint.x += nHitBackDist
    MapPoint = GetVectorByRotate(MapPoint, nFrontDir)
    NewAtkPos = MapPoint + AtkPos
    return NewAtkPos, CalcPos


def GetDirValueByVector(nX, nZ):
    vecTmp = math3d.vector(nX, 0, nZ)
    if vecTmp.is_zero:
        return 0
    # 不归一化的话精度不准确
    vecTmp.normalize()
    vecTmp.z = min(1, max(vecTmp.z, -1))
    fRadius = math.acos(vecTmp.z)
    if nX < 0:
        fRadius = -fRadius
    fAngle = int(math.degrees(fRadius))
    if fAngle < 0:
        fAngle += 360
    return fAngle


g_AllDirVector = {}
for nDir in xrange(0, 360):
    nRadians = math.radians(nDir)
    g_AllDirVector[nDir] = math3d.vector(math.cos(nRadians), 0, math.sin(nRadians))


def GetMath3dVectorByDir(nDir):
    global g_AllDirVector
    nDir %= 360
    return g_AllDirVector[nDir]


# 获得圆形半径内的随机位置:自身圆形内随机
def GetCircelInsideRandomPos(Pos, nCircleRadius):
    import random
    nRadomAngle = math.radians(random.randint(0, 359))
    PosDistDir = math3d.vector(math.cos(nRadomAngle), 0, math.sin(nRadomAngle))
    NewPos = Pos + PosDistDir * random.randint(0, nCircleRadius)
    return NewPos


# 获得圆形半径上的随机位置:自身圆形边缘随机
def GetCircleEdgeRandomPos(Pos, nCircleRadius, nAngle=None):
    import random
    if nAngle is not None:
        nRadomAngle = math.radians(nAngle)
    else:
        nRadomAngle = math.radians(random.randint(0, 359))
    PosDistDir = math3d.vector(math.cos(nRadomAngle), 0, math.sin(nRadomAngle))
    NewPos = Pos + PosDistDir * nCircleRadius
    return NewPos


def GetCircleEdgeAveragePos(Pos, nCircleRadius, nRandomBegineAngle, nCurIndex, nTotalIndex):
    nRadomAngle = math.radians(360 * (nCurIndex - 1) / nTotalIndex + nRandomBegineAngle)
    PosDistDir = math3d.vector(math.cos(nRadomAngle), 0, math.sin(nRadomAngle))
    NewPos = Pos + PosDistDir * nCircleRadius
    return NewPos


# 获得矩形范围内的随机位置
#      `^`       |````````````````````````````|
#       |        |                            |
#  nRectWidth    ·--->nFrontDir              |
#       |        |                            |
#       |        |                            |
#      ___       ``````````````````````````````
#                |---------nRectHeight--------|
def GetSelfFrontRectRandomPos(Pos, nFrontDir, nRectWidth, nRectHeight):
    # 左侧
    import random
    if random.randint(0, 1) == 0:
        nRadians = math.radians(nFrontDir + 90)  # 左半侧
    else:
        nRadians = math.radians(nFrontDir - 90)  # 右半侧
    PosDistDir = math3d.vector(math.cos(nRadians), 0, math.sin(nRadians))
    NewPos = Pos + PosDistDir * random.randint(0, int(nRectWidth / 2))

    nRadians = math.radians(nFrontDir)
    PosDistDir = math3d.vector(math.cos(nRadians), 0, math.sin(nRadians))
    NewPos = NewPos + PosDistDir * random.randint(0, int(nRectHeight))
    return NewPos


# 身前直线 + 左右偏移
#                |---------nDistance----------| Left < 0
#             Obj·--->nFrontDir--------------X
#                |---------nDistance----------| Right > 0
def GetSelfFrontPos(Pos, nFrontDir, nDistance, nLeftOrRight=None):
    nRad = math.radians(nFrontDir)
    PosDistDir = math3d.vector(math.cos(nRad), 0, math.sin(nRad))
    NewPos = Pos + PosDistDir * nDistance

    if nLeftOrRight:
        nRad = math.radians(nFrontDir - 90)
        PosDistDir = math3d.vector(math.cos(nRad), 0, math.sin(nRad))
        NewPos += PosDistDir * nLeftOrRight

    return NewPos


# 获取两个欧拉角最小夹角(返回值为正数)
def GetMinAngle(a0, a1):
    angle = 0

    if a1 >= 270 and a0 < 90:
        angle = abs(a1 - (a0 + 360)) % 180
    elif a1 <= 90 and a0 >= 270:
        angle = abs(a1 + 360 - a0) % 180
    else:
        angle = abs(a1 - a0)
        if angle > 180:
            angle = abs(angle - 360)

    return angle
