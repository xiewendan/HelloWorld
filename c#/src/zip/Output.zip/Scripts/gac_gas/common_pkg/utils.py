# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import math
import time
import gac_gas.common.enum_def as enum_def
from gac_gas.common.enum_def import TeamMemberDataType


try:
    import UnityEngine

    IS_CLIENT_PLATFORM = True

    # 获取当前时间
    GetCurTime = time.time

    # 通过GID获取对象
    import logic.game_entity.gac_game_entity_mgr as gac_game_entity_mgr

    GetObjByGlobalID = gac_game_entity_mgr.GetObjByGlobalID

except:
    IS_CLIENT_PLATFORM = False

    # 获取当前时间
    GetCurTime = time.time

    # 通过GID获取对象
    import gac_gas.entity.entity_mgr as entity_mgr

    GetObjByGlobalID = entity_mgr.GetEntity


def DetourQueryCircle(scene, x, y, z, radius):
    if IS_CLIENT_PLATFORM:
        assert False
    else:
        import pyposition.PyPositionSystem.position_system_utils as position_system_utils
        detour_id = scene.GetScenePosIdx().m_nDetourWorldId
        return position_system_utils.CrowdEngineQuery(detour_id, x, y, z, radius)


def DetourFindRandomNav(scene, x, y, z, radius):
    if IS_CLIENT_PLATFORM:
        assert False
    else:
        import math3d
        import pyposition.PyPositionSystem.position_system_utils as position_system_utils
        detour_id = scene.GetScenePosIdx().m_nDetourWorldId
        pos = position_system_utils.CrowdFindRandom(
                detour_id, x, y, z, radius)
        if pos:
            pos = math3d.vector(*pos)
        return pos


def DetourFindNearestNav(scene, x, y, z, filter):
    import pyposition.PyPositionSystem.position_system_utils as position_system_utils
    import math3d

    detour_id = scene.GetScenePosIdx().m_nDetourWorldId
    bInNav = position_system_utils.CrowdInNav(
            detour_id, math3d.vector(x, y, z), math3d.vector(0, 0.2, 0), filter)
    if not bInNav:
        ret = position_system_utils.CrowdFindNearest(detour_id, math3d.vector(x, y, z),
                                                     math3d.vector(enum_def.EDetourParam.eExtWidth,
                                                                   enum_def.EDetourParam.eExtHeight,
                                                                   enum_def.EDetourParam.eExtWidth), filter)
        if not ret:
            print("CANT FIND POS:", x, y, z)
            return None
        print("FIND NEAREST:", x, y, z, ret[0], ret[1], ret[2])
        x, y, z = ret
    else:
        print("POS IN NAV:", x, y, z)

    return math3d.vector(x, y, z)


def DetourChangeNavFlag(scene, x, y, z, extx, exty, extz, flag):
    if IS_CLIENT_PLATFORM:
        return False
    else:
        detour_id = scene.GetScenePosIdx().m_nDetourWorldId
        QueryFlag = enum_def.EDetourFilterConfig.eElement
        NewFlag = flag | enum_def.EDetourFilterConfig.eElement
        import pyposition.PyPositionSystem.position_system_utils as position_system_utils
        return position_system_utils.CrowdEngineChangeFlag(detour_id, x, y, z, extx, exty, extz, QueryFlag, NewFlag)


# 计算两点间二维距离
def Cal2PosDistance(Pos1, Pos2):
    delta = Pos1 - Pos2
    delta.y = 0
    return delta.length


# 计算两点间二维距离
def Cal2PosDistanceEx(tuplePos1, tuplePos2):
    return math.sqrt(math.pow(tuplePos1[0] - tuplePos2[0], 2) + math.pow(tuplePos1[2] - tuplePos2[2], 2))


# 计算两点间的三维距离
def Cal3PosDistance(Pos1, Pos2):
    delta = Pos1 - Pos2
    return delta.length


# 计算两点间的三维距离
def Cal3PosDistanceEx(tuplePos1, tuplePos2):
    return math.sqrt(math.pow(tuplePos1[0] - tuplePos2[0], 2) + math.pow(tuplePos1[1] - tuplePos2[1], 2) + math.pow(
            tuplePos1[2] - tuplePos2[2], 2))


def RemoveGameObj(GameObj):
    import gac_gas.entity.entity_interface as entity_interface
    SceneObj = entity_interface.InfoCmp_GetScene(GameObj)
    if SceneObj:
        SceneObj.LateDestroyObj(GameObj)
    else:
        GameObj.Destroy()


def CameraSetActive(Index):
    if IS_CLIENT_PLATFORM:
        import UnityEngine
        import CommonController
        CommonScriptObj = UnityEngine.GameObject.Find(enum_def.ECommonScriptParam.eGlobalScriptObj)
        CameraController = CommonScriptObj.GetComponent(CommonController.CameraControl)
        CameraController.UsingCamera(Index)


def MouseDetectSkyEnable(bEnable):
    if IS_CLIENT_PLATFORM:
        import UnityEngine
        import MouseController
        CommonScriptObj = UnityEngine.GameObject.Find(enum_def.ECommonScriptParam.eGlobalScriptObj)
        MouseDetect = CommonScriptObj.GetComponent(MouseController.MouseDetect)
        MouseDetect.EnableDetectSky(bEnable)


# 显示untity的一个对象
def ShowGameObj(szName, bShow):
    import UnityEngine
    Untity_GametObj = UnityEngine.GameObject.Find(szName)
    if Untity_GametObj.GetComponent("Renderer"):
        Untity_GametObj.GetComponent("Renderer").enabled = bShow
    for UntityChild in Untity_GametObj.GetComponentsInChildren(UnityEngine.Renderer):
        UntityChild.enabled = bShow

def ShowBloodScreen( fFactor ):
    if IS_CLIENT_PLATFORM:
        import UnityEngine
        import CommonController
        CommonScriptObj = UnityEngine.GameObject.Find(enum_def.ECommonScriptParam.eGlobalScriptObj)
        CameraController = CommonScriptObj.GetComponent(CommonController.CameraControl)
        CameraController.SetBloodScreenFactor(fFactor)


def ShowRedArea(bShow, tupleRedArea=None):
    if bShow:
        tupleWholeArea = (-8.1, -11.1, 23.1, 5.1)

        SetRedArea(tupleWholeArea, UnityEngine.Color(1, 0, 0, 1), tupleRedArea, UnityEngine.Color(0, 0, 0, 0))

    nFactor = bShow and 0.3 or 0
    SetBlendFactor(nFactor)


def SetRedArea(tupleWholeArea, objWholeAreaColor, tupleRedArea, objRedAreaColor):
    import YTGame

    listWholeArea = [float(x) for x in tupleWholeArea]
    listRedArea = [float(x) for x in tupleRedArea]

    YTGame.RedAreaShow.SetRedArea("RedAreaXX", listWholeArea, objWholeAreaColor, listRedArea, objRedAreaColor)
    YTGame.RedAreaShow.SetRedArea("RedAreaXX7", listWholeArea, objWholeAreaColor, listRedArea, objRedAreaColor)
    YTGame.RedAreaShow.SetRedArea("RedAreaYY", listWholeArea, objWholeAreaColor, listRedArea, objRedAreaColor)


def SetBlendFactor(nFactor):
    import YTGame
    YTGame.RedAreaShow.SetBlendFactor("RedAreaXX", nFactor)
    YTGame.RedAreaShow.SetBlendFactor("RedAreaXX7", nFactor)
    YTGame.RedAreaShow.SetBlendFactor("RedAreaYY", nFactor)


def IsEnemyObj(Obj):
    import gac_gas.entity.entity_interface as entity_interface
    if IS_CLIENT_PLATFORM:
        import logic.game_entity.gac_game_entity_mgr as gac_game_entity_mgr

        HeroObj = gac_game_entity_mgr.GetHero()
        if not HeroObj:
            return False

        nHeroCamp = entity_interface.InfoCmp_GetCamp(HeroObj)
        return entity_interface.FightCmp_IsEnemyCamp(Obj, nHeroCamp)

    else:
        assert False

def ConvertSecondToStrFormatMS(nSecond):
    nMinutes = 0
    nSeconds = nSecond
    if nSecond >= 60:
        nMinutes = int(nSecond / 60)
        nSeconds = int(nSecond % 60)

    if nMinutes >= 10:
        szMinutes = str(nMinutes)
    else:
        szMinutes = "0" + str(nMinutes)

    if nSeconds >= 10:
        szSeconds = str(nSeconds)
    else:
        szSeconds = "0" + str(nSeconds)

    szTime = szMinutes + ":" + szSeconds
    return szTime

def ConvertSecondToStrFormatHMS(nSecond):
    nHours = 0
    nSeconds = nSecond
    if nSecond > 3600:
        nHours = int(nSecond / 3600)
        nSeconds = int(nSecond % 3600)

    if nHours >= 10:
        szHours = str(nHours)
    else:
        szHours = "0" + str(nHours)

    szTime = szHours + ":" + ConvertSecondToStrFormatMS(nSeconds)
    return szTime

def ScreenPos2WorldPos(nX, nY, nLayerType=0):
    from FairyUIEx import CommonFunc
    pos = CommonFunc.GetInst().ScreenPos2WorldPos(nX, nY, nLayerType)
    print("ScreenPos2WorldPos",nX, nY, nLayerType, pos)
    return pos

def WorldPos2ScreenPos(worldPos, nOffsetY=0):
    from FairyUIEx import CommonFunc
    pos = CommonFunc.GetInst().WorldPos2ScreenPos(worldPos)
    print("WorldPos2ScreenPos", worldPos, nOffsetY, pos)
    return pos


def ConvertKeyIntToStr(dictIntKey):
    """
    将dict中所有的key转为字符串
    dict格式：
        所有key可以是整数，可以是字符串；
        会递归替换，层次结构可以是dict和list，最终的值可以int，str，tuple

    @param dictIntKey:
    @return:
    """
    if isinstance(dictIntKey, dict):
        dictStrKey = {}
        for nKey, nValue in dictIntKey.iteritems():
            dictStrKey[str(nKey)] = ConvertKeyIntToStr(nValue)

        return dictStrKey

    elif isinstance(dictIntKey, list):
        listStrKey = []
        listIntKey = dictIntKey
        for nIndex, nValue in enumerate(listIntKey):
            listStrKey.append(ConvertKeyIntToStr(nValue))

        return listStrKey

    else:
        return dictIntKey


def ConvertKeyStrToInt(dictStrKey):
    """
    将dict中所有的key转为整数
    dict格式：
        key是整数字符串时会转成数字，其余保留；
        会递归替换，层次结构可以是dict和list，最终的值可以int，str，tuple

    @param dictStrKey:
    @return:
    """
    if isinstance(dictStrKey, dict):
        dictIntKey = {}
        for szKey, nValue in dictStrKey.iteritems():
            assert isinstance(szKey, str) or isinstance(szKey, unicode)
            if szKey.isdigit():
                szKey = int(szKey)
            dictIntKey[szKey] = ConvertKeyStrToInt(nValue)

        return dictIntKey

    elif isinstance(dictStrKey, list):
        listIntKey = []
        listStrKey = dictStrKey
        for nIndex, nValue in enumerate(listStrKey):
            listIntKey.append(ConvertKeyStrToInt(nValue))

        return listIntKey
    else:
        return dictStrKey

# 生成队伍成员信息
def CreateTeamPlayerInfo(Player):
    return {
        TeamMemberDataType.eGID: Player.GetGlobalID(),
        TeamMemberDataType.eName: Player.GetName(),
        TeamMemberDataType.eSex: Player.GetSex(),
        TeamMemberDataType.eLevel: Player.GetLevel(),
        TeamMemberDataType.eFactionID: Player.GetFactionID(),
        TeamMemberDataType.eOnline: True,
        TeamMemberDataType.eEnterTime: int(time.time()),
        TeamMemberDataType.eClusterID: theApp.GetClusterID(),
    }


def GetItemFactory():
    """@rtype:gac_gas.item.item_factory.ItemFactory"""
    if IS_CLIENT_PLATFORM:
        import logic.item.gac_item_factory as gac_item_factory
        return gac_item_factory.g_GacItemFactory
    else:
        import gas.item.gas_item_factory as gas_item_factory
        return gas_item_factory.g_GasItemFactory