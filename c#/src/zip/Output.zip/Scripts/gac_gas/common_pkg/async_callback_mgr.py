# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.common.singleton import singleton


# 本地异步回调辅助装饰器
def AsyncSync():
    def fwrap(func):
        def SyncCall(*args, **kwargs):
            gen = func(*args, **kwargs)
            nGenID = RegGenerator(gen)
            AsyncCallbackMgrObj.GeneratorNext(nGenID)

        SyncCall.func_closure_for_reload = func
        return SyncCall

    return fwrap


@singleton
class AsyncCallbackMgr(object):
    def __init__(self):
        # 通用
        self.m_nCallbackID = 0              # funCallback auto id
        self.m_dictCallback = {}            # id 2 funCallback
        self.m_dictCallback2IDList = {}        # funCallback 2 ids

        # 本地使用
        self.m_nGeneratorAutoID = 0
        self.m_nCurRunningGeneratorID = 0
        self.m_dictGenerator = {}

    def RegCallback(self, funCallback):
        self.m_nCallbackID += 1
        self.m_dictCallback[self.m_nCallbackID] = funCallback

        if funCallback not in self.m_dictCallback2IDList:
            self.m_dictCallback2IDList[funCallback] = []
        self.m_dictCallback2IDList[funCallback].append(self.m_nCallbackID)

        return self.m_nCallbackID

    def PopCallback(self, nCallbackID):
        funCallback = self.m_dictCallback.pop(nCallbackID, None)

        if funCallback is not None and funCallback in self.m_dictCallback2IDList:
            self.m_dictCallback2IDList[funCallback].remove(nCallbackID)
            if not self.m_dictCallback2IDList[funCallback]:
                del self.m_dictCallback2IDList[funCallback]

        return funCallback

    def CleanCallback(self, funCallback):
        if funCallback in self.m_dictCallback2IDList:
            for index, nCallbackID in enumerate(self.m_dictCallback2IDList[funCallback]):
                self.m_dictCallback.pop(nCallbackID, None)
            del self.m_dictCallback2IDList[funCallback]

    def CallCallBack(self, nCallbackID, *args, **kwargs):
        funCallback = self.PopCallback(nCallbackID)
        if not funCallback:
            return

        funCallback(*args, **kwargs)

    def RegGenerator(self, gen):
        assert hasattr(gen, "next") and hasattr(gen, "send"), "RegGenerator"
        self.m_nGeneratorAutoID += 1
        self.m_dictGenerator[self.m_nGeneratorAutoID] = gen
        return self.m_nGeneratorAutoID

    def GeneratorNext(self, nGenID):
        if nGenID not in self.m_dictGenerator:
            return

        nOldGenID = self.m_nCurRunningGeneratorID
        try:
            self.m_nCurRunningGeneratorID = nGenID
            self.m_dictGenerator[nGenID].next()
        except StopIteration:
            self.PopGenerator(nGenID)
        finally:
            self.m_nCurRunningGeneratorID = nOldGenID

    def GeneratorSend(self, nGenID, *arg, **kwargs):
        if nGenID not in self.m_dictGenerator:
            return

        nOldGenID = self.m_nCurRunningGeneratorID
        try:
            self.m_nCurRunningGeneratorID = nGenID
            self.m_dictGenerator[nGenID].send(*arg, **kwargs)
        except StopIteration:
            self.PopGenerator(nGenID)
        finally:
            self.m_nCurRunningGeneratorID = nOldGenID

    def PopGenerator(self, nGenID):
        return self.m_dictGenerator.pop(nGenID, None)

    def GetCurGeneratorID(self):
        return self.m_nCurRunningGeneratorID


# -------------------------------------------------------------------

AsyncCallbackMgrObj = AsyncCallbackMgr()
RegCallback = AsyncCallbackMgrObj.RegCallback
PopCallback = AsyncCallbackMgrObj.PopCallback
CleanCallback = AsyncCallbackMgrObj.CleanCallback
CallCallBack = AsyncCallbackMgrObj.CallCallBack
RegGenerator = AsyncCallbackMgrObj.RegGenerator
GeneratorSend = AsyncCallbackMgrObj.GeneratorSend
GetCurGeneratorID = AsyncCallbackMgrObj.GetCurGeneratorID
