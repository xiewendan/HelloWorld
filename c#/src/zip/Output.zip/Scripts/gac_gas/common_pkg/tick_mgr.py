# -*- coding: utf-8 -*-

try:
    import UnityEngine
    IS_CLIENT_PLATFORM = True
except:
    IS_CLIENT_PLATFORM = False


if IS_CLIENT_PLATFORM:
    # noinspection PyUnresolvedReferences
    from framework.tick_mgr import *
else:
    # noinspection PyUnresolvedReferences
    from framework.tick_mgr import *
