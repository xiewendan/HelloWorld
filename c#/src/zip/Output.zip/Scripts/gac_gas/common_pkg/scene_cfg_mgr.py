# -*- coding: utf-8 -*-

# rl "gac_gas.common_pkg.scene_cfg_mgr"

import config.setting.scene.scene_def_cfg_common as ModScene_def_cfg_common
from gac_gas.common.enum_def import ECopyTypeID


def GetCopyTypeID(nSceneTypeID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("CopyType", ECopyTypeID.NormalScene)


# 场景配置表中场景名称
def GetSceneTypeName(nSceneTypeID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get('场景')


# 场景配置表中场景路径
def GetSceneResPath(nSceneTypeID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get('场景路径')


# 场内神兽血量倍数
def GetSceneHPRadio(nSceneTypeID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("Boss血量倍数")


# 场内神兽位置
def GetSceneDogzPos(nSceneTypeID, nCamp):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("神兽位置{}".format(nCamp))


# 场内特殊区域位置
def GetSceneAreaPos(nSceneTypeID, nAreaID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("区域位置{}".format(nAreaID))


# 场内特殊区域范围
def GetSceneAreaCoverage(nSceneTypeID, nAreaID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("区域位置{}范围".format(nAreaID))


# 默认的可放置区
def GetSceneArea(nSceneTypeID, nCamp):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("可放置区域阵营{}".format(nCamp))

# 场内区域属性影响范围
def GetSceneAffectAreaCoverage(nSceneTypeID, nAreaID):
    return ModScene_def_cfg_common.scene_def_cfg_common[nSceneTypeID].get("区域属性影响范围{}".format(nAreaID))