# -*- coding: utf-8 -*-
__author__ = 'ywxu'

# 默认是服务器, 这样集群就不用初始化了
g_bClientPlatform = False


def IsClientPlatform():
    return g_bClientPlatform


def IsServerPlatform():
    return not g_bClientPlatform


def SetClientPlatform():
    global g_bClientPlatform
    g_bClientPlatform = True


def SetServerPlatform():
    global g_bClientPlatform
    g_bClientPlatform = False
