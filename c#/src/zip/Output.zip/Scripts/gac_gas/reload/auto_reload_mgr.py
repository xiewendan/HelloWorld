# -*- coding: utf-8 -*-

import os
import sys
import time
import logging
import platform
import xupdate as xupdate
import gac_gas.common_pkg.tick_mgr as tick_mgr

IS_WINDOWS = platform.system() == 'Windows'


class AutoReloadMgr(object):
    def __init__(self, listReloadPath, szPathReloadTimeFile, szReloadTimeFileName, bLeaderApp=True, bAutoReload=True):
        self.m_Logger = logging.getLogger(self.__class__.__name__)

        self.m_listReloadPath = listReloadPath
        self.m_szPathReloadTimeFile = szPathReloadTimeFile
        self.m_szReloadTimeFileName = os.path.join(szPathReloadTimeFile, szReloadTimeFileName)

        self.m_Logger.info("ReloadTimeFileName: {}".format(self.m_szReloadTimeFileName))

        self.m_bLeaderApp = bLeaderApp
        self.m_bAutoReload = bAutoReload

        self.m_dictLastModifyTime = {}
        self.m_nUnderlingLastReloadTime = 0

        self.m_TickAutoReload = None

    def Init(self):
        self.m_Logger.info("初始化reload管理器: LeaderApp={}, AutoReload={}".format(self.m_bLeaderApp, self.m_bAutoReload))

        if self.m_bAutoReload:
            self.EnableAutoReloadTick()
        else:
            self.DisableAutoReloadTick()

    def Uinit(self):
        self.DisableAutoReloadTick()

    def EnableAutoReloadTick(self):
        self.DisableAutoReloadTick()

        if self.m_bLeaderApp:
            self.m_TickAutoReload = tick_mgr.RegisterNotFixTick("reload tick", 1000, self.OnLeaderUpdate)
        else:
            self.m_TickAutoReload = tick_mgr.RegisterNotFixTick("reload tick", 1000, self.OnUnderlingUpdate)

        self.m_Logger.info("开启auto reload tick")

    def DisableAutoReloadTick(self):
        if self.m_TickAutoReload:
            tick_mgr.UnRegisterTick(self.m_TickAutoReload)
            self.m_TickAutoReload = None

            self.m_Logger.info("停止auto reload tick")

    def OnUpdate(self):
        try:
            if self.m_listReloadPath:
                for szPath in self.m_listReloadPath:
                    self.LookRoundFiles(szPath)
        except Exception, e:
            self.m_Logger.error(str(e))

    def OnLeaderUpdate(self):
        self.OnUpdate()

    def OnUnderlingUpdate(self):
        nTime = self.ReadLeaderReloadTime()
        if nTime > self.m_nUnderlingLastReloadTime:
            self.m_nUnderlingLastReloadTime = nTime
            self.OnUpdate()

    def LookRoundFiles(self, szPath):
        bReload = False
        for szBaseDir, listDirList, listFileList in os.walk(szPath):
            for szFileName in listFileList:
                if not szFileName.endswith(".py"):
                    continue

                szFilePath = os.path.join(szBaseDir, szFileName)
                if self.CheckFileAndUpdate(szFilePath):
                    bReload = True

        if bReload:
            self.OnReloadedSomeFile()

    def CheckFileAndUpdate(self, szFilePath):
        szFileName = os.path.basename(os.path.splitext(szFilePath)[0])

        nModifyTime = os.stat(szFilePath).st_mtime
        nLastModifyTime = self.m_dictLastModifyTime.get(szFilePath)
        if nLastModifyTime is None:
            self.m_dictLastModifyTime[szFilePath] = nModifyTime
            return False

        if nLastModifyTime == nModifyTime:
            return False

        self.m_dictLastModifyTime[szFilePath] = nModifyTime

        for k, v in sys.modules.iteritems():
            szTmpFileName = k.split('.')[-1]
            if szFileName == szTmpFileName:
                if v:
                    xupdate.update(k)

        return True

    def OnReloadedSomeFile(self):
        if IS_WINDOWS and self.m_bLeaderApp:
            self.SaveLeaderReloadTime()

    def ReadLeaderReloadTime(self):
        nTime = 0
        if os.path.isfile(self.m_szReloadTimeFileName):
            with open(self.m_szReloadTimeFileName, 'r') as file:
                szData = file.read()
                if szData:
                    nTime = float(szData)
        return nTime

    def SaveLeaderReloadTime(self):
        if not os.path.exists(self.m_szPathReloadTimeFile):
            os.makedirs(self.m_szPathReloadTimeFile)

        with open(self.m_szReloadTimeFileName, 'w') as file:
            file.write(str(time.time()))
