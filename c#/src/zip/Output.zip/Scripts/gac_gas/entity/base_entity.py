# -*- coding: utf-8 -*-

import logging
import gac_gas.entity.entity_mgr as entity_mgr
import gac_gas.common.rpc_wrapper as rpc_wrapper


# 实体基类
class BaseEntity(object):
    def __init__(self, szID=None):
        super(BaseEntity, self).__init__()
        self.m_Logger = logging.getLogger(self.__class__.__name__)

        # ID
        if szID is None:
            self.m_szID = entity_mgr.GenEntityID()
        else:
            self.m_szID = szID

        # 连接对象
        self.m_ConnObj = None
        # 代理对象
        self.m_PeerEntityRpc = None
        # 是否已经销毁
        self.m_bDestroy = False

        # 注册到管理器
        entity_mgr.Register(self)

    def OnConnCome(self):
        pass

    def OnConnLost(self):
        pass

    def BindConn(self, ConnObj):
        if ConnObj is None:
            return

        if self.m_ConnObj == ConnObj:
            return

        self.UnBindConn()

        self.m_ConnObj = ConnObj

        self.m_PeerEntityRpc = rpc_wrapper.RpcWrapperPeerEntity(self.m_ConnObj)

        self.OnConnCome()

        self.m_ConnObj.BindEntity(self)

    def UnBindConn(self):
        if self.m_ConnObj is not None:
            ConnObj = self.m_ConnObj
            self.m_ConnObj = None
            self.m_PeerEntityRpc = None

            self.OnConnLost()

            ConnObj.UnBindEntity()

            self.Destroy()

    def GiveConnTo(self, TargetEntity):
        ConnObj = self.m_ConnObj
        if ConnObj is not None:
            TargetEntity.UnBindConn()
            self.UnBindConn()
            TargetEntity.BindConn(ConnObj)

    def GetID(self):
        return self.m_szID

    def GetConnRpc(self):
        return self.m_ConnObj.GetPeerRpc() if self.m_ConnObj else None

    def GetPeerEntityRpc(self):
        return self.m_PeerEntityRpc

    def GetConn(self):
        return self.m_ConnObj

    def IsDestroyed(self):
        return self.m_bDestroy

    def Destroy(self, bNow=False):
        if self.m_bDestroy:
            return

        self.m_bDestroy = True

        ConnObj = self.m_ConnObj
        self.UnBindConn()
        if ConnObj is not None:
            ConnObj.Destroy(bNow)

        entity_mgr.UnRegister(self.m_szID)

    # ----------------------msg-----------------------------

    # 处理消息
    def OnPbxMsg(self, data):
        TargetObj = self
        if len(data) == 3:
            for szFuncName in data[2]:
                TargetObj = getattr(TargetObj, szFuncName)()

        if TargetObj:
            getattr(TargetObj, data[0])(*data[1])
        else:
            self.m_Logger.error("NoneType have no attr: {}".format(data[0]))
