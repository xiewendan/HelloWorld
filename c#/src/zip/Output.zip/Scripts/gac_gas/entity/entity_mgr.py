# -*- coding: utf-8 -*-

from gac_gas.common.idmanager import IdManager

g_dictEntity = {}

# 生成实体ID
def GenEntityID():
    return IdManager.ID2Str(IdManager.GenID())


# 获取实体
def GetEntity(szEntityID):
    return g_dictEntity.get(szEntityID)


# 注册实体
def Register(Entity):
    g_dictEntity[Entity.GetID()] = Entity


# 注销实体
def UnRegister(szEntityID):
    if szEntityID in g_dictEntity:
        del g_dictEntity[szEntityID]
