# -*- coding: utf-8 -*-

"""对象位置信息接口"""

import gac_gas.common.enum_def as enum_def


# 取得对象位置
def MoveCmp_GetPosition(GameEntity):
    PositionCmp = GameEntity.GetCmponentByName(enum_def.EComponentEntityType.EntityPosition)
    if PositionCmp:
        return PositionCmp.GetPosition()


# 取得对象位置
def MoveCmp_GetPositionSelf(GameEntity):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if PositionCmp:
        return PositionCmp.GetPositionSelf()


# 是否正在移动
def MoveCmp_GetIsMoving(GameEntity):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    return PositionCmp.GetIsMoving()


# 是否已到达
def MoveCmp_GetIsReach(GameEntity):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    return PositionCmp.GetIsReach()


# 取得目标位置点
def MoveCmp_GetTargetPosition(GameEntity):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return None
    return PositionCmp.GetTargetPosition()


# 移动到目标点
def MoveCmp_CrowdMove(GameEntity, x, y, z):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    return PositionCmp.CrowdMove(x, y, z)

def MoveCmp_GetDetourFilter(GameEntity):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return 0
    return PositionCmp.GetDetourFilter()

# 停止移动
def MoveCmp_StopMove(GameEntity):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    return PositionCmp.StopMove()


# 设置朝向
def MoveCmp_SetDir(GameEntity, dir):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    PositionCmp.SetDir(dir)


# 设置目标为不可移动
def MoveCmp_EnableMoveObj(GameEntity, enable):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    return PositionCmp.EnableMoveObj(enable)


# 设置目标为不可移动
def MoveCmp_IgnoreMoveObj(GameEntity, ignore):
    PositionCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityPosition)
    if not PositionCmp:
        return False
    return PositionCmp.IgnoreMoveObj(ignore)
