# -*- coding: utf-8 -*-

"""对象场内玩法接口"""

import gac_gas.common.enum_def as enum_def


# -------------------------------------------场内卡牌玩法-------------------------------
# 抽卡
def CardCmp_DrawCard(GameEntity, nDrawNum):
    CardCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityCard)
    if CardCmp:
        CardCmp.DrawCard(nDrawNum)


# 设置卡牌组件是否活跃
def CardCmp_SetEnable(GameEntity, bEnable):
    CardCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityCard)
    if CardCmp:
        CardCmp.SetEnable(bEnable)


# 使用卡牌
def CardCmp_UseCard(GameEntity, szCardID, listPosition):
    CardCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityCard)
    if CardCmp:
        CardCmp.UseCard(szCardID, listPosition)


# -------------------------------------------视野-------------------------------
def ViewCmp_GetLostRadius(GameEntity):
    ViewCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityView)
    if ViewCmp:
        return ViewCmp.GetLostRadius()


def ViewCmp_GetViewRadius(GameEntity):
    ViewCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityView)
    if ViewCmp:
        return ViewCmp.GetViewRadius()
