# -*- coding: utf-8 -*-

"""对象调试功能接口"""

import gac_gas.common.enum_def as enum_def


# 鼠标点击功能开启
def MouseDetectCmp_OpenMouseDetect(GameEntity):
    MouseDetectComp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityMouseDetect)
    if MouseDetectComp:
        MouseDetectComp.OpenMouseDetect()


def MouseDetectCmp_Highlighting(GameEntity, bHightLight):
    MouseDetectComp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityMouseDetect)
    if MouseDetectComp:
        MouseDetectComp.Highlighting(bHightLight)
