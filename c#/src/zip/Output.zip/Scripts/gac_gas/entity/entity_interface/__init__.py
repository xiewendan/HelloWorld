# -*- coding: utf-8 -*-

"""
此模块为对象系统接口模块
只做中间层接口,不做逻辑相关
请不要把逻辑操作放到此模块
请不要在模块中 导入逻辑相关的模块
"""

from interface_info_base import *
from interface_position import *
from interface_ai import *
from interface_model import *
from interface_fight import *
from interface_scene import *
from interface_debug import *
