# -*- coding: utf-8 -*-

"""对象ai接口"""

import gac_gas.common.enum_def as enum_def


# 得到目标
def AICmp_GetTarget(GameEntity, nSearchRange=None, bIsFight=True):
    AICmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityAI)
    if AICmp:
        return AICmp.GetTarget(nSearchRange, bIsFight)


# 找目标
def AICmp_FindTarget(GameEntity, nSearchRange=None):
    AICmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityAI)
    if AICmp:
        return AICmp.FindTarget(GameEntity, nSearchRange)


# 重设目标
def AICmp_ResetTarget(GameEntity, nSearchRange=None):
    AICmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityAI)
    if AICmp:
        return AICmp.ResetTarget(nSearchRange)


# 得到目标gid
def AICmp_GetTargetGID(GameEntity):
    AICmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityAI)
    if AICmp:
        return AICmp.GetTargetGID()


# 开启/关闭AI
def AICmp_SetEnable(GameEntity, bEnable):
    AICmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityAI)
    if AICmp:
        AICmp.SetEnable(bEnable)
