# -*- coding: utf-8 -*-

"""对象战斗接口"""

import gac_gas.common.enum_def as enum_def


# -------------------------------------------战斗组件--------------------------------------
# 是否敌对关系
def FightCmp_IsEnemyCamp(GameEntity, nHeroCamp):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return False
    return FightCmp.IsEnemyCamp(nHeroCamp)


# 得到对象阵营
def FightCmp_GetCamp(GameEntity):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return 0
    return FightCmp.GetCamp()


# 得到对象阵营
def FightCmp_SetCamp(GameEntity, nCamp):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return 0
    return FightCmp.SetCamp(nCamp)


# 对象是否已经死亡
def FightCmp_IsDead(GameEntity):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return True
    return FightCmp.IsDead()


# 对象是否可以技能
def FightCmp_IsCanDoSkill(GameEntity):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return False
    return FightCmp.IsCanDoSkill()


# 得到对象身上的战斗属性
def FightCmp_GetParamValue(GameEntity, szKey):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    return FightCmp.GetParamValue(szKey)


# 受到伤害
def FightCmp_AddDamage(GameEntity, nDamage, nReason=enum_def.EHpChangedReason.eOtherType):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    return FightCmp.AddDamage(nDamage, nReason)


# 可以被攻击
def FightCmp_CanHurt(GameEntity, TargetObj):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if FightCmp:
        return FightCmp.CanHurt(TargetObj)
    return False


# 获取当前锁定目标
def FightCmp_GetTarget(GameEntity):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if FightCmp:
        return FightCmp.GetTarget()
    return False


# 受到攻击,改变血量
def FightCmp_AddHpByDamage(GameEntity, nDamge):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if FightCmp:
        FightCmp.AddHpByDamage(nDamge)


# 是否是战斗对象
def FightCmp_IsFightable(GameEntity):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if FightCmp:
        return FightCmp.IsFightable()

# 得到战斗属性
def FightCmp_GetPokemonType(GameEntity):
    FightCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityFightAttr)
    if FightCmp:
        return FightCmp.GetPokemonType()

# -------------------------------------------技能组件--------------------------------------
# 当前攻击的目标
def SkillCmp_GetLockObj(GameEntity):
    SkillCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityDoSkill)
    return SkillCmp.GetLockObj()


# 是否正在放技能
def SkillCmp_IsDoingSkill(GameEntity):
    SkillCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityDoSkill)
    if SkillCmp:
        return SkillCmp.IsDoingSkill()


def SkillCmp_GetCurSkill(GameEntity):
    SkillCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityDoSkill)
    if SkillCmp:
        return SkillCmp.GetCurSkill()


# 设置锁定目标
def SkillCmp_SetLockID(GameEntity, nLockID):
    SkillCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityDoSkill)
    if SkillCmp:
        SkillCmp.SetLockID(nLockID)


# 放技能
def SkillCmp_DoSkill2Target(GameEntity, nSkillID, objTarget):
    SkillCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityDoSkill)
    if SkillCmp:
        SkillCmp.DoSkill2Target(nSkillID, objTarget)


# 结束技能
def SkillCmp_CancelFightSkill(GameEntity):
    SkillCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityDoSkill)
    if SkillCmp:
        SkillCmp.CancelFightSkill()


# ----------------------------------------战斗接口-------------------------------------------

def FightInter_IsEnemyObj(Obj):
    import gac_gas.common_pkg.utils as utils
    import gac_gas.entity.entity_interface as entity_interface
    import logic.game_entity.gac_game_entity_mgr as gac_game_entity_mgr
    if utils.IS_CLIENT_PLATFORM:
        HeroObj = gac_game_entity_mgr.GetHero()
        if not HeroObj:
            return False

        nHeroCamp = entity_interface.InfoCmp_GetCamp(HeroObj)
        return FightCmp_IsEnemyCamp(Obj, nHeroCamp)

    else:
        assert False
        return False