# -*- coding: utf-8 -*-

"""对象模型接口"""

import gac_gas.common.enum_def as enum_def


def ModelCmp_OnAniMoveBegin(GameEntity):
    ModelCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityModel)
    if ModelCmp:
        ModelCmp.OnAniMoveBegin()

def ModelCmp_OnAniMoveEnd(GameEntity):
    ModelCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityModel)
    if ModelCmp:
        ModelCmp.OnAniMoveEnd()


