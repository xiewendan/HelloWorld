# -*- coding: utf-8 -*-

"""对象基础信息接口"""

import gac_gas.common.enum_def as enum_def


def InfoCmp_GetGameObjType(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.GetGameObjType()


def InfoCmp_GetName(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.GetName()


def InfoCmp_GetScene(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.GetScene()


def InfoCmp_SetScene(GameEntity, SceneObj):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    InfoCmp.SetScene(SceneObj)


def InfoCmp_IsPlayer(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.IsPlayer()


def InfoCmp_GetCamp(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.GetCamp()


def InfoCmp_GetMasterID(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.GetMasterID()

# 是否是主动npc
def InfoCmp_IsInitiative(GameEntity):
    InfoCmp = GameEntity.GetComponentByName(enum_def.EComponentEntityType.EntityInfoBase)
    return InfoCmp.IsInitiative()
