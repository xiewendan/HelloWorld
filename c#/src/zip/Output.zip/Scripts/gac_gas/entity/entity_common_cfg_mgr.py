# -*- coding: utf-8 -*-

import gac_gas.common.enum_def as enum_def
import config.setting.game_obj.game_obj_common as game_obj_common
import config.setting.game_obj.component_group as component_group
from gac_gas.common.singleton import singleton

@singleton
class EntityCommonCfgMgr(object):
    def __init__(self):
        self.m_dictEntityCfgData = {}
        self.CacheCfgData()

    def CacheCfgData(self):
        self.m_dictEntityCfgData = {}
        for nCfgID, dictCfgData in game_obj_common.game_obj_common.iteritems():
            dictNewCfgData = {}
            for szProperty, szProVal in dictCfgData.iteritems():
                if szProperty in enum_def.EPropertyType.eStr2Pro:
                    dictNewCfgData[enum_def.EPropertyType.eStr2Pro[szProperty]] = szProVal
                else:
                    dictNewCfgData[szProperty] = szProVal

            if "组件组合类型" in dictNewCfgData:
                nGroupID = dictNewCfgData["组件组合类型"]
                dictGroupData = component_group.component_group[nGroupID]

                dictComponent = {}
                for szComponentType, szComponentSubType in dictGroupData.iteritems():
                    if szComponentType in ["ID", "备注"]:
                        continue
                    if szComponentType in enum_def.EComponentEntityType.eStr2Type:
                        szComponentType = enum_def.EComponentEntityType.eStr2Type[szComponentType]

                    dictComponent[szComponentType] = szComponentSubType

                dictNewCfgData[enum_def.EPropertyType.ComponentDict] = dictComponent

            dictNewCfgData[enum_def.EPropertyType.CfgID] = nCfgID
            self.m_dictEntityCfgData[nCfgID] = dictNewCfgData

    def GetCfgData(self, nCfgID):
        return self.m_dictEntityCfgData.get(nCfgID, {})

    def CetDetourFilterByCfg(self, nCfgID):
        return self.m_dictEntityCfgData[nCfgID].get(enum_def.EPropertyType.DetourFilter, 0)

    def GetAllCfgData(self):
        return self.m_dictEntityCfgData


g_EntityCommonCfgMgr = EntityCommonCfgMgr()
GetCfgData = g_EntityCommonCfgMgr.GetCfgData
CetDetourFilterByCfg = g_EntityCommonCfgMgr.CetDetourFilterByCfg
GetAllCfgData = g_EntityCommonCfgMgr.GetAllCfgData
