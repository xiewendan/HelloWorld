# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import event_dispatcher

Dispatcher = event_dispatcher.EventDispatcher()

print("------------------------1-----------------------")


def Test1():
    print("****************test1")


def Test2():
    print("****************test2")


eEventType1 = "e1"
nObserverID1 = Dispatcher.RegisterObserver(eEventType1, Test1)

eEventType2 = "e2"
nObserverID2 = Dispatcher.RegisterObserver(eEventType2, Test2)

print("pre:")
print("****************test1")
print("****************test2")
print("\nret:")
Dispatcher.Notify(eEventType1)
Dispatcher.Notify(eEventType2)

print("------------------------2-----------------------")

Dispatcher.UnRegisterObserver(nObserverID2)

print("pre:")
print("****************test1")
print("\nret:")
Dispatcher.Notify(eEventType1)
Dispatcher.Notify(eEventType2)

print("------------------------3-----------------------")


def Test3():
    print("****************test3")


listObserverID3 = []


def Test4():
    print("****************test4")

    nObserverID3 = Dispatcher.RegisterObserver(eEventType2, Test3)
    listObserverID3.append(nObserverID3)


nObserverID4 = Dispatcher.RegisterObserver(eEventType2, Test4)

print("pre:")
print("****************test4")
print("####")
print("****************test4")
print("****************test3")
print("####")
print("\nret:")

Dispatcher.Notify(eEventType2)
print("####")
Dispatcher.Notify(eEventType2)

for nObserverID in listObserverID3:
    Dispatcher.UnRegisterObserver(nObserverID)

Dispatcher.UnRegisterObserver(nObserverID4)

print("####")
Dispatcher.Notify(eEventType2)

print("------------------------4-----------------------")


def Test5():
    print("****************test5")


nObserverID5 = Dispatcher.RegisterObserver(eEventType2, Test5)

print("pre:")
print("****************test5")
print("####")
print("\nret:")

Dispatcher.Notify(eEventType2)
print("####")
del Test5
Dispatcher.Notify(eEventType2)

print("------------------------5-----------------------")


def Test6():
    print("****************test6")


def Test7():
    print("****************test7")

    global Test6
    del Test6


nObserverID6 = Dispatcher.RegisterObserver(eEventType2, Test6)

print("pre:")
print("****************test6")
print("####")
print("****************test7")
print("####")
print("\nret:")

Dispatcher.Notify(eEventType2)
print("####")
nObserverID7 = Dispatcher.RegisterObserver(eEventType2, Test7)
Dispatcher.Notify(eEventType2)
print("####")
del Test7
Dispatcher.Notify(eEventType2)

print("------------------------6-----------------------")


class A(object):
    def __init__(self):
        self.m_nObserverID = Dispatcher.RegisterObserver(eEventType2, self.fun1)

    def fun1(self):
        print("*********************class fun1")


print("pre:")
print("*********************class fun1")
print("####")
print("*********************class fun1")
print("\nret:")

a = A()
a.fun1()
print("####")
Dispatcher.Notify(eEventType2)

print("------------------------6-----------------------")

del a

print("pre:")
print("\nret:")
Dispatcher.Notify(eEventType2)
