# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
import event_dispatcher as event_dispatcher

_logger = logging.getLogger("event_wrapper")


# 即时事件装饰器
def event_wrapper(eEventType):
    def _event_wrapper(func):
        def __event_wrapper(*args, **kwargs):
            try:
                func(*args, **kwargs)
            except Exception, e:
                import traceback
                traceback.print_exc()
                _logger.error(str(e))

            event_dispatcher.Notify(eEventType, *args, **kwargs)

        __event_wrapper.func_closure_for_reload = func
        return __event_wrapper

    return _event_wrapper


# 延时事件装饰器
def delay_event_wrapper(eEventType, nDelayTime):
    def _delay_event_wrapper(func):
        def __delay_event_wrapper(*args, **kwargs):
            try:
                func(*args, **kwargs)
            except Exception, e:
                import traceback
                traceback.print_exc()
                _logger.error(str(e))

            event_dispatcher.DelayNotify(eEventType, nDelayTime, *args, **kwargs)

        __delay_event_wrapper.func_closure_for_reload = func
        return __delay_event_wrapper

    assert nDelayTime >= 0, "延时时长必不小于0:{}".format(nDelayTime)
    return _delay_event_wrapper
