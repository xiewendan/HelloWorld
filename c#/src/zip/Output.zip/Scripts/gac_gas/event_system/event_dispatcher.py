# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import time
import logging
import weakref


class RefError(RuntimeError):
    pass


class WeakWrapper(object):
    def __init__(self, func):
        if hasattr(func, "__self__") and func.__self__ is not None:
            self.m_ObjRef = weakref.ref(func.__self__)
            self.m_func = func.__func__
        else:
            self.m_ObjRef = None
            self.m_func = weakref.ref(func)

    def __call__(self, *args, **kwargs):
        if self.m_ObjRef:
            RealObj = self.m_ObjRef()
            if RealObj:
                args = (RealObj,) + args
                return self.m_func(*args, **kwargs)
            else:
                raise RefError
        else:
            args = args
            func = self.m_func()
            if func:
                return func(*args, **kwargs)
            else:
                raise RefError


# 事件系统
class EventDispatcher(object):
    def __init__(self):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        # 所有注册侦听者
        self.m_dictAllObserver = {}
        # 侦听者ID对应事件类型
        self.m_dictObserverID2EventType = {}
        # 待注册侦听者
        self.m_dictReadyAddObserver = {}
        # 待注销侦听者
        self.m_dictReadyDelObserver = {}
        # 当前事件触发深度
        self.m_nNotifyDepth = 0
        # 当前侦听者ID
        self.m_nCurObserverID = 0
        # 延时触发
        self.m_listDelayNotify = []

    # 获取新的侦听者ID
    def GetNewObserverID(self):
        self.m_nCurObserverID += 1
        return self.m_nCurObserverID

    # 注册
    def RegisterObserver(self, eEventType, funCallback):
        nNewObserverID = self.GetNewObserverID()

        if self.m_nNotifyDepth > 0:
            # 事件触发过程中，不会立即进入侦听队列中
            self.m_Logger.info("注册事件侦听者-当前事件触发过程:{},{},{}".format(eEventType, nNewObserverID, funCallback))
            self.m_dictReadyAddObserver[nNewObserverID] = (eEventType, WeakWrapper(funCallback))
        else:
            self.m_Logger.info("注册事件侦听者-正常:{},{},{}".format(eEventType, nNewObserverID, funCallback))
            self.m_dictAllObserver.setdefault(eEventType, {})
            self.m_dictAllObserver[eEventType][nNewObserverID] = WeakWrapper(funCallback)

        self.m_dictObserverID2EventType[nNewObserverID] = eEventType

        return nNewObserverID

    # 注销
    def UnRegisterObserver(self, nObserverID):
        self.m_Logger.info("注销事件侦听者:{}".format(nObserverID))

        # 待注册侦听者
        self.m_dictReadyAddObserver.pop(nObserverID, None)

        # 已经在侦听队列中
        eEventType = self.m_dictObserverID2EventType.pop(nObserverID, None)
        if not eEventType:
            self.m_Logger.info("注销事件侦听者失败1:{}".format(nObserverID))
            return

        dictEventObserver = self.m_dictAllObserver.get(eEventType)
        if not dictEventObserver:
            self.m_Logger.info("注销事件侦听者失败2:{},{}".format(nObserverID, eEventType))
            return

        if self.m_nNotifyDepth > 0:
            # 事件触发过程中
            self.m_Logger.info("注销事件侦听者-当前事件触发过程:{},{}".format(nObserverID, eEventType))
            if nObserverID in dictEventObserver:
                dictEventObserver[nObserverID] = None
        else:
            self.m_Logger.info("注销事件侦听者-正常:{},{}".format(nObserverID, eEventType))
            dictEventObserver.pop(nObserverID, None)
            if not dictEventObserver:
                del self.m_dictAllObserver[eEventType]

    # 触发事件
    def Notify(self, eEventType, *args, **kwargs):
        self.m_Logger.info("触发事件:{}".format(eEventType))

        dictEventObserver = self.m_dictAllObserver.get(eEventType)
        if not dictEventObserver:
            return

        # 标记进入循环
        self.m_nNotifyDepth += 1
        for nObserverID, funWrapperCallback in dictEventObserver.iteritems():
            if not funWrapperCallback:
                self.m_dictReadyDelObserver.setdefault(eEventType, set())
                self.m_dictReadyDelObserver[eEventType].add(nObserverID)
                continue

            try:
                funWrapperCallback(*args, **kwargs)
            except RefError:
                self.m_dictReadyDelObserver.setdefault(eEventType, set())
                self.m_dictReadyDelObserver[eEventType].add(nObserverID)
                continue
            except Exception, e:
                import traceback
                traceback.print_exc()
                self.m_Logger.error(str(e))
                continue

        # 标记退出循环
        self.m_nNotifyDepth -= 1

        # 处理删除
        if self.m_dictReadyDelObserver and self.m_nNotifyDepth == 0:
            for eEventType, setObserverID in self.m_dictReadyDelObserver.iteritems():
                dictEventObserver = self.m_dictAllObserver.get(eEventType)
                if not dictEventObserver:
                    continue

                for nObserverID in setObserverID:
                    self.m_Logger.info("注销事件侦听者-触发事件后:{},{}".format(eEventType, nObserverID))

                    # 待注册侦听者
                    self.m_dictReadyAddObserver.pop(nObserverID, None)

                    # 已经在侦听队列中
                    self.m_dictObserverID2EventType.pop(nObserverID, None)

                    dictEventObserver.pop(nObserverID, None)

                if not dictEventObserver:
                    del self.m_dictAllObserver[eEventType]

            self.m_dictReadyDelObserver = {}

        # 处理添加
        if self.m_dictReadyAddObserver and self.m_nNotifyDepth == 0:
            for nNewObserverID, (eEventType, funWrapperCallback) in self.m_dictReadyAddObserver.iteritems():
                self.m_Logger.info("注册事件侦听者-触发事件后:{},{}".format(eEventType, nNewObserverID))
                self.m_dictAllObserver.setdefault(eEventType, {})
                self.m_dictAllObserver[eEventType][nNewObserverID] = funWrapperCallback

            self.m_dictReadyAddObserver = {}

    # 延时触发事件
    def DelayNotify(self, eEventType, nDelayTime, *args, **kwargs):
        self.m_Logger.info("延时触发事件:{}".format(eEventType))
        assert nDelayTime >= 0, "延时时长必不小于0:{}".format(nDelayTime)
        nDeadlineTime = time.time() + nDelayTime
        self.m_listDelayNotify.append((eEventType, nDeadlineTime, args, kwargs))

    # 处理所有延时消息
    def FlushDelayEvent(self):
        listDelayNotify = self.m_listDelayNotify
        self.m_listDelayNotify = []
        nCurTime = time.time()
        for eEventType, nDeadlineTime, args, kwargs in listDelayNotify:
            if nCurTime < nDeadlineTime:
                self.m_listDelayNotify.append((eEventType, nDeadlineTime, args, kwargs))
                continue

            self.Notify(eEventType, args, kwargs)


# -----------------------------------------------------------------------------------

EventDispatcherObj = EventDispatcher()
RegisterObserver = EventDispatcherObj.RegisterObserver
UnRegisterObserver = EventDispatcherObj.UnRegisterObserver
Notify = EventDispatcherObj.Notify
DelayNotify = EventDispatcherObj.DelayNotify
FlushDelayEvent = EventDispatcherObj.FlushDelayEvent


# 请让此代码保持在最后，多谢
def __onreload__(new_dict):
    global EventDispatcherObj
    EventDispatcherObj = new_dict.get("EventDispatcherObj")
