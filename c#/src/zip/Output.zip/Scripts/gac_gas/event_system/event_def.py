# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.common.enum_def import ConstMe


# 事件枚举
class EEventType(ConstMe):
    # ----------------------游戏进程相关------------------------------
    GameResume = "GameResume"                           # 游戏恢复
    GamePause = "GamePause"                             # 游戏暂停
    GameExit = "GameExit"                               # 游戏退出
    AndroidBack = "AndroidBack"                         # 安卓返回键
    NetworkChanged = "NetworkChanged"                   # 网络切换

    # ---------------------游戏逻辑相关--------------------------------

    FetchServerListOK = "FetchServerListOK"             # 下载服务器列表完成
    LoginSuccess = "LoginSuccess"                       # 登陆成功

    GameObjDie = "GameObjDie"                           # 游戏对象死亡
    GameObjBeforeDestroy = "GameObjBeforeDestroy"       # 游戏对象销毁前
    GameObjAfterDestroy = "GameObjAfterDestroy"         # 游戏对象销毁后
    GameObjAppear = "GameObjAppear"                     # 游戏对象出现

    SceneCreateSuccess = "SceneCreateSuccess"           # 场景创建成功
    SceneCreateFail = "SceneCreateFail"                 # 场景创建失败

    JoinTeam = "JoinTeam"                               # 加入队伍
    LeaveTeam = "LeaveTeam"                             # 离开队伍
    TeamDataUpdate = "TeamDataUpdate"                   # 队伍信息改变
