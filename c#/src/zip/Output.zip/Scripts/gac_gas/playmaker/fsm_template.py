# -*- coding: utf-8 -*-
__author__ = 'ywxu'

from gac_gas.common.singleton import singleton
@singleton
class FsmTemplateMgr(object):
    def __init__(self):
        # dict{key, template fsm}
        self.dictFsmTemplate = {}

    def AddFsmTemplateFromDict(self, dictTemplate):
        from .fsm import Fsm
        dictFsm = dictTemplate['fsm']
        fsmTemplateName = dictTemplate['m_Name']

        fsmTemplate = Fsm()
        fsmTemplate.InitFromDict(dictFsm)
        self.dictFsmTemplate[fsmTemplateName] = fsmTemplate
        return fsmTemplate

    # 只读不给改资源层....
    def GetFsmTemplate(self, name):
        return self.dictFsmTemplate.get(name)
