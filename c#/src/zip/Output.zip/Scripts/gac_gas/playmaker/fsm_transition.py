# -*- coding: utf-8 -*-
__author__ = 'ywxu'

class FsmTransition(object):
    def __init__(self):
        self.fsmEventName = ""
        # private string toState;
        self.toState = ""
        # private FsmState toFsmState(索引用起来麻烦)
        # self.toFsmState = None

    def CopyFsmTransition(self):
        transitionCopy = FsmTransition()
        transitionCopy.fsmEventName = self.fsmEventName
        transitionCopy.toState = self.toState
        # 对象索引要更新..
        return transitionCopy

    def InitFromDict(self, dictData):
        fsmEventData = dictData['fsmEvent']
        self.fsmEventName = fsmEventData['name']
        self.toState = dictData['toState']
