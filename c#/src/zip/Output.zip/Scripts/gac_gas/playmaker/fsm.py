# -*- coding: utf-8 -*-
__author__ = 'ywxu'

from .fsm_state import FsmState
from .fsm_event_data import FsmEventData
from .fsm_transition import FsmTransition
import gac_gas.playmaker.fsm_log as FsmLog


# playmaker虽然有资源概念, 但共享资源概念不强
# 当前fsm应该是运行器, 而非资源, 需要有一个fsmSource, 下面的states等都是索引
class Fsm(object):
    EventData = FsmEventData()

    # targetSelf = FsmEventTarget()

    # region 初始化和销毁-----------------------------------------------------------------------------------------------
    def __init__(self):
        # region runtime 实例属性
        self.started = False
        self.finished = False
        self.manualUpdate = True  # 手动update
        self.switchedState = True
        self.activeStateEntered = False
        # 引用, 销毁时需要解引用
        self.owner = None  # type GameObject
        # self.fsmComponent = None  # type: PlayMakerFsmComponent
        self.switchToState = None  # type: FsmState
        self.activeState = None  # type: FsmState
        # endregion

        # region 资源属性(以后分离)
        # 状态机名字(编辑器保证不会重复, 可以当key用)
        self.name = ""
        self.startState = ""
        self.restartOnEnable = False
        self.enableDebugFlow = True
        # 资源列表
        self.states = {}  # dict(stateName, FsmState())
        self.events = {}  # dict(eventName, eventName)
        self.globalTransitions = {}  # dict(eventName, FsmTransition())
        self.variables = {}
        # endregion

        # 没实现
        # private bool keepDelayedEventsOnStateExit;
        # private Fsm host;
        # private Fsm rootFsm;
        # private List<Fsm> subFsmList;
        # public List<FsmEvent> ExposedEvents = new List<FsmEvent>();

    def CopyFsm(self, objOwner):
        fsmCopy = Fsm()

        fsmCopy.name = self.name
        fsmCopy.startState = self.startState
        fsmCopy.restartOnEnable = self.restartOnEnable
        fsmCopy.states = {}
        fsmCopy.owner = objOwner

        for stateName, fsmState in self.states.iteritems():
            fsmCopy.states[stateName] = fsmState.CopyFsmState(fsmCopy)

        for eventName, fsmEventName in self.events.iteritems():
            fsmCopy.events[eventName] = fsmEventName

        for transitionName, globalTransition in self.globalTransitions.iteritems():
            fsmCopy.globalTransitions[transitionName] = globalTransition.CopyFsmTransition()

        import copy
        fsmCopy.variables = copy.deepcopy(self.variables)

        return fsmCopy

    # 从配置表中初始化
    def InitFromDict(self, dictData):
        self.name = dictData['name']
        self.manualUpdate = dictData['manualUpdate'] == 1
        self.restartOnEnable = dictData['RestartOnEnable'] == 1
        self.enableDebugFlow = dictData['EnableDebugFlow'] == 1
        self.enableDebugFlow = True
        self.startState = dictData['startState']

        # 整个状态机用过的event
        for eventData in dictData["events"]:
            fsmEventName = eventData['name']
            self.events[fsmEventName] = fsmEventName

        # for eventName in dictData["exposed_events"]:
        #     self.exposedEvents.append(FsmEvent.GetFsmEvent(eventName))

        for stateData in dictData["states"]:
            stateName = stateData['name']
            fsmState = FsmState(self)
            fsmState.name = stateName
            fsmState.isSequence = stateData['isSequence']
            fsmState.LoadActions(stateData['actionData'])
            fsmState.LoadTransitions(stateData['transitions'])
            self.states[stateName] = fsmState

        for globalTransitionsData in dictData["globalTransitions"]:
            fsmEventData = globalTransitionsData['fsmEvent']
            fsmEventName = fsmEventData['name']
            toStateName = globalTransitionsData['toState']
            fsmTransition = FsmTransition()
            fsmTransition.fsmEventName = fsmEventName
            fsmTransition.toState = toStateName
            self.globalTransitions[fsmEventName] = fsmTransition

        # 变量
        for szDataType, dictDataType in dictData['variables'].iteritems():
            if dictDataType:
                for useVarData in dictDataType:
                    if useVarData:
                        # 注意vector3 = {x:11,y:22,z:33}
                        self.variables[useVarData['name']] = useVarData['value']

    def OnDestroy(self):
        if self.EventData.SentByFsm is self:
            self.EventData.SentByFsm = FsmEventData()

        if FsmLog.LoggingEnabled:
            FsmLog.LogDestroy(self)

        # 退出当前状态, 清理tick
        self.StopAndReset()

        # 解引用
        self.owner = None
        self.switchToState = None
        self.activeState = None

        # CR 还没销毁state
        self.states = {}
        self.globalTransitions = {}

    # endregion

    # region getter/setter----------------------------------------------------------------------------------------------
    def IsSwitchingState(self):
        return self.switchToState is not None

    # public FsmState ActiveState
    # {
    # 	get
    # 	{
    # 		if (activeState == null && activeStateName != "")
    # 		{
    # 			activeState = GetState(activeStateName);
    # 		}
    # 		return activeState;
    # 	}
    # 	private set
    # 	{
    # 		activeState = value;
    # 		activeStateName = ((activeState == null) ? "" : activeState.Name);
    # 	}
    # }

    def GetState(self, name):
        return self.states[name]

    def IsActive(self):
        if not self.finished:
            return self.activeState is not None
        return False

    def GetOwner(self):
        return self.owner
    # endregion

    # region 分层状态机支持---------------------------------------------------------------------------------------------
    def GetRootFsm(self):
        return None

    def CreateSubFsm(self):
        return None

    def GetSubFsm(self, subFsmName):
        return None

    # endregion

    # region 状态代码控制切换-------------------------------------------------------------------------------------------
    def SetState(self, stateName):
        self.SwitchState(stateName)

    def SwitchState(self, toState):
        if toState:
            if self.activeState is not None and self.activeStateEntered:
                self.ExitState(self.activeState)

            self.activeState = toState

        self.EnterState(toState)

    # 延迟执行状态跳转操作
    def UpdateStateChanges(self):
        if self.IsSwitchingState():
            self.SwitchState(self.switchToState)

    # endregion

    # region 状态机事件->跳转-------------------------------------------------------------------------------------------
    def DoTransition(self, fsmTransition, isGlobal):
        toFsmState = self.GetState(fsmTransition.toState)

        if toFsmState is None:
            return False

        # LastTransition = transition

        if FsmLog.LoggingEnabled:
            FsmLog.LogTransition(self.activeState, fsmTransition)

        self.switchToState = toFsmState

        # if self.EventData.SentByFsm != self:
        self.UpdateStateChanges()

        return True

    def UpdateDelayedEvents(self):
        pass

    def ClearDelayedEvents(self):
        pass

    def HasEvent(self, eventName):
        return self.events.has_key(eventName)

    # target: 自己fsm, GameObject, GameObjectFsm, FsmComp, 广播等
    # 默认暂时是自己吧.
    def Event(self, fsmEventName):
        if FsmLog.LoggingEnabled:
            FsmLog.LogSendEvent(self.activeState, fsmEventName)
        return self.ProcessEvent(fsmEventName, None)

    def DelayedEvent(self, fsmEventName, delay):
        print("######omega print 没实现")

    def BroadcastEvent(self, fsmEventName, excludeSelf=False):
        print("omega print11111111111 BroadcastEvent")

    def ProcessEvent(self, fsmEventName, fsmEventData=None):
        if self.IsActive() and fsmEventName:
            if not self.started:
                self.Start()

            if self.IsActive():
                if fsmEventData:
                    self.SetEventDataSentByInfo(fsmEventData)

                # state内部action会关心event?
                if self.activeState.OnEvent(fsmEventName):
                    # FsmExecutionStack.PopFsm()
                    pass
                else:
                    # 优先全局event跳转
                    fsmTransition = self.globalTransitions.get(fsmEventName)
                    if fsmTransition:
                        if FsmLog.LoggingEnabled:
                            FsmLog.LogEvent(fsmEventName, self.activeState)
                        if self.DoTransition(fsmTransition, True):
                            # FsmExecutionStack.PopFsm()
                            return True

                    # 局部event跳转
                    fsmTransition = self.activeState.transitions.get(fsmEventName)
                    if fsmTransition:
                        if FsmLog.LoggingEnabled:
                            FsmLog.LogEvent(fsmEventName, self.activeState)
                        if self.DoTransition(fsmTransition, False):
                            # FsmExecutionStack.PopFsm()
                            return True

                        # FsmExecutionStack.PopFsm()
        return False

    # FsmExecutionStack是记录当前运行是fsm->state->action
    @staticmethod
    def SetEventDataSentByInfo(fsmEventData=None):
        if fsmEventData:
            Fsm.EventData.SentByFsm = fsmEventData.SentByFsm
            Fsm.EventData.SentByState = fsmEventData.SentByState
            Fsm.EventData.SentByAction = fsmEventData.SentByAction
            pass
        else:
            # self.EventData.SentByFsm = FsmExecutionStack.ExecutingFsm
            # self.EventData.SentByState = FsmExecutionStack.ExecutingState
            # self.EventData.SentByAction = FsmExecutionStack.ExecutingAction
            pass

    @staticmethod
    def GetEventDataSentByInfo():
        fsmEventData = FsmEventData()
        # fsmEventData.SentByFsm = FsmExecutionStack.ExecutingFsm
        # fsmEventData.SentByState = FsmExecutionStack.ExecutingState
        # fsmEventData.SentByAction = FsmExecutionStack.ExecutingAction
        return fsmEventData

    # endregion

    # region 状态机Runtime对外------------------------------------------------------------------------------------------
    def Start(self):
        if FsmLog.LoggingEnabled:
            FsmLog.LogStart(self.activeState)

        self.started = True
        self.finished = False

        if self.activeState is None:
            self.activeState = self.GetState(self.startState)
            self.activeStateEntered = False

        self.switchToState = self.activeState
        self.UpdateStateChanges()

    def Stop(self):
        if self.restartOnEnable:
            self.StopAndReset()
        self.started = False
        self.finished = True
        if FsmLog.LoggingEnabled:
            FsmLog.LogStop(self)

    def StopAndReset(self):
        if self.activeState and self.activeStateEntered:
            self.ExitState(self.activeState)
        self.activeState = None
        self.switchedState = False

    def Update(self):
        if not self.activeStateEntered:
            self.Continue()

        self.UpdateDelayedEvents()

        if self.activeState:
            self.UpdateState(self.activeState)

    # endregion

    # region 状态机内部Runtime------------------------------------------------------------------------------------------
    def UpdateState(self, state):
        state.OnUpdate()
        self.UpdateStateChanges()

    def Continue(self):
        self.activeStateEntered = True
        self.EnterState(self.activeState)

    def EnterState(self, state):
        # EventTarget = null;
        self.switchedState = True
        self.activeStateEntered = True
        self.switchToState = None

        if FsmLog.LoggingEnabled:
            FsmLog.LogEnterState(self.activeState)

        state.OnEnter()

    def ExitState(self, state):
        if FsmLog.LoggingEnabled:
            FsmLog.LogExitState(self.activeState)

        self.activeState = None
        state.OnExit()

        # killdelayEvents()

    # endregion

    # region 内部Onxxxx-------------------------------------------------------------------------------------------------
    def OnEnable(self):
        self.finished = False
        if self.activeState is None or self.restartOnEnable:
            self.activeState = self.GetState(self.startState)
            self.activeStateEntered = False
            if self.started:
                self.Start()

    def OnDisable(self):
        self.Stop()

    # region  ---------------动态变量----------------------
    def GetVarables(self, name, default=None):
        return self.variables.get(name, default)
    # endregion

    pass
    # endregion
