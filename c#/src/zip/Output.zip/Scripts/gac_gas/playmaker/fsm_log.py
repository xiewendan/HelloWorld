# -*- coding: utf-8 -*-
__author__ = 'ywxu'
import time

LoggingEnabled = False
LoggingActionEnabled = False

def LogDestroy(fsm):
    print("%s PlayMakerFSM     Destroy: %s" % (time.time(), fsm.name))


def LogStart(fsmState):
    stateName = fsmState.name if fsmState else "None"
    print("%s PlayMakerFSM     Start state: %s" % (time.time(), stateName))


def LogStop(fsm):
    print("%s PlayMakerFSM     Stop: %s" % (time.time(), fsm.name))


def LogEvent(fsmEventName, fsmState):
    stateName = fsmState.name if fsmState else "None"
    print("%s PlayMakerFSM             Event: %s State: %s" % (time.time(), fsmEventName, stateName))


def LogSendEvent(fsmStateFrom, fsmEventName):
    stateName = fsmStateFrom.name if fsmStateFrom else "None"
    print("%s PlayMakerFSM             SendEvent: %s fromState: %s" % (time.time(), fsmEventName, stateName))


def LogExitState(fsmState):
    stateName = fsmState.name if fsmState else "None"
    print("%s PlayMakerFSM         ExitState: %s" % (time.time(), stateName))


def LogEnterState(fsmState):
    stateName = fsmState.name if fsmState else "None"
    print("%s PlayMakerFSM         EnterState: %s" % (time.time(), stateName))


def LogTransition(fsmStateFrom, fsmTransition):
    stateNameFrom = fsmStateFrom.name if fsmStateFrom else "None"
    print("%s PlayMakerFSM             DoTransition [%s]: %s -> %s " % (time.time(), fsmTransition.fsmEventName, stateNameFrom, fsmTransition.toState))

def LogAction(actionName, szText):
    print("%s PlayMakerFSM                 DoAction: %s" % (time.time(), actionName))
