# -*- coding: utf-8 -*-
__author__ = 'ywxu'


class FsmEventData(object):
    def __init__(self):
        self.SentByGameObject = None
        self.SentByFsm = None
        self.SentByState = None
        self.SentByAction = None

    # def FsmEventData(self, source):
    # 	SentByGameObject = source.SentByGameObject;
    # 	SentByFsm = source.SentByFsm;
    # 	SentByState = source.SentByState;
    # 	SentByAction = source.SentByAction;

    def DebugLog(self):
        # Debug.Log((object)("Sent By FSM: " + ((SentByFsm != null) ? SentByFsm.Name : "None")))
        # Debug.Log((object)("Sent By State: " + ((SentByState != null) ? SentByState.Name : "None")))
        # Debug.Log((object)("Sent By Action: " + ((SentByAction != null) ? SentByAction.GetType().Name : "None")))
        pass
