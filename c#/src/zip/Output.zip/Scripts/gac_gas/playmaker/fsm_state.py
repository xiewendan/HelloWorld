# -*- coding: utf-8 -*-
__author__ = 'ywxu'

from .fsm_event import FsmEvent
from .fsm_state_action import GetFsmStateAction
from .fsm_transition import FsmTransition
import fsm_log as FsmLog

# 加载类, 不要删除
# noinspection PyUnresolvedReferences
import fsm_state_actions


# playmaker paramDataType枚举
class ParamDataType(object):
    Integer = int('00', 16)  # 0
    Boolean = int('01', 16)  # 1
    Float = int('02', 16)  # 2
    String = int('03', 16)  # 3
    Color = int('04', 16)  # 4
    ObjectReference = int('05', 16)  # 5
    LayerMask = int('06', 16)  # 6
    Enum = int('07', 16)  # 7
    Vector2 = int('08', 16)  # 8
    Vector3 = int('09', 16)  # 9
    Vector4 = int('0a', 16)  # 10
    Rect = int('0b', 16)  # 11
    Array = int('0c', 16)  # 12
    Character = int('0d', 16)   # 13
    AnimationCurve = int('0e', 16)  # 14
    FsmFloat = int('0f', 16)    # 15
    FsmInt = int('10', 16)      # 16
    FsmBool = int('11', 16)     # 17
    FsmString = int('12', 16)   # 18
    FsmGameObject = int('13', 16)  # 19
    FsmOwnerDefault = int('14', 16)  # 20
    FunctionCall = int('15', 16)  # 21
    FsmAnimationCurve = int('16', 16)  # 22
    FsmEvent = int('17', 16)  # 23
    FsmObject = int('18', 16)  # 24
    FsmColor = int('19', 16)  # 25
    Unsupported = int('1a', 16)  # 26
    GameObject = int('1b', 16)  # 27
    FsmVector3 = int('1c', 16)  # 28
    LayoutOption = int('1d', 16)  # 29
    FsmRect = int('1e', 16)  # 30
    FsmEventTarget = int('1f', 16)  # 31
    FsmMaterial = int('20', 16)  # 32
    FsmTexture = int('21', 16)  # 33
    Quaternion = int('22', 16)  # 34
    FsmQuaternion = int('23', 16)  # 35
    FsmProperty = int('24', 16)  # 36
    FsmVector2 = int('25', 16)  # 37
    FsmTemplateControl = int('26', 16)  # 38
    FsmVar = int('27', 16)  # 39
    CustomClass = int('28', 16)  # 40
    FsmArray = int('29', 16)  # 41
    FsmEnum = int('2a', 16)  # 42


# 读取actionData 16进制数据
# 16进制字符串转十进制数组, chunk代表几个字符是一块, Unit代表几个字符组成一个10进制
def ToByteArray(szByte16, sizeChunk, sizeUnit):
    if szByte16 is None:
        return []

    length = len(szByte16)
    array = []
    startIndex = 0
    while startIndex < length:
        szUnit = szByte16[startIndex:startIndex + sizeChunk]
        szUnit = szUnit[0:sizeUnit]
        array.append(int(szUnit, 16))
        startIndex += sizeChunk
    return array


# 根据类型读取参数
def LoadActionField(ActionData, fieldType, paramIndex):
    paramDataPos = ActionData['paramDataPos'][paramIndex]

    if fieldType == ParamDataType.Integer:
        return int(ActionData['byteData'][paramDataPos])
    elif fieldType == ParamDataType.Boolean:
        value = bool(ActionData['byteData'][paramDataPos])
        return value
    elif fieldType == ParamDataType.String:
        return ActionData['stringParams'][paramDataPos]
    elif fieldType == ParamDataType.FsmFloat:
        useVariableData = ActionData['fsmFloatParams'][paramDataPos]
        value = useVariableData['value']
        return value
    elif fieldType == ParamDataType.FsmEvent:
        fsmEventName = ActionData['stringParams'][paramDataPos]
        return fsmEventName
    elif fieldType == ParamDataType.FsmString:
        return ActionData['fsmStringParams'][paramDataPos]['value']
    else:
        print("######omega print 没实现数据类型读取:%s" % fieldType)


class FsmState(object):

    # region Description : 初始化
    def __init__(self, fsm):
        # region Description : 序列化数据
        self.name = ""
        self.isSequence = False
        self.transitions = {}  # dict(eventName, FsmTransition())
        self.actions = []
        # endregion

        # region Description : 运行时数据
        self.active = False
        self.finished = False
        self.activeActionIndex = 0  # 当前激活action数组索引, 从零开始, 第一个action是[0]
        self.fsm = fsm  # type: Fsm
        self.activeActions = []  # 已经激活(执行中)的action列表
        self.finishedActions = []  # 运行结束的actions
        # endregion

    def CopyFsmState(self, fsm):
        stateCopy = FsmState(fsm)
        stateCopy.name = self.name
        stateCopy.isSequence = self.isSequence

        for eventName, fsmTransition in self.transitions.iteritems():
            stateCopy.transitions[eventName] = fsmTransition.CopyFsmTransition()

        for fsmStateAction in self.actions:
            stateCopy.actions.append(fsmStateAction.CopyFsmStateAction(stateCopy, fsm))

        return stateCopy

    def LoadTransitions(self, dictTransitions):
        for transitionData in dictTransitions:
            fsmTransition = FsmTransition()
            fsmTransition.InitFromDict(transitionData)
            self.transitions[fsmTransition.fsmEventName] = fsmTransition

    def LoadActions(self, dictActionData):
        dictActionData['actionEnabled'] = ToByteArray(dictActionData['actionEnabled'], 2, 2)  # 2数字字符串组成一个16进制代表bool
        dictActionData['actionStartIndex'] = ToByteArray(dictActionData['actionStartIndex'], 8, 2)
        dictActionData['paramDataType'] = ToByteArray(dictActionData['paramDataType'], 8, 2)
        dictActionData['paramDataPos'] = ToByteArray(dictActionData['paramDataPos'], 8, 2)
        dictActionData['paramByteDataSize'] = ToByteArray(dictActionData['paramByteDataSize'], 8, 2)
        dictActionData['byteData'] = ToByteArray(dictActionData['byteData'], 2, 2)

        actionIndex = 0
        paramCount = len(dictActionData['paramName'])

        # print("######omega print ActionData:%s" % ActionData)

        for actionName in dictActionData['actionNames']:
            # 原来这里是actionData负责, 但如果转表后就不需要了.
            actionName = actionName.split('.')[-1]
            print("######omega print LoadAction %s : %s" % (actionName, actionIndex))
            actionStateClassName = GetFsmStateAction(actionName)
            actionState = actionStateClassName()
            actionState.SetEnabled(dictActionData['actionEnabled'][actionIndex])
            # 加载action参数
            actionStartIndexList = dictActionData['actionStartIndex']
            actionCount = len(actionStartIndexList)
            nextParamIndex = actionStartIndexList[actionIndex]
            # 获取参数数量 : 下个action开始索引 - 当前action开始索引, 没有下个则paramCount - 当前action开始索引
            actionParamCount = actionStartIndexList[
                                   actionIndex + 1] - nextParamIndex if actionIndex + 1 < actionCount else paramCount - nextParamIndex
            # print("######omega print paramCount:%s" % actionParamCount)
            for n in xrange(actionParamCount):
                paramName = dictActionData['paramName'][nextParamIndex]
                paramDataType = dictActionData['paramDataType'][nextParamIndex]
                value = LoadActionField(dictActionData, paramDataType, nextParamIndex)
                setattr(actionState, paramName, value)
                nextParamIndex += 1
                print("######omega print LoadActionField %s : %s" % (paramName, value))

            # 检查参数是否正确
            actionState.CheckParamError()
            self.actions.append(actionState)
            actionIndex += 1
    # endregion

    def GetFsm(self):
        return self.fsm

    def FinishAction(self, action):
        self.finishedActions.append(action)

    # 从激活action列表中移除已经结束的action
    def RemoveFinishedActions(self):
        for fsmStateAction in self.finishedActions:
            if fsmStateAction in self.activeActions:
                self.activeActions.remove(fsmStateAction)

        self.finishedActions = []

    # CR 这函数复杂了.OnEnter时调用, OnUpdate时调用
    # 主要是处理序列模式
    def CheckAllActionsFinished(self):
        # print("######omega print CheckFinished:", self.finished, self.active, self.fsm.IsSwitchingState())
        if not self.finished and self.active and not self.fsm.IsSwitchingState():
            # 如果已经没有激活且运行中的action, 继续执行执行或者结束
            self.RemoveFinishedActions()
            if not self.activeActions:
                activeActionIndexNext = self.activeActionIndex + 1
                if not self.isSequence or activeActionIndexNext >= len(self.actions) or self.ActivateActions(activeActionIndexNext):
                    self.finished = True
                    self.fsm.Event(FsmEvent.Finished)

    # 激活(执行)所有action
    # 返回True就是全部执行完
    # 返回False:
    #   1 存在中途跳转, 执行中途退出
    #   2 存在阻塞序列action,执行中途退出
    def ActivateActions(self, startIndex):
        for i in xrange(startIndex, len(self.actions)):
            self.activeActionIndex = i
            fsmStateAction = self.actions[i]

            if not fsmStateAction.IsEnabled():
                # 当前action不启用则当完成, 注意没加入activeActions
                fsmStateAction.SetFinished(True)
            else:
                fsmStateAction.active = True
                fsmStateAction.SetFinished(False)
                fsmStateAction.entered = True

                if FsmLog.LoggingActionEnabled:
                    FsmLog.LogAction(fsmStateAction.ActionName, None)

                fsmStateAction.OnEnter()

                # action结束, 丢入已经激活后的action列表, 方便update时用
                if not fsmStateAction.finished:
                    self.activeActions.append(fsmStateAction)

                # 如果action执行期间触发跳转则退出, 不执行后续action
                if self.fsm.IsSwitchingState():
                    # print("omega print11111111111111111")
                    return False

                # 序列模式开启, 如果当前action阻塞(没结束)则中断
                if not fsmStateAction.finished and self.isSequence:
                    return False

        return True

    # 是否有本地跳转事件Finished
    def HasFinishedTransition(self):
        return self.transitions.has_key(FsmEvent.Finished)

    # region Description : 对Fsm接口 -----------------------------------------------------------------------------------
    def OnEnter(self):
        self.active = True
        self.finished = False
        self.activeActions = []
        self.finishedActions = []

        # 从第一个action开始执行
        if self.ActivateActions(0):
            # 如果全部action激活, 检测是否真的全部action结束?
            self.CheckAllActionsFinished()

    def OnEvent(self, fsmEventName):
        flag = False

        for fsmStateAction in self.activeActions:
            flag = fsmStateAction.Event(fsmEventName)

        return self.fsm.switchToState or flag

    # 服务器版尽量不使用update, 除非action要求用, 导致fsm需要update
    # 但技能暂时不需要,所以要处理序列模式, 主要是回来调
    def OnUpdate(self):
        if not self.finished:
            for fsmStateAction in self.activeActions:
                fsmStateAction.OnUpdate()
            self.CheckAllActionsFinished()

    # 退出状态的消耗有点高
    def OnExit(self):
        self.active = False
        self.finished = False
        # 所有已经Enter过的action->OnExit
        for fsmStateAction in self.actions:
            if fsmStateAction.entered:
                fsmStateAction.OnExit()
    # endregion


