# -*- coding: utf-8 -*-
__author__ = 'ywxu'

# dict(name, fsmStateAction)
gDictFsmStateActions = {}


def fsm_state_action(cls):
    RegisterFsmStateAction(cls)
    return cls


def RegisterFsmStateAction(action):
    global gDictFsmStateActions
    gDictFsmStateActions[action.ActionName] = action


def GetFsmStateAction(actionName):
    # print("######omega print GetStateAction:%s" % actionName)
    return gDictFsmStateActions.get(actionName)


def GetAllFsmStateAction():
    return gDictFsmStateActions

class FsmStateAction(object):
    ActionName = "FsmStateAction"

    def __init__(self):
        self.name = ""
        self.isOpen = True
        self.active = True
        self.finished = False
        # 父state索引
        self.fsmState = None
        # 父fsm索引
        self.fsm = None
        # 父playmaker组件索引
        self.fsmComponent = None

        self.entered = False
        self.enabled = True

    def CopyFsmStateAction(self, fsmStateParent, fsmParent, fsmStateAction=None):
        fsmStateActionCopy = fsmStateAction or FsmStateAction()
        fsmStateActionCopy.fsmState = fsmStateParent
        fsmStateActionCopy.fsm = fsmParent
        fsmStateActionCopy.name = self.name
        return fsmStateActionCopy

    def CheckParamError(self):
        pass

    def GetFsm(self):
        return self.fsm

    def SetEnabled(self, b):
        self.enabled = b

    def IsEnabled(self):
        return self.enabled

    def SetFinished(self, finished):
        if finished:
            self.active = False
        self.finished = finished

    def Finish(self):
        if not self.finished:
            self.active = False
            self.finished = True
            self.fsmState.FinishAction(self)

    def Reset(self):
        pass

    def OnEnter(self):
        pass

    def OnUpdate(self):
        pass

    def OnExit(self):
        pass

    def Event(self, fsmEventName):
        pass

