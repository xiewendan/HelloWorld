# -*- coding: utf-8 -*-
__author__ = 'ywxu'


class FsmEvent(object):
    # 系统消息
    Finished = "FINISHED"
    Disable = "DISABLE"


