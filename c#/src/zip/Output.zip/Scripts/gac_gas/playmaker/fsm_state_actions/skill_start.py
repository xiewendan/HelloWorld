# -*- coding: utf-8 -*-
from gac_gas.playmaker.fsm_state_action import fsm_state_action
from .skill_base import BaseSkill
from gac_gas.common.enum_def import EComponentEntityType


# 伤害
@fsm_state_action
class DoSkill(BaseSkill):
    ActionName = "SkillStart"

    def __init__(self):
        super(DoSkill, self).__init__()
        # region Description 序列化数据
        # 效果动作
        self.ani = ""
        # 动作后摇打断点 (do技能触发打断当前技能)
        self.break_point = 0
        # 移动触发技能打断点
        self.move_break_point = 0
        # 能量消耗
        self.cost = 0
        # tick loop次数(<=0代表无限), 超过就会发出loopove事件, 根据节点事件跳到下一个节点
        # self.loop_count = 0
        # endregion

        # region Description : runtime attrs
        # endregion

    def CopyFsmStateAction(self, fsmStateParent, fsmParent, fsmStateAction=None):
        fsmStateActionCopy = fsmStateAction or DoSkill()
        fsmStateActionCopy = super(DoSkill, self).CopyFsmStateAction(fsmStateParent, fsmParent, fsmStateActionCopy)
        fsmStateActionCopy.ani = self.ani
        fsmStateActionCopy.cost = self.cost
        fsmStateActionCopy.break_point = self.break_point
        fsmStateActionCopy.move_break_point = self.move_break_point
        return fsmStateActionCopy

    def OnEnter(self):
        # 播放动画
        if self.ani:
            objOwner = self.GetFsm().GetOwner()
            objOwner.GetGacEntityRpc().RRpcGetModelCmp().Gas2GacModelSetTrigger(self.ani)

        super(DoSkill, self).OnEnter()

    def OnExit(self):
        super(DoSkill, self).OnExit()

    # pipe行为
    def OnTick(self):
        self.DoPipe()
        super(DoSkill, self).OnTick()

    def DoPipe(self):
        # 攻击者
        objOwner = self.GetFsm().GetOwner()

        # 攻击者战斗属性组件
        ComponentFightAttrOwner = objOwner.GetComponentByName(EComponentEntityType.EntityFightAttr)
        ComponentDoSkill = objOwner.GetComponentByName(EComponentEntityType.EntityDoSkill)

        # 获取当前锁定目标(没有选择目标功能,先临时不能打自己)
        objTarget = ComponentDoSkill.GetLockObj()
        if objTarget is None or objTarget is objOwner:
            return

        ComponentFightAttrOwner.CalcHurt(objTarget, ComponentDoSkill.GetCurSkillID())
