# -*- coding: utf-8 -*-

import gac_gas.entity.entity_interface as entity_interface
from gac_gas.playmaker.fsm_state_action import fsm_state_action
from .skill_base import BaseSkill


# 伤害
@fsm_state_action
class EndSkill(BaseSkill):
    ActionName = "SkillEnd"

    def __init__(self):
        super(EndSkill, self).__init__()
        # region Description 序列化数据
        # 效果动作
        self.ani = ""
        # 动作后摇打断点 (do技能触发打断当前技能)
        self.break_point = 0
        # 移动触发技能打断点
        self.move_break_point = 0

    def CopyFsmStateAction(self, fsmStateParent, fsmParent, fsmStateAction=None):
        fsmStateActionCopy = fsmStateAction or EndSkill()
        fsmStateActionCopy = super(EndSkill, self).CopyFsmStateAction(fsmStateParent, fsmParent, fsmStateActionCopy)
        fsmStateActionCopy.ani = self.ani
        fsmStateActionCopy.break_point = self.break_point
        fsmStateActionCopy.move_break_point = self.move_break_point
        return fsmStateActionCopy

    def OnEnter(self):
        # 播放动画
        if self.ani:
            objOwner = self.GetFsm().GetOwner()
            objOwner.GetGacEntityRpc().RRpcGetModelCmp().Gas2GacModelSetTrigger(self.ani)

        super(EndSkill, self).OnEnter()

    # 停止技能
    def OnTick(self):
        super(EndSkill, self).OnTick()
        # 结束技能
        objOwner = self.GetFsm().GetOwner()
        entity_interface.SkillCmp_CancelFightSkill(objOwner)
