# -*- coding: utf-8 -*-
__author__ = 'ywxu'

from gac_gas.playmaker.fsm_state_action import fsm_state_action, FsmStateAction
import gac_gas.common_pkg.tick_mgr as tick_mgr

@fsm_state_action
class Wait(FsmStateAction):
    ActionName = "Wait"

    def __init__(self):
        super(Wait, self).__init__()
        # 序列化属性
        self.time = 1
        self.finishEvent = None
        self.realTime = False  # 没实现

        # 非序列化属性
        # self.startTime = 0.0
        # self.timer = 0.0
        self.tick = None

    def CopyFsmStateAction(self, fsmStateParent, fsmParent, fsmStateAction=None):
        fsmStateActionCopy = Wait()
        fsmStateActionCopy = super(Wait, self).CopyFsmStateAction(fsmStateParent, fsmParent, fsmStateActionCopy)
        fsmStateActionCopy.time = self.time
        fsmStateActionCopy.finishEvent = self.finishEvent
        fsmStateActionCopy.realTime = self.realTime
        return fsmStateActionCopy

    def OnEnter(self):
        # print("omega print11111111111111111 OnEnter %s" % self.ActionName)
        if self.time <= 0:
            self.GetFsm().Event(self.finishEvent)
            self.Finish()
            return
        else:
            self.tick = tick_mgr.RegisterNotFixOnceTick("PlayMaker Action Wait", self.time * 1000.0, self.OnTickFinished)

        # self.startTime = FsmTime.RealtimeSinceStartup
        # self.timer = 0.0

    def OnUpdate(self):
        # print("omega print11111111111111111 OnUpdate %s" % self.ActionName)
        # unity实现比较耗, 但可以支持暂停...且不需要tick销毁问题.
        # if self.realTime:
        #     self.timer = timer = FsmTime.RealtimeSinceStartup - startTime
        # else:
        #     self.timer += Time.deltaTime
        #
        # if self.timer >= self.time:
        #     self.Finish()
        #     if self.finishEvent:
        #         self.GetFsm().Event(self.finishEvent)
        pass

    def OnExit(self):
        # print("omega print11111111111111111 OnExit %s" % self.ActionName)
        self.UnRegTick()

    def Reset(self):
        self.UnRegTick()

    # 居然是action优先响应事件究竟是谁
    def Event(self, fsmEventName):
        # print("omega print11111111111111111 Event: %s %s" % (self.ActionName, fsmEventName))
        pass

    def OnTickFinished(self):
        # print("omega print11111111111111111 OnTick:", self.time)
        self.Finish()
        self.GetFsm().Event(self.finishEvent)

    def UnRegTick(self):
        if self.tick:
            tick_mgr.UnRegisterTick(self.tick)
            self.tick = None
