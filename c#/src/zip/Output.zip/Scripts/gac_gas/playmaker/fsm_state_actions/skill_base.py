# -*- coding: utf-8 -*-
import gac_gas.common_pkg.tick_mgr as tick_mgr
from gac_gas.playmaker.fsm_event import FsmEvent
from gac_gas.playmaker.fsm_state_action import FsmStateAction


# 阻塞actioin制作指导:
# 1 onEnter时不会Finish, 不会触发event跳转

# 基础技能节点实现, 主要是有tick功能
# 做带tick功能的所有技能节点
class BaseSkill(FsmStateAction):
    def __init__(self):
        super(BaseSkill, self).__init__()
        self.time = 1
        # 运行时数据
        self.tick = None

    def CopyFsmStateAction(self, fsmStateParent, fsmParent, fsmStateAction=None):
        fsmStateActionCopy = fsmStateAction or BaseSkill()
        fsmStateActionCopy = super(BaseSkill, self).CopyFsmStateAction(fsmStateParent, fsmParent, fsmStateActionCopy)
        fsmStateActionCopy.time = self.time
        return fsmStateActionCopy

    # 可能立刻触发跳转, 所以派生类要最后条用
    def OnEnter(self):
        if self.time > 0:
            self.RegTick()
        else:
            self.OnTickFinished()

    # 如果都有正常销毁, 这里不需要取消tick
    def OnExit(self):
        self.UnRegTick()

    def UnRegTick(self):
        if self.tick:
            tick_mgr.UnRegisterTick(self.tick)
            self.tick = None

    def RegTick(self):
        self.UnRegTick()
        self.tick = tick_mgr.RegisterNotFixOnceTick("PlayMaker Action RegTick", self.time * 1000.0, self.OnTick)

    # finished是state结束事件, 只有所有action结束后才会执行
    # 所以默认tick, wait是不需要有结束事件的, state所有action结束后也会触发一个
    def OnTick(self):
        self.Finish()
        self.fsmState.CheckAllActionsFinished()
        self.fsm.UpdateStateChanges()
