# -*- coding: utf-8 -*-

from gac_gas.playmaker.fsm_state_action import fsm_state_action, FsmStateAction
from gac_gas.common.enum_def import EComponentSceneType, EComponentEntityType

# 创建子弹
# 钩爪类子弹需要子弹反馈事件到fsm, 但配置里面应该是不需要处理
@fsm_state_action
class FireBullet(FsmStateAction):
    ActionName = "FireBullet"

    def __init__(self):
        super(FireBullet, self).__init__()
        self.id = 0

    def CopyFsmStateAction(self, fsmStateParent, fsmParent, fsmStateAction=None):
        fsmStateActionCopy = fsmStateAction or FireBullet()
        fsmStateActionCopy = super(FireBullet, self).CopyFsmStateAction(fsmStateParent, fsmParent, fsmStateActionCopy)
        fsmStateActionCopy.id = self.id
        return fsmStateActionCopy

    def CheckParamError(self):
        import config.setting.battle.bullet_common as bullet_common
        if self.id not in bullet_common.bullet_common:
            print("!!! Skill Error[子弹] 子弹ID[%s]不存在!" % self.id)
    
    def OnEnter(self):
        objOwner = self.GetFsm().GetOwner()
        BulletMgr = objOwner.GetScene().GetComponentByName(EComponentSceneType.eBulletMgr)
        DoSkillCmp = objOwner.GetComponentByName(EComponentEntityType.EntityDoSkill)
        objBullet = BulletMgr.CreateBullet(self.id, DoSkillCmp.GetCurSkillID(), objOwner)
        objOwner.GetGacEntityRpc().RRpcGetModelCmp().Gas2GacModelFireBullet(objBullet.GetTargetID(), objBullet.GetLifeTime())
        self.Finish()

