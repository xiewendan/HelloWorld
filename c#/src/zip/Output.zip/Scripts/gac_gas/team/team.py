# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
from gac_gas.common.const_def import sys_const
from gac_gas.common.enum_def import TeamDataType
from gac_gas.common.enum_def import TeamMemberDataType


# 队伍类
class Team(object):
    def __init__(self, szTeamID=None, nTeamServerID=None):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_szTeamID = szTeamID
        self.m_nTeamServerID = nTeamServerID
        self.m_listMemberGID = []
        self.m_dictMemberData = {}
        self.m_szCaptainGID = None
        self.m_bIsDestroy = False

    def GetTeamID(self):
        return self.m_szTeamID

    def GetTeamServerID(self):
        return self.m_nTeamServerID

    def GetMemberGIDList(self):
        return list(self.m_listMemberGID)

    def GetMemberCount(self):
        return len(self.m_listMemberGID)

    def GetCaptainGID(self):
        return self.m_szCaptainGID

    def SetCaptainGID(self, szCaptainGID):
        self.m_Logger.info("队伍队长改变:{}, {}, {}".format(self.m_szTeamID, self.m_szCaptainGID, szCaptainGID))

        self.m_szCaptainGID = szCaptainGID
        self.OnCaptainChanged()

    def IsCaptain(self, szGID):
        return szGID == self.m_szCaptainGID

    def IsInTeam(self, szGID):
        return not self.m_bIsDestroy and szGID in self.m_dictMemberData

    def IsEmpty(self):
        return self.GetMemberCount() == 0

    def IsFull(self):
        return self.GetMemberCount() >= sys_const.TEAM_MEMBER_LIMIT

    def IsValid(self):
        if not self.m_dictMemberData:
            return True

        for dictPlayerInfo in self.m_dictMemberData.itervalues():
            if dictPlayerInfo[TeamMemberDataType.eOnline]:
                return False

        return True

    def IsSameTeam(self, dictData):
        if not dictData:
            return False

        if self.m_szTeamID != dictData[TeamDataType.eTeamID]:
            return False

        if self.m_nTeamServerID != dictData[TeamDataType.eTeamServerID]:
            return False

        if self.m_szCaptainGID != dictData[TeamDataType.eCaptainGID]:
            return False

        if len(dictData[TeamDataType.eMemberData]) != len(self.m_dictMemberData):
            return False

        for szGID, dictPlayerInfo in dictData[TeamDataType.eMemberData].iteritems():
            if szGID not in self.m_dictMemberData:
                return False

        return True

    def GetTeamData(self):
        dictData = {
            TeamDataType.eTeamID: self.m_szTeamID,
            TeamDataType.eTeamServerID: self.m_nTeamServerID,
            TeamDataType.eCaptainGID: self.m_szCaptainGID,
            TeamDataType.eMemberData: self.m_dictMemberData,
        }
        return dictData

    def GetMemberInfo(self, szGID):
        return self.m_dictMemberData.get(szGID)

    def Parser(self, dictData):
        self.m_szTeamID = dictData[TeamDataType.eTeamID]
        self.m_nTeamServerID = dictData[TeamDataType.eTeamServerID]
        self.m_szCaptainGID = dictData[TeamDataType.eCaptainGID]
        self.m_dictMemberData = dictData[TeamDataType.eMemberData]

        self.m_Logger.info("队伍解析:{}".format(self.m_szTeamID))

        # 成员ID列表，然后按进队时间排列
        self.m_listMemberGID = []
        listTemp = sorted(self.m_dictMemberData.iteritems(), key=lambda x: x[1][TeamMemberDataType.eEnterTime])
        for tupleInfo in listTemp:
            self.m_listMemberGID.append(tupleInfo[0])

    def UpdateData(self, dictData):
        self.m_Logger.info("队伍更新:{}".format(self.m_szTeamID))

        self.Parser(dictData)
        self.OnUpdateData(dictData)

    def JoinTeam(self, dictData, szGID):
        self.m_Logger.info("队伍加入:{}, {}".format(self.m_szTeamID, szGID))

        self.Parser(dictData)
        self.OnJoinTeam(dictData, szGID)

    def AddMember(self, dictPlayerInfo, bIsCaptainGID=False):
        self.m_Logger.info("队伍添加成员1:{}, {}".format(self.m_szTeamID, self.IsFull()))

        if self.IsFull():
            return False

        szMemberGID = dictPlayerInfo[TeamMemberDataType.eGID]

        self.m_Logger.info("队伍添加成员2:{}, {}, {}".format(self.m_szTeamID, szMemberGID, bIsCaptainGID))

        if bIsCaptainGID:
            assert self.m_szCaptainGID is None
            self.m_szCaptainGID = szMemberGID

        self.m_dictMemberData[szMemberGID] = dictPlayerInfo

        if szMemberGID not in self.m_listMemberGID:
            self.m_listMemberGID.append(szMemberGID)

        self.OnAddMember(dictPlayerInfo, bIsCaptainGID)

        return True

    def RemoveMember(self, szMemberGID):
        self.m_Logger.info("队伍删除成员:{}, {}".format(self.m_szTeamID, szMemberGID))

        if szMemberGID not in self.m_dictMemberData:
            return False

        del self.m_dictMemberData[szMemberGID]

        if szMemberGID in self.m_listMemberGID:
            self.m_listMemberGID.remove(szMemberGID)

        self.OnRemoveMember(szMemberGID)

        if not self.m_dictMemberData:
            # 已经没有成员，删除队伍
            self.Destroy()
        elif szMemberGID == self.m_szCaptainGID:
            # 队长离开，选择新队长
            pass

        return True

    def UpdateMemberInfo(self, szMemberGID, dictInfo):
        self.m_Logger.info("队伍成员信息更新:{}, {}, {}".format(self.m_szTeamID, szMemberGID, dictInfo))

        dictPlayerInfo = self.m_dictMemberData.get(szMemberGID)
        if not dictPlayerInfo:
            return

        bDirty = False
        for eType, value in dictInfo.iteritems():
            if eType not in dictPlayerInfo or dictPlayerInfo[eType] != value:
                dictPlayerInfo[eType] = value
                if not bDirty:
                    bDirty = True

        if bDirty:
            self.OnUpdateMemberInfo(szMemberGID, dictInfo)

    def Destroy(self):
        if self.m_bIsDestroy:
            return

        self.m_Logger.info("队伍销毁:{}".format(self.m_szTeamID))

        self.m_bIsDestroy = True

        self.OnDestroy()

        self.m_szTeamID = None
        self.m_nTeamServerID = None
        self.m_listMemberGID = []
        self.m_dictMemberData = {}
        self.m_szCaptainGID = None

    # -------------------------------回调-----------------------------

    def OnUpdateData(self, dictData):
        pass

    def OnJoinTeam(self, dictData, szGID):
        pass

    def OnAddMember(self, dictPlayerInfo, bIsCaptainGID=False):
        pass

    def OnRemoveMember(self, szMemberGID):
        pass

    def OnUpdateMemberInfo(self, szMemberGID, dictInfo):
        pass

    def OnCaptainChanged(self):
        pass

    def OnDestroy(self):
        pass
