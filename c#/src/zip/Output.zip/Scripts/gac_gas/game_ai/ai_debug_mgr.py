# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import json
import logging
import gac_gas.common_pkg.utils as utils
from gac_gas.game_ai.behavior_tree.base_node import BaseNode
from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.common.singleton import singleton
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EAIType

AI_DEBUG_IP = 'localhost'
AI_DEBUG_PORT = 12345


# 调试AI类型
DEBUG_AI_TYPE = {EAIType.BT, EAIType.FSM}


@singleton
class AIDebugMgr(object):
    def __init__(self, funOnConnect=None, funOnDisconnect=None):
        self.m_Logger = logging.getLogger(self.__class__.__name__)

        self.m_ConnectObj = None
        self.m_szCurGID = 0
        self.m_dictDebugInfo = {}

        self.m_funOnConnect = funOnConnect
        self.m_funOnDisconnect = funOnDisconnect

    def Init(self, funOnConnect=None, funOnDisconnect=None):
        self.m_funOnConnect = funOnConnect
        self.m_funOnDisconnect = funOnDisconnect

    def IsConnected(self):
        return self.m_ConnectObj is not None

    def Connect(self):
        if self.IsConnected():
            return

        try:
            import rpyc
            self.m_ConnectObj = rpyc.connect(AI_DEBUG_IP, AI_DEBUG_PORT)
        except Exception, e:
            self.ClearDebugFun()

            self.m_Logger.info("尝试连接AI编辑器失败:{}".format(e))
        else:
            self.m_Logger.info("尝试连接AI编辑器成功")

            self.LoadAI()
            if self.m_funOnConnect:
                self.m_funOnConnect()

    def DisConnect(self):
        if not self.IsConnected():
            return

        self.m_Logger.info("断开连接AI编辑器")

        self.m_ConnectObj.close()
        self.m_ConnectObj = None
        self.ClearDebugFun()
        if self.m_funOnDisconnect:
            self.m_funOnDisconnect()

    def CheckValueType(self, value):
        return (isinstance(value, int) or isinstance(value, float) or
            isinstance(value, bool) or isinstance(value, unicode) or
            isinstance(value, str) or isinstance(value, tuple))

    def GetNodeInfo(self, objNode):
        dictNodeInfo = {}

        # 先取可编辑属性
        dictEditAttr = objNode.GetAllEditAttr()
        for szAttrName in dictEditAttr:
            value = objNode.GetAttrValue(szAttrName)
            if self.CheckValueType(value):
                dictNodeInfo[szAttrName] = value

        # 先取私有属性
        dictAllAINodeData = objNode.GetAllAINodeData()
        for szAttrName, value in dictAllAINodeData.iteritems():
            if self.CheckValueType(value):
                dictNodeInfo[szAttrName] = value

        return dictNodeInfo

    def GetStateInfo(self, objNode):
        dictStateInfo = {}

        # 先取可编辑属性
        dictEditAttr = objNode.GetAllEditAttr()
        for szAttrName in dictEditAttr:
            value = objNode.GetAttrValue(szAttrName)
            if self.CheckValueType(value):
                dictStateInfo[szAttrName] = value

        # 先取私有属性
        dictAllStateData = objNode.GetAllStateData()
        for szAttrName, value in dictAllStateData.iteritems():
            if self.CheckValueType(value):
                dictStateInfo[szAttrName] = value

        return dictStateInfo

    def OnDebug(self, objNode, szOpt, bUpdateState=True):
        if not self.IsConnected():
            self.ClearDebugFun()
            return

        if isinstance(objNode, BaseNode):
            if self.m_szCurGID != objNode.m_TreeObj.m_GameObj.GetGlobalID():
                return

            dictDebugInfo = {"opt": szOpt,
                             "update_state": bUpdateState,
                             "tree_name": objNode.GetFileTreeName(),
                             "id": objNode.GetDiagramID(),
                             "status": objNode.GetStatus(),
                             "info": self.GetNodeInfo(objNode)}
        elif isinstance(objNode, AIStateBase):
            if self.m_szCurGID != objNode.m_FSMObj.m_GameObj.GetGlobalID():
                return

            dictDebugInfo = {"opt": szOpt,
                             "update_state": bUpdateState,
                             "fsm_name": objNode.GetFileFSMName(),
                             "id": objNode.GetDiagramID(),
                             "info": self.GetStateInfo(objNode)}
        else:
            assert False

        self.SendDebugInfo(dictDebugInfo)

    def LoadAI(self):
        if not self.IsConnected():
            self.ClearDebugFun()
            return

        obj = utils.GetObjByGlobalID(self.m_szCurGID)
        if not obj or not self.IsSelectedObjOK(obj):
            return

        AICmp = obj.GetComponentByName(EComponentEntityType.EntityAI)
        AIExecutorObj = AICmp.GetAIExecutor()
        if AICmp.GetAIType() is EAIType.BT:
            szBTFileName = AIExecutorObj.GetConfigFileName()
            dictDebugInfo = {"opt": "load_bt", "tree_name": szBTFileName}
        elif AICmp.GetAIType() is EAIType.FSM:
            szFSMFileName = AIExecutorObj.GetConfigFileName()
            dictDebugInfo = {"opt": "load_fsm", "fsm_name": szFSMFileName}
        else:
            assert False

        self.m_dictDebugInfo = {}
        self.SendDebugInfo(dictDebugInfo)

        AIExecutorObj.SetDebugFun(obj, AICmp.m_dictAIData, self.OnDebug)

    def ClearDebugFun(self):
        self.m_dictDebugInfo = {}

        obj = utils.GetObjByGlobalID(self.m_szCurGID)
        if obj and self.IsSelectedObjOK(obj):
            AICmp = obj.GetComponentByName(EComponentEntityType.EntityAI)
            AIExecutorObj = AICmp.GetAIExecutor()
            AIExecutorObj.SetDebugFun(obj, AICmp.m_dictAIData, None)

    def IsNodeInfoDirty(self, nID, dictNodeInfo):
        dictOldNodeInfo = self.m_dictDebugInfo.get(nID)
        if dictOldNodeInfo is None:
            return True

        for szAttrName in dictOldNodeInfo:
            objOldValue = dictOldNodeInfo.get(szAttrName)
            objNewValue = dictNodeInfo.get(szAttrName)
            if objOldValue != objNewValue:
                return True

        return False

    def SendDebugInfo(self, dictDebugInfo):
        if not self.IsConnected():
            return

        nID = dictDebugInfo.get("id")
        if not self.IsNodeInfoDirty(nID, dictDebugInfo):
            return

        self.m_dictDebugInfo[nID] = dictDebugInfo
        szDebugInfo = json.dumps(dictDebugInfo)
        try:
            self.m_ConnectObj.root.debug(szDebugInfo)
        except:
            self.m_ConnectObj = None
            self.ClearDebugFun()
            if self.m_funOnDisconnect:
                self.m_funOnDisconnect()

    def IsSelectedObjOK(self, obj=None):
        if obj is None:
            obj = utils.GetObjByGlobalID(self.m_szCurGID)

        if not obj:
            return False

        AICmp = obj.GetComponentByName(EComponentEntityType.EntityAI)
        if not AICmp:
            return False

        if AICmp.GetAIType() not in DEBUG_AI_TYPE:
            return False

        return True

    def SetSelectObj(self, objSelect):
        if not self.IsConnected():
            return

        # 标记本记选定
        self.m_szCurGID = objSelect.GetGlobalID()
        if not self.IsSelectedObjOK(objSelect):
            return

        self.ClearDebugFun()
        self.LoadAI()

    def SetSelectObjEx(self, szGID):
        objSelect = utils.GetObjByGlobalID(szGID)
        self.SetSelectObj(objSelect)

# --------------------------------------------------------------------------------------------------

AIDebugMgrObj = AIDebugMgr()
Init = AIDebugMgrObj.Init
SetSelInitectObj = AIDebugMgrObj.SetSelectObj
SetSelectObjEx = AIDebugMgrObj.SetSelectObjEx
Connect = AIDebugMgrObj.Connect
DisConnect = AIDebugMgrObj.DisConnect
IsConnected = AIDebugMgrObj.IsConnected
