# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.conditional.conditional import Conditional


# 条件：值不是
class IsNotValue(Conditional):
    s_szNodeNote = "判断树上变量值不是指定值"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(IsNotValue, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("check_value", "", szCaption="预设值", szNote="预设值")
        self.RegisterEditAttr("tree_var", "", szCaption="设置树属性", szNote="设置树属性", bIsPublic=True)

    def OnUpdate(self):
        szCheckValue = self.GetAttrValue("check_value")
        szTreeValue = self.GetAttrValue("tree_var")
        if str(szTreeValue) != str(szCheckValue):
            return Status.SUCCESS
        return Status.FAIL
