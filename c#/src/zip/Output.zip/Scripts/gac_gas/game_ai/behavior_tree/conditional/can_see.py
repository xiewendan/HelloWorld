﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.conditional.conditional import Conditional

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.entity.entity_interface as entity_interface
except:
    pass


# 条件：是否看见目标
class CanSee(Conditional):
    s_szNodeNote = "判断是否在给定的范围内看见目标。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(CanSee, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("view_radius", -1, szCaption="视觉距离(米)", szNote="视觉距离, 当值为负值时，使用配置表视野属性")

    def OnUpdate(self):
        nSearchRange = self.GetAttrValue("view_radius")
        if nSearchRange < 0:
            nSearchRange = None

        TargetObj = entity_interface.AICmp_GetTarget(self.m_TreeObj.m_GameObj, nSearchRange=nSearchRange, bIsFight=True)
        if TargetObj:
            self.m_TreeObj.SetAIData("target_gid", TargetObj.GetGlobalID())
            return Status.SUCCESS
        else:
            self.m_TreeObj.SetAIData("target_gid", None)
            return Status.FAIL
