# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.conditional.conditional import Conditional


# 条件：是否为true
class IsTrue(Conditional):
    s_szNodeNote = "判断树上变量是否为逻辑真。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(IsTrue, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("check_value", True, szCaption="预设值", szNote="预设值", bIsPublic=True)

    def OnUpdate(self):
        bCheckValue = self.GetAttrValue("check_value")
        if not bCheckValue:
            return Status.SUCCESS
        return Status.FAIL
