# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：状态机节点
class Submachine(Action):
    s_szImageFile = "images/fsm.png"
    s_szNodeNote = "状态机节点。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Submachine, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("fsm_name", "", szCaption="状态机名称", szNote="状态机名称")
        self.m_AIStateMachineObj = None

    def IsSubmachineNode(self):
        return True

    def Destroy(self):
        if self.m_AIStateMachineObj:
            self.m_AIStateMachineObj.Destroy()
            self.m_AIStateMachineObj = None
        super(Submachine, self).Destroy()

    def OnInitialize(self):
        super(Submachine, self).OnInitialize()
        if self.m_AIStateMachineObj is None:
            import gac_gas.game_ai.ai_state_machine.ai_state_machine_mgr as ai_state_machine_mgr
            szFSMName = self.GetAttrValue("fsm_name")
            self.m_AIStateMachineObj = ai_state_machine_mgr.GetFSM(szFSMName)
            assert self.m_AIStateMachineObj is not None, "状态机不存在：{}".format(szFSMName)

        self.m_AIStateMachineObj.Reset(self.m_TreeObj.m_GameObj, self.m_TreeObj.m_dictAIData)

        # 调试相关
        self.m_AIStateMachineObj.SetDebugFun(self.m_TreeObj.m_GameObj, self.m_TreeObj.m_dictAIData, self.m_TreeObj.GetDebugFun())

    def OnTerminate(self, eStatus):
        if self.m_AIStateMachineObj:
            self.m_AIStateMachineObj.Stop(self.m_TreeObj.m_GameObj, self.m_TreeObj.m_dictAIData)

            # 调试相关
            self.m_AIStateMachineObj.SetDebugFun(self.m_TreeObj.m_GameObj, self.m_TreeObj.m_dictAIData, None)

        super(Submachine, self).OnTerminate(eStatus)

    def OnUpdate(self):
        self.m_AIStateMachineObj.Update(self.m_TreeObj.m_GameObj, self.m_TreeObj.m_dictAIData)
        if self.m_AIStateMachineObj.IsRunning(self.m_TreeObj.m_GameObj, self.m_TreeObj.m_dictAIData):
            return Status.RUNNING
        return Status.SUCCESS
