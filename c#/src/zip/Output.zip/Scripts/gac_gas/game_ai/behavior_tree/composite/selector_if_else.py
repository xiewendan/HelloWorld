# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.game_ai.behavior_tree.base_node as base_node
from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.composite.composite import Composite


# 条件选择节点
class SelectorIfElse(Composite):
    s_szImageFile = "images/selector.png"
    s_szNodeNote = "条件选择节点，一定有三个子节点，第一个子节点必为条件节点， 如果第一个子节成功，则执行第二子节点，反之执行第三子节点。"

    def OnUpdate(self):
        return Status.SUCCESS

    def OnInitialize(self):
        super(SelectorIfElse, self).OnInitialize()
        if not self.m_listChildren:
            return

        assert(self.m_nChildrenCount == 3 and base_node.IsConditionalNode(self.m_listChildren[0])), "条件选择节点，一定有三个子节点，第一个子节点必为条件节点， 如果第一个子节成功，则执行第二子节点，反之执行第三子节点。"

        self.m_nCurChildIndex = 0
        CurChildObj = self.m_listChildren[self.m_nCurChildIndex]
        self.m_TreeObj.Start(CurChildObj)

    def OnChildComplete(self, eStatus):
        if self.m_nCurChildIndex == 0:
            if eStatus == Status.SUCCESS:
                self.m_nCurChildIndex = 1
            else:
                self.m_nCurChildIndex = 2

            CurChildObj = self.m_listChildren[self.m_nCurChildIndex]
            self.m_TreeObj.Start(CurChildObj)
        else:
            self.m_TreeObj.Stop(self, eStatus)
