﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from node_type import NodeType
from status import Status


# 检查是否是复合节点
def IsCompositeNode(NodeObj):
    return NodeObj.GetNodeType() is NodeType.COMPOSITE


# 检查是否是条件节点
def IsConditionalNode(NodeObj):
    return NodeObj.GetNodeType() is NodeType.CONDITIONAL


# 检查是否是装饰节点
def IsDecoratorNode(NodeObj):
    return NodeObj.GetNodeType() is NodeType.DECORATOR


# 检查是否是行为节点
def IsActionNode(NodeObj):
    return NodeObj.GetNodeType() is NodeType.ACTION


# 检查是否是子树
def IsSubtreeNode(NodeObj):
    return NodeObj.IsSubtreeNode()


# 获取属性值错误
class GetAttrError(RuntimeError): pass


# 设置属性值错误
class SetAttrError(RuntimeError): pass


# 节点基类
class BaseNode(object):
    s_szImageFile = "images/default.png"
    s_szNodeNote = "这是一个节点"

    def __init__(self, eNodeType, ParentObj=None, TreeObj=None):
        assert eNodeType is not None, "Must set type in BaseNode"

        self.SetTree(TreeObj)
        self._m_eType = eNodeType
        self._m_ParentObj = ParentObj
        self._m_dictLinkAttr = {}
        self._m_dictAttr = {}
        self._m_nDiagramID = 0
        self._m_szFileTreeName = None
        self._m_szNodeName = self.__class__.__name__,

    # 获取显示图片
    @classmethod
    def GetImageFile(cls):
        return cls.s_szImageFile

    # 获取说明
    @classmethod
    def GetNodeNote(cls):
        return cls.s_szNodeNote

    # 注册可编辑属性，属性名，默认值， 注释, 是否是公共属性(节点始化使用)
    def RegisterEditAttr(self, szName, defaultValue, szCaption=None, szNote=None, bIsPublic=False):
        assert (self._m_dictAttr.get(szName) is None)
        assert (isinstance(defaultValue, int) or isinstance(defaultValue, float) or isinstance(defaultValue, bool) or isinstance(defaultValue, unicode) or
                isinstance(defaultValue, str) or isinstance(defaultValue, tuple))
        assert (isinstance(szName, str) or isinstance(szName, unicode))
        assert (isinstance(szCaption, str) or isinstance(szCaption, unicode) or szCaption is None)
        assert (isinstance(szNote, str) or isinstance(szNote, unicode) or szNote is None)
        assert (isinstance(bIsPublic, bool))

        if szCaption is None:
            szCaption = szName

        if szNote is None:
            szNote = szCaption

        self._m_dictAttr[szName] = {"Name": szName, "Value": defaultValue, "IsPublic": bIsPublic, "Caption": szCaption, "Note": szNote}

    # 销毁
    def Destroy(self):
        self.m_TreeObj = None
        self._m_ParentObj = None

    # 获取可编辑属性
    def GetAllEditAttr(self):
        return self._m_dictAttr

    # 添加连接属性(节点始化使用)
    def AddLinkAttr(self, szName, szValue):
        assert ((szName in self._m_dictAttr) and (self._m_dictAttr[szName]["IsPublic"]))
        self._m_dictLinkAttr[szName] = szValue

    # 设置dictAttrData(节点始化使用)
    def SetAttrData(self, dictAttrData):
        for szName, value in dictAttrData.iteritems():
            if szName in self._m_dictAttr:
                self._m_dictAttr[szName]["Value"] = value
            else:
                raise NotImplementedError("No Attr1:%s" % szName)

    # 设置dictAttrData(节点始化使用)
    def SetLinkAttrData(self, dictLinkAttrData, dictTreeAttr):
        for szName, dictInfo in dictLinkAttrData.iteritems():
            if szName in self._m_dictAttr:
                szTreeAttr = dictInfo["LinkAttr"]
                if szTreeAttr in dictTreeAttr:
                    self._m_dictLinkAttr[szName] = szTreeAttr
                else:
                    raise NotImplementedError("No Tree Attr:%s" % szTreeAttr)
            else:
                raise NotImplementedError("No Attr2:%s" % szName)

    # 获取节点类型
    def GetNodeType(self):
        return self._m_eType

    # 设置树
    def SetTree(self, TreeObj):
        self.m_TreeObj = TreeObj

    # 获取树
    def GetTree(self):
        return self.m_TreeObj

    # 设置真系父节点
    def SetParentNode(self, ParentObj):
        self._m_ParentObj = ParentObj

    # 获取真系父节点
    def GetParentNode(self):
        return self._m_ParentObj

    # 获取父组合节点
    def GetParentCompositeNode(self):
        ParentObj = self._m_ParentObj

        while ParentObj:
            if IsCompositeNode(ParentObj):
                return ParentObj
            else:
                ParentObj = ParentObj.GetParentNode()

    # 是子树节点
    def IsSubtreeNode(self):
        return False

    # 是状态机节点
    def IsSubmachineNode(self):
        return False

    # 设置图节点ID
    def SetDiagramID(self, nID):
        self._m_nDiagramID = nID
        self._m_szNodeName = "{}_{}".format(self.__class__.__name__, self._m_nDiagramID)

    # 获取图节点ID
    def GetDiagramID(self):
        return self._m_nDiagramID

    # 获取节点名称
    def GetNodeName(self):
        return self._m_szNodeName

    # 设置树文件名
    def SetFileTreeName(self, szName):
        self._m_szFileTreeName = szName

    # 获取树文件名
    def GetFileTreeName(self):
        return self._m_szFileTreeName

    # 初始化
    def OnInitialize(self):
        self.SetNodeAIData("status", Status.RUNNING)

    # 结束
    def OnTerminate(self, eStatus):
        self.SetNodeAIData("status", eStatus)

    # 更新
    def OnUpdate(self):
        return Status.SUCCESS

    # 是不是正在运行中
    def IsRunning(self):
        return self.GetNodeAIData("status") == Status.RUNNING

    # 获取状态
    def GetStatus(self):
        return self.GetNodeAIData("status")

    # 更新
    def Tick(self):
        if self.GetStatus() != Status.RUNNING:
            self.OnInitialize()

        eStatus = self.OnUpdate()

        if eStatus != Status.RUNNING:
            self.OnTerminate(eStatus)

        return eStatus

    # 中止
    def Abort(self, eStatus):
        if self.m_TreeObj and self.IsRunning():
            self.m_TreeObj.Remove(self)

        self.OnTerminate(eStatus)

    # 设置AI数据
    def SetNodeAIData(self, szKey, value):
        self.m_TreeObj.m_dictAIData[self._m_szNodeName][szKey] = value

    # 获取节点AI数据
    def GetNodeAIData(self, szKey, default=None):
        return self.m_TreeObj.m_dictAIData[self._m_szNodeName].get(szKey, default)

    # 清理节点AI数据
    def RemoveNodeAIData(self, szKey):
        self.m_TreeObj.m_dictAIData[self._m_szNodeName].pop(szKey)

    # 获取所有节点AI数据
    def GetAllAINodeData(self):
        return dict(self.m_TreeObj.m_dictAIData[self._m_szNodeName])

    # 获取属性
    def GetAttrValue(self, szName):
        # 检查绑定树属性
        szTreeName = self._m_dictLinkAttr.get(szName)
        if szTreeName:
            if self.m_TreeObj.HasTreeAttr(szTreeName):
                return self.m_TreeObj.GetTreeAttr(szTreeName)
            else:
                raise NotImplementedError("__getattr__  No Link Attr:%s" % szName)

        # 检查节点属性
        if szName in self._m_dictAttr:
            return self.GetNodeAIData(szName)

        raise GetAttrError("GetAttrError Error: {}-{}".format(self._m_szNodeName, szName))

    # 设置属性
    def SetAttrValue(self, szName, value):
        # 检查绑定树属性
        szTreeName = self._m_dictLinkAttr.get(szName)
        if szTreeName:
            if self.m_TreeObj.HasTreeAttr(szTreeName):
                self.m_TreeObj.SetTreeAttr(szTreeName, value)
                return
            else:
                raise NotImplementedError("__setattr__ No Link Attr:%s" % szName)

        # 检查节点属性
        if szName in self._m_dictAttr:
            self.SetNodeAIData(szName, value)
            return

        raise SetAttrError("SetAttrValue Error: {}-({}:{})".format(self._m_szNodeName, szName, value))
