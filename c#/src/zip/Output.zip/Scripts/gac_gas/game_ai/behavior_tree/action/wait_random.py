# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import random
from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action

try:
    import gac_gas.common_pkg.utils as utils
except:
    pass


# 行为：随机等待（卡点）
class WaitRandom(Action):
    s_szNodeNote = "随机阻塞等待一定时间，属于持续过程。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(WaitRandom, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("min_wait_time", 1.0, szCaption="最小时间间隔(秒)", szNote="最小时间间隔(秒)")
        self.RegisterEditAttr("max_min_wait_time", 3.0, szCaption="最大时间间隔(秒)", szNote="最大时间间隔(秒)")

    def OnInitialize(self):
        super(WaitRandom, self).OnInitialize()
        nEndTime = utils.GetCurTime() + random.uniform(self.GetAttrValue("min_wait_time"), self.GetAttrValue("max_min_wait_time"))
        self.SetNodeAIData("end_time", nEndTime)

    def OnUpdate(self):
        if utils.GetCurTime() <= self.GetNodeAIData("end_time", 0):
            return Status.RUNNING
        return Status.SUCCESS
