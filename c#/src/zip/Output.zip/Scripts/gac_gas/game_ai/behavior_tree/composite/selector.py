# -*- coding: utf-8 -*-

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.composite.composite import Composite


# 选择节点
class Selector(Composite):
    s_szImageFile = "images/selector.png"
    s_szNodeNote = "从左到右执行字节点，子节点返回成功则向上返回成功，如果所有子节点失败，则向上返回失败。"

    def OnUpdate(self):
        return Status.SUCCESS

    def OnInitialize(self):
        super(Selector, self).OnInitialize()
        if not self.m_listChildren:
            return

        self.m_nCurChildIndex = 0
        CurChildObj = self.m_listChildren[self.m_nCurChildIndex]
        self.m_TreeObj.Start(CurChildObj)

    def OnChildComplete(self, eStatus):
        if eStatus == Status.SUCCESS:
            self.m_TreeObj.Stop(self, eStatus)
            return

        assert (eStatus == Status.FAIL)
        self.m_nCurChildIndex += 1
        if self.m_nCurChildIndex >= self.m_nChildrenCount:
            self.m_TreeObj.Stop(self, eStatus)
        else:
            CurChildObj = self.m_listChildren[self.m_nCurChildIndex]
            self.m_TreeObj.Start(CurChildObj)
