﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

class NodeType(object):
    COMPOSITE = 1
    DECORATOR = 2
    ACTION = 3
    CONDITIONAL = 4
    ENTER = 5

    @staticmethod
    def str(nodeType):
        return ["COMPOSITE", "DECORATOR", "ACTION", "CONDITIONAL", "ENTER", ][nodeType - 1]
