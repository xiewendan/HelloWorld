# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import random
from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.conditional.conditional import Conditional


# 条件：判断概率是否合适
class IsRandomOk(Conditional):
    s_szNodeNote = "判断概率是否合适。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(IsRandomOk, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("check_flag", 1, szCaption="检查方式", szNote="检查方式（1:小于, 2:小于等于, 3:大于, 4:大于等于）")
        self.RegisterEditAttr("check_value", 0.5, szCaption="概率", szNote="概率(0-1)")

    def OnUpdate(self):
        nCheckFlag = self.GetAttrValue("check_flag")
        nCheckValue = self.GetAttrValue("check_value")

        if nCheckFlag == 1:
            if random.random() < nCheckValue:
                return Status.SUCCESS
        elif nCheckFlag == 2:
            if random.random() <= nCheckValue:
                return Status.SUCCESS
        elif nCheckFlag == 3:
            if random.random() > nCheckValue:
                return Status.SUCCESS
        elif nCheckFlag == 4:
            if random.random() >= nCheckValue:
                return Status.SUCCESS

        return Status.FAIL
