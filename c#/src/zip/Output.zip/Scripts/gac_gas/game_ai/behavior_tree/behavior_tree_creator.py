# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import sys
import json
import codecs
import node_info
from behavior_tree import BehaviorTree
from gac_gas.common_pkg.utils import IS_CLIENT_PLATFORM
from gac_gas.common.const_def import sys_const
from gac_gas.common.singleton import singleton


# 行为树生成器
@singleton
class BehaviorTreeCreator(object):
    def __init__(self):
        self.m_TreeObj = None
        self.m_dictTreeNode = {}
        self.m_dictNodeInfo = node_info.g_dictNodeInfo

    def Parser(self, szTreeName, ParentNode=None):
        szFileName = sys_const.BT_FILE_PATH.format(szTreeName)
        if IS_CLIENT_PLATFORM:
            szFileName = "{0}{1}".format("Data/", szFileName)
        else:
            szFileName = "{0}{1}".format(theApp.GetResPath(), szFileName)

        with codecs.open(szFileName, 'r', 'utf-8') as fFile:
            szData = fFile.read()

        assert szData, "BehaviorTreeCreator Parser Error:[{0}] is empty!!!".format(szFileName)

        if hasattr(json, "loads"):
            dictData = json.loads(szData)
        elif hasattr(json, "read"):
            dictData = json.read(szData)
        else:
            assert False
        dictNode = dictData.get("Nodes")
        assert (dictNode is not None)

        if ParentNode is not None:
            self.m_TreeObj = ParentNode.GetTree()
        else:
            self.m_TreeObj = BehaviorTree()
            self.m_dictTreeNode = self.m_TreeObj.GetNodeDict()

        dictTreeAttrData = {}
        dictTreeAttrDataEx = dictData.get("TreeAttrsEx")
        if dictTreeAttrDataEx:
            for szName in dictTreeAttrDataEx:
                dictTreeAttrData[szName] = dictTreeAttrDataEx[szName]["Value"]
        elif dictData.get("TreeAttrs"):
            dictTreeAttrData = dictData.get("TreeAttrs")

        if not dictData.get("Tree"):
            return

        RootNodeObj = self._DoParser(dictData["Tree"], dictNode, dictTreeAttrData, szTreeName)
        RootNodeObj.SetTree(self.m_TreeObj)

        if ParentNode is not None:
            RootNodeObj.SetParentNode(ParentNode)
            ParentNode.SetChild(RootNodeObj)
            self.m_TreeObj.MergeTreeAttrDate(dictTreeAttrData)
        else:
            self.m_TreeObj.SetTreeAttrData(dictTreeAttrData)
            self.m_TreeObj.SetRootNode(RootNodeObj)

        return self.m_TreeObj

    def _GetClassObj(self, szClassName):
        szClassModuleName = self.m_dictNodeInfo.get(szClassName)
        if szClassModuleName is not None:
            mModule = sys.modules.get(szClassModuleName)
            if not mModule:
                __import__(szClassModuleName)
                mModule = sys.modules[szClassModuleName]

            ClassObj = getattr(mModule, szClassName)
            return ClassObj

    def _DoParser(self, dictData, dictNode, dictTreeAttr, szTreeName):
        nID = dictData["ID"]
        listChildren = dictData.get("Children")

        szKey = str(nID)
        dictInfo = dictNode[szKey]
        szClassName = dictInfo['ClassName']
        dictAttrData = dictInfo['AttrData']
        dictLinkAttrData = dictNode[szKey]["LinkData"]

        ClassObj = self._GetClassObj(szClassName)
        NodeObj = ClassObj()
        NodeObj.SetDiagramID(nID)
        NodeObj.SetFileTreeName(szTreeName)
        NodeObj.SetAttrData(dictAttrData)
        NodeObj.SetLinkAttrData(dictLinkAttrData, dictTreeAttr)
        self.m_dictTreeNode[NodeObj.GetNodeName()] = NodeObj

        if listChildren:
            for dictChildData in listChildren:
                ChildNodeObj = self._DoParser(dictChildData, dictNode, dictTreeAttr, szTreeName)
                if ChildNodeObj is not None:
                    ChildNodeObj.SetParentNode(NodeObj)
                    ChildNodeObj.SetTree(self.m_TreeObj)
                    try:
                        NodeObj.AddChild(ChildNodeObj)
                    except:
                        NodeObj.SetChild(ChildNodeObj)

                    # 如果是子树节点
                    if ChildNodeObj.IsSubtreeNode():
                        self.Parser(ChildNodeObj.m_szTreeName, ChildNodeObj)

        return NodeObj


# -----------------------------------------------------------------------------------
BehaviorTreeCreatorObj = BehaviorTreeCreator()
Parser = BehaviorTreeCreatorObj.Parser
