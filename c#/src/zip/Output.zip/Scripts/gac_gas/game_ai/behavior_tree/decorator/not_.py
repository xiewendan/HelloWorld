# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.decorator.decorator import Decorator


# 修饰：逻辑非
class Not(Decorator):
    s_szNodeNote = "将子节点的结果按反来处理后返回。"

    def OnChildComplete(self, eStatus):
        if eStatus == Status.SUCCESS:
            self.m_TreeObj.Stop(self, Status.FAIL)
        elif eStatus == Status.FAIL:
            self.m_TreeObj.Stop(self, Status.SUCCESS)
