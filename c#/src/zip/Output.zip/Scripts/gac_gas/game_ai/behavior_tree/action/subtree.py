# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：子树
class Subtree(Action):
    s_szImageFile = "images/tree.png"
    s_szNodeNote = "子树。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Subtree, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("subtree_name", "", szCaption="子树名称", szNote="子树名称")
        self.m_DecoratorChildObj = None

    def IsSubtreeNode(self):
        return True

    def Destroy(self):
        if self.m_DecoratorChildObj:
            self.m_DecoratorChildObj.Destroy()
        super(Subtree, self).Destroy()

    def SetChild(self, ChildNodeObj):
        self.m_DecoratorChildObj = ChildNodeObj

    def OnInitialize(self):
        super(Subtree, self).OnInitialize()
        if not self.m_DecoratorChildObj:
            return
        self.m_TreeObj.Start(self.m_DecoratorChildObj)

    def OnUpdate(self):
        return Status.SUCCESS

    def OnChildComplete(self, eStatus):
        self.m_TreeObj.Stop(self, eStatus)

    def Abort(self, eStatus):
        if self.m_DecoratorChildObj and self.m_DecoratorChildObj.IsRunning():
            self.m_DecoratorChildObj.Abort(eStatus)

        super(Subtree, self).Abort(eStatus)
