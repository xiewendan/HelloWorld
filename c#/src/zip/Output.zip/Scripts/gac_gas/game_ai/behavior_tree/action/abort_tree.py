# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.base_node import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：重新开始树遍历
class AbortTree(Action):
    s_szNodeNote = "强制重新开始树遍历。"

    def OnUpdate(self):
        self.m_TreeObj.Abort(Status.ABORTED)
        return Status.SUCCESS
