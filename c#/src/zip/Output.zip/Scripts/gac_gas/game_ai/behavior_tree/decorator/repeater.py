# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.decorator.decorator import Decorator


# 修饰：重复执行
class Repeater(Decorator):
    s_szNodeNote = "重复执行子节点，直到重复次数已达或者子节点返回失败。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Repeater, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("repeater_count", 1, szCaption="重复次数", szNote="重复次数")
        self.RegisterEditAttr("repeater_forever", False, szCaption="是否永久重复", szNote="是否永久重复")
        self.RegisterEditAttr("end_if_failure", False, szCaption="失败后返回", szNote="失败后返回")

    def OnUpdate(self):
        return Status.RUNNING

    def OnInitialize(self):
        super(Repeater, self).OnInitialize()
        self.SetNodeAIData("cur_count", 0)

    def OnChildComplete(self, eStatus):
        # 失败就返回
        bEndIfFailure = self.GetAttrValue("end_if_failure")
        if eStatus == Status.FAIL and bEndIfFailure:
            self.m_TreeObj.Stop(self, eStatus)
            return

        # 永久重复
        bRepeaterForever = self.GetAttrValue("repeater_forever")
        if bRepeaterForever:
            self.m_TreeObj.AddRunNode(self.m_DecoratorChildObj)
            return

        # 重复次数
        nRepeaterCount = self.GetAttrValue("repeater_count")
        nCurCount = self.GetNodeAIData("cur_count", 0)
        nCurCount += 1
        if nCurCount < nRepeaterCount:
            self.SetNodeAIData("cur_count", nCurCount)
            self.m_TreeObj.AddRunNode(self.m_DecoratorChildObj)
        else:
            self.m_TreeObj.Stop(self, eStatus)
