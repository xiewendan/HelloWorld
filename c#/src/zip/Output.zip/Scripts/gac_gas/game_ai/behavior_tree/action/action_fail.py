# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：永远失败
class ActionFail(Action):
    s_szNodeNote = "永远失败"

    def OnUpdate(self):
        return Status.FAIL
