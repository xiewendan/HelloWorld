# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action

try:
    import gac_gas.common_pkg.utils as utils
except:
    pass


# 行为：等待（卡点）
class Wait(Action):
    s_szNodeNote = "阻塞等待一定时间，属于持续过程。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Wait, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("wait_time", 1.0, szCaption="时间间隔(秒)", szNote="时间间隔(秒)")

    def OnInitialize(self):
        super(Wait, self).OnInitialize()
        nEndTime = utils.GetCurTime() + self.GetAttrValue("wait_time")
        self.SetNodeAIData("end_time", nEndTime)

    def OnUpdate(self):
        if utils.GetCurTime() <= self.GetNodeAIData("end_time", 0):
            return Status.RUNNING
        return Status.SUCCESS
