# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.base_node import BaseNode
from gac_gas.game_ai.behavior_tree.node_type import NodeType
from gac_gas.game_ai.behavior_tree.status import Status


# 修饰节点基类
class Decorator(BaseNode):
    s_szNodeNote = "这是一个Decorator节点"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Decorator, self).__init__(NodeType.DECORATOR, ParentObj, TreeObj)
        self.m_DecoratorChildObj = None

    def Destroy(self):
        if self.m_DecoratorChildObj:
            self.m_DecoratorChildObj.Destroy()
        super(Decorator, self).Destroy()

    def SetChild(self, ChildNodeObj):
        self.m_DecoratorChildObj = ChildNodeObj

    def OnInitialize(self):
        super(Decorator, self).OnInitialize()
        if not self.m_DecoratorChildObj:
            return

        self.m_TreeObj.Start(self.m_DecoratorChildObj)

    def OnUpdate(self):
        return Status.SUCCESS

    def OnChildComplete(self, eStatus):
        assert False, "必须重载此函数"

    def Abort(self, eStatus):
        if self.m_DecoratorChildObj and self.m_DecoratorChildObj.IsRunning():
            self.m_DecoratorChildObj.Abort(eStatus)

        super(Decorator, self).Abort(eStatus)
