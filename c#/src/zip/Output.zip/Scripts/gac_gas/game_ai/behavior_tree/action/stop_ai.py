# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：停止AI
class StopAi(Action):
    s_szNodeNote = "停止AI"

    def OnUpdate(self):
        return Status.FAIL
