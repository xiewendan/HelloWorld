# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.base_node import BaseNode
from gac_gas.game_ai.behavior_tree.node_type import NodeType
from gac_gas.game_ai.behavior_tree.status import Status


# 行为节点基类
class Action(BaseNode):
    s_szImageFile = "images/action.png"
    s_szNodeNote = "这是一个Action节点"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Action, self).__init__(NodeType.ACTION, ParentObj, TreeObj)

    def OnUpdate(self):
        return Status.SUCCESS
