# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：停止移动
class MoveToStop(Action):
    s_szNodeNote = "立刻停止移动。"

    def OnUpdate(self):
        return Status.FAIL
