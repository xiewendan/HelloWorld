# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.game_ai.command_system as command_system
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.game_ai.command_system import ECommandType
except:
    pass


# 行为：闲逛
class Wander(Action):
    s_szNodeNote = "闲逛"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Wander, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("wander_radius", 3.0, szCaption="闲逛半径(米)", szNote="闲逛半径(米)")

    def OnInitialize(self):
        super(Wander, self).OnInitialize()
        TargetPosObj = self.GetNodeAIData("cur_pos")
        if not TargetPosObj:
            nWanderRadius = self.GetNodeAIData("wander_radius")
            CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_TreeObj.m_GameObj)
            TargetPosObj = utils.DetourFindRandomNav(self.m_TreeObj.m_SceneObj, CurPosObj.x, CurPosObj.y, CurPosObj.z, nWanderRadius)
            self.SetNodeAIData("cur_pos", TargetPosObj)

    def OnTerminate(self, eStatus):
        self.RemoveNodeAIData("cur_pos")
        super(Wander, self).OnTerminate(eStatus)

    def OnUpdate(self):
        TargetPosObj = self.GetNodeAIData("cur_pos")
        if not TargetPosObj:
            return Status.FAIL

        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_TreeObj.m_GameObj)
        if utils.Cal2PosDistance(TargetPosObj, CurPosObj) <= 0.3:
            return Status.SUCCESS

        if entity_interface.MoveCmp_GetIsMoving(self.m_TreeObj.m_GameObj):
            CurMovePosObj = entity_interface.MoveCmp_GetTargetPosition(self.m_TreeObj.m_GameObj)
            if utils.Cal2PosDistance(CurMovePosObj, TargetPosObj) <= 0.3:
                return Status.RUNNING

        # 发送命令
        command_system.DoCmd(self.m_TreeObj.m_GameObj, ECommandType.MoveTo, (TargetPosObj.x, TargetPosObj.y, TargetPosObj.z))

        return Status.RUNNING
