# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.action.action import Action
from gac_gas.game_ai.behavior_tree.status import Status

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.game_ai.command_system as command_system
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.game_ai.command_system import ECommandType
except:
    pass


# 行为：向给定目的位置移动
class MoveToDestPos(Action):
    s_szNodeNote = "向给定目的位置移动。"

    def OnInitialize(self):
        super(MoveToDestPos, self).OnInitialize()
        DestPosObj = self.GetNodeAIData("dest_pos")
        if not DestPosObj:
            DestPosObj = entity_interface.InfoCmp_GetScene(self.m_TreeObj.m_GameObj).GetEnemyDogzPosByEntity(self.m_TreeObj.m_GameObj)
            self.SetNodeAIData("dest_pos", DestPosObj)

    def OnTerminate(self, eStatus):
        self.RemoveNodeAIData("dest_pos")
        super(MoveToDestPos, self).OnTerminate(eStatus)

    def OnUpdate(self):
        DestPosObj = self.GetNodeAIData("dest_pos")

        # 已经到达
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_TreeObj.m_GameObj)
        if utils.Cal2PosDistance(DestPosObj, CurPosObj) <= 0.3:
            return Status.SUCCESS

        # 正在追击
        if entity_interface.MoveCmp_GetIsMoving(self.m_TreeObj.m_GameObj):
            CurMovePosObj = entity_interface.MoveCmp_GetTargetPosition(self.m_TreeObj.m_GameObj)
            if utils.Cal2PosDistance(CurMovePosObj, DestPosObj) <= 0.3:
                return Status.RUNNING

        # 发送命令
        command_system.DoCmd(self.m_TreeObj.m_GameObj, ECommandType.MoveTo, (DestPosObj.x, DestPosObj.y, DestPosObj.z))

        return Status.RUNNING
