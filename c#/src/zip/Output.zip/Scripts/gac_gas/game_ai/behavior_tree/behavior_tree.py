﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.game_ai.ai_executor_base as ai_executor_base
import base_node as base_node
from collections import deque
from status import Status
from node_type import NodeType

# 类型转换函数
VALUE_CONVERT_FUN = {
    type(0): int,
    type(1.0): float,
    type(True): bool,
    type(""): str,
    type(u""): str,
}


def GetValueConvetFun(value):
    return VALUE_CONVERT_FUN[type(value)]


# 树属性
TREE_ATTR_DATA = "tree_attr_data"

# 当前正运行中的节点
RUNNING_NODE_DATA = "running_node_data"

# 前置条件节点
ABORT_CONDITION_DATA = "abort_condition_data"


# 行为树类
class BehaviorTree(ai_executor_base.AIExecutorBase):
    def __init__(self, RootNodeObj=None, dictTreeAttrData=None):
        super(BehaviorTree, self).__init__()
        # 基础属性
        self._m_RootNodeObj = RootNodeObj
        self._m_dictTreeNode = {}
        self._m_dequeNode = None
        self._m_listAbortCondition = None

        if dictTreeAttrData:
            self.SetTreeAttrData(dictTreeAttrData)
        else:
            self._m_dictTreeAttrData = {}

        # 当前正在检查AbortCondition
        self._m_bCheckAbortCondition = False

    # 销毁函数
    def OnDestroy(self):
        self.Abort(Status.ABORTED)

        for NodeObj in self._m_dictTreeNode.itervalues():
            NodeObj.Destroy()
        self._m_dictTreeNode = {}

        self._m_RootNodeObj = None
        self._m_dictTreeAttrData = {}
        self._m_dequeNode.clear()
        self._m_listAbortCondition = None

    # 设置根节点
    def SetRootNode(self, RootNodeObj):
        self._m_RootNodeObj = RootNodeObj

    # 获取根节点
    def GetRootNode(self):
        return self._m_RootNodeObj

    # 设置节点字典(树初始化使用)
    def SetNodeDict(self, dictTreeNode):
        self._m_dictTreeNode = dictTreeNode

    # 获取节点字典(树初始化使用)
    def GetNodeDict(self):
        return self._m_dictTreeNode

    # 设置所有树属性(树初始化使用)
    def SetTreeAttrData(self, dictTreeAttrData):
        for szName, value in dictTreeAttrData.iteritems():
            self._m_dictTreeAttrData[szName] = {"value": value, "fun": GetValueConvetFun(value)}

    # 增加树属性(树初始化使用)
    def MergeTreeAttrDate(self, dictTreeAttrData):
        for szName, value in dictTreeAttrData.iteritems():
            if szName in self._m_dictTreeAttrData:
                continue
            self._m_dictTreeAttrData[szName] = {"value": value, "fun": GetValueConvetFun(value)}

    # 检查是否有树属性(运行中使用)
    def HasTreeAttr(self, szName):
        return szName in self._m_dictTreeAttrData

    # 设置指定树属性(运行中使用)
    def SetTreeAttr(self, szName, value):
        # 检查节点属性
        if not self.IsCheckAbortCondition():
            self.m_dictAIData[TREE_ATTR_DATA][szName] = self._m_dictTreeAttrData[szName]["fun"](value)

    # 获取指定树属性(运行中使用)
    def GetTreeAttr(self, szName):
        return self.m_dictAIData[TREE_ATTR_DATA][szName]

    # 正在检查前置条件节点(运行中使用)
    def IsCheckAbortCondition(self):
        return self._m_bCheckAbortCondition

    # 初始终化
    def Init(self):
        self._m_dequeNode = self.m_dictAIData[RUNNING_NODE_DATA]

        if not self._m_dequeNode:
            self.Start(self._m_RootNodeObj)
            self._m_listAbortCondition = self.m_dictAIData[ABORT_CONDITION_DATA] = []
        else:
            self._m_listAbortCondition = self.m_dictAIData[ABORT_CONDITION_DATA]

        self._m_dequeNode.append(None)

    # 节点更新后
    def _HandleAbortConditionNode(self, NodeObj):
        if base_node.IsConditionalNode(NodeObj):
            ParentNodeObj = NodeObj.GetParentCompositeNode()
            if ParentNodeObj and ParentNodeObj.IsAbortNode():
                self._m_listAbortCondition.append(NodeObj.GetNodeName())

    # 更新条件中止节点
    def _UpdateAbortConditionalNodes(self):
        self._m_bCheckAbortCondition = True

        # print("更新条件中止节点开始：{}".format(self._m_listAbortCondition))

        bNeedRemove = False
        for szNodeName in self._m_listAbortCondition:
            ConditionalNodeObj = self._m_dictTreeNode[szNodeName]
            if ConditionalNodeObj.IsNeedRemove():
                if not bNeedRemove:
                    bNeedRemove = True
                continue

            eOldStatus = ConditionalNodeObj.GetStatus()
            eResponse = ConditionalNodeObj.Tick()

            # print("更新条件中止节点:{}-({},{})".format(szNodeName, eOldStatus, eResponse))

            # 调试，节点更新
            if self._m_funDebug is not None:
                self._m_funDebug(ConditionalNodeObj, "update_node", False)

            if eOldStatus == eResponse:
                continue

            ParentNodeObj = ConditionalNodeObj.GetParentCompositeNode()
            ParentNodeObj.OnConditionalAbort(ConditionalNodeObj)

            if not bNeedRemove and ConditionalNodeObj.IsNeedRemove():
                bNeedRemove = True

        self._m_bCheckAbortCondition = False

        if bNeedRemove:
            self._m_listAbortCondition = [x for x in self._m_listAbortCondition if not self._m_dictTreeNode[x].IsNeedRemove()]
            self.m_dictAIData[ABORT_CONDITION_DATA] = self._m_listAbortCondition

        # print("更新条件中止节点结束：{}".format(self._m_listAbortCondition))

    # 重置
    def OnReset(self):
        self.Abort(Status.ABORTED)

        # 树属性
        dictAttr = {}
        for szTreeAttrName, dictValue in self._m_dictTreeAttrData.iteritems():
            dictAttr[szTreeAttrName] = dictValue["value"]
        self.m_dictAIData[TREE_ATTR_DATA] = dictAttr

        # 节点属性
        for szNodeName, NodeObj in self._m_dictTreeNode.iteritems():
            dictAttr = {}
            for szNodeAttrName, dictValue in NodeObj.GetAllEditAttr().iteritems():
                dictAttr[szNodeAttrName] = dictValue["Value"]
            self.m_dictAIData[szNodeName] = dictAttr

    # 更新
    def OnUpdate(self):
        # print("*******************更新开始:{}".format(self.m_GameObj.GetGlobalID()))

        self.Init()

        self._UpdateAbortConditionalNodes()

        # print("***********当前状态1：{}".format(self._m_dequeNode))

        while self.Step():
            pass

        # print("***********当前状态2：{},{}".format(self._m_dequeNode, self._m_listAbortCondition))

        self._m_dequeNode = None
        self._m_listAbortCondition = None

        # print("*******************更新结束:{}".format(self.m_GameObj.GetGlobalID()))

    # 开始执行节点
    def Start(self, NodeObj):
        self._m_dequeNode.appendleft(NodeObj.GetNodeName())

        # 调试，节点添加
        if self._m_funDebug is not None:
            self._m_funDebug(NodeObj, "add_node")

    # 停止执行节点
    def Stop(self, NodeObj, eStatus):
        NodeObj.Abort(eStatus)
        self.NodeCallback(NodeObj, eStatus)

    # 添加执行节点
    def AddRunNode(self, NodeObj):
        self._m_dequeNode.append(NodeObj)

        # 调试，节点添加
        if self._m_funDebug is not None:
            self._m_funDebug(NodeObj, "add_node")

    # Node回调
    def NodeCallback(self, NodeObj, eStatus):
        ParentNodeObj = NodeObj.GetParentNode()
        if ParentNodeObj:
            ParentNodeObj.OnChildComplete(eStatus)

    # 删除节点
    def Remove(self, NodeObj):
        try:
            self._m_dequeNode.remove(NodeObj.GetNodeName())
        except ValueError:
            pass

        # 调试，节点删除
        if self._m_funDebug is not None:
            self._m_funDebug(NodeObj, "del_node")

    # 中止树遍历
    def Abort(self, eStatus=Status.ABORTED):
        while self._m_dequeNode:
            szNodeName = self._m_dequeNode.pop()
            if not szNodeName:
                continue
            self._m_dictTreeNode[szNodeName].Abort(eStatus)

        if self._m_bCheckAbortCondition:
            for szNodeName in self._m_listAbortCondition:
                ConditionalNodeObj = self._m_dictTreeNode[szNodeName]
                ConditionalNodeObj.SetNeedRemove(True)
        else:
            self._m_listAbortCondition = []

        if self.m_dictAIData is not None:
            # 正在运行队列
            self.m_dictAIData[RUNNING_NODE_DATA] = deque()

            # 前置每件节点
            self.m_dictAIData[ABORT_CONDITION_DATA] = []

    # 遍历一步
    def Step(self):
        if not self._m_dequeNode:
            return False

        szNodeName = self._m_dequeNode.popleft()
        if not szNodeName:
            return False

        CurNodeObj = self._m_dictTreeNode[szNodeName]
        eResponse = CurNodeObj.Tick()

        # print("遍历一步:{}-{}".format(szNodeName, eResponse))

        if eResponse == Status.RUNNING:
            if CurNodeObj.GetNodeType() is not NodeType.COMPOSITE or self._m_funDebug:
                self._m_dequeNode.append(szNodeName)
        else:
            self.NodeCallback(CurNodeObj, eResponse)
            self._HandleAbortConditionNode(CurNodeObj)

            # 调试，节点删除
            if self._m_funDebug is not None:
                self._m_funDebug(CurNodeObj, "del_node")

        # 调试接口
        if self._m_funDebug:
            self._m_funDebug(CurNodeObj, "update_node")

        return True

    # 设置调试回调
    def OnSetDebugFun(self):
        # 调试接口
        if self._m_funDebug is not None:
            # 发送当前正在运行的节点状态
            dequeNode = self.m_dictAIData.get(RUNNING_NODE_DATA)
            if dequeNode:
                for szNodeName in dequeNode:
                    if not szNodeName:
                        continue
                    CurNodeObj = self._m_dictTreeNode[szNodeName]
                    self._m_funDebug(CurNodeObj, "add_node")

            # 发送当前正在条件节点状态
            listAbortCondition = self.m_dictAIData.get(ABORT_CONDITION_DATA)
            if listAbortCondition:
                for szNodeName in listAbortCondition:
                    ConditionalNodeObj = self._m_dictTreeNode[szNodeName]
                    self._m_funDebug(ConditionalNodeObj, "update_node", False)
