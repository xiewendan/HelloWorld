# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.base_node import BaseNode
from gac_gas.game_ai.behavior_tree.node_type import NodeType
from gac_gas.game_ai.behavior_tree.status import Status


# 条件节点基类
class Conditional(BaseNode):
    s_szImageFile = "images/question.png"
    s_szNodeNote = "这是一个Conditional节点"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Conditional, self).__init__(NodeType.CONDITIONAL, ParentObj, TreeObj)

    def SetNeedRemove(self, bValue):
        self.SetNodeAIData("need_remove", bValue)

    def IsNeedRemove(self):
        return self.GetNodeAIData("need_remove", False)

    def OnInitialize(self):
        super(Conditional, self).OnInitialize()
        self.SetNodeAIData("need_remove", False)

    def OnUpdate(self):
        return Status.SUCCESS
