﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

class Status(object):
    INVALID = 0
    SUCCESS = 1
    RUNNING = 2
    FAIL = 3
    ABORTED = 4

    @staticmethod
    def str(status):
        return ["INVALID", "SUCCESS", "RUNNING", "FAIL", "ABORTED", ][status]
