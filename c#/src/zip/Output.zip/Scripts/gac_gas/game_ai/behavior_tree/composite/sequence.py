# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.composite.composite import Composite


# 顺序节点
class Sequence(Composite):
    s_szImageFile = "images/selector.png"
    s_szNodeNote = "从左到右顺序执行子节点，只要有子节点返回失败，则向上返回失败，只有在所有子节点都返回成功，才向上返回成功。"

    def OnUpdate(self):
        return Status.SUCCESS

    def OnInitialize(self):
        super(Sequence, self).OnInitialize()
        if not self.m_listChildren:
            return

        self.m_nCurChildIndex = 0
        CurChildObj = self.m_listChildren[self.m_nCurChildIndex]
        self.m_TreeObj.Start(CurChildObj)

    def OnChildComplete(self, eStatus):
        if eStatus == Status.FAIL:
            self.m_TreeObj.Stop(self, Status.FAIL)
            return

        assert (eStatus == Status.SUCCESS)
        self.m_nCurChildIndex += 1
        if self.m_nCurChildIndex >= self.m_nChildrenCount:
            self.m_TreeObj.Stop(self, Status.SUCCESS)
        else:
            CurChildObj = self.m_listChildren[self.m_nCurChildIndex]
            self.m_TreeObj.Start(CurChildObj)
