# -*- coding: utf-8 -*-


class AbortType(object):
    NONE = 0
    SELF = 1
    LOWPRIORITY = 2
    BOTH = 3

    @staticmethod
    def str(eStatus):
        return ["NONE", "SELF", "LOWPRIORITY", "BOTH"][eStatus]

    @staticmethod
    def GetAllAbortType():
        return ["NONE", "SELF", "LOWPRIORITY", "BOTH"]

    @staticmethod
    def GetAbortTypeByName(szTypeName):
        import inspect

        listAttr = inspect.getmembers(AbortType)
        for tupleInfo in listAttr:
            if tupleInfo[0] == szTypeName:
                return tupleInfo[1]
