﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action


# 行为：设置树变量
class SetTreeVar(Action):
    s_szNodeNote = "设置树上的公共变量。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(SetTreeVar, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("value", "", szCaption="预设置属性", szNote="预设置属性")
        self.RegisterEditAttr("tree_var", "", szCaption="设置树属性", szNote="设置树属性", bIsPublic=True)

    def OnUpdate(self):
        szValue = self.GetAttrValue("value")
        self.SetAttrValue("tree_var", szValue)
        return Status.SUCCESS
