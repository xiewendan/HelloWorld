# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.common_pkg.triangle_transform as triangle_transform
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.common.enum_def import EComponentEntityType
except:
    pass


# 行为：战斗
class Attack(Action):
    s_szNodeNote = u"战斗"

    def OnUpdate(self):
        GameObj = self.m_TreeObj.m_GameObj

        # 失败目标
        TargetObj = entity_interface.AICmp_GetTarget(GameObj)
        if not TargetObj:
            return Status.FAIL

        # 正在技能中
        if entity_interface.SkillCmp_IsDoingSkill(GameObj):
            return Status.RUNNING

        # 需要追击
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(GameObj)
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if utils.Cal2PosDistance(TargetPosObj, CurPosObj) > 2:
            return Status.FAIL

        nTargetDir = triangle_transform.GetDirValueByVector(TargetPosObj.x - CurPosObj.x, TargetPosObj.z - CurPosObj.z)
        entity_interface.MoveCmp_SetDir(GameObj, nTargetDir)

        entity_interface.SkillCmp_DoSkill2Target(GameObj, 1, TargetObj)

        return Status.RUNNING
