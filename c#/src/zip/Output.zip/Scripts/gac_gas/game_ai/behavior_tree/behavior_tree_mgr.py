# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree import behavior_tree_creator
from gac_gas.common.singleton import singleton


# 行为树管理器
@singleton
class BehaviorTreeMgr(object):
    def __init__(self):
        self.m_dictTree = {}

    def GetTreeByName(self, szTreeName):
        BTObj = self.m_dictTree.get(szTreeName)
        if not BTObj:
            BTObj = behavior_tree_creator.Parser(szTreeName)
            self.m_dictTree[szTreeName] = BTObj
            BTObj.SetConfigFileName(szTreeName)
        return BTObj


# ----------------------------------------------------------------------------
BehaviorTreeMgrObj = BehaviorTreeMgr()
GetBehaviorTree = BehaviorTreeMgrObj.GetTreeByName
