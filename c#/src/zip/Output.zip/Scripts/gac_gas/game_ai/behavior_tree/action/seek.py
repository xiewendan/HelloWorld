﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import time
from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.action.action import Action

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.game_ai.target_selector.target_selector_utils as target_selector_utils
    import gac_gas.game_ai.command_system as command_system
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.game_ai.command_system import ECommandType
    from gac_gas.game_ai.command_system import EComponentEntityType
except:
    pass

# 追击的最大预测时间(秒)
REFRESH_TARGET_INTERVAL = 3.0


# 追逐目标
class Seek(Action):
    s_szNodeNote = "在给定的范围追逐目标，追逐为持续过程。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Seek, self).__init__(ParentObj, TreeObj)
        self.RegisterEditAttr("refresh_target_interval", REFRESH_TARGET_INTERVAL, szCaption="重新寻找目标时间(秒)", szNote="重新寻找目标时间(秒)")
        self.RegisterEditAttr("check_skill", True, szCaption="检查技能", szNote="检查技能")

    def OnInitialize(self):
        super(Seek, self).OnInitialize()
        self.SetNodeAIData("refresh_target_deadline", time.time() + self.GetAttrValue("refresh_target_interval"))

    def OnTerminate(self, eStatus):
        self.RemoveNodeAIData("refresh_target_deadline")
        super(Seek, self).OnTerminate(eStatus)

    def OnUpdate(self):
        # 失败目标
        TargetObj = entity_interface.AICmp_GetTarget(self.m_TreeObj.m_GameObj)
        if not TargetObj:
            return Status.FAIL

        # print("当前目标：{}".format(TargetObj.GetGlobalID()))

        # 已经到达
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_TreeObj.m_GameObj)
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if utils.Cal2PosDistance(TargetPosObj, CurPosObj) <= 0.3:
            return Status.SUCCESS

        # 正在技能中
        if entity_interface.SkillCmp_IsDoingSkill(self.m_TreeObj.m_GameObj):
            return Status.FAIL

        # 检查技能
        if self.GetAttrValue("check_skill"):
            if target_selector_utils.IsInSkillDistance(self.m_TreeObj.m_GameObj, TargetObj):
                return Status.SUCCESS

        # 重新寻找目标时间
        nCurTime = time.time()
        if nCurTime >= self.GetNodeAIData("refresh_target_deadline"):
            if entity_interface.AICmp_ResetTarget(self.m_TreeObj.m_GameObj):
                return Status.FAIL

        # 重新寻找目标消息
        if nCurTime <= self.m_TreeObj.GetAIData("try_reset_target", 0):
            self.m_TreeObj.RemoveAIData("try_reset_target")
            if entity_interface.AICmp_ResetTarget(self.m_TreeObj.m_GameObj):
                return Status.FAIL

        # 正在追击
        if entity_interface.MoveCmp_GetIsMoving(self.m_TreeObj.m_GameObj):
            CurMovePosObj = entity_interface.MoveCmp_GetTargetPosition(self.m_TreeObj.m_GameObj)
            if utils.Cal2PosDistance(CurMovePosObj, TargetPosObj) <= 0.3:
                return Status.RUNNING

        # 发送命令
        command_system.DoCmd(self.m_TreeObj.m_GameObj, ECommandType.MoveTo, (TargetPosObj.x, TargetPosObj.y, TargetPosObj.z))

        return Status.RUNNING
