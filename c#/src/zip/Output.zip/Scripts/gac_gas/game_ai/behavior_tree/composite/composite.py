# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.base_node import BaseNode
from gac_gas.game_ai.behavior_tree.node_type import NodeType
from gac_gas.game_ai.behavior_tree.abort_type import AbortType


# 组合节点基类
class Composite(BaseNode):
    s_szNodeNote = "这是一个组合节点基类"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(Composite, self).__init__(NodeType.COMPOSITE, ParentObj, TreeObj)
        self.RegisterEditAttr("abort_type", AbortType.NONE, szCaption=u"Abort类型", szNote=u"Abort类型")

        self.m_listChildren = []
        self.m_nCurChildIndex = None
        self.m_nChildrenCount = 0
        self.m_bIsHandleConditional = False

    def Destroy(self):
        for ChildNodeObj in self.m_listChildren:
            ChildNodeObj.Destroy()

        self.m_listChildren = []

        super(Composite, self).Destroy()

    def Abort(self, eStatus):
        for objChild in self.m_listChildren:
            if objChild.IsRunning():
                objChild.Abort(eStatus)

        super(Composite, self).Abort(eStatus)

    def IsAbortNode(self):
        return self.GetAttrValue("abort_type") is not AbortType.NONE

    def AddChild(self, ChildNodeObj):
        self.m_listChildren.append(ChildNodeObj)
        self.m_nChildrenCount += 1

    def ClearChildren(self):
        self.m_listChildren = []
        self.m_nChildrenCount = 0
        self.m_nCurChildIndex = None

    def GetChildrenCount(self):
        return self.m_nChildrenCount

    def OnConditionalAbort(self, ChildObj):
        if self.m_bIsHandleConditional:
            return False

        self.m_bIsHandleConditional = True
        eAbortType = self.GetAttrValue("abort_type")
        if eAbortType == AbortType.SELF:
            if self.IsRunning():
                self._AbortSelf(Status.ABORTED)
            else:
                ChildObj.SetNeedRemove(True)
        elif eAbortType == AbortType.LOWPRIORITY:
            if not self.IsRunning():
                self.m_TreeObj.Abort(Status.ABORTED)
        else:
            if self.IsRunning():
                self._AbortSelf(Status.ABORTED)
            else:
                self.m_TreeObj.Abort(Status.ABORTED)

        self.m_bIsHandleConditional = False

    def _AbortSelf(self, eStatus):
        for ChildObj in self.m_listChildren:
            if ChildObj.IsRunning():
                ChildObj.Abort(eStatus)
        self.OnInitialize()
