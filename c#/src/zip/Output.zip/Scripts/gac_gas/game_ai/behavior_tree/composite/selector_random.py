# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import random
from gac_gas.game_ai.behavior_tree.status import Status
from gac_gas.game_ai.behavior_tree.composite.composite import Composite


# 随机选择节点
class SelectorRandom(Composite):
    s_szImageFile = "images/selector.png"
    s_szNodeNote = "随机选中一个子节点执行，如果子节点成功，则返回成功，如果失败，则再随机选择其余的节点，直到所有子节点都失败了，才返回失败。"

    def __init__(self, ParentObj=None, TreeObj=None):
        super(SelectorRandom, self).__init__(ParentObj, TreeObj)

        self._m_dictDirtyChildren = set()

    def Destroy(self):
        self._m_dictDirtyChildren = set()
        super(SelectorRandom, self).Destroy()

    def OnUpdate(self):
        return Status.SUCCESS

    def OnInitialize(self):
        super(SelectorRandom, self).OnInitialize()
        if not self.m_listChildren:
            return

        self._m_dictDirtyChildren = set()
        CurChildObj = self.GetChildRandom()
        if CurChildObj:
            self.m_TreeObj.Start(CurChildObj)
            self._m_dictDirtyChildren.add(CurChildObj)

    def GetChildRandom(self):
        listReadyChildren = []
        for ChildNodeObj in self.m_listChildren:
            if ChildNodeObj not in self._m_dictDirtyChildren:
                listReadyChildren.append(ChildNodeObj)

        if not listReadyChildren:
            return None

        return random.choice(listReadyChildren)

    def OnChildComplete(self, eStatus):
        if eStatus == Status.SUCCESS:
            self.m_TreeObj.Stop(self, eStatus)
            return

        assert (eStatus == Status.FAIL)
        CurChildObj = self.GetChildRandom()
        if CurChildObj is None:
            self.m_TreeObj.Stop(self, eStatus)
        else:
            self.m_TreeObj.Start(CurChildObj)
            self._m_dictDirtyChildren.add(CurChildObj)
