# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.common.singleton import singleton


# 简单脚本AI管理类
@singleton
class AIScriptMgr(object):
    def __init__(self):
        self.m_dictAIScriptClass = {}
        self.m_dictAIScriptObj = {}
        # 脚本注册
        pass

    def RegisterScript(self, ScriptClassObj):
        eScriptType = ScriptClassObj.GetType()
        assert eScriptType is not None, "AIScriptMgr RegisterScript Error: [{0}] is None!!!".format(ScriptClassObj.__class__)
        assert eScriptType not in self.m_dictAIScriptClass, "AIScriptMgr RegisterScript Error: [{0}] is already existed!!!".format(ScriptClassObj.__class__)
        self.m_dictAIScriptClass[eScriptType] = ScriptClassObj

    def CreateScript(self, eScriptType):
        ScriptClassObj = self.m_dictAIScriptClass.get(eScriptType)
        if ScriptClassObj is not None:
            return ScriptClassObj()

    def GetScript(self, eScriptType):
        ScriptObj = self.m_dictAIScriptObj.get(eScriptType)
        if ScriptObj is not None:
            ScriptObj = self.CreateScript(eScriptType)
            if ScriptObj:
                self.m_dictAIScriptObj[eScriptType] = ScriptObj
        return ScriptObj


# -------------------------------------------------------------------------------------
AIScriptMgrObj = AIScriptMgr()
GetScript = AIScriptMgrObj.GetScript
