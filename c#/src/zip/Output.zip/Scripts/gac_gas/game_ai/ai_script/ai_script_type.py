# -*- coding: utf-8 -*-
# __author__ = gzxiepeng


# 简单脚本类型
class EAIScriptType(object):
    pass
