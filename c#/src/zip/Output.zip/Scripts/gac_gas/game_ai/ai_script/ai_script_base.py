# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.game_ai.ai_executor_base as ai_executor_base

# 简单脚本AI基类
class AIScriptBase(ai_executor_base.AIExecutorBase):
    s_eScriptType = None

    @classmethod
    def GetType(cls):
        return cls.s_eScriptType

    def OnUpdate(self):
        pass

    def OnReset(self):
        pass

    def OnDestroy(self):
        pass
