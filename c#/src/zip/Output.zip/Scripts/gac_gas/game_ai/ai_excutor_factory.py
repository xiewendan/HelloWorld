# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.game_ai.behavior_tree.behavior_tree_mgr as behavior_tree_mgr
import gac_gas.game_ai.ai_script.ai_script_mgr as ai_script_mgr
import gac_gas.game_ai.ai_state_machine.ai_state_machine_mgr as ai_state_machine_mgr
from gac_gas.common.enum_def import EAIType


def GetAIExcutor(eAIType, szAIArg):
    # AI执行核心
    if eAIType == EAIType.BT:
        return behavior_tree_mgr.GetBehaviorTree(szAIArg)
    elif eAIType == EAIType.ST:
        return ai_script_mgr.GetScript(szAIArg)
    elif eAIType == EAIType.FSM:
        return ai_state_machine_mgr.GetFSM(szAIArg)
    else:
        assert False, "AI配置出错：{}-{}".format(eAIType, szAIArg)
