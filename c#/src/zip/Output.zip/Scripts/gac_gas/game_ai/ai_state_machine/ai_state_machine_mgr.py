# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.ai_state_machine import ai_state_machine_creator
from gac_gas.common.singleton import singleton


# 状态机管理器
@singleton
class AIStateMachineMgr(object):
    def __init__(self):
        self.m_dictFSM = {}

    def GetFSM(self, szFSMName):
        FSMObj = self.m_dictFSM.get(szFSMName)
        if not FSMObj:
            FSMObj = ai_state_machine_creator.Parser(szFSMName)
            self.m_dictFSM[szFSMName] = FSMObj
            FSMObj.SetConfigFileName(szFSMName)
        return FSMObj


# ----------------------------------------------------------------------------
AIStateMachineMgrObj = AIStateMachineMgr()
GetFSM = AIStateMachineMgrObj.GetFSM
