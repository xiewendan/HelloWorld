# -*- coding: utf-8 -*-

from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

class GamePrepare(AIStateBase):
    s_szStateNote = "赛前准备阶段"

    def __init__(self, FSMObj=None):
        super(GamePrepare, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.FULLPLAYER])

    def OnEvent(self, eGameMessageType, *args, **kwargs):
        if eGameMessageType == EAIStateEvent.FULLPLAYER:
            nNextStateID = self.GetNextState(eGameMessageType)
            self.m_FSMObj.ChangeState(self, nNextStateID)
