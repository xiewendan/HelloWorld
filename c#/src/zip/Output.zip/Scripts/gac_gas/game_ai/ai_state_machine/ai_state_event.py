# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

# 状态机节点消息
class EAIStateEvent(object):
    # 以下是AI消息
    RUNNING = "running"
    FINISH = "finish"
    REVERT_PREVIOUS = "revert_previous"
    FIND_TARGET = "find_target"
    NEED_CHASE = "need_chase"
    NEED_ATTACK = "need_attack"
    LOST_TARGET = "lost_target"
    STUCK = "stuck"

    # 以下是场景消息
    ENTER_SCENE = "enter_scene"  # 进场景
    FULLPLAYER = "full_player"  # 人齐了
    DOGZ_DIE = "dogz_die"  # 神兽死了
