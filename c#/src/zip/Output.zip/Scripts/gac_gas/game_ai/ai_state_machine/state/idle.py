# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.entity.entity_interface as entity_interface
except:
    pass


# 空闲状态
class Idle(AIStateBase):
    s_szStateNote = "空闲状态"

    def __init__(self, FSMObj=None):
        super(Idle, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.FIND_TARGET])

    def OnUpdate(self):
        TargetObj = entity_interface.AICmp_GetTarget(self.m_FSMObj.m_GameObj, bIsFight=False)
        if TargetObj:
            self.m_FSMObj.SetAIData("target_gid", TargetObj.GetGlobalID())
            return EAIStateEvent.FIND_TARGET
        else:
            if self.m_FSMObj.GetAIData("target_gid") is not None:
                self.m_FSMObj.SetAIData("target_gid", None)

        return EAIStateEvent.RUNNING
