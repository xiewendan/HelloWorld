# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import time
from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.game_ai.target_selector.target_selector_utils as target_selector_utils
    import gac_gas.game_ai.command_system as command_system
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.game_ai.command_system import ECommandType
    from gac_gas.game_ai.command_system import EComponentEntityType
except:
    pass


# 追击的最大预测时间(秒)
REFRESH_TARGET_INTERVAL = 3.0


# 追击状态
class Chase(AIStateBase):
    s_szStateNote = "追击状态"

    def __init__(self, FSMObj=None):
        super(Chase, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.NEED_ATTACK, EAIStateEvent.LOST_TARGET])

        self.RegisterEditAttr("refresh_target_interval", REFRESH_TARGET_INTERVAL, szCaption="重新寻找目标时间(秒)", szNote="重新寻找目标时间(秒)")
        self.RegisterEditAttr("check_skill", True, szCaption="检查技能", szNote="检查技能")

    def OnEnter(self):
        self.SetStateAIData("refresh_target_deadline", time.time() + self.GetAttrValue("refresh_target_interval"))

    def OnExit(self):
        self.RemoveStateAIData("refresh_target_deadline")

    def OnUpdate(self):
        # 失败目标
        TargetObj = entity_interface.AICmp_GetTarget(self.m_FSMObj.m_GameObj)
        if not TargetObj:
            return EAIStateEvent.LOST_TARGET

        # 已经到达
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_FSMObj.m_GameObj)
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if utils.Cal2PosDistance(TargetPosObj, CurPosObj) <= 0.3:
            return EAIStateEvent.NEED_ATTACK

        # 检查技能
        if self.GetAttrValue("check_skill"):
            if target_selector_utils.IsInSkillDistance(self.m_FSMObj.m_GameObj, TargetObj):
                return EAIStateEvent.NEED_ATTACK

        # 重新寻找目标时间
        nCurTime = time.time()
        if nCurTime >= self.GetStateAIData("refresh_target_deadline"):
            if entity_interface.AICmp_ResetTarget(self.m_FSMObj.m_GameObj):
                return EAIStateEvent.RUNNING

        # 重新寻找目标消息
        if nCurTime <= self.m_FSMObj.GetAIData("try_reset_target", 0):
            self.m_FSMObj.RemoveAIData("try_reset_target")
            if entity_interface.AICmp_ResetTarget(self.m_FSMObj.m_GameObj):
                return EAIStateEvent.RUNNING

        # 正在追击
        if entity_interface.MoveCmp_GetIsMoving(self.m_FSMObj.m_GameObj):
            CurMovePosObj = entity_interface.MoveCmp_GetTargetPosition(self.m_FSMObj.m_GameObj)
            if utils.Cal2PosDistance(CurMovePosObj, TargetPosObj) <= 0.3:
                return EAIStateEvent.RUNNING

        # 发送命令
        command_system.DoCmd(self.m_FSMObj.m_GameObj, ECommandType.MoveTo, (TargetPosObj.x, TargetPosObj.y, TargetPosObj.z))

        return EAIStateEvent.RUNNING
