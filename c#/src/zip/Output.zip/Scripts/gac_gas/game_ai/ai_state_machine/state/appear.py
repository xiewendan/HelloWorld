# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent


# 出场状态
class Appear(AIStateBase):
    s_szStateNote = "出场状态"

    def __init__(self, FSMObj=None):
        super(Appear, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.FINISH])

    def OnUpdate(self):
        return EAIStateEvent.FINISH
