# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

# 获取属性值错误
class GetAttrError(RuntimeError): pass

# 设置属性值错误
class SetAttrError(RuntimeError): pass


# AI状态基类
class AIStateBase(object):
    s_szStateNote = "这是一个状态节点"

    def __init__(self, FSMObj=None):
        self.SetFSMObj(FSMObj)
        self._m_dictAttr = {}
        self._m_dictChangeStateInfo = {}
        self._m_listStateEvent = []
        self._m_szStateType = self.__class__.__name__
        self._m_szFileFSMName = None
        self._m_nDiagramID = 0

    # 获取说明
    @classmethod
    def GetStateNote(cls):
        return cls.s_szStateNote

    # 销毁
    def Destroy(self):
        self.m_FSMObj = None

    def SetFSMObj(self, FSMObj):
        self.m_FSMObj = FSMObj

    def IsSubmachine(self):
        return False

    # 注册可编辑属性，属性名，默认值， 注释, 是否是公共属性(节点始化使用)
    def RegisterEditAttr(self, szName, defaultValue, szCaption=None, szNote=None):
        assert (self._m_dictAttr.get(szName) is None)
        assert (isinstance(defaultValue, int) or isinstance(defaultValue, float) or isinstance(defaultValue, bool) or isinstance(defaultValue, unicode) or
                isinstance(defaultValue, str) or isinstance(defaultValue, tuple))
        assert (isinstance(szName, str) or isinstance(szName, unicode))
        assert (isinstance(szCaption, str) or isinstance(szCaption, unicode) or szCaption is None)
        assert (isinstance(szNote, str) or isinstance(szNote, unicode) or szNote is None)

        if szCaption is None:
            szCaption = szName

        if szNote is None:
            szNote = szCaption

        self._m_dictAttr[szName] = {"Name": szName, "Value": defaultValue, "Caption": szCaption, "Note": szNote}

    # 获取可编辑属性
    def GetAllEditAttr(self):
        return self._m_dictAttr

    # 设置dictAttrData(节点始化使用)
    def SetAttrData(self, dictAttrData):
        for szName, value in dictAttrData.iteritems():
            if szName in self._m_dictAttr:
                self._m_dictAttr[szName]["Value"] = value
            else:
                raise NotImplementedError("No Attr1:%s" % szName)

    # 获取属性
    def GetAttrValue(self, szName):
        # 检查节点属性
        if szName in self._m_dictAttr:
            return self.GetStateAIData(szName)
        raise GetAttrError("GetAttrError Error: {}-{}".format(self._m_szStateType, szName))

    # 设置属性
    def SetAttrValue(self, szName, value):
        # 检查节点属性
        if szName in self._m_dictAttr:
            self.SetStateAIData(szName, value)
            return
        raise SetAttrError("SetAttrValue Error: {}-({}:{})".format(self._m_szStateType, szName, value))

    # 设置状态AI数据
    def SetStateAIData(self, szKey, value):
        self.m_FSMObj.m_dictAIData[self._m_szStateType][szKey] = value

    # 获取状态AI数据
    def GetStateAIData(self, szKey, default=None):
        return self.m_FSMObj.m_dictAIData[self._m_szStateType].get(szKey, default)

    # 清理状态AI数据
    def RemoveStateAIData(self, szKey):
        self.m_FSMObj.m_dictAIData[self._m_szStateType].pop(szKey)

    # 获取所有节点AI数据
    def GetAllStateData(self):
        return dict(self.m_FSMObj.m_dictAIData[self._m_szStateType])

    # 设置图节点ID
    def SetDiagramID(self, nID):
        self._m_nDiagramID = nID
        self._m_szStateType = "{}_{}".format(self.__class__.__name__, self._m_nDiagramID)

    # 获取图节点ID
    def GetDiagramID(self):
        return self._m_nDiagramID

    # 设置树文件名
    def SetFileFSMName(self, szName):
        self._m_szFileFSMName = szName

    # 获取树文件名
    def GetFileFSMName(self):
        return self._m_szFileFSMName

    def GetStateType(self):
        return self._m_szStateType

    def GetAllStateEvent(self):
        return self._m_listStateEvent

    def RegisterEvent(self, listAIStateEvent):
        for eAIStateEvent in listAIStateEvent:
            if eAIStateEvent not in self._m_listStateEvent:
                self._m_listStateEvent.append(eAIStateEvent)

    def SetChangeStateInfo(self, dictChangeStateInfo):
        self._m_dictChangeStateInfo = dictChangeStateInfo

    def GetNextState(self, eStateEventType):
        return self._m_dictChangeStateInfo.get(eStateEventType)

    def OnEnter(self):
        pass

    def OnEvent(self, eEventType, *args, **kwargs):
        pass

    def OnUpdate(self):
        pass

    def OnReset(self):
        pass

    def OnExit(self):
        pass
