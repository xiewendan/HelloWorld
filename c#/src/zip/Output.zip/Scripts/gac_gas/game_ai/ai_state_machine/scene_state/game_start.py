# -*- coding: utf-8 -*-

from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

try:
    import gac_gas.common_pkg.tick_mgr as tick_mgr
    import gac_gas.entity.entity_interface as entity_interface
except:
    pass


# 注意,这是全局唯一实例,所以不能把信息存储在这上面
class GameStart(AIStateBase):
    s_szStateNote = "开始阶段"

    def __init__(self, FSMObj=None):
        super(GameStart, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.DOGZ_DIE])
        self.RegisterEditAttr("DrawCardTime", 10000, szCaption="抽卡时间(毫秒)", szNote="抽卡时间(毫秒)")

    def OnEnter(self):
        print "GameStart"
        ScenePlayObj = self.m_FSMObj.m_GameObj
        for HeroObj, SideGroupObj in ScenePlayObj.m_dictGroupSide.iteritems():
            HeroObj.GetGacEntityRpc().RRpcGetCardCmp().Gas2GacShowCard()
            entity_interface.CardCmp_DrawCard(HeroObj, 3)
        self.RegisterDrawCardTick()

    def RegisterDrawCardTick(self):
        ScenePlayObj = self.m_FSMObj.m_GameObj
        nDrawCardTick = tick_mgr.RegisterTick("GasBattleScenePlayer.RegisterDrawCardTick",self.GetAttrValue("DrawCardTime"),self.DrawCard, ScenePlayObj.m_Scene.GetSceneID())
        self.SetStateAIData("RegisterDrawCardTick", nDrawCardTick)

    def DrawCard(self, szSceneID):
        SceneObj = theApp.GetSceneMgr().GetSceneByID(szSceneID)
        if not SceneObj:
            return
        ScenePlayObj = SceneObj.m_ScenePlay
        for HeroObj, SideGroupObj in ScenePlayObj.m_dictGroupSide.iteritems():
            entity_interface.CardCmp_DrawCard(HeroObj, 1)

    def UnRegisterDrawCardTick(self):
        nDrawCardTick = self.m_FSMObj.m_dictAIData["RegisterDrawCardTick"]
        if nDrawCardTick:
            tick_mgr.UnRegisterTick(nDrawCardTick)
            self.m_FSMObj.RemoveAIData("RegisterDrawCardTick")

    def OnExit(self):
        print "exit GameStart"
        self.UnRegisterDrawCardTick()
