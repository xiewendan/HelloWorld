# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from ai_state_base import AIStateBase
from ai_state_event import EAIStateEvent


# 行为：状态机节点
class SubmachineState(AIStateBase):
    def __init__(self, FSMObj=None):
        super(SubmachineState, self).__init__(FSMObj)
        self.RegisterEditAttr("fsm_name", "", szCaption="状态机名称", szNote="状态机名称")
        self.RegisterEvent([EAIStateEvent.FINISH])

    def IsSubmachine(self):
        return True

    def Destroy(self):
        if self.m_AIStateMachineObj:
            self.m_AIStateMachineObj.Destroy()
            self.m_AIStateMachineObj = None
        super(SubmachineState, self).Destroy()

    def OnEnter(self):
        if self.m_AIStateMachineObj is None:
            import gac_gas.game_ai.ai_state_machine.ai_state_machine_mgr as ai_state_machine_mgr
            szFSMName = self.GetAttrValue("fsm_name")
            self.m_AIStateMachineObj = ai_state_machine_mgr.GetFSM(szFSMName)
            assert self.m_AIStateMachineObj is not None, "状态机不存在：{}".format(szFSMName)

        self.m_AIStateMachineObj.Reset(self.m_FSMObj.m_GameObj, self.m_FSMObj.m_dictAIData)

        # 调试相关
        self.m_AIStateMachineObj.SetDebugFun(self.m_FSMObj.m_GameObj, self.m_FSMObj.m_dictAIData, self.m_FSMObj.GetDebugFun())

    def OnExit(self):
        if self.m_AIStateMachineObj:
            self.m_AIStateMachineObj.Stop(self.m_FSMObj.m_GameObj, self.m_FSMObj.m_dictAIData)

            # 调试相关
            self.m_AIStateMachineObj.SetDebugFun(self.m_FSMObj.m_GameObj, self.m_FSMObj.m_dictAIData, None)

    def OnUpdate(self):
        self.m_AIStateMachineObj.Update(self.m_FSMObj.m_GameObj, self.m_FSMObj.m_dictAIData)
        if self.m_AIStateMachineObj.IsRunning(self.m_FSMObj.m_GameObj, self.m_FSMObj.m_dictAIData):
            return EAIStateEvent.RUNNING
        return EAIStateEvent.FINISH
