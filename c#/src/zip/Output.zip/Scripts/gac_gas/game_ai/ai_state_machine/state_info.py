# -*- coding: utf-8 -*-

g_dictStateInfo = {
    "Appear": "gac_gas.game_ai.ai_state_machine.state.appear",
    "Chase": "gac_gas.game_ai.ai_state_machine.state.chase",
    "Fight": "gac_gas.game_ai.ai_state_machine.state.fight",
    "GameOver": "gac_gas.game_ai.ai_state_machine.scene_state.game_over",
    "GamePrepare": "gac_gas.game_ai.ai_state_machine.scene_state.game_prepare",
    "GameStart": "gac_gas.game_ai.ai_state_machine.scene_state.game_start",
    "Idle": "gac_gas.game_ai.ai_state_machine.state.idle",
    "MoveToDestPos": "gac_gas.game_ai.ai_state_machine.state.move_to_dest_pos",
    "SubmachineState": "gac_gas.game_ai.ai_state_machine.submachine_state",
    "Wander": "gac_gas.game_ai.ai_state_machine.state.wander",
}
