# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import sys
import json
import codecs
import state_info
from ai_state_machine import AIStateMachine
from gac_gas.common_pkg.utils import IS_CLIENT_PLATFORM
from gac_gas.common.const_def import sys_const
from gac_gas.common.singleton import singleton


# 特殊状态, 状态图使用，实际运行中并不使用
SPEICAL_STATE = {"Enter", "Exit"}


# 状态机生成器
@singleton
class AIStateMachineCreator(object):
    def __init__(self):
        self.m_FSMObj = None
        self.m_dictState = {}
        self.m_dictStateInfo = state_info.g_dictStateInfo

    def Parser(self, szFSMName):
        szFileName = sys_const.FSM_FILE_PATH.format(szFSMName)
        if IS_CLIENT_PLATFORM:
            szFileName = "{0}{1}".format("Data/", szFileName)
        else:
            szFileName = "{0}{1}".format(theApp.GetResPath(), szFileName)

        with codecs.open(szFileName, 'r', 'utf-8') as fFile:
            szData = fFile.read()

        assert szData, "AIStateMachineCreator Parser Error:[{0}] is empty!!!".format(szFileName)

        if hasattr(json, "loads"):
            dictData = json.loads(szData)
        elif hasattr(json, "read"):
            dictData = json.read(szData)
        else:
            assert False

        dictState = dictData.get("States")
        assert (dictState is not None)

        self.m_FSMObj = AIStateMachine()
        self.m_dictState = self.m_FSMObj.GetStateDict()

        if not dictData.get("RootState"):
            return

        nRootStateID = dictData["RootState"]
        RootStateObj = self._DoParser(nRootStateID, dictState, szFSMName)
        RootStateObj.SetFSMObj(self.m_FSMObj)

        self.m_FSMObj.SetRootStateID(nRootStateID)

        return self.m_FSMObj

    def _GetClassObj(self, szClassName):
        szClassModuleName = self.m_dictStateInfo.get(szClassName)
        if szClassModuleName is not None:
            mModule = sys.modules.get(szClassModuleName)
            if not mModule:
                __import__(szClassModuleName)
                mModule = sys.modules[szClassModuleName]

            ClassObj = getattr(mModule, szClassName)
            return ClassObj

    def _DoParser(self, nID, dictState, szFSMName):
        dictInfo = dictState[str(nID)]
        szClassName = dictInfo['ClassName']
        dictAttrData = dictInfo['AttrData']
        dictChangeStateInfo = dictInfo["ChangeStateInfo"]

        ClassObj = self._GetClassObj(szClassName)
        StateObj = ClassObj()
        StateObj.SetDiagramID(nID)
        StateObj.SetFileFSMName(szFSMName)
        StateObj.SetAttrData(dictAttrData)
        StateObj.SetChangeStateInfo(dictChangeStateInfo)
        self.m_dictState[nID] = StateObj

        if dictChangeStateInfo:
            for nNextID in dictChangeStateInfo.itervalues():
                if nNextID in self.m_dictState:
                    continue

                dictNectInfo = dictState[str(nNextID)]
                if dictNectInfo['ClassName'] in SPEICAL_STATE:
                    continue

                NextStateObj = self._DoParser(nNextID, dictState, szFSMName)
                if NextStateObj is not None:
                    NextStateObj.SetFSMObj(self.m_FSMObj)

        return StateObj


# -----------------------------------------------------------------------------------
AIStateMachineCreatorObj = AIStateMachineCreator()
Parser = AIStateMachineCreatorObj.Parser
