# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.game_ai.ai_executor_base as ai_executor_base
from ai_state_event import EAIStateEvent


# AI状态机
class AIStateMachine(ai_executor_base.AIExecutorBase):
    def __init__(self):
        super(AIStateMachine, self).__init__()
        self._m_nRootStateID = None
        self._m_dictState = {}

    # 设置初始状态
    def SetRootStateID(self, nRootStateID):
        self._m_nRootStateID = nRootStateID

    # 获取初始状态
    def GetRootStateID(self):
        return self._m_nRootStateID

    # 设置状态字典(树初始化使用)
    def SetStateDict(self, dictState):
        self._m_dictState = dictState

    # 获取状态字典(树初始化使用)
    def GetStateDict(self):
        return self._m_dictState

    def ChangeState(self, CurrentState, nNextStateID):
        NextStateObj = self._m_dictState[nNextStateID]
        self._ChangeState(CurrentState, NextStateObj)

    def _ChangeState(self, CurrentState, NextStateObj):
        if CurrentState:
            self.m_dictAIData["fsm_pre_state"] = CurrentState.GetDiagramID()
            CurrentState.OnExit()

            # 调试
            if self._m_funDebug is not None:
                self._m_funDebug(CurrentState, "exit_state")
        else:
            self.m_dictAIData["fsm_pre_state"] = None

        if NextStateObj:
            self.m_dictAIData["fsm_cur_state"] = NextStateObj.GetDiagramID()
            NextStateObj.OnEnter()

            # 调试
            if self._m_funDebug is not None:
                self._m_funDebug(NextStateObj, "enter_state")
        else:
            self.m_dictAIData["fsm_cur_state"] = None

    def OnEvent(self, eGameMessageType, *args, **kwargs):
        nCurStateID = self.m_dictAIData.get("fsm_cur_state")
        if not nCurStateID:
            nCurStateID = self.GetRootStateID()

        if not nCurStateID:
            return

        CurrentState = self._m_dictState[nCurStateID]
        if not CurrentState:
            return
        CurrentState.OnEvent(eGameMessageType, *args, **kwargs)

    def OnUpdate(self):
        nCurStateID = self.m_dictAIData.get("fsm_cur_state")
        if not nCurStateID:
            return

        CurrentState = self._m_dictState[nCurStateID]
        if not CurrentState:
            return

        eStateEventType = CurrentState.OnUpdate()

        # 调试
        if self._m_funDebug is not None:
            self._m_funDebug(CurrentState, "update_state")

        if eStateEventType == EAIStateEvent.RUNNING:
            # 正在运行
            return
        elif eStateEventType == EAIStateEvent.REVERT_PREVIOUS:
            # 返回上一状态
            nNextStateID = self.m_dictAIData.get("fsm_pre_state")
        else:
            # 寻找下一状态
            nNextStateID = CurrentState.GetNextState(eStateEventType)

        if nNextStateID:
            NextStateObj = self._m_dictState.get(nNextStateID)
        else:
            NextStateObj = None

        self._ChangeState(CurrentState, NextStateObj)

    def OnReset(self):
        # 退出原状态
        nCurStateID = self.m_dictAIData.get("fsm_cur_state")
        if nCurStateID:
            CurrentState = self._m_dictState[nCurStateID]
            CurrentState.OnReset()

            # 调试
            if self._m_funDebug is not None:
                self._m_funDebug(CurrentState, "exit_state")

        # 清除数据
        for StateObj in self._m_dictState.itervalues():
            dictAttr = {}
            for szAttrName, dictValue in StateObj.GetAllEditAttr().iteritems():
                dictAttr[szAttrName] = dictValue["Value"]
            self.m_dictAIData[StateObj.GetStateType()] = dictAttr

        # 设置新状态
        NextStateObj = self._m_dictState[self._m_nRootStateID]
        self._ChangeState(None, NextStateObj)

    def Stop(self, GameObj, dictAIData):
        self.SetData(GameObj, dictAIData)

        # 退出原状态
        nCurStateID = self.m_dictAIData.get("fsm_cur_state")
        if nCurStateID:
            CurrentState = self._m_dictState[nCurStateID]
            CurrentState.OnExit()

            # 调试
            if self._m_funDebug is not None:
                self._m_funDebug(CurrentState, "exit_state")

        # 清除数据
        for szStateType, StateObj in self._m_dictState.iteritems():
            if szStateType in self.m_dictAIData:
                del self.m_dictAIData[szStateType]

        self.m_dictAIData["fsm_cur_state"] = None

        self.SetData(None, None)

    # 当前状态正在运行
    def IsRunning(self, GameObj, dictAIData):
        return dictAIData.get("fsm_cur_state") is not None

    def OnDestroy(self):
        for StateObj in self._m_dictState.itervalues():
            StateObj.Destroy()
        self._m_dictState = {}

    # 设置调试回调
    def OnSetDebugFun(self):
        # 调试接口
        if self._m_funDebug is not None:
            # 发送当前正在运行的节点状态
            nCurStateID = self.m_dictAIData.get("fsm_cur_state")
            if nCurStateID:
                CurrentState = self._m_dictState[nCurStateID]
                self._m_funDebug(CurrentState, "enter_state")
