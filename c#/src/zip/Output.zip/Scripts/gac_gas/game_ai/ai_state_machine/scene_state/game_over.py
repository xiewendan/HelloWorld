# -*- coding: utf-8 -*-

from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase

class GameOver(AIStateBase):
    s_szStateNote = "始束阶段"

    def __init__(self, FSMObj=None):
        super(GameOver, self).__init__(FSMObj)
