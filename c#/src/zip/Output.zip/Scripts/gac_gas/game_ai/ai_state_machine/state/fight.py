# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from gac_gas.game_ai.ai_state_machine.ai_state_base import AIStateBase
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.common_pkg.triangle_transform as triangle_transform
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.common.enum_def import EComponentEntityType
except:
    pass


# 战斗状态
class Fight(AIStateBase):
    s_szStateNote = "战斗状态"

    def __init__(self, FSMObj=None):
        super(Fight, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.NEED_CHASE, EAIStateEvent.LOST_TARGET])

    def OnUpdate(self):
        GameObj = self.m_FSMObj.m_GameObj

        # 失败目标
        TargetObj = entity_interface.AICmp_GetTarget(GameObj)
        if not TargetObj:
            return EAIStateEvent.LOST_TARGET

        # 正在技能中
        if entity_interface.SkillCmp_IsDoingSkill(GameObj):
            return EAIStateEvent.RUNNING

        # 需要追击
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(GameObj)
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if utils.Cal2PosDistance(TargetPosObj, CurPosObj) > 2:
            return EAIStateEvent.NEED_CHASE

        nTargetDir = triangle_transform.GetDirValueByVector(TargetPosObj.x - CurPosObj.x, TargetPosObj.z - CurPosObj.z)
        entity_interface.MoveCmp_SetDir(GameObj, nTargetDir)

        entity_interface.SkillCmp_DoSkill2Target(GameObj, 1, TargetObj)

        return EAIStateEvent.RUNNING
