# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from idle import Idle
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.game_ai.command_system as command_system
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.game_ai.command_system import ECommandType
except:
    pass


# 闲逛状态
class Wander(Idle):
    s_szStateNote = "闲逛状态"

    def __init__(self, FSMObj=None):
        super(Wander, self).__init__(FSMObj)
        self.RegisterEvent([EAIStateEvent.STUCK])

        self.RegisterEditAttr("wander_radius", 3.0, szCaption="闲逛半径(米)", szNote="闲逛半径(米)")

    def OnEnter(self):
        self.FindNextPos()

    def OnExit(self):
        self.RemoveStateAIData("cur_pos")

    def OnUpdate(self):
        eStateEventType = super(Wander, self).OnUpdate()
        if eStateEventType is not EAIStateEvent.RUNNING:
            return eStateEventType

        TargetPosObj = self.GetStateAIData("cur_pos")
        if not TargetPosObj:
            return EAIStateEvent.STUCK

        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_FSMObj.m_GameObj)
        if utils.Cal2PosDistance(TargetPosObj, CurPosObj) <= 0.3:
            self.FindNextPos()
            return EAIStateEvent.RUNNING

        if entity_interface.MoveCmp_GetIsMoving(self.m_FSMObj.m_GameObj):
            CurMovePosObj = entity_interface.MoveCmp_GetTargetPosition(self.m_FSMObj.m_GameObj)
            if utils.Cal2PosDistance(CurMovePosObj, TargetPosObj) <= 0.3:
                return EAIStateEvent.RUNNING

        # 发送命令
        command_system.DoCmd(self.m_FSMObj.m_GameObj, ECommandType.MoveTo, (TargetPosObj.x, TargetPosObj.y, TargetPosObj.z))

        return EAIStateEvent.RUNNING

    def FindNextPos(self):
        nWanderRadius = self.GetAttrValue("wander_radius")
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_FSMObj.m_GameObj)
        TargetPosObj = utils.DetourFindRandomNav(self.m_FSMObj.m_SceneObj, CurPosObj.x, CurPosObj.y, CurPosObj.z, nWanderRadius)
        self.SetStateAIData("cur_pos", TargetPosObj)
