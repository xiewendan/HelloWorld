# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from idle import Idle
from gac_gas.game_ai.ai_state_machine.ai_state_event import EAIStateEvent

try:
    import gac_gas.common_pkg.utils as utils
    import gac_gas.game_ai.command_system as command_system
    import gac_gas.entity.entity_interface as entity_interface
    from gac_gas.game_ai.command_system import ECommandType
except:
    pass


# 向主基地前进
class MoveToDestPos(Idle):
    s_szStateNote = "向主基地前进状态"

    def OnEnter(self):
        DestPosObj = self.GetStateAIData("dest_pos")
        if not DestPosObj:
            DestPosObj = entity_interface.InfoCmp_GetScene(self.m_FSMObj.m_GameObj).GetEnemyDogzPosByEntity(self.m_FSMObj.m_GameObj)
            self.SetStateAIData("dest_pos", DestPosObj)

    def OnExit(self):
        self.RemoveStateAIData("dest_pos")

    def OnUpdate(self):
        eStateEventType = super(MoveToDestPos, self).OnUpdate()
        if eStateEventType is not EAIStateEvent.RUNNING:
            return eStateEventType

        DestPosObj = self.GetStateAIData("dest_pos")

        # 已经到达
        CurPosObj = entity_interface.MoveCmp_GetPositionSelf(self.m_FSMObj.m_GameObj)
        if utils.Cal2PosDistance(DestPosObj, CurPosObj) <= 0.3:
            return EAIStateEvent.RUNNING

        # 正在追击
        if entity_interface.MoveCmp_GetIsMoving(self.m_FSMObj.m_GameObj):
            CurMovePosObj = entity_interface.MoveCmp_GetTargetPosition(self.m_FSMObj.m_GameObj)
            if utils.Cal2PosDistance(CurMovePosObj, DestPosObj) <= 0.3:
                return EAIStateEvent.RUNNING

        # 发送命令
        command_system.DoCmd(self.m_FSMObj.m_GameObj, ECommandType.MoveTo, (DestPosObj.x, DestPosObj.y, DestPosObj.z))

        return EAIStateEvent.RUNNING
