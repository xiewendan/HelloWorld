# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.entity.entity_interface as entity_interface
import gac_gas.entity.entity_common_cfg_mgr as entity_common_cfg_mgr
from gac_gas.common.enum_def import ConstMe
from gac_gas.common.enum_def import EPropertyType
from gac_gas.common_pkg import utils


# 指挥命令类型
class ECommandType(ConstMe):
    CreateEntity = "create_entity"
    SetTarget = "set_target"
    SelectEntity = "select_entity"
    MoveTo = "move_to"
    DoSkill = "do_skill"
    UseCard = "use_card"
    ChangeCamp = "change_camp"


# -------------------------------------所有命令-----------------------------------------------------

# 创建实体
def CreateEntity(GameObj, nEntityCfgID, nCamp, nX, nY, nZ):
    SceneObj = entity_interface.InfoCmp_GetScene(GameObj)
    if not SceneObj:
        return

    nDetourFilter = entity_common_cfg_mgr.CetDetourFilterByCfg(nEntityCfgID)

    Pos = utils.DetourFindNearestNav(SceneObj, nX, nY, nZ, nDetourFilter)
    if not Pos:
        return

    dictDynamicPro = {
        EPropertyType.Pos: [Pos.x, Pos.y, Pos.z],
        EPropertyType.Dir: 0,
        EPropertyType.SceneIdx: SceneObj.GetScenePosIdx(),
    }

    GameEntity = SceneObj.CreateGameObjInScene(nEntityCfgID, dictDynamicPro)
    entity_interface.FightCmp_SetCamp(GameEntity, nCamp)


# 设置目标
def SetTarget(GameObj, szTargetGID):
    pass


# 选择对象
def SelectEntity(GameObj, szGID):
    import gac_gas.game_ai.ai_debug_mgr as ai_debug_mgr
    ai_debug_mgr.SetSelectObjEx(szGID)


# 移动
def MoveTo(GameObj, nX, nY, nZ):
    SceneObj = entity_interface.InfoCmp_GetScene(GameObj)
    if not SceneObj:
        return

    entity_interface.MoveCmp_CrowdMove(GameObj, nX, nY, nZ)


# 技能
def DoSkill(GameObj, nSkillID):
    pass


# 使用卡牌
def UseCard(GameObj, szCardID, listPosition):
    entity_interface.CardCmp_UseCard(GameObj, szCardID, listPosition)


# 场内切换阵容
def ChangeCamp(GameObj):
    SceneObj = entity_interface.InfoCmp_GetScene(GameObj)
    if hasattr(SceneObj, "RequestChangeCamp"):
        SceneObj.RequestChangeCamp(GameObj)


# -------------------------------------命令管理----------------------------------------------------

g_AllCommand = {
    ECommandType.CreateEntity: CreateEntity,
    ECommandType.SetTarget: SetTarget,
    ECommandType.SelectEntity: SelectEntity,
    ECommandType.MoveTo: MoveTo,
    ECommandType.DoSkill: DoSkill,
    ECommandType.UseCard: UseCard,
    ECommandType.ChangeCamp: ChangeCamp,
}


# 指令命令
def DoCmd(GameObj, eCommandType, args):
    funCmd = g_AllCommand.get(eCommandType)
    assert funCmd is not None, "指挥命令无效：{}".format(eCommandType)
    funCmd(GameObj, *args)
