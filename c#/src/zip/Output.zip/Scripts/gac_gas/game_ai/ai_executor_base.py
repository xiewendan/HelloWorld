# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
import gac_gas.entity.entity_interface as entity_interface

try:
    import bat.game_scene.bat_battle_scene as bat_battle_scene
except:
    pass


# AI基类
class AIExecutorBase(object):
    def __init__(self):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_GameObj = None
        self.m_dictAIData = {}
        self.m_SceneObj = None

        # 以下接口是调试接口
        self._m_funDebug = None

        # 调试使用
        self._m_szConfigFileName = None

    def SetData(self, GameObj, dictAIData):
        self.m_GameObj = GameObj
        self.m_dictAIData = dictAIData
        self.OnSetData(GameObj, dictAIData)

    def OnSetData(self, GameObj, dictAIData):
        if GameObj:
            if isinstance(GameObj, bat_battle_scene.BatBattleScenePlay):
                self.m_SceneObj = GameObj
            else:
                self.m_SceneObj = entity_interface.InfoCmp_GetScene(GameObj)
        else:
            self.m_SceneObj = None

    def Update(self, GameObj, dictAIData):
        self.SetData(GameObj, dictAIData)
        self.OnUpdate()
        self.SetData(None, None)

    def OnUpdate(self):
        raise NotImplementedError

    def Reset(self, GameObj, dictAIData):
        self.SetData(GameObj, dictAIData)
        self.OnReset()
        self.SetData(None, None)

    def OnReset(self):
        raise NotImplementedError

    def Destroy(self, GameObj, dictAIData):
        self.SetData(GameObj, dictAIData)
        self.OnDestroy()
        self.SetData(None, None)

    def OnDestroy(self):
        raise NotImplementedError

    def OnEvent(self, eGameMessageType, *args, **kwargs):
        pass

    def NotifyEvent(self, GameObj, dictAIData, eGameMessageType, *args, **kwargs):
        self.SetData(GameObj, dictAIData)
        self.OnEvent(eGameMessageType, *args, **kwargs)
        self.SetData(None, None)

    # 设置AI数据
    def SetAIData(self, szKey, value):
        self.m_dictAIData[szKey] = value

    # 获取AI数据
    def GetAIData(self, szKey, default=None):
        return self.m_dictAIData.get(szKey, default)

    # 清理AI数据
    def RemoveAIData(self, szKey):
        self.m_dictAIData.pop(szKey)

    # 设置行为树文件名（调试使用）
    def SetConfigFileName(self, szConfigFileName):
        self._m_szConfigFileName = szConfigFileName

    # 获取行为树文件名（调试使用）
    def GetConfigFileName(self):
        return self._m_szConfigFileName

    # 设置调试回调
    def OnSetDebugFun(self):
        pass

    # 设置调试回调
    def SetDebugFun(self, GameObj, dictAIData, funDebug):
        self._m_funDebug = funDebug

        self.SetData(GameObj, dictAIData)
        self.OnSetDebugFun()
        self.SetData(None, None)

    def GetDebugFun(self):
        return self._m_funDebug
