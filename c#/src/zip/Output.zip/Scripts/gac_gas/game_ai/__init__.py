# -*- coding: utf-8 -*-

import logging
import sys


def logger_init():
    logger = logging.getLogger("AI")

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setLevel(logging.DEBUG)

    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    return logger


logger_init()
