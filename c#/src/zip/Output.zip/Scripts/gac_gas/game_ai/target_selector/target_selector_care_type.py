# -*- coding: utf-8 -*-

import target_selector_utils as target_selector_utils
import target_selector_base as target_selector_base
import gac_gas.entity.entity_interface as entity_interface
from gac_gas.common.enum_def import ETargetSelectorType


# 目标选择锁定类型
class TargetSelectorCareType(target_selector_base.BaseTargetSelector):
    s_eTargetSelectorType = ETargetSelectorType.CareType

    def __init__(self):
        self.m_setCareType = set()

    def Init(self, listArg):
        self.m_setCareType = set(listArg)

    def GetTarget(self, FromObj, nSearchRange=None, bIsFight=True):
        if nSearchRange is None:
            nSearchRange = self.GetSearchRange(FromObj, bIsFight)

        if nSearchRange <= 0:
            return

        # 当前目标
        TargetObj = target_selector_utils.TryGetCurTarget(FromObj, nSearchRange)
        if TargetObj:
            return TargetObj

        # 主动怪检查周围
        if entity_interface.InfoCmp_IsInitiative(FromObj):
            return self.FindTarget(FromObj, nSearchRange)

    def FindTarget(self, FromObj, nSearchRange=None):
        if nSearchRange is None:
            nSearchRange = self.GetSearchRange(FromObj, False)

        if nSearchRange > 0:
            return target_selector_utils.TryGetCareTypeTargetFromNearby(FromObj, self.m_setCareType, nAttackRange=1, nSearchRange=nSearchRange)
