# -*- coding: utf-8 -*-

# 目标选择基类
class BaseTargetSelector(object):
    s_eTargetSelectorType = None

    @classmethod
    def GetType(cls):
        return cls.s_eTargetSelectorType

    def Init(self, listArg):
        pass

    def GetTarget(self, FromObj, nSearchRange=None, bIsFight=True):
        assert NotImplementedError

    def FindTarget(self, FromObj, nSearchRange=None):
        assert NotImplementedError

    def GetSearchRange(self, FromObj, bIsFight=True):
        if bIsFight:
            return FromObj.m_ViewCmp.GetLostRadius()
        else:
            return FromObj.m_ViewCmp.GetViewRadius()
