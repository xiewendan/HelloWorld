# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.common_pkg.utils as utils
import gac_gas.entity.entity_interface as entity_interface
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EGameObjType

# 选择攻击目标
NO_TARGETED_TYPE = {EGameObjType.Player, EGameObjType.Hero, EGameObjType.Trigger}


# 通过GID获取目标对象
def GetTargetByGlobalID(szGID):
    GameObj = utils.GetObjByGlobalID(szGID)
    if not GameObj:
        return

    # 可攻击对象类型
    if entity_interface.InfoCmp_GetGameObjType(GameObj) in NO_TARGETED_TYPE:
        return

    # 判断死亡
    # 检查在同一场景
    if entity_interface.FightCmp_IsDead(GameObj):
        return

    return GameObj


# 通过GID获取可攻击目标对象
def GetAttackTargetByGlobalID(FromObj, szTargetGID):
    # 检查目标对象
    TargetObj = GetTargetByGlobalID(szTargetGID)
    if not TargetObj:
        return

    # 检查在同一场景
    SceneObj = entity_interface.InfoCmp_GetScene(FromObj)
    TargetScene = entity_interface.InfoCmp_GetScene(TargetObj)
    if TargetScene is not SceneObj:
        return

    # 判断是否可被攻击
    if not entity_interface.FightCmp_CanHurt(FromObj, TargetObj):
        return

    return TargetObj


# 当前目标
def TryGetCurTarget(FromObj, nSearchRange):
    assert nSearchRange and nSearchRange > 0, "索敌距离不对:{}".format(nSearchRange)

    szTargetGID = entity_interface.AICmp_GetTargetGID(FromObj)
    if not szTargetGID:
        return

    TargetObj = GetAttackTargetByGlobalID(FromObj, szTargetGID)
    if not TargetObj:
        return

    FromPosObj = entity_interface.MoveCmp_GetPositionSelf(FromObj)
    TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)

    if not FromPosObj or not TargetPosObj:
        return

    if utils.Cal2PosDistance(FromPosObj, TargetPosObj) > nSearchRange:
        return

    return TargetObj


# 周围目标
def TryGetTargetFromNearby(FromObj, nSearchRange):
    nFromGID = FromObj.GetGlobalID()
    SceneObj = entity_interface.InfoCmp_GetScene(FromObj)
    if not SceneObj:
        return

    FromPosObj = entity_interface.MoveCmp_GetPositionSelf(FromObj)
    if not FromPosObj:
        return

    FightCmp = FromObj.GetComponentByName(EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return

    listCanSee = utils.DetourQueryCircle(SceneObj, FromPosObj.x, FromPosObj.y, FromPosObj.z, nSearchRange)
    if not listCanSee:
        return

    SelectedTargetObj = None
    nNearestDistance = nSearchRange
    for szGID in listCanSee:
        if not szGID or szGID == nFromGID:
            continue

        TargetObj = GetTargetByGlobalID(szGID)
        if not TargetObj:
            continue

        # 判断是否可被攻击
        if not FightCmp.CanHurt(TargetObj):
            continue

        # 判断技能属性
        if entity_interface.InfoCmp_GetGameObjType(TargetObj) is EGameObjType.AreaObj:
            TargetFightCmp = TargetObj.GetComponentByName(EComponentEntityType.EntityFightAttr)
            if SceneObj.m_ScenePlay.PokemonTypeRelation(FightCmp.GetPokemonType(), TargetFightCmp.GetPokemonType()) != -1:
                continue

        # 距离检查
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if not TargetObj:
            continue

        nDistance = utils.Cal2PosDistance(FromPosObj, TargetPosObj)
        if nDistance < nNearestDistance:
            SelectedTargetObj = TargetObj
            nNearestDistance = nDistance

    return SelectedTargetObj


# 获取锁定类型可攻击对象
def TryGetLockTypeTargetFromNearby(FromObj, setLockType, nAttackRange, nSearchRange):
    # print("************获取锁定类型可攻击对象:{}".format(setLockType))

    nFromGID = FromObj.GetGlobalID()
    SceneObj = entity_interface.InfoCmp_GetScene(FromObj)
    if not SceneObj:
        return

    FromPosObj = entity_interface.MoveCmp_GetPositionSelf(FromObj)
    if not FromPosObj:
        return

    FightCmp = FromObj.GetComponentByName(EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return

    listCanSee = utils.DetourQueryCircle(SceneObj, FromPosObj.x, FromPosObj.y, FromPosObj.z, nSearchRange)
    if not listCanSee:
        return

    SelectedTargetObj = None
    nNearestDistance = nSearchRange
    for szGID in listCanSee:
        if not szGID or szGID == nFromGID:
            continue

        TargetObj = GetTargetByGlobalID(szGID)
        if not TargetObj:
            continue

        # 检查类型
        if entity_interface.InfoCmp_GetGameObjType(TargetObj) not in setLockType:
            continue

        # 判断是否可被攻击
        if not FightCmp.CanHurt(TargetObj):
            continue

        # 判断技能属性
        if entity_interface.InfoCmp_GetGameObjType(TargetObj) is EGameObjType.AreaObj:
            TargetFightCmp = TargetObj.GetComponentByName(EComponentEntityType.EntityFightAttr)
            if SceneObj.m_ScenePlay.PokemonTypeRelation(FightCmp.GetPokemonType(), TargetFightCmp.GetPokemonType()) != -1:
                continue

        # 距离检查
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if not TargetObj:
            continue

        nDistance = utils.Cal2PosDistance(FromPosObj, TargetPosObj)
        if nDistance < nNearestDistance:
            SelectedTargetObj = TargetObj
            nNearestDistance = nDistance

    return SelectedTargetObj


# 获取关心类型可攻击对象
def TryGetCareTypeTargetFromNearby(FromObj, setCareType, nAttackRange, nSearchRange):
    # print("************获取关心类型可攻击对象:{}".format(setCareType))

    nFromGID = FromObj.GetGlobalID()
    SceneObj = entity_interface.InfoCmp_GetScene(FromObj)
    if not SceneObj:
        return

    FromPosObj = entity_interface.MoveCmp_GetPositionSelf(FromObj)
    if not FromPosObj:
        return

    FightCmp = FromObj.GetComponentByName(EComponentEntityType.EntityFightAttr)
    if not FightCmp:
        return

    listCanSee = utils.DetourQueryCircle(SceneObj, FromPosObj.x, FromPosObj.y, FromPosObj.z, nSearchRange)
    if not listCanSee:
        return

    PriorityTypeGameObj = None
    SelectedTargetObj = None
    nNearestDistance = nSearchRange
    for szGID in listCanSee:
        if not szGID or szGID == nFromGID:
            continue

        TargetObj = GetTargetByGlobalID(szGID)
        if not TargetObj:
            continue

        # 判断是否可被攻击
        if not FightCmp.CanHurt(TargetObj):
            continue

        # 判断技能属性
        if entity_interface.InfoCmp_GetGameObjType(TargetObj) is EGameObjType.AreaObj:
            TargetFightCmp = TargetObj.GetComponentByName(EComponentEntityType.EntityFightAttr)
            if SceneObj.m_ScenePlay.PokemonTypeRelation(FightCmp.GetPokemonType(), TargetFightCmp.GetPokemonType()) != -1:
                continue

        # 距离检查
        TargetPosObj = entity_interface.MoveCmp_GetPositionSelf(TargetObj)
        if not TargetObj:
            continue

        nDistance = utils.Cal2PosDistance(FromPosObj, TargetPosObj)
        if PriorityTypeGameObj:
            # 攻击距离内有优先对象
            if entity_interface.InfoCmp_GetGameObjType(TargetObj) in setCareType:
                continue

            if nDistance < nNearestDistance:
                PriorityTypeGameObj = TargetObj
                nNearestDistance = nDistance
        else:
            if nDistance <= nAttackRange:
                PriorityTypeGameObj = TargetObj
                nNearestDistance = nDistance
            else:
                if nDistance < nNearestDistance:
                    SelectedTargetObj = TargetObj
                    nNearestDistance = nDistance

    if PriorityTypeGameObj:
        return PriorityTypeGameObj

    return SelectedTargetObj

# 判断攻击距离
def IsInSkillDistance(AttackerObj, TargetObj, nDistance=None, nSkillID=None):
    nCastDistance = 1.5

    if nDistance is None:
        nDistance = utils.Cal2PosDistance(entity_interface.MoveCmp_GetPositionSelf(TargetObj),
                                          entity_interface.MoveCmp_GetPositionSelf(AttackerObj))

    return nDistance <= nCastDistance
