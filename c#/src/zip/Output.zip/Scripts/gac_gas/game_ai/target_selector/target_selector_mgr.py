# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import target_selector_common as target_selector_common
import target_selector_lock_type as target_selector_lock_type
import target_selector_care_type as target_selector_care_type


# 目标选择器管理类
class TargetSelectorMgr(object):
    def __init__(self):
        self.m_dictTargetSelector = {}

        # 目标选择器注册
        self.RegisterTargetSelector(target_selector_common.TargetSelectorCommon())
        self.RegisterTargetSelector(target_selector_lock_type.TargetSelectorLockType())
        self.RegisterTargetSelector(target_selector_care_type.TargetSelectorCareType())

    def RegisterTargetSelector(self, TargetSelectorObj):
        eTargetSelector = TargetSelectorObj.GetType()
        assert eTargetSelector is not None, "TargetSelectorMgr RegisterTargetSelector Error: [{0}] is None!!!".format(TargetSelectorObj.__class__)
        assert eTargetSelector not in self.m_dictTargetSelector, "RegisterTargetSelector RegisterScript Error: [{0}] is already existed!!!".format(
            TargetSelectorObj.__class__)
        self.m_dictTargetSelector[eTargetSelector] = TargetSelectorObj

    def GetTargetSelector(self, eTargetSelector):
        return self.m_dictTargetSelector.get(eTargetSelector)


# -------------------------------------------------------------------------------------
TargetSelectorMgrObj = TargetSelectorMgr()
GetTargetSelector = TargetSelectorMgrObj.GetTargetSelector
