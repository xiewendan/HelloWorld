# -*- coding: utf-8 -*-

import os
import logging
import platform
import colorama
import socket
from threading import Event
from threading import Thread
from Queue import Empty
from logging import handlers
from multiprocessing.dummy import Queue

# win操作系统
IS_WINDOWS = platform.system() == 'Windows'


# 过滤器
class RequireWinPlatform(logging.Filter):
    def __init__(self, name=''):
        super(RequireWinPlatform, self).__init__(name)
        self._m_bIsWin = IS_WINDOWS

    def filter(self, record):
        return self._m_bIsWin


# 颜色wrap
def _color_wrap(*colors):
    def wrapped(inp):
        return "".join(list(colors) + [inp, colorama.Style.RESET_ALL])
    return wrapped


# 输出颜色
class ColorizedStreamHandler(logging.StreamHandler):
    colors = {
        # This needs to be in order from highest logging level to lowest.
        'ERROR': _color_wrap(colorama.Fore.RED),
        'WARNING': _color_wrap(colorama.Fore.YELLOW),
        'INFO': _color_wrap(colorama.Fore.GREEN),
        'DEBUG': _color_wrap(colorama.Fore.CYAN),
    }

    _sentinel = None

    def __init__(self, stream=None):
        logging.StreamHandler.__init__(self, stream)

        if IS_WINDOWS and colorama:
            self.stream = colorama.AnsiToWin32(self.stream)

        self.queue = Queue()
        self._stop = Event()
        self._thread = None
        self._async = False

    def should_color(self):
        # Don't colorize things if we do not have colorama
        if IS_WINDOWS and not colorama:
            return False

        if os.environ.get('TERM') == 'cygwin':
            return False

        real_stream = (self.stream if not isinstance(self.stream, colorama.AnsiToWin32) else self.stream.wrapped)

        # If the stream is a tty we should color it
        if hasattr(real_stream, "isatty") and real_stream.isatty():
            return True

        # If we have an ASNI term we should color it
        if os.environ.get("TERM") == "ANSI":
            return True

        # If anything else we should not color it
        return False

    def format(self, record):
        try:
            msg = logging.StreamHandler.format(self, record)
        except:
            logging.info('%s' % str(record))
            return ""

        color = self.__class__.colors.get(record.levelname, None)
        if color and self.should_color():
            try:
                if IS_WINDOWS and isinstance(msg, str):
                    return color(msg.decode('utf-8'))
                return color(msg)
            except UnicodeDecodeError:
                return msg  # skip colors
        else:
            if IS_WINDOWS and isinstance(msg, str):
                return msg.decode('utf-8')
            return msg

    def emit(self, record):
        if not self._async:
            # logging.StreamHandler.emit(self, record)
            self.doemit(record)
        else:
            self.queue.put(record)

    def doemit(self, record):
        try:
            logging.StreamHandler.emit(self, record)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(record)

    def start(self):
        if not self._async:
            # print('start ColorizedStreamHandler')
            logging.getLogger().info('start ColorizedStreamHandler')
            self._async = True
            self._thread = t = Thread(target=self._monitor)
            t.setDaemon(True)
            t.start()

    def _monitor(self):
        while not self._stop.isSet():
            try:
                record = self.queue.get(True)
                if record is self.__class__._sentinel:
                    break
                self.doemit(record)
            except (Empty, EOFError):
                pass
        # There might still be records in the queue.
        while True:
            try:
                record = self.queue.get(False)
                if record is self.__class__._sentinel:
                    break
                self.doemit(record)
            except (Empty, EOFError):
                break

    def stop(self):
        self._async = False
        # print('stop ColorizedStreamHandler')
        logging.getLogger().info('stop ColorizedStreamHandler')
        self._stop.set()
        self.queue.put_nowait(self.__class__._sentinel)
        if self._thread is not None:
            self._thread.join()
        self._thread = None


# 异步
class AsyncSysLogHandler(handlers.SysLogHandler):
    _sentinel = None

    def __init__(self, address=('localhost', 5140),
                 facility=handlers.SysLogHandler.LOG_LOCAL7, socktype=socket.SOCK_DGRAM):
        super(AsyncSysLogHandler, self).__init__(address, facility, socktype)
        self.queue = Queue()
        self._stop = Event()
        self._thread = None
        self._async = False

    def emit(self, record):
        try:
            msg = self.format(record) + '\000'
            """
            We need to convert record level to lowercase, maybe this will
            change in the future.
            """
            prio = '<%d>' % self.encodePriority(self.facility, self.mapPriority(record.levelname))
            # Message is a string. Convert to bytes as required by RFC 5424
            if type(msg) is unicode:
                msg = msg.encode('utf-8')
            msg = prio + msg
            if not self._async:
                self.doemit(msg)
            else:
                self.queue.put(msg)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(record)

    def doemit(self, msg):
        try:
            # if len(msg) >
            self.socket.sendto(msg, self.address)
        except (KeyboardInterrupt, SystemExit):
            raise
        except:
            self.handleError(msg)

    def start(self):
        if not self._async:
            # print('start AsyncSysLogHandler')
            logging.getLogger().info('start AsyncSysLogHandler')
            self._async = True
            self._thread = t = Thread(target=self._monitor)
            t.setDaemon(True)
            t.start()

    def _monitor(self):
        while not self._stop.isSet():
            try:
                record = self.queue.get(True)
                if record is self.__class__._sentinel:
                    break
                self.doemit(record)
            except (Empty, EOFError):
                pass
        # There might still be records in the queue.
        while True:
            try:
                record = self.queue.get(False)
                if record is self.__class__._sentinel:
                    break
                self.doemit(record)
            except (Empty, EOFError):
                break

    def stop(self):
        # print('stop AsyncSysLogHandler')
        logging.getLogger().info('stop AsyncSysLogHandler')
        self._async = False
        self._stop.set()
        self.queue.put_nowait(self.__class__._sentinel)
        if self._thread is not None:
            self._thread.join()
        self._thread = None


# 默认日志配置
DEFAULT_LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'normal': {
            'format': '%(asctime)s - %(levelname)s - %(name)s - %(message)s'
        },
        'develop': {
            'format': '%(asctime)s [%(levelname)s][%(filename)s:%(lineno)d][%(funcName)s] %(message)s',
        },
        'print_format': {
            'format': '[WARN][DO NOT USE PRINT][%(process)d]: %(message)s'
        },
        'syslog': {
            'format': '%(asctime)s - %(levelname)s - %(name)s - %(message)s'
        },
    },
    'filters': {
        'require_win_platform': {
            '()': RequireWinPlatform,
        },
    },
    'handlers': {
        'console': {
            # 'level': 'INFO',
            'level': 'DEBUG',
            'formatter': 'normal',
            '()': ColorizedStreamHandler,
        },
        'print': {
            'level': 'DEBUG',
            'formatter': 'print_format',
            '()': ColorizedStreamHandler,
        },
        'null': {
            'class': 'logging.NullHandler',
        },
        'syslog': {
            'facility': 'local7',
            'level': 'DEBUG',
            # 'address': '/dev/log',
            'address': ('127.0.0.1', 5140),
            'formatter': 'syslog',
            # 'class': 'logging.handlers.SysLogHandler', # 这里要变成异步的
            '()': AsyncSysLogHandler,
        },
        'logfile': {
            "class": "logging.FileHandler",
            "level": "DEBUG",
            "formatter": "develop",
            # 'filters': ['require_win_platform'],
            # "filename": os.path.join('..', 'log', MBLogManager.LogManager.log_tag + ".log"),
            "encoding": "utf8",
            "mode": "w",
        },
    },
    'loggers': {
        'print': {
            # 'handlers': ['normal'],
            'handlers': ['null'],
            'propagate': False,
        },
        'stderr': {
            # 'handlers': ['normal'],
            'handlers': [],
            'propagate': False,
        },
    },
    'root': {
        'handlers': ['console'],
        # 'level': 'DEBUG',
        # 'level': 'WARN',
        'level': 'INFO',
    },
}

# 初始化
def Init(bAsync=False):
    if not bAsync:
        return

    for handler in logging.getLogger().handlers:
        if hasattr(handler, 'start'):
            handler.start()

# 结束
def Unit():
    for handler in logging.getLogger().handlers:
        if hasattr(handler, 'stop'):
            handler.stop()

# log初始化
def InitLog(szLogDir, szLogFileName, dictAppConfig):
    global DEFAULT_LOGGING

    # 创建log目录
    if not os.path.exists(szLogDir):
        os.makedirs(szLogDir)

    szLogFile = "{}/{}-log.txt".format(szLogDir, szLogFileName)

    # 如果是调试
    bIsDebug = dictAppConfig.get('debug', False)
    if bIsDebug:
        # 只有开发的时候才允许print
        DEFAULT_LOGGING['loggers']['print']['handlers'] = ['print']
        if IS_WINDOWS and dictAppConfig.get('save_stdout_to_file', False):
            DEFAULT_LOGGING['loggers']['print']['handlers'].append('logfile')

        DEFAULT_LOGGING['root']['level'] = 'DEBUG'

    if IS_WINDOWS:
        DEFAULT_LOGGING['handlers']['syslog'] = DEFAULT_LOGGING['handlers']['null']
        DEFAULT_LOGGING['handlers']['logfile']['filename'] = szLogFile
        DEFAULT_LOGGING['root']['handlers'] = ['console', 'logfile']
        DEFAULT_LOGGING['loggers']['stderr']['handlers'] = ['console', 'logfile']
    else:
        DEFAULT_LOGGING['handlers']['logfile'] = DEFAULT_LOGGING['handlers']['null']
        if bIsDebug:
            DEFAULT_LOGGING['root']['handlers'] = ['console', 'syslog']
            DEFAULT_LOGGING['loggers']['stderr']['handlers'] = ['console']

            if dictAppConfig.get('save_log_to_file', False):
                DEFAULT_LOGGING['handlers']['logfile'] = DEFAULT_LOGGING['handlers']['logfile']
                DEFAULT_LOGGING['handlers']['logfile']['filename'] = szLogFile
                DEFAULT_LOGGING['root']['handlers'].append('logfile')
                DEFAULT_LOGGING['loggers']['stderr']['handlers'].append('logfile')
        else:
            DEFAULT_LOGGING['root']['handlers'] = ['syslog']

    from logging.config import dictConfig
    dictConfig(DEFAULT_LOGGING)

    from ex_logger import ExLogger
    logging.setLoggerClass(ExLogger)

    # 初始化
    Init()

    if bIsDebug and dictAppConfig.get('redirect_stdout', False):
        # 只有启用这个配置项，才会对标准输出做重定向
        from redirect_stdout import RedirectStdout
        RedirectStdout()

    logging.info("完成logger初始化")
