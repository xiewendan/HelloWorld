# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import sys
import logging
import numbers
import platform
import traceback
from threading import local

try:
    import __builtin__
    theApp = __builtin__.theApp
except:
    pass


# win操作系统
IS_WINDOWS = platform.system() == 'Windows'


# 记录标准输入、标准错误
g_lastStdOut = sys.stdout
g_lastStdErr = sys.stderr


# LoggingProxy
class LoggingProxy(object):
    """Forward file object to :class:`logging.Logger` instance.

    :param logger: The :class:`logging.Logger` instance to forward to.
    :param loglevel: Loglevel to use when writing messages.

    """
    mode = 'w'
    name = None
    closed = False
    loglevel = logging.ERROR
    _thread = local()

    def __init__(self, logger, loglevel=None):
        self.logger = logger
        if loglevel and not isinstance(loglevel, numbers.Integral):
            loglevel = logging.getLevelName(loglevel.upper())
        self.loglevel = loglevel or self.logger.level or self.loglevel
        self._safewrap_handlers()

    def _safewrap_handlers(self):
        """Make the logger handlers dump internal errors to
        `sys.__stderr__` instead of `sys.stderr` to circumvent
        infinite loops."""

        def wrap_handler(handler):  # pragma: no cover

            class WithSafeHandleError(logging.Handler):

                def handleError(self, record):
                    exc_info = sys.exc_info()
                    try:
                        try:
                            traceback.print_exception(exc_info[0],
                                                      exc_info[1],
                                                      exc_info[2],
                                                      None, sys.__stderr__)
                        except IOError:
                            pass  # see python issue 5971
                    finally:
                        del exc_info

            handler.handleError = WithSafeHandleError().handleError

        return [wrap_handler(h) for h in self.logger.handlers]

    def write(self, data):
        """Write message to logging object."""
        if getattr(self._thread, 'recurse_protection', False):
            # Logger is logging back to this file, so stop recursing.
            return
        data = data.strip()
        if data and not self.closed:
            self._thread.recurse_protection = True
            try:
                if IS_WINDOWS and isinstance(data, str):
                    data = data.decode('utf-8')

                    if getattr(theApp, "bPrintDetail", False):
                        import os
                        import traceback
                        self.logger.log(self.loglevel, os.linesep.join(traceback.format_stack()))

                self.logger.log(self.loglevel, data.rstrip())
                # for line in data.rstrip().splitlines():
                #     self.logger.log(self.log_level, line.rstrip())
            finally:
                self._thread.recurse_protection = False

    def writelines(self, sequence):
        """`writelines(sequence_of_strings) -> None`.

        Write the strings to the file.

        The sequence can be any iterable object producing strings.
        This is equivalent to calling :meth:`write` for each string.

        """
        for part in sequence:
            self.write(part)

    def flush(self):
        """This object is not buffered so any :meth:`flush` requests
        are ignored."""
        pass

    def close(self):
        """When the object is closed, no write requests are forwarded to
        the logging object anymore."""
        self.closed = True

    def isatty(self):
        """Always return :const:`False`. Just here for file support."""
        return False


# 重定向标准输出到logger
def RedirectStdoutsToLogger(logger, loglevel=None, stdout=True, stderr=True):
    """Redirect :class:`sys.stdout` and :class:`sys.stderr` to a
    logging instance.

    :param logger: The :class:`logging.Logger` instance to redirect to.
    :param loglevel: The loglevel redirected messages will be logged as.
    :param stdout: whether to redirect
    :param stderr: whether to redirect

    """
    global g_lastStdOut, g_lastStdErr
    proxy = LoggingProxy(logger, loglevel)
    if stdout:
        g_lastStdOut, sys.stdout = sys.stdout, proxy
    if stderr:
        g_lastStdErr, sys.stderr = sys.stderr, proxy
    return proxy


def RedirectStdout():
    from logging import getLogger
    RedirectStdoutsToLogger(getLogger('print'), 'DEBUG', stdout=True, stderr=False)
    RedirectStdoutsToLogger(getLogger('stderr'), 'ERROR', stdout=False, stderr=True)


def RevertStdOut():
    global g_lastStdOut
    g_lastStdOut, sys.stdout = sys.stdout, g_lastStdOut


def RevertStdErr():
    global g_lastStdErr
    g_lastStdErr, sys.stderr = sys.stderr, g_lastStdErr
