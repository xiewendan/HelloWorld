# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import os
import logging
import traceback
from threading import Event
from threading import Thread
from Queue import Empty
from multiprocessing.dummy import Queue

__all__ = ["InitDumpHandler", "UnitDumpHandler", "SaveDump"]

# 存放dump
_QueueDump = Queue()


# dump处理器
_DumpFileHandler = None


# Dump
class DumpFileHandler(object):
    """
    This class implements an internal threaded listener which watches for
    traceback being added to a queue, removes them and passes them to a
    dump file.
    """
    _sentinel = None

    def __init__(self, path_dumps, name):
        """
        Initialise an instance with the specified queue.
        """
        global _QueueDump
        self.queue = _QueueDump
        self._stop = Event()
        self._thread = None
        self.logger = logging.getLogger('dumps')
        self.path_dumps = path_dumps
        self.name = name

        # 检查目录
        if not os.path.exists(self.path_dumps):
            try:
                os.makedirs(self.path_dumps)
            except:
                if not os.path.exists(self.path_dumps):
                    raise RuntimeError("dump目录创建失败: {}".format(self.path_dumps))

    def dequeue(self, block):
        """
        Dequeue a record and return it, optionally blocking.

        The base implementation uses get. You may want to override this method
        if you want to use timeouts or work with custom queue implementations.
        """
        return self.queue.get(block)

    def start(self):
        """
        Start the listener.

        This starts up a background thread to monitor the queue for
        LogRecords to process.
        """
        self._thread = t = Thread(target=self._monitor)
        t.setDaemon(True)
        t.start()

    def handle(self, record):
        """
        Handle a record.
        """
        # self.logger.info("catch traceback, save to file.")

        record, extend, fileflag = record

        length = len(record)
        if fileflag:
            name = "%s.%d.%s.dmp" % (self.name, length, fileflag)
        else:
            name = "%s.%d.dmp" % (self.name, length,)
        dumpfilepath = os.path.join(self.path_dumps, name)
        try:
            with open(dumpfilepath, 'a') as dumpfile:
                dumpfile.write("\n".join([record, extend]) if extend is not None else record)
                dumpfile.close()
        except:
            self.logger.error("save dump file failed.")
            self.logger.error(traceback.format_exc())
        else:
            self.logger.info("save dump file %s done.", name)

    def _monitor(self):
        q = self.queue
        has_task_done = hasattr(q, 'task_done')
        while not self._stop.isSet():
            try:
                record = self.dequeue(True)
                if record is self.__class__._sentinel:
                    break
                self.handle(record)
                if has_task_done:
                    q.task_done()
            except (Empty, EOFError):
                pass
        # There might still be records in the queue.
        while True:
            try:
                record = self.dequeue(False)
                if record is self.__class__._sentinel:
                    break
                self.handle(record)
                if has_task_done:
                    q.task_done()
            except (Empty, EOFError):
                break

    def enqueue_sentinel(self):
        """
        This is used to enqueue the sentinel record.

        The base implementation uses put_nowait. You may want to override this
        method if you want to use timeouts or work with custom queue
        implementations.
        """
        self.queue.put_nowait(self._sentinel)

    def stop(self):
        """
        Stop the listener.

        This asks the thread to terminate, and then waits for it to do so.
        Note that if you don't call this before your application exits, there
        may be some records still left on the queue, which won't be processed.
        """
        self._stop.set()
        self.enqueue_sentinel()
        if self._thread is not None:
            self._thread.join()
        self._thread = None

    def setname(self, name):
        self.name = name


def InitDumpHandler(szPathDumps, szName):
    global _DumpFileHandler
    if _DumpFileHandler is None:
        _DumpFileHandler = DumpFileHandler(szPathDumps, szName)
        _DumpFileHandler.start()

def UnitDumpHandler():
    global _DumpFileHandler
    if _DumpFileHandler is not None:
        _DumpFileHandler.stop()
        _DumpFileHandler = None

def SaveDump(record, extend=None, fileflag=None):
    global _QueueDump
    _QueueDump.put((record, extend, fileflag))

