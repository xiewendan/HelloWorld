# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import time
import logging
import traceback
import dump_handler as dump_handler
from record_var import RecordVar

# 调试相关
g_bDebug = False
g_nLogTime = 0
g_nLogNum = 0


def ClearDebugData():
    global g_bDebug, g_nLogTime, g_nLogNum
    if g_bDebug:
        g_nLogTime = 0
        g_nLogNum = 0


def EnableDebugLog():
    global g_bDebug, g_nLogTime, g_nLogNum
    g_bDebug = True
    g_nLogTime = 0
    g_nLogNum = 0


def DisableDebugLog():
    global g_bDebug, g_nLogTime, g_nLogNum
    g_bDebug = False
    g_nLogTime = 0
    g_nLogNum = 0


def DumpDebugLog(LoggerObj):
    if g_bDebug:
        LoggerObj.info(">>>>>>>>>>jmjmjm DumpDebugLog, 总时间: {:.4f}; 总数量：{} <<<<<<<<<<\n".format(g_nLogTime, g_nLogNum))


# Logger
class ExLogger(logging.Logger):
    def log_last_except(self):
        szTrace = traceback.format_exc()
        try:
            szVar = RecordVar.recordvar()
        except:
            # 如果获取变量失败，则直接跳过
            szVar = ""

        self.error('\n'.join([szTrace, szVar]))
        dump_handler.SaveDump(szTrace, szVar)

    def info(self, msg, *args, **kwargs):
        global g_bDebug, g_nLogTime, g_nLogNum
        if not g_bDebug:
            super(ExLogger, self).info(msg, *args, **kwargs)
        else:
            bT = time.clock()
            super(ExLogger, self).info(msg, *args, **kwargs)
            eT = time.clock()
            g_nLogTime += (eT - bT) * 1000
            g_nLogNum += 1
