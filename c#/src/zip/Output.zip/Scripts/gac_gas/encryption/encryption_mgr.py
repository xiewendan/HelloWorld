# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
from gac_gas.common.singleton import singleton


@singleton
class EncyptionMgr(object):
    def __init__(self):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_szFixSeed = "Wk679cc5gcWAILsRku0lZ8t7+pHVYud5"
        self.m_funCreateSesssionKey = None
        self.m_SessionKeyEncrypter = None
        self.m_SessionKeyDecrypter = None
        self.m_ARC4CrypterClass = None

    def Init(self, szLoginKeyPath, funCreateSesssionKey=None, LoginKeyEncrypterClass=None, LoginKeyDecrypterClass=None, ARC4CrypterClass=None):
        self.m_funCreateSesssionKey = funCreateSesssionKey
        self.m_ARC4CrypterClass = ARC4CrypterClass

        if LoginKeyEncrypterClass:
            self.m_SessionKeyEncrypter = LoginKeyEncrypterClass(szLoginKeyPath)

        if LoginKeyDecrypterClass:
            self.m_SessionKeyDecrypter = LoginKeyDecrypterClass(szLoginKeyPath)

    def CreateSesssionKey(self):
        assert self.m_funCreateSesssionKey is not None
        return self.m_funCreateSesssionKey()

    def EncryptSessionKey(self, szSessionKey):
        if not self.m_SessionKeyEncrypter:
            return None

        try:
            return self.m_SessionKeyEncrypter.encrypte(szSessionKey)
        except:
            self.m_Logger.error("无法加密Session Key")
            return None

    def EncryptAndFixSessionKey(self, szSessionKey):
        return self.EncryptSessionKey(szSessionKey) + self.m_szFixSeed

    def DecryptSessionKey(self, szCryptSessionKey):
        if not self.m_SessionKeyDecrypter:
            return None

        try:
            return self.m_SessionKeyDecrypter.decrypt(szCryptSessionKey)
        except:
            self.m_Logger.error("无法解密Session Key")
            return None

    def DecryptAndFixSessionKey(self, szFixAndCryptSessionKey):
        nFixSeedBegin = szFixAndCryptSessionKey.rfind(self.m_szFixSeed)
        if nFixSeedBegin < 0 or szFixAndCryptSessionKey[nFixSeedBegin:] != self.m_szFixSeed:
            raise RuntimeError("客户端提交的 session key 格式不对:{}".format(szFixAndCryptSessionKey))

        szCryptSessionKey = szFixAndCryptSessionKey[:nFixSeedBegin]
        if len(szCryptSessionKey) < 256:
            raise RuntimeError("客户端提交的 session key 长度不够:{}".format(szFixAndCryptSessionKey))

        return self.DecryptSessionKey(szCryptSessionKey)

    def CreateEncrypterAndDecrypterBySessionKey(self, szSessionKey):
        assert self.m_ARC4CrypterClass is not None
        return self.m_ARC4CrypterClass(szSessionKey), self.m_ARC4CrypterClass(szSessionKey)


# ------------------------------------------------------------------------------------

EncyptionMgrObj = EncyptionMgr()
Init = EncyptionMgrObj.Init
CreateSesssionKey = EncyptionMgrObj.CreateSesssionKey
EncryptSessionKey = EncyptionMgrObj.EncryptSessionKey
DecryptSessionKey = EncyptionMgrObj.DecryptSessionKey
EncryptAndFixSessionKey = EncyptionMgrObj.EncryptAndFixSessionKey
DecryptAndFixSessionKey = EncyptionMgrObj.DecryptAndFixSessionKey
CreateEncrypterAndDecrypterBySessionKey = EncyptionMgrObj.CreateEncrypterAndDecrypterBySessionKey
