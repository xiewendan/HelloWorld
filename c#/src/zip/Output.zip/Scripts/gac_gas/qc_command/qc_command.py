# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import re
import weakref
import gac_gas.entity.entity_interface as entity_interface
import gac_gas.common_pkg.utils as utils
from gac_gas.common.singleton import singleton

# 记录指令说明
g_dictCmd = {}
g_setRealCmd = set()

# 是否是客户端
IS_CLIENT_PLATFORM = utils.IS_CLIENT_PLATFORM

# 检查指令
GM_PATTERN = re.compile(r"^([>!\?]?)(qc\.(\w+))\(.*")


# ------------------------------------GM指令修饰-------------------------------

# GM指令装饰器
def cmd_note_deco(szCmd, szNote):
    def _cmd_note_deco(func):
        def __cmd_note_deco(*args, **kwargs):
            if szCmd.startswith(">qc."):
                # 客户端指令写法
                if not utils.IS_CLIENT_PLATFORM:
                    # 如果是服务器
                    dictInfo = {"opt": szRealCmd, "args": args, "kwargs": kwargs}
                    g_GMPlayer.GetGacPlayer().QcCommandOpt(dictInfo)
                    return
            elif szCmd.startswith("?qc."):
                if not entity_interface.InfoCmp_GetScene(g_GMPlayer):
                    # 如果是单人场景
                    dictInfo = {"opt": szRealCmd, "args": args, "kwargs": kwargs}
                    g_GMPlayer.GetGacPlayer().QcCommandOpt(dictInfo)
                    return

            ret = func(*args, **kwargs)
            QcPrint("********************************命令OK********************************")
            return ret

        __cmd_note_deco.func_closure_for_reload = func
        return __cmd_note_deco

    assert szCmd.startswith("qc.") or szCmd.startswith(">qc.") or szCmd.startswith("?qc.") or szCmd.startswith("!qc."), "qc指令只能使用[>!?]qc.开头"

    if szCmd in g_dictCmd:
        assert False, "错误1:注册命令重复:{}".format(szCmd)

    MatchObj = GM_PATTERN.match(szCmd)
    szRealCmd = MatchObj.group(3)
    if szRealCmd in g_setRealCmd:
        assert False, "错误2:注册命令重复:{}".format(szRealCmd)

    g_dictCmd[szCmd] = szNote
    g_setRealCmd.add(szRealCmd)

    return _cmd_note_deco


# -----------------------------------------以下是辅助函数-------------------------------

# 打印信息
def QcPrint(*args):
    listArgs = []
    for value in args:
        print(value)
        listArgs.append(str(value))
    szMsg = " ".join(listArgs)
    if IS_CLIENT_PLATFORM:
        print(szMsg)
    elif g_GMPlayer:
        g_GMPlayer.GetGacAvatarRpc().QcPrint(szMsg)


# 调整玩家对象
def SetGMPlayer(Player):
    if Player:
        global g_GMPlayer
        g_GMPlayer = weakref.proxy(Player)
    else:
        g_GMPlayer = Player


# 处理GM指令
def HandleCmd(szCmd):
    # print szCmd

    szCmd = szCmd.lstrip()

    if szCmd and (szCmd.startswith(">qc.") or szCmd.startswith("?qc.") or szCmd.startswith("!qc.")):
        assert False, "执行qc执行不需要加（>,?, !）"
    elif not szCmd or (not szCmd.startswith("qc.") and not szCmd.startswith("!qc.")):
        return szCmd

    MatchObj = GM_PATTERN.match(szCmd)
    szRealCmd = MatchObj.group(3)

    if szCmd.startswith("!qc."):
        szRealCmdStartswith = "!qc.{}".format(szRealCmd)
        bFind = False
        for szKey in g_dictCmd:
            if szKey.startswith(szRealCmdStartswith):
                bFind = True
                break

        assert bFind, "没有找到相应qc指令:{}".format(szRealCmdStartswith, szCmd)

    elif szCmd.startswith("qc."):
        szRealCmdStartswith = "!qc.{}".format(szRealCmd)
        for szKey in g_dictCmd:
            if szKey.startswith(szRealCmdStartswith):
                szCmd = "!{0}".format(szCmd)
                break

    assert szRealCmd in g_setRealCmd, "没有找到相应qc指令:{}".format(szRealCmd)

    return szCmd


# 检查是否注册指令
def CheckQCCmd(szRealCmd):
    return szRealCmd in g_setRealCmd


# ------------------------------------ 指令对象 供shushine用 -----------------
# sunshine用的
@singleton
class QcComanndSetMgr(object):
    def __init__(self):
        self.m_dictCommandSet = {}

    def GetName(self):
        return "GM指令集"

    def AddCommandSet(self, SetObj):
        self.m_dictCommandSet[SetObj.GetEditComponentName()] = SetObj

    def GetCommandSet(self, szSet):
        return self.m_dictCommandSet.get(szSet)

    def GetAllComandSet(self):
        return self.m_dictCommandSet


class BaseQcCommandMgr(object):
    def __init__(self):
        self.m_dictCmd = {}
        self.m_dictName2Cmd = {}

    # 增加一个gm指令
    # dictParam所有参数默认当字符串处理, 因为最后要生存gm指令字符串 ex: {"speed":"100"} or 没参数使用{}
    #                                    参数名字前缀为'_'会不显示在编辑器上面
    # szName 指令唯一标识
    # szCmd 指令函数名, 同一个cmd可以多个Command, 例如killcd(True), killcd(False)
    def AddCommand(self, szName, szCmd, dictParam):
        if hasattr(self, szName):
            return

        for name, value in dictParam.iteritems():
            setattr(self, szName + '_' + name, value)

        def callback():
            szParam = ""

            # 拼接函数参数值
            for k in dictParam.iterkeys():
                key = k
                if key.startswith("_"):
                    key = key[1:]

                if szParam == "":
                    szParam = key + "=" + getattr(self, szName + '_' + k)
                else:
                    szParam += "," + key + "=" + getattr(self, szName + '_' + k)

            # 生成指令字符串 ex: "qc.killcd(False)"
            szCmdArgs = szCmd + "(" + szParam + ")"
            # 调用gm控制台输入字符串处理
            self.ExecCmd(szCmdArgs)

        setattr(self, szName, callback)
        self.m_dictCmd[szName] = dictParam
        self.m_dictName2Cmd[szName] = szCmd

    def ExecCmd(self, szCmdLine):
        import logic.gm_command.gm_command as gm_command
        gm_command.GMCommandMgrObj.OnDebugInput(szCmdLine)

    #  ------------------ sunshine方法 -------------------
    def GetEditParentID(self):
        return QcComanndSetMgr().GetName()

    def GetEditComponentName(self):
        return "指令集"


def AddCommandSet(szSetName, szCodeName):
    szDefineClassCode = "class {1}QcCommandMgr(BaseQcCommandMgr):\n"\
                        "   def GetEditComponentName(self):\n"\
                        "       return '{0}'\n"\
                        "QcComanndSetMgr().AddCommandSet({1}QcCommandMgr())\n"

    exec szDefineClassCode.format(szSetName, szCodeName)


def AddCommand(szSetName, szCodeName, szName, szCmd, dictParam):
    if IS_CLIENT_PLATFORM:
        commandSet = QcComanndSetMgr().GetCommandSet(szSetName)
        if commandSet is None:
            AddCommandSet(szSetName, szCodeName)

        QcComanndSetMgr().GetCommandSet(szSetName).AddCommand(szName, szCmd, dictParam)


# -----------------------------------------以下是qc指令-------------------------------

@cmd_note_deco("qc.test(*args, **kwargs)", "【测试】")
def test(*args, **kwargs):
    print("测试:{}, {}".format(args, kwargs))


@cmd_note_deco("!qc.bt(bValue=True)", "【AI调试】AI调试")
def bt(bValue=True):
    import gac_gas.game_ai.ai_debug_mgr as ai_debug_mgr
    if bValue:
        ai_debug_mgr.Connect()
    else:
        ai_debug_mgr.DisConnect()

# ********************************************************************************
# sunshine 需要放最好哈
# ********************************************************************************
# 注册指令
if IS_CLIENT_PLATFORM:
    pass


# 请让此代码保持在最后，多谢
def __onreload__(new_dict):
    global g_dictCmd
    g_dictCmd = new_dict.get("g_dictCmd")
