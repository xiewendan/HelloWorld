# -*- coding: utf-8 -*-


class StateMachine(object):
    """
    # 单层状态机
    """

    def __init__(self):
        self.m_CurrentState = None
        self.m_PreviousState = None
        self.m_bDestroy = False

    def SetCurrentState(self, StateObj):
        self.m_CurrentState = StateObj

    def SetPreviousState(self, StateObj):
        self.m_PreviousState = StateObj

    def GetCurrentState(self):
        return self.m_CurrentState

    def GetPreviousState(self):
        return self.m_PreviousState

    def IsInState(self, StateClass):
        return isinstance(self.m_CurrentState, StateClass)

    def Update(self):
        if self.m_CurrentState is not None:
            self.m_CurrentState.OnUpdate()

    def ChangeState(self, NewStateObj):
        self.m_PreviousState = self.m_CurrentState

        if self.m_CurrentState is not None:
            self.m_CurrentState.OnExit()

        self.m_CurrentState = NewStateObj

        if self.m_CurrentState is not None:
            self.m_CurrentState.OnEnter()

    def OnEvent(self, eEventType, *args, **kwargs):
        if self.m_CurrentState:
            self.m_CurrentState.OnEvent(eEventType, *args, **kwargs)

    def Destroy(self):
        if self.m_bDestroy:
            return

        self.OnDestroy()

        self.m_CurrentState = None
        self.m_PreviousState = None

        self.m_bDestroy = True

    def OnDestroy(self):
        pass


class State(object):
    """
    # 状态接口类，子类必须重载所有方法
    """

    def __str__(self):
        return self.__class__.__name__

    def OnEnter(self):
        raise NotImplementedError

    def OnUpdate(self):
        raise NotImplementedError

    def OnEvent(self, eEventType, *args, **kwargs):
        raise NotImplementedError

    def OnReset(self):
        raise NotImplementedError

    def OnExit(self):
        raise NotImplementedError
