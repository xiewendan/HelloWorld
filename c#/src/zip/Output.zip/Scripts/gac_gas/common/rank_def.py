# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

from enum_def import ConstMe


# 通用排行榜的类型
class ERankType(ConstMe):
    eTest = "test"                      # 测试


# 默认季度
DEFAULT_SEASON = "default"


# 所有通用排行榜
RANK_CFG = {
    # 锦标赛
    ERankType.eTest: ["C1",],
}
