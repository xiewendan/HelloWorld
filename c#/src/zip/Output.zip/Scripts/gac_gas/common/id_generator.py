# -*- coding: utf-8 -*-
# __author__ = gzxiepeng


# 自增ID
class IdGenerator(object):
    """
    IdGenerator产生一个简单的自增的整数id，主要是给callback使用
    """
    def __init__(self):
        self.m_nCurID = 1

    def GenId(self):
        self.m_nCurID += 1
        return self.m_nCurID


# 循环自增ID
class RotatedIdGenerator(object):
    """
    RotatedIdManager产生一个简单的自增的，同时还会循环的整数id，主要是给callback使用
    假设callback id在循环的这段时间之内已经自动释放了
    """
    s_nMaxID = 2 ** 32

    def __init__(self):
        self.m_nCurID = 1

    def GenId(self):
        if self.m_nCurID < RotatedIdGenerator.s_nMaxID:
            self.m_nCurID += 1
        else:
            self.m_nCurID = 1
        return self.m_nCurID


