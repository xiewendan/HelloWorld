# -*- coding: utf-8 -*-

"""
数据库定义的表及表结构需要在这里声明，方便统一管理和维护，如果不清楚，请联系偶
"""

from enum_def import EPropertyType


class Const(object):
    class ConstError(TypeError):
        pass

    def __setattr__(self, name, value):
        if self.__dict__.has_key(name):
            raise self.ConstError, "Can't rebind const(%s)" % name
        self.__dict__[name] = value


# 表名称定义
class CollectionName(Const):
    ACCOUNT = "accounts"
    PLAYER = "players"
    RANK = "rank"


class CollectionHashCfg(Const):
    HASH_CFG = {
        CollectionName.ACCOUNT: False,
        CollectionName.PLAYER: False,
        CollectionName.RANK: False,
    }

    @staticmethod
    def Check():
        for k, v in CollectionName.__dict__.iteritems():
            if k[0].isupper() and k[1].isupper():
                assert v in CollectionHashCfg.HASH_CFG, ("CollectionName.%s not match CollectionHashCfg " % v)


# 账号属性
class AccountProperty(Const):
    ID = "_id"
    NAME = "name"                                       # 这里的name实际是UID
    URS = "urs"
    AID = "aid"
    CHANNEL = "channel"                                 # 来自哪个渠道
    CREATE_TIME = "create_time"
    LAST_LOGIN_TIME = "last_login_time"
    IS_BLOCK = "is_block"
    BLOCK_END_TIME = "block_end_time"                   # 冻结的结束时间，-1表示永久冻结，否则是timestamp
    OLD_UID = "old_uid"
    FULLNAME = "fullname"                               # 完整的渠道账号名称 xx@xx.xx.xx.xx
    PLAYERS = "players"


# 角色属性
class PlayerProperty(Const):
    ID = '_id'
    NAME = "name"
    SHORT_ID = "short_id"
    ACCOUNT = "account"
    CLUSTERID = "clusterid"
    LAST_CLUSTERID = "last_clusterid"
    ORIGINAL_CLUSTERID = "original_clusterid"
    CREATE_TIME = "create_time"
    LOGIN_TIME = "login_time"
    LAST_LOGIN_TIME = "last_login_time"
    LAST_LOGOUT_TIME = "last_logout_time"
    IS_DELETE = "is_delete"
    IS_BLOCK = "is_block"
    BLOCK_END_TIME = "block_end_time"                   # 冻结的结束时间，-1表示永久冻结，否则是timestamp
    FACTION_ID = "faction_id"
    SEX = "sex"
    LEVEL = "level"
    LAST_LOCATION = "last_location"
    BAG_DATA = "bag_data"
    FUBEN_DATA = "fuben_data"


# 通用排行榜
class RankProperty(Const):
    ID = "_id"                          # id
    RANK_SEASON = "season"              # 排名季度
    RANK_TYPE = "type"                  # 排名类型
    RANK_DATA = "data"                  # 排名数据
    RANK_LIMIT = "limit"                # 排名限制数据