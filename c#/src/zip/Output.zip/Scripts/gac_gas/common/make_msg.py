# -*- coding: utf-8 -*-

def MakeGac2CountryEntityCallMsg(szGacID, szTargetServerName, szTargetEntityID, data):
    return [szGacID, [szTargetServerName, szTargetEntityID], data]


def MakeGas2GacEntityMsg(szGacID, szMethodName, args, listSubMethodName):
    return [szGacID, [szMethodName, args, listSubMethodName]]


def MakeBattle2GacEntityMsg(szGacID, szMethodName, args, listSubMethodName):
    return [szGacID, [szMethodName, args, listSubMethodName]]


def MakeWorldEntityCallMsg(nSrcClusterID, szSrcServerName, szSrcEntityID,
                           nTargetClusterID, szTargetServerName, szTargetEntityID,
                           param1, param2, listSubMethodName):
    return [[nSrcClusterID, szSrcServerName, szSrcEntityID], [nTargetClusterID, szTargetServerName, szTargetEntityID], [param1, param2, listSubMethodName]]


def MakeEngineWorldEntityCallMsg(param1, param2, listSubMethodName):
    return [param1, param2, listSubMethodName]


def MakeEntityMsgBroadcast(listGacAvatarID, szType, szMethodName, args, szGID, listSubMethodName):
    return [listGacAvatarID, ["RecvMsgCache", [[(szType, szMethodName, args, szGID, listSubMethodName), ], ], []]]
