# -*- coding: utf-8 -*-
# __author__ = gzxiepeng


# 函数回调包装器
class Functor(object):
    def __init__(self, func, *args):
        assert callable(func)
        self.m_func = func
        self.m_agrs = args

    def __call__(self, *args, **kwargs):
        args = self.m_agrs + args
        return self.m_func(*args, **kwargs)
