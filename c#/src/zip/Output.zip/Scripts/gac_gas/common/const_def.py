# -*- coding: utf-8 -*-
# __author__ = gzxiepeng


# 常量类
class _Const(object):
    class ConstError(TypeError):
        pass

    class ConstCaseError(ConstError):
        pass

    def __setattr__(self, szKey, value):
        if szKey in self.__dict__:
            raise self.ConstError("can't change const %s" % szKey)
        if not szKey.isupper():
            raise self.ConstCaseError('const name "%s" is not all uppercase' % szKey)
        self.__dict__[szKey] = value


sys_const = _Const()

# ------------------------------------------------------------------------------------------------------

# 一日多少秒
sys_const.SECONDS_DAY = 60 * 60 * 24

# 一小时多少秒
sys_const.SECONDS_HOUR = 60 * 60

# 默认移动速度（单位：米）
sys_const.MOVE_SPEED_DEFAULT = 1

# 默认攻击的距离（单位：米）
sys_const.ATTACK_DISTANCE_DEFAULT = 1

# 获取行为树文件路径
sys_const.BT_FILE_PATH = "BT/{0}.bt"

# 获取状态机文件路径
sys_const.FSM_FILE_PATH = "FSM/{0}.fsm"

# ai的更新间隔(单位：毫秒)
sys_const.AI_INTERVAL_DEFAULT = 1000

# ai的更新间隔-战场对战npc(单位：毫秒)
sys_const.AI_INTERVAL_NPC_DEFAULT = 1000

# ai的更新间隔-对战角色思考(单位：毫秒)
sys_const.AI_INTERVAL_THINK_DEFAULT = 1000

# 组队相关，多少秒内不能对同一玩家重复邀请
sys_const.TEAM_INVITE_LIMIT_TIME = 5

# 组队相关，多少秒内不能对同一队伍重复申请
sys_const.TEAM_APPLY_LIMIT_TIME = 5

# 组队相关，创建队伍等待时间(单位：秒)
sys_const.TEAM_CREATE_WAITING_TIME = 5

# 组队相关，离开队伍等待时间(单位：秒)
sys_const.TEAM_EXIT_WAITING_TIME = 5

# 组队相关，申请等待时间(单位：秒)
sys_const.TEAM_APPLY_WAITING_TIME = 40

# 组队相关，申请目标玩家信息等待时间(单位：秒)
sys_const.TEAM_APPLY_PLAYER_WAITING_TIME = 3

# 组队相关，邀请等待时间(单位：秒)
sys_const.TEAM_INVITE_WAITING_TIME = 40

# 组队相关，确认被邀请等待时间(单位：秒)
sys_const.TEAM_CONFIRM_INVITE_WAITING_TIME = 3

# 组队相关，确认被申请等待时间(单位：秒)
sys_const.TEAM_CONFIRM_APPLY_WAITING_TIME = 3

# 组队相关，最邀请数量(单位：秒)
sys_const.TEAM_INVITE_LIMIT = 3

# 组队相关，队伍最大成员数量
sys_const.TEAM_MEMBER_LIMIT = 5

# 组队相关，队伍销毁等待时间, 所有队员都不在线启动销毁(单位：秒)
sys_const.TEAM_DESTROY_WAITING_TIME = 120

# 物品配置表路径
sys_const.ITEM_CONFIG_PATH = "config.setting.item.item_table.{0}"