# -*- coding: utf-8 -*-

import struct


# 网络包头
class MsgHeader(object):
    def __init__(self):
        super(MsgHeader, self).__init__()
        self.m_nMsgID = 0
        self.m_nMsgSize = 0
        self.m_binary = None

    def Set(self, nMsgID, nMsgSize):
        self.m_nMsgID = nMsgID
        self.m_nMsgSize = nMsgSize

        if nMsgID <= 0xff:
            nMsgIDType = 1
            szMsgIDType = 'B'
        elif nMsgID <= 0xffff:
            nMsgIDType = 2
            szMsgIDType = 'H'
        else:
            nMsgIDType = 4
            szMsgIDType = 'I'

        if nMsgSize <= 0xff:
            nMsgSizeType = 1
            szMsgSizeType = 'B'
        elif nMsgSize <= 0xffff:
            nMsgSizeType = 2
            szMsgSizeType = 'H'
        else:
            nMsgSizeType = 4
            szMsgSizeType = 'I'

        self.m_binary = struct.pack("<B%s%s" % (szMsgIDType, szMsgSizeType),
                                    self.MakeUint8(nMsgIDType, nMsgSizeType),
                                    nMsgID,
                                    nMsgSize)

    def SetFromData(self, szData):
        if not szData:
            return False

        h, = struct.unpack(">B", szData[0])
        nMsgIDType = self.LowBit4(h)
        nMsgSizeType = self.HighBit4(h)
        nHeadLen = nMsgIDType + nMsgSizeType + 1
        if len(szData) < nHeadLen:
            return False

        if nMsgIDType == 1:
            szMsgIDType = 'B'
        elif nMsgIDType == 2:
            szMsgIDType = 'H'
        elif nMsgIDType == 4:
            szMsgIDType = 'I'
        else:
            return False

        if nMsgSizeType == 1:
            szMsgSizeType = 'B'
        elif nMsgSizeType == 2:
            szMsgSizeType = 'H'
        elif nMsgSizeType == 4:
            szMsgSizeType = 'I'
        else:
            return False

        self.m_binary = szData[0:nHeadLen]
        h, self.m_nMsgID, self.m_nMsgSize = struct.unpack("<B%s%s" % (szMsgIDType, szMsgSizeType), self.m_binary)
        return True

    def MakeUint8(self, low, high):
        # 1<<4==16
        assert low < 16 and high < 16, "make uint8 error"
        return (low & 0x0f) | ((high & 0x0f) << 4)

    def LowBit4(self, nUint8):
        assert nUint8 < 256, "LowBit4 error %s" % nUint8
        return nUint8 & 0x0f

    def HighBit4(self, nUint8):
        assert nUint8 < 256, "HighBit4 error %s" % nUint8
        return nUint8 >> 4

    def GetHeadSize(self):
        return len(self.m_binary)

    def GetMsgSize(self):
        return self.m_nMsgSize

    def GetMsgID(self):
        return self.m_nMsgID

    def GetBinary(self):
        return self.m_binary
