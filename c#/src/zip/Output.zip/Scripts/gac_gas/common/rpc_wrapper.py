# -*- coding: utf-8 -*-

from enum_def import EMsgType


# 魔法头
MAGIC_START = "RRpcGet"


class BaseRpcWrapper(object):
    def __init__(self, Parent=None):
        # 父
        self.m_Parent = Parent
        # 是否是根代理
        self.m_bRoot = Parent is None
        # 子代理
        self.m_dictSubRpc = {}
        # 子函数名
        self.m_listSubMethodName = []
        # 是否阻塞
        self.m_bBlock = False
        # 缓存消息
        self.m_listCacheMsg = []
        # 是否已经销毁
        self.m_bDestroy = False

    def Block(self):
        assert self.m_bRoot, "只有根代码才可以阻塞"
        self.m_bBlock = True

    def UnBlock(self):
        assert self.m_bRoot, "只有根代码才可以阻塞"
        self.m_bBlock = False
        self.FlushMsg()

    def IsBlock(self):
        return self.m_bBlock

    def FlushMsg(self):
        if not self.m_listCacheMsg:
            return

        for args in self.m_listCacheMsg:
            self._DoSend(*args)
            self.m_listCacheMsg = []

    def _GenRpcFunc(self, szMethodName, listSubMethodName):
        raise NotImplementedError

    def _Clone(self):
        raise NotImplementedError

    def Send(self, *args):
        if self.m_bDestroy:
            return

        if self.m_bRoot:
            if self.m_bBlock:
                self.m_listCacheMsg.append(args)
            else:
                self._DoSend(*args)
        else:
            self.m_Parent.Send(*args)

    def _DoSend(self, *args):
        pass

    def _OnPreGet(self):
        pass

    def __getattr__(self, szMethodName):
        if not szMethodName.startswith(MAGIC_START):
            setattr(self, szMethodName, self._GenRpcFunc(szMethodName, self.m_listSubMethodName))
            return getattr(self, szMethodName)
        else:
            c = self._Clone()
            c.m_listSubMethodName = self.m_listSubMethodName + [szMethodName]
            self.m_dictSubRpc[szMethodName] = c

            def GetFunc():
                s = self.m_dictSubRpc[szMethodName]
                if s:
                    s._OnPreGet()
                return s

            setattr(self, szMethodName, GetFunc)
            return getattr(self, szMethodName)

    def IsDestroy(self):
        return self.m_bDestroy

    def OnDestroy(self):
        pass

    def Destroy(self):
        if self.m_bDestroy:
            return

        self.OnDestroy()

        for Obj in self.m_dictSubRpc.itervalues():
            Obj.Destroy()

        self.m_dictSubRpc.clear()
        self.m_Parent = None

        self.__dict__.clear()
        self.m_bDestroy = True

# ----------------------------------------connection到connection的rpc----------------------------------
class RpcWrapperConnection(object):
    def __init__(self, ConnObj):
        self.m_ConnObj = ConnObj

    def __getattr__(self, szMethodName):
        def Func(*args):
            self.m_ConnObj.Send(EMsgType.CONN_CALL, [szMethodName, args])

        setattr(self, szMethodName, Func)
        return getattr(self, szMethodName)

    def Destroy(self):
        self.m_ConnObj = None


# ----------------------------------------connection的主entity-----------------------------------------
class RpcWrapperPeerEntity(object):
    def __init__(self, ConnObj):
        self.m_ConnObj = ConnObj

    def __getattr__(self, szMethodName):
        def Func(*args):
            self.m_ConnObj.Send(EMsgType.SELF_ENTITY_MSG, [szMethodName, args])

        setattr(self, szMethodName, Func)
        return getattr(self, szMethodName)

    def Destroy(self):
        self.m_ConnObj = None
