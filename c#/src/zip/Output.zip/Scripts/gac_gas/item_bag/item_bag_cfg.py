# -*- coding: utf-8 -*-

# __author__ = gzxiejinchun@corp.netease.com
# __date__ = 2017/6/7 19:50

# desc: 背包配置表


import config.setting.item.item_bag_common as item_bag_common


class ItemBagCfgMgr(object):
    """背包配置表管理器"""

    def __init__(self):
        pass

    def GetSpaceCount(self, nItemBagSpace):
        """返回空间大小"""

        return item_bag_common.item_bag_common[nItemBagSpace]['SpaceCount']


g_ItemBagCfgMgr = ItemBagCfgMgr()
