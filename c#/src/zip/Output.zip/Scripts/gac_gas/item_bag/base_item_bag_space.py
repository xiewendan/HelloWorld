# -*- coding: utf-8 -*-

# desc: 物品背包的空间

import gac_gas.item.base_item as base_item
import gac_gas.item.item_cfg_mgr as item_cfg_mgr


class BaseItemBagSpace(object):
    """物品背包的空间"""

    def __init__(self, nItemBagSpace, nSpaceCount, nExSpaceCount=0):
        self.m_nItemBagSpace = nItemBagSpace        # 空间索引
        self.m_nSpaceCount = nSpaceCount            # 初始空间大小
        self.m_nExSpaceCount = nExSpaceCount        # 拓展空间大小

        self.m_dictPos2Item = {}                    # Pos:ItemObj

        self.m_BagMgrObj = None

        # self.m_logger = logging.getLogger(self.__class__.__name__)

    def SetBagMgr(self, BagMgrObj):
        """设置管理的背包"""
        self.m_BagMgrObj = BagMgrObj

    def GetBagMgr(self):
        return self.m_BagMgrObj

    def GetSpaceCount(self):
        """返回背包空间大小"""
        return self.m_nSpaceCount

    def SetSpaceCount(self, nSpaceCount):
        self.m_nSpaceCount = nSpaceCount

    def GetExSpaceCount(self):
        """返回背包的拓展空间大小"""
        return self.m_nExSpaceCount

    def AddExSpaceCount(self, nAddExSpaceCount):
        """加拓展空间大小"""
        assert self.m_nExSpaceCount + nAddExSpaceCount >= 0

        self.m_nExSpaceCount += nAddExSpaceCount

    def SetExSpaceCount(self, nAddExSpaceCount):
        """加拓展空间大小"""

        assert nAddExSpaceCount >= 0

        self.m_nExSpaceCount = nAddExSpaceCount

    def GetTotalSpaceCount(self):
        """返回总的背包空间大小"""
        return self.m_nSpaceCount + self.m_nExSpaceCount

    def HasPos(self, nPos):
        """格子是否合法，有效"""
        return 0 < nPos <= self.GetTotalSpaceCount()

    def AssertPos(self, nPos):
        """检查输入的位置是否合法"""
        print nPos
        print self.GetTotalSpaceCount()
        assert 0 < nPos <= self.GetTotalSpaceCount()

    def IsGridEmpty(self, nPos):
        """指定格子是否为空"""
        self.AssertPos(nPos)

        if nPos not in self.m_dictPos2Item:
            return True
        else:
            Item = self.m_dictPos2Item[nPos]

            return Item.GetCount() == 0

    def GetEmptyGridNum(self):
        """返回空格子的数量"""
        nTotalSpaceCount = self.GetTotalSpaceCount()

        nEmptyGridNum = nTotalSpaceCount - len(self.m_dictPos2Item)

        return nEmptyGridNum

    def FindFirstEmptyPos(self):
        """查找第一个空的位置"""
        nTotalSpaceCount = self.GetTotalSpaceCount()
        for nPos in xrange(1, nTotalSpaceCount + 1):
            if self.IsGridEmpty(nPos):
                return nPos

        return 0

    def IsFull(self):
        """是否已满"""
        return self.FindFirstEmptyPos() == 0

    def SetItemByPos(self, nPos, ItemObj):
        """
        设置指定格子的物品，如果物品为None，则清空
        @param nPos:
        @param ItemObj:
        @return:
        """
        self.AssertPos(nPos)

        if ItemObj:
            assert isinstance(ItemObj, base_item.BaseItem)

            self.m_dictPos2Item[nPos] = ItemObj

            self.OnAddItem(nPos, ItemObj)

        else:
            if nPos in self.m_dictPos2Item:
                self.AssertDelItemByPos(nPos)

    def GetItemByPos(self, nPos):
        """返回指定格子的物品"""
        self.AssertPos(nPos)

        return self.m_dictPos2Item.get(nPos)

    def AddItemByPos(self, nPos, ItemObj):
        """添加物品到指定格子"""
        self.AssertPos(nPos)
        assert isinstance(ItemObj, base_item.BaseItem)

        self.SetItemByPos(nPos, ItemObj)

    def AssertDelItemByPos(self, nPos):
        """删除指定格子的物品,内部接口，物品必须存在"""
        self.AssertPos(nPos)

        ItemObj = self.m_dictPos2Item[nPos]
        del self.m_dictPos2Item[nPos]

        self.OnDelItem(nPos, ItemObj)

    def GetItemCountByPos(self, nPos):
        """返回指定格子的物品数量"""
        self.AssertPos(nPos)

        ItemObj = self.m_dictPos2Item.get(nPos)

        if ItemObj:
            return ItemObj.GetCount()
        else:
            return 0

    def AddItemCountByPos(self, nPos, nCount, nFoldLimit):
        """指定格子增加物品的个数"""
        self.AssertPos(nPos)

        ItemObj = self.GetItemByPos(nPos)

        assert ItemObj

        nNewCount = ItemObj.GetCount() + nCount

        # assert 0 <= nNewCount <= nFoldLimit

        if nNewCount == 0:
            self.AssertDelItemByPos(nPos)

        else:
            ItemObj.AddCount(nCount)

            self.OnItemCountChange(nPos, ItemObj, nCount)

    def TraverseGrid(self, funItemFunc):
        """
        遍历每一个格子，并回调到funcItemFunc中
        @param funItemFunc: funcItemFunc( nItemBagSpace, nPos, ItemObj) 。返回True则终止变遍历
        @return: 无返回值
        """
        nTotalSpaceCount = self.GetTotalSpaceCount()
        for nPos in xrange(1, nTotalSpaceCount + 1):
            ItemObj = self.GetItemByPos(nPos)
            if funItemFunc(self.m_nItemBagSpace, nPos, ItemObj):
                return

    def GetAllItemList(self):
        """返回所有物品的列表"""

        listItemObj = []

        for nPos, ItemObj in self.m_dictPos2Item.items():
            listItemObj.append(ItemObj)

        return listItemObj

    def GetItemByItemID(self, szItemID):
        """返回指定id的物品,如果有"""
        for nPos, ItemObj in self.m_dictPos2Item.items():
            if ItemObj and ItemObj.GetItemID() == szItemID:
                return nPos, ItemObj
        return None, None

    def GetAllItemDict(self):
        """返回所有物品的位置映射到对应的物品"""
        return self.m_dictPos2Item

    def ClearItem(self):
        """清除所有物品"""
        self.m_nExSpaceCount = 0

        dictPos2Item = self.m_dictPos2Item          # 缓存需要删除的物品(CR这里没缓存)
        self.m_dictPos2Item = {}                    # Pos:ItemObj
        self.OnClearItem(dictPos2Item)

    def GetPos2ItemSyncData(self):
        """位置到物品同步信息"""
        dictPos2ItemSyncData = {}

        for nPos, ItemObj in self.m_dictPos2Item.items():
            dictPos2ItemSyncData[nPos] = ItemObj.GetItemSyncData()

        return dictPos2ItemSyncData

    def GetListEmptyPos(self):
        """
        返回所有空格子的位置
        @return:[(nItemBagSpace, nPos), (nItemBagSpace, nPos)]
        """
        listEmptyPos = []

        def GridTraverseCB(nItemBagSpace, nPos, ItemObj):
            if ItemObj is None:
                listEmptyPos.append((nItemBagSpace, nPos))

        self.TraverseGrid(GridTraverseCB)

        return listEmptyPos

    def GetFirstEmptyPos(self):
        """
        返回第一个空的格子
        @return: nPos
        """
        dictEmptyPos = {}

        def GridTraverseCB(nItemBagSpace, nPos, ItemObj):
            print ItemObj
            if ItemObj is None:
                dictEmptyPos[0] = nPos
                return True

        self.TraverseGrid(GridTraverseCB)
        print dictEmptyPos
        return dictEmptyPos.get(0, None)

    # ********************************************************************************
    # 类型相关接口 nBigID, nCount
    # ********************************************************************************
    def GetItemByType(self, nBigID, nIndex):
        """查找背包里的物品"""
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)
        listItem = []

        for nPos, ItemObj in self.m_dictPos2Item.items():
            if ItemObj and ItemObj.GetBigID() == nBigID and ItemObj.GetIndex() == nIndex:
                listItem.append(ItemObj)
        return listItem

    def GetItemCountByType(self, nBigID, nIndex):
        """查找背包空间中物品的数量"""
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)

        listItemCount = [0]

        for nPos, ItemObj in self.m_dictPos2Item.items():
            if ItemObj and ItemObj.GetBigID() == nBigID and ItemObj.GetIndex() == nIndex:
                listItemCount[0] += ItemObj.GetCount()

        return listItemCount[0]

    def GetListItemPosByType(self, nBigID, nIndex):
        """
        返回所有物品所在格子
        @return:
        """
        listItemPos = []

        for nPos, ItemObj in self.m_dictPos2Item.items():
            if ItemObj and ItemObj.GetBigID() == nBigID and ItemObj.GetIndex() == nIndex:
                listItemPos.append((self.m_nItemBagSpace, nPos))

        return listItemPos

    def GetListItemPosByItemType(self, nTypeID):
        listItemPos = []

        for nPos, ItemObj in self.m_dictPos2Item.items():
            if ItemObj and ItemObj.GetTypeID() == nTypeID:
                listItemPos.append(nPos)

        return listItemPos

    # ********************************************************************************
    # 重写的背包内的回调事件
    # ********************************************************************************
    def OnAddItem(self, nPos, ItemObj):
        """添加物品"""
        pass

    def OnDelItem(self, nPos, ItemObj):
        """删除物品"""
        pass

    def OnClearItem(self, dictPos2Item):
        """清除物品"""
        pass

    def OnItemCountChange(self, nPos, ItemObj, nCount):
        """物品数量变化"""
        pass

    # ********************************************************************************
    # 测试
    # ********************************************************************************
    def TestPrint(self):
        nTotalSpaceCount = self.GetTotalSpaceCount()

        print("空间大小:%s,%s", self.GetSpaceCount(), self.GetExSpaceCount())

        for nPos in xrange(1, nTotalSpaceCount + 1):
            ItemObj = self.GetItemByPos(nPos)

            if ItemObj:
                nBigID = ItemObj.GetBigID()
                nIndex = ItemObj.GetIndex()
                nCount = ItemObj.GetCount()
                dynamicData = ItemObj.GetDynamicData()
                nAddTime = ItemObj.GetAddTime()
                print("%s:%s,%s,%s,%s,%s", nPos, nBigID, nIndex, nCount, dynamicData, nAddTime)

            else:
                print("%s:None", nPos)
