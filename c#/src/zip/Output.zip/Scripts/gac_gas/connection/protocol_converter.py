# -*- coding: utf-8 -*-
# @Author  : jmhuo

import traceback
import string_or_index_cache as string_or_index_cache
from gac_gas.common.enum_def import EMsgType
from gac_gas.common.enum_def import EEntityAvatarMsgType

# 游戏对象消息类型
GAME_OBJ_MSG_TYPE = EEntityAvatarMsgType.GAMEOBJMSG

# 高频固定参数rpc
HARD_FUN_PARAM0 = set([])


class ProtoColConverter(object):
    def __init__(self, ConnObj):
        self.m_ConnObj = ConnObj

        self.m_StringOrIndexSendCache = string_or_index_cache.StringOrIndexCache()
        self.m_StringOrIndexRecvCache = string_or_index_cache.StringOrIndexCache()

        self.String2IndexFunc = {
            EMsgType.CONN_CALL: self._ConvertString2Index,
            EMsgType.SELF_ENTITY_MSG: self._ConvertString2Index,
            EMsgType.SEND_SESSION_KEY: lambda x:x,
            EMsgType.GAS2GATE_FORWARD_GAC: self._ConvertString2Index_RecvMsgCache,
            EMsgType.GAC2GATE_FORWARD_GAS: self._ConvertString2Index_SubMsg,  # SubMsg
            EMsgType.BAT2GATE_FORWARD_GAC: self._ConvertString2Index_SubMsg,
            EMsgType.GAC2GATE_FORWARD_BAT: self._ConvertString2Index_SubMsg,
        }

        self.Index2StringFunc = {
            EMsgType.CONN_CALL: self._ConvertIndex2String,
            EMsgType.SELF_ENTITY_MSG: self._ConvertIndex2String,
            EMsgType.SEND_SESSION_KEY: lambda x:x,
            EMsgType.GAS2GATE_FORWARD_GAC: self._ConvertIndex2String_RecvMsgCache,
            EMsgType.GAC2GATE_FORWARD_GAS: self._ConvertIndex2String_SubMsg,  # SubMsg
            EMsgType.BAT2GATE_FORWARD_GAC: self._ConvertIndex2String_SubMsg,
            EMsgType.GAC2GATE_FORWARD_BAT: self._ConvertIndex2String_SubMsg,
        }

    def SetDebug(self, b):
        self.m_StringOrIndexSendCache.SetDebug(b)
        self.m_StringOrIndexRecvCache.SetDebug(b)

    def Dump(self, nLimit=100):
        sendList = self.m_StringOrIndexSendCache.DebugGetIndex()
        recvList = self.m_StringOrIndexRecvCache.DebugGetString()

        s = "发送-------------------------------------\n"
        for i, v in enumerate(sendList):
            if i > nLimit:
                break
            s = s + str(v) + "\n"

        s += "接收-------------------------------------\n"
        for i, v in enumerate(recvList):
            if i > nLimit:
                break
            s = s + str(v) + "\n"

        return s

    def ClearSend(self):
        self.m_StringOrIndexSendCache.Clear()

    def ClearRecv(self):
        self.m_StringOrIndexRecvCache.Clear()

    def DispatchRegString(self, nMsgID, data):
        szString, nIndex = data
        self.m_StringOrIndexRecvCache.RegString(szString, nIndex)
        return True

    def Destroy(self):
        self.m_ConnObj = None
        self.String2IndexFunc.clear()
        self.Index2StringFunc.clear()

    # -----------------------------------------------------------------
    # 发送优化
    def _ConvertString2Index(self, data):
        data[0] = self._GetIndexBySendString(data[0])

    def _ConvertString2Index_RecvMsgCache(self, data):
        if "RecvMsgCache" == data[0]:
            # RecvMsgCacheData ======= ['RecvMsgCache', [[[2, 'DoSkillByGas', ['5a9a57e8de0aea0a1004dcec', 278, 100501, 0, '', 1.0, 19], '5b3089f5de0aea1374b67ff5']]], []]
            listRecvMsgCacheArg = data[1]
            listCache = listRecvMsgCacheArg[0]
            for msg in listCache:
                if msg[1] in HARD_FUN_PARAM0:
                    # 高频函数第一参数为目标对象id
                    msg[2][0] = self._GetIndexBySendString(msg[2][0])

                # 函数名
                msg[1] = self._GetIndexBySendString(msg[1])

                # 绑定对象id
                if msg[0] == GAME_OBJ_MSG_TYPE:
                    msg[3] = self._GetIndexBySendString(msg[3])

                    # 对象嵌套函数名
                    listSubMethodName = msg[4]
                    for nIndex, szSubMethodName in enumerate(listSubMethodName):
                        listSubMethodName[nIndex] = self._GetIndexBySendString(szSubMethodName)

        data[0] = self._GetIndexBySendString(data[0])

        # 嵌套调用函数名
        listSubMethodName = data[2]
        for nIndex, szSubMethodName in enumerate(listSubMethodName):
            listSubMethodName[nIndex] = self._GetIndexBySendString(szSubMethodName)

    def _ConvertString2Index_SubMsg(self, data):
        szMethodName = data[0]
        data[0] = self._GetIndexBySendString(data[0])
        if "SubMsg" == szMethodName:
            # self._ConvertString2Index_SubMsg(data[1])
            listSubMsgArg = data[1]
            listSubMsgArg[0] = self._GetIndexBySendString(listSubMsgArg[0])
            listSubMsgArg[2] = self._GetIndexBySendString(listSubMsgArg[2])
        elif "ProxyMsg4Account" == szMethodName:
            # self._ConvertString2Index_SubMsg(data[1])
            listSubMsgArg = data[1]
            listSubMsgArg[0] = self._GetIndexBySendString(listSubMsgArg[0])

        if len(data) >= 3:
            listSubMethodName = data[2]
            for index, subMethodName in enumerate(listSubMethodName):
                listSubMethodName[index] = self._GetIndexBySendString(subMethodName)

    def CheckString2IndexSendCache(self):
        if self.m_StringOrIndexSendCache.IsFull():
            self.m_StringOrIndexSendCache.Clear()
            self.m_ConnObj.RawSend(EMsgType.CLEAR_REG_STRING, "")

    def ConvertString2IndexBySendData(self, nMsgID, data):
        self.CheckString2IndexSendCache()

        try:
            func = self.String2IndexFunc[nMsgID]
            func(data)
        except Exception, e:
            traceback.print_exc()
            raise e

        return data

    # 根据string获取index, 并且自动注册到自己和peer端,成功返回index,失败返回szString
    def _GetIndexBySendString(self, szString):
        nIndex, bTryReg = self.m_StringOrIndexSendCache.GetIndexEx(szString)
        if nIndex is None:
            return szString
        else:
            if bTryReg:
                self.m_ConnObj.RawSend(EMsgType.REG_STRING, [szString, nIndex])
            return nIndex

    # --------------------------------------------------------------------------
    # 接收优化
    def ConvertIndex2StringByRecvData(self, nMsgID, data):
        try:
            func = self.Index2StringFunc[nMsgID]
            func(data)
        except Exception, e:
            traceback.print_exc()
            raise e

    def _ConvertIndex2String(self, data):
        if not isinstance(data[0], basestring):
            szMethodName = self.m_StringOrIndexRecvCache.GetString(data[0])
            assert isinstance(szMethodName, basestring), "Convert2String no key:%s" % data[0]
            data[0] = szMethodName

    def _ConvertIndex2String_RecvMsgCache(self, data):
        # 单独对这个函数进行优化，不进行容错，因为是高频函数，不能容错
        CacheIndex = self.m_StringOrIndexRecvCache.m_dictIndex2String
        data[0] = CacheIndex[data[0]]
        if "RecvMsgCache" == data[0]:
            for msg in data[1][0]:
                # 函数名
                msg[1] = CacheIndex[msg[1]]

                if msg[1] in HARD_FUN_PARAM0:
                    # 高频函数第一参数为目标对象id
                    msg[2][0] = CacheIndex[msg[2][0]]

                # 对象id
                if msg[0] == GAME_OBJ_MSG_TYPE:
                    msg[3] = CacheIndex[msg[3]]

                    # 嵌套调用函数名
                    listSubMethodName = msg[4]
                    for nIndex, szSubMethodName in enumerate(listSubMethodName):
                        listSubMethodName[nIndex] = self.m_StringOrIndexRecvCache.GetString(szSubMethodName)

        # 嵌套调用函数名
        listSubMethodName = data[2]
        for nIndex, szSubMethodName in enumerate(listSubMethodName):
            listSubMethodName[nIndex] = self.m_StringOrIndexRecvCache.GetString(szSubMethodName)

    def _ConvertIndex2String_SubMsg(self, data):
        szMethodName = ""

        if not isinstance(data[0], basestring):
            szMethodName = self.m_StringOrIndexRecvCache.GetString(data[0])
            assert isinstance(szMethodName, basestring), "Convert2String no key:%s" % data[0]
            data[0] = szMethodName

        if "SubMsg" == szMethodName:
            listSubMsgArg = data[1]
            if not isinstance(listSubMsgArg[0], basestring):
                szMethodName = self.m_StringOrIndexRecvCache.GetString(listSubMsgArg[0])
                objEntityID = self.m_StringOrIndexRecvCache.GetString(listSubMsgArg[2])
                assert isinstance(szMethodName, basestring), "Convert2String no key:%s" % listSubMsgArg[0]
                listSubMsgArg[0] = szMethodName
                listSubMsgArg[2] = objEntityID

        elif "ProxyMsg4Account" == szMethodName:
            listSubMsgArg = data[1]
            if not isinstance(listSubMsgArg[0], basestring):
                szMethodName = self.m_StringOrIndexRecvCache.GetString(listSubMsgArg[0])
                assert isinstance(szMethodName, basestring), "Convert2String no key:%s" % listSubMsgArg[0]
                listSubMsgArg[0] = szMethodName

        if len(data) >= 3:
            listSubMethodName = data[2]

            for index, subMethodName in enumerate(listSubMethodName):
                listSubMethodName[index] = self.m_StringOrIndexRecvCache.GetString(subMethodName)
