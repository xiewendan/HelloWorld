# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.common.rpc_wrapper as rpc_wrapper


# 网络连接基类
class ConnectionBase(object):
    def __init__(self, ConnectionMgr, nConnID):
        # 连接ID
        self.m_nConnID = nConnID
        # 连接端的代理
        self.m_PeerRpc = rpc_wrapper.RpcWrapperConnection(self)
        # 所在连接管理器
        self.m_ConnectionMgr = ConnectionMgr
        # 对应实体
        self.m_Entity = None
        # 对面连接信息
        self.m_szRemoteInfo = None
        # 对面IP地址
        self.m_szRemoteIP = None
        # 是否已经销毁
        self.m_bDestroy = False

    # ---------------------------------------属性函数------------------------------------------

    # 获取连接ID
    def GetID(self):
        return self.m_nConnID

    # 获取连接端代理
    def GetPeerRpc(self):
        return self.m_PeerRpc

    # 对面连接信息
    def GetRemoteInfo(self):
        return self.m_szRemoteInfo

    # 获取连接端IP
    def GetRemoteIP(self):
        return self.m_szRemoteIP

    # ---------------------------------------实体函数------------------------------------------

    # 绑定实体
    def BindEntity(self, BaseEntity):
        if BaseEntity is None:
            return

        if self.m_Entity == BaseEntity:
            return

        self.UnBindEntity()

        self.m_Entity = BaseEntity
        self.m_Entity.BindConn(self)

    # 解除绑定实体
    def UnBindEntity(self):
        if self.m_Entity is not None:
            Entity = self.m_Entity
            self.m_Entity = None
            Entity.UnBindConn()

    # 更新
    def OnUpdate(self):
        pass

    def Update(self):
        self.OnUpdate()

    # 销毁
    def OnDestroy(self, bNow=False):
        pass

    # 销毁
    def Destroy(self, bNow=False):
        if self.m_bDestroy:
            return

        self.m_bDestroy = True

        self.UnBindEntity()

        self.m_ConnectionMgr.UnRegisterConn(self)

        self.OnDestroy(bNow)
