# -*- coding: utf-8 -*-

from connection_base import ConnectionBase


# 网络连接
class ConnectionServerBase(ConnectionBase):
    def __init__(self, ConnectionMgr, nConnID):
        super(ConnectionServerBase, self).__init__(ConnectionMgr, nConnID)
        # 连接数量
        self.m_nRequestQueueSize = ConnectionMgr.m_nMaxRequestQueueSize

    # ---------------------------------------网络函数------------------------------------------

    # 侦听
    def Listen(self, szIP, nPort):
        raise NotImplementedError

    # 断开连接
    def ShutDown(self):
        raise NotImplementedError

    # ---------------------------------------实体函数------------------------------------------

    # 销毁
    def OnDestroy(self, bNow=False):
        self.ShutDown()
