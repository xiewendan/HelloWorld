# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import datetime
import logging
import time
import msgpack
import traceback
import gac_gas.encryption.encryption_mgr as encryption_mgr
import gac_gas.common_pkg.tick_mgr as tick_mgr
from bson import objectid
from connection_base import ConnectionBase
from gac_gas.common.enum_def import EMsgType


# ------------------------------------协议包相关----------------------------------------

def DecodeMsgtype(obj):
    # .d = __datetime__
    # .o = __objectid__

    if b'.d' in obj:
        obj = datetime.datetime.strptime(obj[".s"], "%Y%m%dT%H:%M:%S.%f")
    elif b'.o' in obj:
        obj = objectid.ObjectId(str(obj[".s"]))
    return obj


def EncodeMsgtype(obj):
    # .d= __datetime__
    # .o = __objectid__

    if isinstance(obj, datetime.datetime):
        return {'.d': True, '.s': obj.strftime("%Y%m%dT%H:%M:%S.%f")}
    elif isinstance(obj, objectid.ObjectId):
        return {'.o': True, '.s': obj.binary}
    return obj

# --------------------------------------------------------------------------------------

# 网络连接
class ConnectionClientBase(ConnectionBase):
    def __init__(self, ConnectionMgr, nConnID):
        super(ConnectionClientBase, self).__init__(ConnectionMgr, nConnID)
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        # 连接管理器ID
        self.m_nConnectionMgrID = ConnectionMgr.m_nConnectionMgrID
        # 是否心跳
        self.m_bKeepAlive = ConnectionMgr.m_bKeepAlive
        # 上次心跳时间
        self.m_nLastPingTime = 0
        # 心跳检查间隔(时间:毫秒)
        self.m_nCheckAliveInterval = ConnectionMgr.m_nCheckAliveInterval
        # 心跳时间超时(时间:毫秒)
        self.m_nCheckAliveTimeout = ConnectionMgr.m_nCheckAliveTimeout
        # 心跳Tick
        self.m_TickAlive = None
        # 网络延时
        self.m_nDelayMS = 0
        # 连接的额外信息
        self.m_Context = None

        # 加密相关
        self.m_szSessionKey = None
        self.m_Encrypter = None
        self.m_Decrypter = None

        # ---------------------
        self.m_bDebug = False
        self.m_TickDebug = None
        self.m_nRecvTotal = 0  # 总共
        self.m_nSendTotal = 0
        self.m_nRecvAverage = 0
        self.m_nSendAverage = 0

        self.m_nHighRecvPreSec = 0
        self.m_nHighSendPreSec = 0
        self.m_nRunSecond = 0

        self.m_nCurSecondSend = 0
        self.m_nCurSecondRecv = 0

        self.m_nLastSecondSend = 0
        self.m_nLastSecondRecv = 0

    # ---------------------------------------属性函数------------------------------------------

    # 连接的额外信息
    def SetContext(self, Context):
        self.m_Context = Context

    # 连接的额外信息
    def GetContext(self):
        return self.m_Context

    # 更新IP地址
    def UpdateRemoteInfo(self, szIP=None, nPort=None):
        self.m_szRemoteIP = szIP

        if szIP is None:
            self.m_szRemoteInfo = "{}-{}-lost".format(self.m_ConnectionMgr.GetConnMgrID(), self.GetID())
        else:
            self.m_szRemoteInfo = "{}-{}-({}, {})".format(self.m_ConnectionMgr.GetConnMgrID(), self.GetID(), szIP, nPort)

    # 更新IP地址
    def TryUpdateRemoteInfo(self):
        raise NotImplementedError

    # ---------------------------------------心跳函数------------------------------------------

    # 心跳相关
    def OnTick(self):
        self.OnConnTick()

    # 心跳相关
    def OnConnTick(self):
        if self.m_bKeepAlive:
            self.m_PeerRpc.KeepAlive(int(time.time() * 1000))

            if self.m_nCheckAliveTimeout > 0:
                nCurTime = int(time.time() * 1000)
                if nCurTime > self.m_nLastPingTime + self.m_nCheckAliveTimeout:
                    self.m_Logger.info("超时断开:conn:%d,time:%d,last:%d,off:%d,check:%d", self.GetID(), nCurTime, self.m_nLastPingTime, nCurTime-self.m_nLastPingTime, self.m_nCheckAliveTimeout)
                    self.ShutDownNow()

    # 更新心跳时间
    def UpdateLastPingTime(self):
        self.m_nLastPingTime = int(time.time() * 1000)

    # 心跳相关
    def KeepAlive(self, Context=None):
        self.UpdateLastPingTime()

        if Context:
            self.m_PeerRpc.KeepAliveBack(Context)

    # 心跳相关
    def KeepAliveBack(self, Context):
        nCurTime = int(time.time() * 1000)
        if Context < nCurTime:
            self.m_nDelayMS = nCurTime - Context

    # 获取网络延时
    def GetDelayMs(self):
        return self.m_nDelayMS

    # 开始心跳
    def EnableAliveTick(self):
        self.DisableAliveTick()

        if self.m_bKeepAlive:
            self.m_TickAlive = tick_mgr.RegisterTick("EnableAliveTick", self.m_nCheckAliveInterval, self.OnTick)

    # 结束心跳
    def DisableAliveTick(self):
        if self.m_TickAlive:
            tick_mgr.UnRegisterTick(self.m_TickAlive)
            self.m_TickAlive = None

    # ---------------------------------------调试函数------------------------------------------

    def EnableDebug(self):
        self.m_bDebug = True
        if self.m_TickDebug is None:
            self.m_TickDebug = tick_mgr.RegisterNotFixTick("EnableDebug", 1000, self.OnDebugTick)

    def DisableDebug(self):
        self.m_bDebug = False
        if self.m_TickDebug:
            tick_mgr.UnRegisterTick(self.m_TickDebug)
            self.m_TickDebug = None

    def OnDebugTick(self):
        self.m_nRunSecond += 1
        self.m_nSendTotal += self.m_nCurSecondSend
        self.m_nRecvTotal += self.m_nCurSecondRecv

        self.m_nHighRecvPreSec = max(self.m_nHighRecvPreSec, self.m_nCurSecondRecv)
        self.m_nHighSendPreSec = max(self.m_nHighSendPreSec, self.m_nCurSecondSend)

        self.m_nRecvAverage = self.m_nRecvTotal / self.m_nRunSecond * 1.0
        self.m_nSendAverage = self.m_nSendTotal / self.m_nRunSecond * 1.0

        self.m_nLastSecondSend = self.m_nCurSecondSend
        self.m_nLastSecondRecv = self.m_nCurSecondRecv

        self.m_nCurSecondSend = 0
        self.m_nCurSecondRecv = 0

        # print self.Dump()

    def Dump(self):
        if self.m_bDebug:
            return "下行:%.2fK/%.2fK/%.2fK ; 上行:%.2fK/%.2fK/%.2fK(即/峰/总)" % (
                self.m_nLastSecondRecv / 1000.0, self.m_nHighRecvPreSec / 1000.0, self.m_nRecvTotal / 1000.0, self.m_nLastSecondSend / 1000.0,
                self.m_nHighSendPreSec / 1000.0, self.m_nSendTotal / 1000.0)
        else:
            return ""

    # ---------------------------------------网络函数------------------------------------------

    # 连接
    def Connect(self, szIP, nPort):
        raise NotImplementedError

    # 断开连接
    def ShutDown(self, bFlush=True, bRemote=False):
        raise NotImplementedError

    # 立刻断开连接
    def ShutDownNow(self):
        self.ShutDown(False)

    # 发送加密
    def SendSessionKey(self):
        # 这里发送session key给服务器，如果需要加密的话
        if not self.m_ConnectionMgr.IsNeedEncryption():
            self.m_Logger.info("没有启用加密")
            return

        self.m_szSessionKey = encryption_mgr.CreateSesssionKey()

        szCryptSessionKey = encryption_mgr.EncryptAndFixSessionKey(self.m_szSessionKey)
        self.m_Logger.info("向服务器发送 session key 的包")

        # print("{},{}".format(self.m_szSessionKey, szCryptSessionKey))

        self.Send(EMsgType.SEND_SESSION_KEY, szCryptSessionKey)

        self.m_Encrypter, self.m_Decrypter = encryption_mgr.CreateEncrypterAndDecrypterBySessionKey(self.m_szSessionKey)

    def SetSessionKey(self, szCryptKey):
        # 这里是客户端发送sessiong key过来
        self.m_Logger.info("收到客户端发送 session key 的包")

        # print("{}".format(szCryptKey))

        if not self.m_ConnectionMgr.IsNeedEncryption():
            self.m_Logger.info("没有启用加密")
            return

        try:
            self.m_szSessionKey = encryption_mgr.DecryptAndFixSessionKey(szCryptKey)
            self.m_Encrypter, self.m_Decrypter = encryption_mgr.CreateEncrypterAndDecrypterBySessionKey(self.m_szSessionKey)
        except Exception, e:
            self.m_Logger.error(e)
            self.ShutDown(False)

    # 成功连接事件
    def OnConnectEvent(self, nConnID=None):
        self.m_Logger.info("成功连接事件")

        self.TryUpdateRemoteInfo()

        # 更新心跳
        self.UpdateLastPingTime()

        # 向连接管理器注册自己
        self.m_ConnectionMgr.RegisterConn(self)

        # 连接成功处理
        self.OnConnect()

        # 绑定实体
        self.m_ConnectionMgr.TryBindEntity(self)

        # 连接管理器处理成功连接
        if self.m_ConnectionMgr.m_funConnectCallback:
            self.m_ConnectionMgr.m_funConnectCallback(self)

    # 子类可以实现
    def OnConnect(self):
        pass

    # 连接失败事件
    def OnConnectFailedEvent(self, nReason):
        self.m_Logger.info("连接失败事件:{}".format(nReason))

        # 注销绑定实体
        self.UnBindEntity()

        # 连接失败处理
        self.OnConnectFailed(nReason)

        # 连接管理器处理失败连接
        if self.m_ConnectionMgr.m_funConnectFailCallback:
            self.m_ConnectionMgr.m_funConnectFailCallback(self)

        # 向连接管理器注销自己
        self.m_ConnectionMgr.UnRegisterConn(self)

    # 子类可以实现
    def OnConnectFailed(self, nReason):
        pass

    # 被动断开连接
    def OnDisConnectEvent(self, nReason, bRemote):
        pass

    # 主动断开连接
    def OnDisConnectedEvent(self, nReason, bRemote):
        self.m_Logger.info("主动断开连接")

        # 注销绑定实体
        self.UnBindEntity()

        # 断开连接回调
        self.OnDisConnected(nReason, bRemote)

        # 连接管理器处理断开连接
        if self.m_ConnectionMgr.m_funDisConnectCallback:
            self.m_ConnectionMgr.m_funDisConnectCallback(self)

        # 向连接管理器注销自己
        self.m_ConnectionMgr.UnRegisterConn(self)

    # 子类可以实现
    def OnDisConnected(self, nReason, bRemote):
        pass

    # ---------------------------------------协议包函数------------------------------------------

    # 收到协议包
    def OnRecv(self, nMsgID, szPackData):
        # print("************收到协议包:[{},{}]->{}".format(self.m_nConnectionMgrID, self.m_nConnID, nMsgID))

        # 调试
        if self.m_bDebug:
            self.m_nCurSecondRecv += len(szPackData)

        self.UpdateLastPingTime()

        if nMsgID == EMsgType.ENGINE_WORLD_ENTITY_CALL:
            self.Dispatch(nMsgID, szPackData)
        else:
            szPackData = self.Decrypt(szPackData)
            data = self.MsgUnPack(szPackData)
            self.Dispatch(nMsgID, data)

    # 收到原始协议包
    def OnRawRecv(self, szPackData):
        # print("************收到原始协议包:[{},{}]".format(self.m_nConnectionMgrID, self.m_nConnID))

        self.UpdateLastPingTime()

    # 分发协议包
    def Dispatch(self, nMsgID, data):
        try:
            if nMsgID == EMsgType.CONN_CALL:
                # 本链接
                getattr(self, data[0])(*data[1])
            elif nMsgID == EMsgType.SELF_ENTITY_MSG:
                # 本链接绑定的entity
                if self.m_Entity is not None:
                    self.m_Entity.OnPbxMsg(data)
            else:
                # self.m_Logger.info("*****************OnDispatch: {}, {}, {}".format(self.GetID(), nMsgID, data))
                self.OnDispatch(nMsgID, data)
        except Exception, e:
            self.m_Logger.error(e)
            traceback.print_exc()

    # 分发协议包
    def OnDispatch(self, nMsgID, data):
        if self.m_ConnectionMgr.m_funDispatchMsgCallback:
            self.m_ConnectionMgr.m_funDispatchMsgCallback(self, nMsgID, data)
        else:
            self.m_Logger.error("ignore message nMsgID:{}, data:{}".format(nMsgID, data))

    # 发送数据
    def Send(self, nMsgID, data):
        if not self._Send(nMsgID, data):
            self.ShutDown(False)

    def RawSend(self, nMsgID, data):
        if not self._Send(nMsgID, data):
            self.ShutDown(False)

    # 发送数据
    def _Send(self, nMsgID, data):
        raise NotImplementedError

    # 打包
    def MsgPack(self, Obj):
        return msgpack.packb(Obj, use_bin_type=True, default=EncodeMsgtype)

    # 解包
    def MsgUnPack(self, szMsg):
        return msgpack.unpackb(szMsg, encoding='utf-8', object_hook=DecodeMsgtype)

    # ---------------------------------------加解密函数------------------------------------------

    def Encrypt(self, szPackData):
        if self.m_Encrypter:
            return self.m_Encrypter.encrypt(szPackData)
        return szPackData

    def Decrypt(self, szPackData):
        if self.m_Decrypter:
            szPackData = szPackData[:]
            return self.m_Decrypter.decrypt(szPackData)
        return szPackData

    # ---------------------------------------实体函数------------------------------------------

    # 销毁
    def OnDestroy(self, bNow=False):
        self.m_ConnectionMgr.UnRegisterConn(self)

        if bNow:
            self.ShutDownNow()
        else:
            self.ShutDown()
