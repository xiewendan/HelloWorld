# -*- coding: utf-8 -*-

import logging
import gac_gas.connection.connection_mgr_mgr as connection_mgr_mgr


# 连接管理器
class ConnectionClientMgrBase(object):
    def __init__(self, dictConnectionArgs):
        super(ConnectionClientMgrBase, self).__init__()

        self.m_Logger = logging.getLogger(self.__class__.__name__)

        # 连接名称
        self.m_szConnectionName = dictConnectionArgs.get("con_name", "")
        # 请求连接队列大小
        self.m_nMaxRequestQueueSize = dictConnectionArgs.get("max_req_queue_size", 1000)
        # 接收缓存大小
        self.m_nConnMaxInBufSize = dictConnectionArgs.get("conn_max_in_buf_size", 2 * 1024 * 1024)
        # 写缓存大小
        self.m_nConnMaxOutBufSize = dictConnectionArgs.get("conn_max_out_buf_size", 2 * 1024 * 1024)
        # 连接管理ID
        self.m_nConnectionMgrID = None
        # 是否心跳
        self.m_bKeepAlive = dictConnectionArgs.get("keep_alive", False)
        # 心跳检查间隔(时间:毫秒)
        self.m_nCheckAliveInterval = dictConnectionArgs.get("check_alive_interval", 2000)
        # 心跳检查超时(时间:毫秒)
        self.m_nCheckAliveTimeout = dictConnectionArgs.get("check_alive_timeout", 60000)
        # 所有连接
        self.m_dictConnection = {}
        # 连接成功回调
        self.m_funConnectCallback = dictConnectionArgs.get("connect_callback", None)
        # 连接失败回调
        self.m_funConnectFailCallback = dictConnectionArgs.get("connect_fail_callback", None)
        # 断开连接回调
        self.m_funDisConnectCallback = dictConnectionArgs.get("disconnect_callback", None)
        # 消息派发
        self.m_funDispatchMsgCallback = dictConnectionArgs.get("dispatch_msg_callback", None)
        # 实现类
        self.m_EntityClass = dictConnectionArgs.get("entity_class", None)
        # 连接类
        self.m_ConnectionClass = dictConnectionArgs.get("connection_class", None)
        # 连接类
        self.m_tupleConnectionClassArgs = dictConnectionArgs.get("connection_class_args", None)
        # 是否启用加密
        self.m_bNeedEncryption = dictConnectionArgs.get("need_encryption", False)
        # 当前连接ID
        self.m_nCurConnID = 0

        # 初始化
        self.Init()
        self.m_Logger.info("初始化管理器ID:{}".format(self.m_nConnectionMgrID))

        # 注册管理器
        connection_mgr_mgr.Register(self)

    def Init(self):
        # 连接管理ID
        self.m_nConnectionMgrID = connection_mgr_mgr.GenConnMgrID()

    # 生成连接ID
    def GenConnID(self):
        self.m_nCurConnID += 1
        return self.m_nCurConnID

    # 获取连接管理器ID
    def GetConnMgrID(self):
        return self.m_nConnectionMgrID

    # 获取连接
    def GetConn(self, nConnID):
        return self.m_dictConnection.get(nConnID)

    # 注册连接
    def RegisterConn(self, ConnObj):
        self.m_Logger.info("注册连接:{}, {}".format(self.m_nConnectionMgrID, ConnObj.GetID()))
        self.m_dictConnection[ConnObj.GetID()] = ConnObj

    # 注销连接
    def UnRegisterConn(self, ConnObj):
        if ConnObj.GetID() in self.m_dictConnection:
            self.m_Logger.info("注销连接:{}, {}".format(self.m_nConnectionMgrID, ConnObj.GetID()))
            del self.m_dictConnection[ConnObj.GetID()]

    # 销毁所有连接
    def DestroyAllConn(self):
        for ConnObj in self.m_dictConnection.values():
            ConnObj.Destroy(True)

    # 是否需要加密
    def IsNeedEncryption(self):
        return self.m_bNeedEncryption

    # 连接对象直接绑定实体
    def TryBindEntity(self, ConnObj):
        if self.m_EntityClass is None:
            return

        if self.m_tupleConnectionClassArgs:
            self.m_Logger.info("连接对象直接绑定实体1:{}".format(self.m_EntityClass.__name__))
            ConnObj.BindEntity(self.m_EntityClass(*self.m_tupleConnectionClassArgs))
        else:
            self.m_Logger.info("连接对象直接绑定实体2:{}".format(self.m_EntityClass.__name__))
            ConnObj.BindEntity(self.m_EntityClass())

    def GetConnectionClass(self):
        raise NotImplementedError

    # 连接邀请
    def OnConnectEvent(self, nConnID):
        ConnectionClientClass = self.GetConnectionClass()
        ConnObj = ConnectionClientClass(self, nConnID)
        ConnObj.OnConnectEvent()

    # 连接失败
    def OnConnectFailedEvent(self, nConnID, nReason):
        ConnObj = self.GetConn(nConnID)
        if ConnObj is not None:
            ConnObj.OnConnectFailedEvent(nReason)
        else:
            if self.m_funConnectFailCallback:
                self.m_funConnectFailCallback(None)

    # 连接断开
    def OnDisConnectEvent(self, nConnID, nReason, bRemote):
        ConnObj = self.GetConn(nConnID)
        if ConnObj is not None:
            ConnObj.OnDisConnectEvent(nReason, bRemote)
        else:
            if self.m_funDisConnectCallback:
                self.m_funDisConnectCallback(None)

    # 连接断开
    def OnDisConnectedEvent(self, nConnID, nReason, bRemote):
        ConnObj = self.GetConn(nConnID)
        if ConnObj is not None:
            ConnObj.OnDisConnectedEvent(nReason, bRemote)
        else:
            if self.m_funDisConnectCallback:
                self.m_funDisConnectCallback(None)

    # 销毁
    def Destroy(self):
        connection_mgr_mgr.UnRegister(self)
        self.DestroyAllConn()
