# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging

import gac_gas.common_pkg.tick_mgr as tick_mgr


class ServerConnectorBase(object):
    def __init__(self,
                 dictServerInfo,
                 szIPKey,
                 szPortKey,
                 dictConnectionArgs=None,
                 bInitConnect=True,
                 nMaxReConnectLimit=None,
                 nReConnectInterval=5000,
                 funReConnectFailCallback=None):

        self.m_Logger = logging.getLogger(self.__class__.__name__)

        # 补充参数
        dictConnectionArgs["szConnectionName"] = "server connector for {}".format(dictServerInfo["name"])
        dictConnectionArgs["connect_callback"] = self.OnConnectCallback
        dictConnectionArgs["connect_fail_callback"] = self.OnConnectFailCallback
        dictConnectionArgs["disconnect_callback"] = self.OnDisConnectedCallback
        self.m_ConnectionClientMgr = self.CreateConnectionClientMgr(dictConnectionArgs)

        self.m_dictServerInfo = dictServerInfo
        self.m_szIP = str(self.m_dictServerInfo[szIPKey])
        self.m_nPort = self.m_dictServerInfo[szPortKey]

        self.m_TickReConnect = None
        self.m_nReConnectInterval = nReConnectInterval
        self.m_nMaxReConnectLimit = nMaxReConnectLimit
        self.m_nFailConnectCount = 0
        self.m_funReConnectFailCallback = funReConnectFailCallback

        if bInitConnect:
            self.Connect()

    # 连接管理类
    def CreateConnectionClientMgr(self, dictConnectionArgs):
        raise NotImplementedError

    # 获取连接类
    def GetConnectionClass(self):
        raise NotImplementedError

    def GetServerInfo(self):
        return self.m_dictServerInfo

    def GetServerName(self):
        return self.m_dictServerInfo["name"]

    def EnableReConnectTick(self):
        self.DisableReConnectTick()
        self.m_TickReConnect = tick_mgr.RegisterOnceTick("ServerConnector-ReConnect", self.m_nReConnectInterval, self.Connect)

    def DisableReConnectTick(self):
        if self.m_TickReConnect:
            tick_mgr.UnRegisterTick(self.m_TickReConnect)
            self.m_TickReConnect = None

    def OnConnectCallback(self, ConnObj):
        self.m_Logger.info("OnConnectCallback: {}".format(self.GetServerName()))
        self.m_nFailConnectCount = 0
        self.DisableReConnectTick()

    def OnConnectFailCallback(self, ConnObj):
        self.m_Logger.info("OnConnectFailed: {}".format(self.GetServerName()))
        self.m_nFailConnectCount += 1

        if self.m_nMaxReConnectLimit is not None and self.m_nFailConnectCount >= self.m_nMaxReConnectLimit:
            self.m_Logger.error("尝试连接[{}]次数达到上限".format(self.GetServerName()))

            # 连接失败回调
            if self.m_funReConnectFailCallback:
                self.m_funReConnectFailCallback()
        else:
            self.EnableReConnectTick()

    def OnDisConnectedCallback(self, ConnObj):
        self.m_Logger.info("OnDisConnectedCallback: {}".format(self.GetServerName()))
        self.EnableReConnectTick()

    def Connect(self):
        self.DisableReConnectTick()

        ConnectionClass = self.GetConnectionClass()
        ConnObj = ConnectionClass(self.m_ConnectionClientMgr, self.m_ConnectionClientMgr.GenConnID())
        ConnObj.Connect(self.m_szIP, self.m_nPort)

    def Destroy(self):
        self.m_funReConnectFailCallback = None
        self.DisableReConnectTick()
        self.m_ConnectionClientMgr.Destroy()
