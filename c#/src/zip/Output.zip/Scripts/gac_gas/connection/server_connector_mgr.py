# -*- coding: utf-8 -*-

import copy
import logging


class ServerConnectorMgr(object):
    def __init__(self, ServerConnectorClass, szIPKey, szPortKey, dictConnectionArgs):
        super(ServerConnectorMgr, self).__init__()
        self.m_Logger = logging.getLogger(self.__class__.__name__)

        self.m_dictName2Server = {}
        self.m_dictName2ServerConn = {}

        self.m_ServerConnectorClass = ServerConnectorClass
        self.m_szIPKey = szIPKey
        self.m_szPortKey = szPortKey
        self.m_dictConnectionArgs = dictConnectionArgs

    def Init(self, dictAllConfig):
        self.ConnectAllServer(dictAllConfig)

    def ConnectAllServer(self, dictAllConfig):
        import common.config_mgr as config_mgr
        for szServerName, dictConfig in dictAllConfig.iteritems():
            if self.m_szIPKey in dictConfig and self.m_szPortKey in dictConfig:
                self.ConnectOneServer(config_mgr.GetConfig(szServerName, dictAllConfig))

    def ConnectOneServer(self, dictServerInfo):
        if dictServerInfo["name"] in self.m_dictName2ServerConn:
            if self.m_dictName2ServerConn[dictServerInfo["name"]].GetServerInfo() == dictServerInfo:
                return
            else:
                self.m_dictName2ServerConn[dictServerInfo["name"]].Destroy()

        dictConnectionArgs = copy.copy(self.m_dictConnectionArgs)
        dictConnectionArgs["connection_class_args"] = (dictServerInfo,)
        self.m_dictName2ServerConn[dictServerInfo["name"]] = self.m_ServerConnectorClass(dictServerInfo, self.m_szIPKey, self.m_szPortKey, dictConnectionArgs)

    def DisConnectOneServer(self, dictServerInfo):
        if dictServerInfo["name"] in self.m_dictName2ServerConn:
            self.m_dictName2ServerConn[dictServerInfo["name"]].Destroy()
            del self.m_dictName2ServerConn[dictServerInfo["name"]]

    def RegisterServer(self, ServerInGateObj):
        self.m_dictName2Server[ServerInGateObj.GetServerName()] = ServerInGateObj
        self.m_Logger.info("注册成功：{}".format(ServerInGateObj.GetServerName()))

    def UnRegisterServer(self, ServerInGateObj):
        szServerName = ServerInGateObj.GetServerName()
        del self.m_dictName2Server[szServerName]
        self.m_Logger.info("反注册成功：{}".format(szServerName))

    def GetServerConn(self, szServerName):
        ServerObj = self.GetServer(szServerName)
        if ServerObj:
            return ServerObj.GetConn()

    def GetServer(self, szServerName):
        return self.m_dictName2Server.get(szServerName)

    def GetAllSerer(self):
        return self.m_dictName2Server

    def Unit(self):
        for ServerConnectorObj in self.m_dictName2ServerConn.itervalues():
            ServerConnectorObj.Destroy()
        self.m_dictName2ServerConn = {}
