# -*- coding: utf-8 -*-
# @Author  : jmhuo

# 缓存上限
INDEX_LIMIT = 20000


class StringOrIndexCache(object):
    def __init__(self):
        super(StringOrIndexCache, self).__init__()
        self.m_dictString2Index = {}
        self.m_dictIndex2String = {}
        self.m_nAutoIndex = 323

        self.m_bDebug = False
        self.m_debugDictGetStringCount = {}  # GetIndex发
        self.m_debugDictGetIndexCount = {}  # GetString收

    def SetDebug(self, b):
        self.m_bDebug = b

    def DebugGetString(self):
        return sorted(self.m_debugDictGetStringCount.iteritems(), key=lambda d: d[1], reverse=True)

    def DebugGetIndex(self):
        return sorted(self.m_debugDictGetIndexCount.iteritems(), key=lambda d: d[1], reverse=True)

    def GenIndex(self):
        self.m_nAutoIndex += 1
        return self.m_nAutoIndex

    def IsFull(self):
        return len(self.m_dictString2Index) > INDEX_LIMIT

    def GetIndex(self, szString):
        if self.m_bDebug:
            self.m_debugDictGetIndexCount[szString] = self.m_debugDictGetIndexCount.get(szString, 0) + 1
        return self.m_dictString2Index.get(szString)

    # 没有就尝试创建 return index,isTryReg
    def GetIndexEx(self, szString):
        if self.IsStringRegistered(szString):
            return self.GetIndex(szString), False
        else:
            return self.RegString(szString), True

    def GetString(self, nIndex):
        return self.m_dictIndex2String.get(nIndex)

    def Dump(self):
        print self.m_dictString2Index

    def Clear(self):
        self.m_dictString2Index.clear()
        self.m_dictIndex2String.clear()

    def IsStringRegistered(self, szString):
        return szString in self.m_dictString2Index

    # 会把老的顶替
    def RegString(self, szString, nIndex=None):
        if self.IsFull():
            print("RegStringRegStringRegString", self)

        if nIndex is None:
            nIndex = self.GenIndex()

        self._UnRegIndex(nIndex)
        self._UnRegString(szString)

        return self._RegString(szString, nIndex)

    def _RegString(self, szString, nIndex):
        self.m_dictString2Index[szString] = nIndex
        self.m_dictIndex2String[nIndex] = szString
        return nIndex

    def _UnRegIndex(self, nIndex):
        szString = self.m_dictIndex2String.pop(nIndex, None)
        if szString:
            self.m_dictString2Index.pop(szString, None)

    def _UnRegString(self, szString):
        nIndex = self.m_dictString2Index.pop(szString, None)
        if nIndex:
            self.m_dictIndex2String.pop(nIndex, None)
