# -*- coding: utf-8 -*-

import client as client
import connection_client as connection_client
from gac_gas.connection.connection_base.server_connector_base import ServerConnectorBase


class ServerConnector(ServerConnectorBase):
    # 连接管理类
    def CreateConnectionClientMgr(self, dictConnectionArgs):
        return client.Client(dictConnectionArgs)

    # 获取连接类
    def GetConnectionClass(self):
        if self.m_ConnectionClientMgr.m_ConnectionClass is not None:
            return self.m_ConnectionClientMgr.m_ConnectionClass
        return connection_client.ConnectionClient
