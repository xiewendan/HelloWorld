# -*- coding: utf-8 -*-

import socket
import asyncore
from StringIO import StringIO
from gac_gas.common.msg_def import MsgHeader
from gac_gas.common.enum_def import EConnectionState
from gac_gas.connection.connection_base.connection_client_base import ConnectionClientBase


# dispatcher
class ConnectionDispatcher(asyncore.dispatcher):
    def __init__(self, ConnectionClientObj, nConnMaxInBufSize, nConnMaxOutBufSize):
        asyncore.dispatcher.__init__(self)
        # 连接对象
        self.m_ConnectionClientObj = ConnectionClientObj
        # sock名称
        self.m_tupleSockName = None
        # 写缓存
        self.m_WriteBuffer = StringIO()
        # 读缓存
        self.m_ReadBuffer = StringIO()
        # 接收缓存大小
        self.m_nReceiveBufferSize = nConnMaxInBufSize
        # 写缓存大小
        self.m_nWriteBufferSize = nConnMaxOutBufSize

    def GetSockName(self):
        return self.m_tupleSockName

    def SetSock(self, sock):
        self.set_socket(sock)
        self.m_tupleSockName = self.socket.getsockname()

    # 连接
    def Connect(self, szIP, nPort):
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.set_reuse_addr()
        self.connect((szIP, nPort))

    # 连接成功回调
    def handle_connect(self):
        self.m_tupleSockName = self.socket.getsockname()
        self.m_ConnectionClientObj.HandleConnect()

    # 连接关闭回调
    def handle_close(self):
        self.m_ConnectionClientObj.ShutDown(False)

    # 连接异常回调
    def handle_expt(self):
        self.m_ConnectionClientObj.ShutDown(False)
        asyncore.dispatcher.handle_expt(self)

    # 连接错误
    def handle_error(self):
        self.m_ConnectionClientObj.ShutDown(False)
        asyncore.dispatcher.handle_error(self)

    # 读数据
    def handle_read(self):
        if self.m_ConnectionClientObj.GetState() != EConnectionState.CONNECTED:
            return

        szData = self.recv(self.m_nReceiveBufferSize)
        if szData:
            self.m_ReadBuffer.write(szData)
            szData = self.m_ReadBuffer.getvalue()
            nPopLen = self.m_ConnectionClientObj.DispatchHead(szData)
            if nPopLen:
                self.m_ReadBuffer = StringIO(szData[nPopLen:])
                self.m_ReadBuffer.seek(0, 2)

    # 写数据
    def handle_write(self):
        if self.m_ConnectionClientObj.GetState() != EConnectionState.CONNECTED:
            return

        szData = self.m_WriteBuffer.getvalue()
        if szData:
            nSendLegth = self.send(szData)
            self.m_WriteBuffer = StringIO(szData[nSendLegth:])
            self.m_WriteBuffer.seek(0, 2)

            # 调试
            if self.m_ConnectionClientObj.m_bDebug:
                self.m_ConnectionClientObj.m_nCurSecondSend += nSendLegth

    # 是否可写
    def writable(self):
        return (self.m_WriteBuffer and self.m_WriteBuffer.getvalue()) or self.m_ConnectionClientObj.GetState() != EConnectionState.CONNECTED

    # 是否已经发送
    def HasEnoughWriteBuffer(self, nTotalLen):
        return len(self.m_WriteBuffer.getvalue()) + nTotalLen < self.m_nWriteBufferSize

    # 发送数据
    def Send(self, szHeadData, szPackData):
        self.m_WriteBuffer.write(szHeadData)
        self.m_WriteBuffer.write(szPackData)


# 网络连接
class ConnectionClient(ConnectionClientBase):
    def __init__(self, ConnectionMgr, nConnID):
        super(ConnectionClient, self).__init__(ConnectionMgr, nConnID)
        # 连接状态
        self.m_eState = EConnectionState.DISCONNECTED
        # dispatcher
        self.m_ConnectionDispatcherObj = ConnectionDispatcher(self, ConnectionMgr.m_nConnMaxInBufSize, ConnectionMgr.m_nConnMaxOutBufSize)

        # 开启心跳Tick
        self.EnableAliveTick()

    def GetState(self):
        return self.m_eState

    def TryUpdateRemoteInfo(self):
        tupleSockName = self.m_ConnectionDispatcherObj.GetSockName()
        if tupleSockName is None:
            self.UpdateRemoteInfo(*tupleSockName)
        else:
            self.UpdateRemoteInfo()

    # ---------------------------------------心跳函数------------------------------------------

    # 心跳相关
    def OnTick(self):
        if self.m_eState == EConnectionState.CONNECTED:
            self.OnConnTick()

    # ---------------------------------------网络函数------------------------------------------

    # 连接
    def Connect(self, szIP, nPort):
        self.m_Logger.info("尝试连接:{}, {}".format(szIP, nPort))
        self.m_eState = EConnectionState.CONNECTING
        self.m_ConnectionDispatcherObj.Connect(szIP, nPort)

    # 处理连接
    def HandleConnect(self):
        if self.m_eState == EConnectionState.CONNECTING or self.m_eState == EConnectionState.DISCONNECTED:
            self.m_eState = EConnectionState.CONNECTED
            self.OnConnectEvent()

    # 设置socket
    def SetSocket(self, sock):
        self.m_Logger.info("设置socket:{}".format(sock.getsockname()))
        self.m_ConnectionDispatcherObj.SetSock(sock)
        self.m_eState = EConnectionState.CONNECTED
        self.OnConnectEvent()

    # 断开连接
    def ShutDown(self, bFlush=True, bRemote=False):
        self.m_Logger.info("断开连接:{}, {}".format(self.m_eState, bFlush))

        if self.m_eState == EConnectionState.DISCONNECTED:
            return

        if self.m_eState == EConnectionState.CONNECTED:
            self.m_eState = EConnectionState.DISCONNECTED
            if self.m_ConnectionDispatcherObj.writable() and bFlush:
                self.m_ConnectionDispatcherObj.handle_write()
            self.m_ConnectionDispatcherObj.close()
            self.OnDisConnectedEvent(0, bRemote)
        elif self.m_eState == EConnectionState.CONNECTING:
            self.m_eState = EConnectionState.DISCONNECTED
            self.OnConnectFailedEvent(0)
            self.m_ConnectionDispatcherObj.close()
        elif self.m_eState == EConnectionState.DISCONNECTING:
            self.m_eState = EConnectionState.DISCONNECTED
            self.m_ConnectionDispatcherObj.close()
            self.OnDisConnectedEvent(0, bRemote)

        self.UpdateRemoteInfo()

    # ---------------------------------------协议包函数------------------------------------------

    # 处理协议包
    def DispatchHead(self, szData):
        nDataLen = len(szData)
        if nDataLen < 1:
            return 0

        nOffset = 0
        while True:
            h = MsgHeader()
            if not h.SetFromData(szData[nOffset:]):
                break

            nTotalLen = h.GetHeadSize() + h.GetMsgSize()
            if nDataLen < nTotalLen + nOffset:
                break
            else:
                nOldOffset = nOffset
                nOffset += nTotalLen
                szPackData = szData[(nOldOffset + h.GetHeadSize()):(nOldOffset + nTotalLen)]
                self.OnRecv(h.GetMsgID(), szPackData)

        return nOffset

    # 发送数据
    def _Send(self, nMsgID, data):
        szPackData = self.MsgPack(data)
        szPackData = self.Encrypt(szPackData)

        h = MsgHeader()
        h.Set(nMsgID, len(szPackData))
        nTotalLen = h.GetHeadSize() + h.GetMsgSize()
        if self.m_ConnectionDispatcherObj.HasEnoughWriteBuffer(nTotalLen):
            self.m_ConnectionDispatcherObj.Send(h.GetBinary(), szPackData)
            return True
        else:
            return False

    # 销毁
    def OnDestroy(self, bNow=False):
        self.DisableAliveTick()
        self.DisableDebug()
        super(ConnectionClient, self).OnDestroy(bNow)
