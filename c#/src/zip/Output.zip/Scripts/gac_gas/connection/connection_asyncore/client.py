# -*- coding: utf-8 -*-

import connection_client as connection_client
from gac_gas.connection.connection_base.connection_client_mgr_base import ConnectionClientMgrBase


# 连接管理器
class Client(ConnectionClientMgrBase):
    # 获取连接类
    def GetConnectionClass(self):
        if self.m_ConnectionClass is not None:
            return self.m_ConnectionClass
        return connection_client.ConnectionClient

    def Connect(self, szIP, nPort):
        ConnectionClientClass = self.GetConnectionClass()
        ConnObj = ConnectionClientClass(self, self.GenConnID())
        ConnObj.Connect(szIP, nPort)
