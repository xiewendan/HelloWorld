# -*- coding: utf-8 -*-

import connection_client as connection_client
import connection_server as connection_server
from gac_gas.connection.connection_base.connection_client_mgr_base import ConnectionClientMgrBase


# 服务器连接管理器
class Server(ConnectionClientMgrBase):
    def __init__(self, dictConnectionArgs):
        super(Server, self).__init__(dictConnectionArgs)
        self.m_ConnServerObj = None

    # 侦听
    def Listen(self, szIP, nPort):
        assert self.m_ConnServerObj is None, "服务器连接已经存在"
        self.m_ConnServerObj = connection_server.ConnectionServer(self, self.GenConnID())
        self.m_ConnServerObj.Listen(szIP, nPort)

    # 连接邀请
    def OnAcceptEvent(self, sock, address):
        ConnectionClientClass = self.GetConnectionClass()
        ConnObj = ConnectionClientClass(self, self.GenConnID())
        ConnObj.SetSocket(sock)

    # 获取连接类
    def GetConnectionClass(self):
        if self.m_ConnectionClass is not None:
            return self.m_ConnectionClass
        return connection_client.ConnectionClient

    # 销毁
    def Destroy(self):
        super(Server, self).Destroy()
        if self.m_ConnServerObj:
            self.m_ConnServerObj.Destroy(True)
            self.m_ConnServerObj = None
