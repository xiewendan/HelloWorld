# -*- coding: utf-8 -*-

import socket
import asyncore
from gac_gas.connection.connection_base.connection_server_base import ConnectionServerBase


# dispatcher
class ConnectionDispatcher(asyncore.dispatcher):
    def __init__(self, ConnectionClientObj, nMaxRequestQueueSize):
        asyncore.dispatcher.__init__(self)
        # 连接对象
        self.m_ConnectionServerObj = ConnectionClientObj
        # 连接数量
        self.m_nRequestQueueSize = nMaxRequestQueueSize

    # 侦听
    def Listen(self, szIP, nPort):
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.bind((szIP, nPort))
        self.listen(self.m_nRequestQueueSize)

    # 连接请求
    def handle_accept(self):
        (sock, address) = self.accept()
        self.m_ConnectionServerObj.OnAcceptEvent(sock, address)

    # 连接关闭回调
    def handle_close(self):
        self.m_ConnectionServerObj.ShutDown()

    # 连接异常回调
    def handle_expt(self):
        self.m_ConnectionServerObj.ShutDown()
        asyncore.dispatcher.handle_expt(self)

    # 连接错误
    def handle_error(self):
        self.m_ConnectionServerObj.ShutDown()
        asyncore.dispatcher.handle_error(self)


# 网络连接
class ConnectionServer(ConnectionServerBase):
    def __init__(self, ConnectionMgr, nConnID):
        super(ConnectionServer, self).__init__(ConnectionMgr, nConnID)
        # dispatcher
        self.m_ConnectionDispatcherObj = ConnectionDispatcher(self, ConnectionMgr.m_nMaxRequestQueueSize)

    # 侦听
    def Listen(self, szIP, nPort):
        self.m_ConnectionDispatcherObj.Listen(szIP, nPort)

    # 连接请求
    def OnAcceptEvent(self, sock, address):
        self.m_ConnectionMgr.OnAcceptEvent(sock, address)

    # 断开连接
    def ShutDown(self):
        self.m_ConnectionDispatcherObj.close()
