# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

# 连接参数
def CreateConnectionArgs(szConnectionName="",
                         nMaxRequestQueueSize=10000,
                         nConnMaxInBufSize=2 * 1024 * 1024,
                         nConnMaxOutBufSize=2 * 1024 * 1024,
                         bKeepAlive=False,
                         nCheckAliveInterval=2000,
                         nCheckAliveTimeout=60000,
                         funConnectCallback=None,
                         funConnectFailCallback=None,
                         funDisConnectCallback=None,
                         funDispatchMsgCallback=None,
                         EntityClass=None,
                         tupleConnectionClassArgs=None,
                         ConnectionClass=None,
                         bNeedEncryption=False):
    return {
        "con_name": szConnectionName,
        "max_req_queue_size": nMaxRequestQueueSize,
        "conn_max_in_buf_size": nConnMaxInBufSize,
        "conn_max_out_buf_size": nConnMaxOutBufSize,
        "keep_alive": bKeepAlive,
        "check_alive_interval": nCheckAliveInterval,
        "check_alive_timeout": nCheckAliveTimeout,
        "connect_callback": funConnectCallback,
        "connect_fail_callback": funConnectFailCallback,
        "disconnect_callback": funDisConnectCallback,
        "dispatch_msg_callback": funDispatchMsgCallback,
        "entity_class": EntityClass,
        "connection_class": ConnectionClass,
        "connection_class_args": tupleConnectionClassArgs,
        "need_encryption": bNeedEncryption,
    }
