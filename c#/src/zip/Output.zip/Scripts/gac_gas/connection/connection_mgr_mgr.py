# -*- coding: utf-8 -*-

g_dictConnMgr = {}
g_nConnMgrID = 0


# 生成连接管理器ID
def GenConnMgrID():
    global g_nConnMgrID
    g_nConnMgrID += 1
    return g_nConnMgrID


# 获取连接管理器
def GetConnMgr(nConnMgrID):
    return g_dictConnMgr.get(nConnMgrID)


# 注册连接管理器
def Register(ConnMgr):
    g_dictConnMgr[ConnMgr.GetConnMgrID()] = ConnMgr
    print("注册连接管理器:{}".format(ConnMgr.GetConnMgrID()))


# 注销连接管理器
def UnRegister(ConnMgr):
    if ConnMgr.GetConnMgrID() in g_dictConnMgr:
        del g_dictConnMgr[ConnMgr.GetConnMgrID()]
        print("注销连接管理器:{}".format(ConnMgr.GetConnMgrID()))
