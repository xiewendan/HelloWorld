# -*- coding: utf-8 -*-

import config.setting.battle.skill_base_common as skill_base_common

g_tAllSkill = {}             # 全部的技能


def GetFightSkillByID(nSkillID):
    """@rtype: gac_gas.skill.class_fight_skill.ClassFightSkill"""
    global g_tAllSkill
    objClassFightSkill = g_tAllSkill.get(nSkillID)
    if objClassFightSkill is None:
        print("Error: not exist skill:", nSkillID)
    return objClassFightSkill


def GetAllFightSkill():
    global g_tAllSkill
    return g_tAllSkill


def InitLoadAllSkill():
    global g_tAllSkill

    g_tAllSkill.clear()

    from gac_gas.skill.class_fight_skill import ClassFightSkill
    items = skill_base_common.skill_base_common.items()

    for nSkillID, v in items:
        g_tAllSkill[nSkillID] = ClassFightSkill(nSkillID)


def ReloadCfg():
    import config.setting.skill.skill_base_common
    reload(config.setting.skill.skill_base_common)
    InitLoadAllSkill()


def GetSkillCfgInfoBySkillID(nSkillID):
    tInfo = skill_base_common.skill_base_common.get(nSkillID)
    if tInfo is not None:
        return tInfo
