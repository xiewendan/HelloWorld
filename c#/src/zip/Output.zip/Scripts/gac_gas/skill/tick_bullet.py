# -*- coding: utf-8 -*-
__author__ = 'ywxu'

from gac_gas.common.enum_def import EBulletTargetType, EComponentEntityType
from config.setting.battle.bullet_common import bullet_common
from gac_gas.skill.class_fight_skill_mgr import GetFightSkillByID
import framework.tick_mgr as tick_mgr
from gac_gas.common_pkg import utils
import gac_gas.component.component_helper as component_helper
import gac_gas.component.component_entity.entity_component_mgr as entity_component_mgr

# 锁定子弹
# tick后触发效果, 子弹创建时继承主人战斗属性, 击中目标后计算
class TickBullet(object):
    def __init__(self, nBulletID, nBulletCfgID, nSkillID, objOwner, cbDestroy):
        self.m_nBulletID = nBulletID
        # 运行时变量
        self.m_nOwnerID = objOwner.GetGlobalID()
        self.m_nTargetID = None
        self.m_vTargetPos = None
        self.m_cbDestroy = cbDestroy
        self.m_tick = None
        self.m_nLifeTime = 1
        
        # 组件
        self.m_ComponentHelper = component_helper.ComponentHelper(self)
        self.AddComponent = self.m_ComponentHelper.AddComponent
        self.GetComponentByName = self.m_ComponentHelper.GetComponentByName

        ComponentObj = entity_component_mgr.CreateComponent(EComponentEntityType.EntityFightAttr, None, self)
        self.m_ComponentHelper.AddComponent(ComponentObj)
        ComponentObj.SetEnable(True)
        self.m_FightAttrCmp = ComponentObj

        # 继承主人伤害公式需要的属性
        cmpFightAttr = objOwner.GetComponentByName(EComponentEntityType.EntityFightAttr)
        ComponentObj.m_nAtk = cmpFightAttr.GetAtk()
        ComponentObj.m_nSkillAtk = cmpFightAttr.GetSkillAtk()
        ComponentObj.m_nLevel = cmpFightAttr.GetLevel()
        self.m_nSkillID = nSkillID

        # 子弹配置属性
        dictBullet = bullet_common.get(nBulletCfgID)
        self.m_nAttackType = dictBullet["攻击类型"]
        self.m_nTargetType = dictBullet["目标类型"]
        self.m_nSpeed = dictBullet["子弹速度"]

        # 注册tick
        # owner里面获取目标
        DoSkillCmp = objOwner.GetComponentByName(EComponentEntityType.EntityDoSkill)

        if self.m_nTargetType is EBulletTargetType.eSingle:
            self.Fire2Target(objOwner, DoSkillCmp.GetLockObj())
        else:
            self.Fire2Ground(objOwner, DoSkillCmp.GetLockPos())

    # 子弹管理器调用
    def DestoryBullet(self):
        self.m_cbDestroy = None
        self.UnRegBulletTick()

    # 子弹内部回调
    def OnBulletDestory(self):
        # 告诉子弹管理器销毁
        self.m_cbDestroy(self.m_nBulletID)
        self.DestoryBullet()

    def UnRegBulletTick(self):
        if self.m_tick:
            tick_mgr.UnRegisterTick(self.m_tick)
            self.m_tick = None

    # region Description : 子弹基本属性 --------------------------------------------------------------------------------
    def GetTargetID(self):
        return self.m_nTargetID

    def GetLifeTime(self):
        return self.m_nLifeTime

    def GetGlobalID(self):
        return self.m_nOwnerID
    # endregion

    def Fire2Target(self, objOwner, objTarget):
        self.m_nTargetID = objTarget.GetGlobalID()
        cmpPositionOwner = objOwner.GetComponentByName(EComponentEntityType.EntityPosition)
        vPosOwner = cmpPositionOwner.GetPositionSelf()
        cmpPositionTarget = objTarget.GetComponentByName(EComponentEntityType.EntityPosition)
        vPosTarget = cmpPositionTarget.GetPositionSelf()
        nDistance = utils.Cal2PosDistance(vPosTarget, vPosOwner)
        self.m_nLifeTime = nDistance / self.m_nSpeed
        self.m_tick = tick_mgr.RegisterOnceTick("Bullet Fire2Target", self.m_nLifeTime, self.OnHitTarget)

    def Fire2Ground(self, objOwner, posTarget):
        self.m_vTargetPos = posTarget
        cmpPositionOwner = objOwner.GetComponentByName(EComponentEntityType.EntityPosition)
        vPosOwner = cmpPositionOwner.GetPositionSelf()
        nDistance = utils.Cal2PosDistance(posTarget, vPosOwner)
        self.m_nLifeTime = nDistance / self.m_nSpeed
        self.m_tick = tick_mgr.RegisterOnceTick("Bullet Fire2Target", self.m_nLifeTime, self.OnHitPos)

    def OnHitTarget(self):
        objTarget = utils.GetObjByGlobalID(self.m_nTargetID)
        if objTarget is None:
            self.OnBulletDestory()
            return

        self.m_FightAttrCmp.CalcHurt(objTarget, self.m_nSkillID)
        self.OnBulletDestory()

    def OnHitPos(self):
        # cmpFightAttr = objOwner.GetComponentByName(EComponentEntityType.EntityFightAttr)
        # cmpFightAttr.CalcHurt(objTarget)
        self.OnBulletDestory()





