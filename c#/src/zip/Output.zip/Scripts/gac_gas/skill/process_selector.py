# -*- coding: utf-8 -*-

import gac_gas.common_def.sys_const as sys_const
from gac_gas.common.enum_def import ESelectorEffectType

# 检查目标是否技能有效对象(OK)
def CheckSelectEffObjType(cmpFrom, cmpTarget, eSelectType):
    """
    @param gac_gas.component.component_entity.entity_fight_attr_component.EntityFightAttrComponent cmpFrom:
    @param gac_gas.component.component_entity.entity_fight_attr_component.EntityFightAttrComponent cmpTarget:
    """
    if cmpTarget.GetIsFightable() is False:
        return False

    # 任意可战对象，可能跨场景
    if eSelectType == ESelectorEffectType.eAnyObj:
        return True

    if eSelectType == ESelectorEffectType.eCanFightObj:
        return cmpFrom.CanHurt(cmpTarget.GetOwner())
    elif eSelectType == ESelectorEffectType.eCanHelpObj:
        return cmpFrom.CanHelp(cmpTarget.GetOwner())
    return False

# pipe对象选择器
# 描述: 专业处理技能对象的选择
class PipeSelector(object):
    def __init__(self, tPipeInfo, IsFar):
        self.m_nMaxAtkDist = sys_const.GRID_SIZE
        self.m_nMinAtkDist = 0
        self.m_bIsFar = IsFar
        self.m_tShowTipsModel = None
        # 子弹配置表id
        self.m_nBulletCfgID = None

    def SetBulletCfgID(self, nBulletCfgID):
        self.m_nBulletCfgID = nBulletCfgID

    def GetBulletCfgID(self):
        return self.m_nBulletCfgID

    # 客户端默认当自身圆形处理
    def GetRangeType(self):
        return PipeAtkAreaType.eSelfCircle

    def GetMaxAtkDist(self):
        return self.m_nMaxAtkDist

    def GetMinAtkDist(self):
        return self.m_nMinAtkDist

    def GetRadius(self):
        return self.m_nMaxAtkDist

    def IsFar(self):
        return self.m_bIsFar

    def DoSelect(self, nFromGlobalID, FromObj, nSelectEffObjType, TargetPos=None):
        pass


class SectorPipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(SectorPipeSelector, self).__init__(tPipeInfo, IsFar)
        self.m_Angle = int(tPipeInfo.get("攻击范围参数1", "120度").replace("度", ""))  # 扇形角度
        self.m_nMaxAtkDist = float(tPipeInfo.get("攻击范围参数2", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 攻击距离
        self.m_Rot = int(tPipeInfo.get("攻击范围参数3", "0度").replace("度", ""))  # 偏转
        self.m_ShowAngle = self.m_Angle
        # mapper大于90度时范围变大了.
        self.m_Angle = self.m_Angle / 2 if self.m_Angle > 80 else self.m_Angle

    def GetRangeType(self):
        return PipeAtkAreaType.eSelfFrontSector

    def GetSectorAngle(self):
        # 扇形角度
        return self.m_ShowAngle

    def GetSectorRot(self):
        # 扇形偏转
        return self.m_Rot

    def DoSelect(self, nFromGlobalID, FromObj, nSelectEffObjType, TargetPos=None):
        nSkillID = FromObj.GetGasSkillSate().GetCurSkillID()
        import gac_gas.skill.skill_mgr_pkg.skill_cfg as skill_cfg
        resultMaxAtkDist = self.m_nMaxAtkDist
        if nSkillID and FromObj.HasWeaponAttrsByTypeID(skill_cfg.GetSkillTypeID(nSkillID)):
            resultMaxAtkDist *= (FromObj.GetWeaponAttrsByName("攻击范围增大", 0) + 1)
        listSelected = gas_aoi_mgr.GetAttackSectorObjByGlobalID(nFromGlobalID, FromObj.GetObjDir() + self.m_Rot)
        return listSelected


class SelfCirclePipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(SelfCirclePipeSelector, self).__init__(tPipeInfo, IsFar)
        if tPipeInfo:
            self.m_nMaxAtkDist = float(tPipeInfo.get("攻击范围参数1", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 半径
            self.m_nMinAtkDist = float(tPipeInfo.get("攻击范围参数2", "0步").replace("步", "")) * sys_const.GRID_SIZE

        self.m_nRadius = sys_const.GRID_SIZE

    def GetRadius(self):
        return self.m_nRadius

    def SetRadius(self, nRadius):
        self.m_nRadius = nRadius

    def GetRangeType(self):
        return PipeAtkAreaType.eSelfCircle

    def DoSelect(self, nFromGlobalID, FromObj, nSelectEffObjType, TargetPos=None):
        # print ("qqqqqqqqqqqqqqqqqqqqqqqqqqqqq")
        # nSkillID = FromObj.GetGasSkillSate().GetCurSkillID()
        # if nSkillID:
        #     import gac_gas.skill.skill_mgr_pkg.skill_cfg as skill_cfg
        #     attrs = FromObj.GetItemAttrs(skill_cfg.GetSkillTypeID(nSkillID))
        #     if attrs:
        #         print ("111111111111111111111111111111")
        #         self.m_nRadius = self.m_nRadius * (1 + attrs.get("爆炸范围增大"))

        listSelected = gas_aoi_mgr.GetAttackAoiObjByGlobalID(nFromGlobalID, self.m_nMaxAtkDist)
        return listSelected


class FrontRectPipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(FrontRectPipeSelector, self).__init__(tPipeInfo, IsFar)
        self.m_nWidth = float(tPipeInfo.get("攻击范围参数1", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 宽
        self.m_nMaxAtkDist = float(tPipeInfo.get("攻击范围参数2", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 长

    def GetRangeType(self):
        return PipeAtkAreaType.eSelfFrontRect

    def DoSelect(self, nFromGlobalID, FromObj, nSelectEffObjType, TargetPos=None):
        listSelected = gas_aoi_mgr.GetAttackFrontRectObjByGlobalID(nFromGlobalID, FromObj.GetObjDir(),
                                                                   self.m_nMaxAtkDist, self.m_nWidth)
        return listSelected


class LockObjPipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(LockObjPipeSelector, self).__init__(tPipeInfo, IsFar)
        self.m_nMaxAtkDist = float(
            tPipeInfo.get("攻击范围参数1", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 最大攻击距离(同时为技能攻击距离)

    def GetRangeType(self):
        return PipeAtkAreaType.eLockObj


class SelfPipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(SelfPipeSelector, self).__init__(tPipeInfo, IsFar)
        self.m_nMaxAtkDist = float(
            tPipeInfo.get("攻击范围参数1", "1步").replace("步", "")) * sys_const.GRID_SIZE  # 最大攻击距离(同时为技能攻击距离)

    def GetRangeType(self):
        return PipeAtkAreaType.eJustSelf


class AreaCirclePipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(AreaCirclePipeSelector, self).__init__(tPipeInfo, IsFar)
        if tPipeInfo:
            self.m_nRadius = float(tPipeInfo.get("攻击范围参数1", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 圆大小
            self.m_nMaxAtkDist = float(
                tPipeInfo.get("攻击范围参数2", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 最大对地距离(同时为技能攻击距离)
        else:
            self.m_nRadius = sys_const.GRID_SIZE

    def GetRadius(self):
        return self.m_nRadius

    def SetRadius(self, nRadius):
        self.m_nRadius = nRadius

    def GetRangeType(self):
        return PipeAtkAreaType.eAreaCircle

    def DoSelect(self, nFromGlobalID, FromObj, nSelectEffObjType, TargetPos=None):
        listSelected = gas_aoi_mgr.GetAoiObjByPosAndGlobalID(TargetPos, nFromGlobalID, self.m_nMaxAtkDist,
                                                             bIncludeFrom=True)
        return listSelected


class SelfRectPipeSelector(PipeSelector):
    def __init__(self, tPipeInfo, IsFar):
        super(SelfRectPipeSelector, self).__init__(tPipeInfo, IsFar)
        self.m_nWidth = float(tPipeInfo.get("攻击范围参数1", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 宽
        self.m_nMaxAtkDist = float(tPipeInfo.get("攻击范围参数2", "3步").replace("步", "")) * sys_const.GRID_SIZE  # 长

    def GetRangeType(self):
        return PipeAtkAreaType.eSelfRect

    def DoSelect(self, nFromGlobalID, FromObj, nSelectEffObjType, TargetPos=None):
        listSelected = gas_aoi_mgr.GetAttackRectObjByGlobalID(nFromGlobalID, FromObj.GetObjDir(), self.m_nWidth,
                                                              self.m_nMaxAtkDist)
        return listSelected

class PipeAtkAreaType(object):
    eSelfFrontSector = 0  # 扇形
    eSelfCircle = 1  # 自身圆形
    eSelfFrontRect = 2  # 身前矩形
    eLockObj = 3  # 单体
    eJustSelf = 4  # 自己
    eAreaCircle = 5  # 对地圆形
    eSelfRect = 8  # 自身矩形
    eNone = 99

    Name2Class = {
        "无": PipeSelector,
        "扇形": SectorPipeSelector,
        "自身圆形": SelfCirclePipeSelector,
        "身前矩形": FrontRectPipeSelector,
        "自身矩形": SelfRectPipeSelector,
        "单体": LockObjPipeSelector,
        "自己": SelfPipeSelector,
        "对地圆形": AreaCirclePipeSelector,
    }

    @staticmethod
    def name2cls(name):
        """ @rtype: PipeSelector|SectorPipeSelector|SelfCirclePipeSelector|FrontRectPipeSelector|SelfRectPipeSelector|LockObjPipeSelector|SelfPipeSelector|AreaCirclePipeSelector"""
        return PipeAtkAreaType.Name2Class[name]

class ClassSkillPipe(object):
    CLASS_SAVE_ATTR_TO_CELL_NAME = {
        "m_nShakeLevel": ("震屏级别", int, 0, False),
        "m_szHurtFx": ("受击特效", str, "", False),
        "m_nHurtFxID": ("受击特效ID", int, 0, False),
    }

    def __init__(self, nPipeID):
        self.m_nPipeID = nPipeID
        self.m_nPipeName = ""
        self.m_nPipeAtkAreaType = 0
        self.m_nPipeMaxObjCount = 0
        self.m_nPipeEffectObjType = 0

        self.InitSkillPipe()

    def GetPipeID(self):
        return self.m_nPipeID

    def InitSkillPipe(self):
        self.m_nPipeName = tPipeInfo.get("效果名称", "默认名称")
        self.m_nPipeMaxObjCount = int(tPipeInfo.get("作用目标个数", "30"))
        if szEffectKeyName == "增加buff":
            pass
        elif szEffectKeyName == "物攻百分比治疗":
            pass
        if szEffectKeyName == "物攻百分比伤害":
            pass
        szAtkAreaType = tPipeInfo.get("攻击范围类型", "无")
        clsPipeSelector = PipeAtkAreaType.name2cls(szAtkAreaType)
        self.m_PipeSelector = clsPipeSelector(tPipeInfo, not self.m_bIsFromNearAtk)
        self.m_nPipeAtkAreaType = self.m_PipeSelector.GetRangeType()

