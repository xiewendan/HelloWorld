# -*- coding: utf-8 -*-

import gac_gas.skill.class_fight_skill_mgr as class_fight_skill_mgr
from gac_gas.common.enum_def import EPokemonType, ESkillDisType
from gac_gas.playmaker.fsm_template import FsmTemplateMgr

class ClassFightSkill(object):
    def __init__(self, nSkillID):
        self.m_nSkillID = nSkillID
        self.m_fsmTemplate = None
        self.InitFightSkill()

    def InitFightSkill(self):
        tInfo = class_fight_skill_mgr.GetSkillCfgInfoBySkillID(self.m_nSkillID)

        self.m_szSkillName = tInfo.get("技能名称", "")
        self.m_nHouYaoTime = tInfo.get("后摇打断点", 0)
        self.m_nCanMoveTime = tInfo.get("移动打断点", 0)
        self.m_bStartSkillCD = tInfo.get("触发技能CD", 0) == 1
        self.m_nSkillCD = tInfo.get("技能CD", 0)
        self.m_nCostEN = tInfo.get("能量消耗", 0)
        self.m_nDisType = tInfo.get('距离类型', ESkillDisType.eNotDefine)
        self.m_nSkillTypeID = tInfo.get("技能类型ID", 0)
        self.m_nSkillCDType = tInfo.get("技能CD类型", 0)
        self.m_nPokemonType = tInfo.get("招式属性", EPokemonType.eNormal)
        self.m_nPower = tInfo.get("招式威力", 0)
        self.m_szTemplateName = tInfo.get("技能模板")
        self.LoadFsmTemplate()

    def GetSkillID(self):
        return self.m_nSkillID

    # 注意这个是资源, 外层暂时需要copy
    def GetFsmTemplate(self):
        return self.m_fsmTemplate

    def LoadFsmTemplate(self):
        # 尝试找模板
        self.m_fsmTemplate = FsmTemplateMgr().GetFsmTemplate(self.m_szTemplateName)

        # 不存在则加载
        if self.m_fsmTemplate is None:
            module = __import__("config.setting.battle.skill_template." + self.m_szTemplateName, fromlist=True)
            assert module, "找不到模板:%s" % self.m_szTemplateName
            dictTemplate = getattr(module, self.m_szTemplateName)
            self.m_fsmTemplate = FsmTemplateMgr().AddFsmTemplateFromDict(dictTemplate[0])
            assert self.m_fsmTemplate, "加载模板失败:%s" % self.m_szTemplateName

    # region Description : 对外基本属性 --------------------------------------------------------------------------------
    def GetPower(self):
        return self.m_nPower

    def GetPokemonType(self):
        return self.m_nPokemonType

    def GetSkillName(self):
        return self.m_szSkillName

    def IsFarSkill(self):
        return self.m_nDisType == ESkillDisType.eFar

    def IsCloseSkill(self):
        return self.m_nDisType == ESkillDisType.eClose

    pass
    # endregion

