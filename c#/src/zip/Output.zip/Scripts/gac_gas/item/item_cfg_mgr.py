# -*- coding: utf-8 -*-

# __author__ = gzxiejinchun@corp.netease.com
# __date__ = 2017/5/31 16:11

# desc: 物品配置表管理器，索引所有物品配置表的信息

import sys

import config.setting.item.item_table_common as item_table_common
import gac_gas.common.enum_def as enum_def
from gac_gas.common.const_def import sys_const
# noinspection PyUnresolvedReferences
import gac_gas.common.const_def as const_def
import json


class ItemCfgMgr(object):
    """物品配置表管理器"""

    def __init__(self):
        self.m_dictBigID2ItemTblCfg = {}            # 大类ID到对应的物品配置表
        self.m_dictBigID2ItemType = {}              # 大类ID/类型ID对应的物品小类ID列表

        self.m_dictCfgInfo2IntObjID = {}            # 物品配置信息对应交互对象ID
        self.m_dictIntObjID2ItemInfo = {}           # 交互对象ID对应物品配置信息

        self.m_dictSkillID2ItemID = {}              # 缓存技能ID对应的物品ID

        self.m_dictTalentSkillID2ItemID = {}        # 缓存天赋技能ID对应的物品ID

        self.m_dictType2BigSmallID = {}             # 缓存typeID到默认物品ID

        self.CacheItemCfgInfo()

    def CacheItemCfgInfo(self):
        self.m_dictBigID2ItemTblCfg = {}

        self.m_dictCfgInfo2IntObjID = {}
        self.m_dictIntObjID2ItemInfo = {}
        self.m_dictBigID2ItemGroupByType = {}
        self.m_dictSortedDefaultCfgItem = {}

        for nBigID, dictItemTable in item_table_common.item_table_common.iteritems():
            szItemTblName = dictItemTable['TableName']
            print szItemTblName
            szItemTblPath = sys_const.ITEM_CONFIG_PATH.format(szItemTblName)

            __import__(szItemTblPath)

            mModule = sys.modules[szItemTblPath]
            dictItemTblCfg = getattr(mModule, szItemTblName)
            assert dictItemTblCfg

            self.m_dictBigID2ItemTblCfg[nBigID] = dictItemTblCfg
            self.m_dictBigID2ItemType[nBigID] = {}
            self.m_dictBigID2ItemGroupByType[nBigID] = {}

            for nIndex, dictCfgInfo in dictItemTblCfg.iteritems():
                nIntObjID = dictCfgInfo.get("IntObjID")
                if nIntObjID:
                    assert nIntObjID not in self.m_dictIntObjID2ItemInfo, "掉落物品和交互对象非唯一对应:{0} 1、[{1[0]},{1[1]}] 2、[{2},{3}]".format(nIntObjID,
                                                                                                                                    self.m_dictIntObjID2ItemInfo[
                                                                                                                                        nIntObjID], nBigID,
                                                                                                                                    nIndex)
                    self.m_dictIntObjID2ItemInfo[nIntObjID] = (nBigID, nIndex)
                    self.m_dictCfgInfo2IntObjID["{}_{}".format(nBigID, nIndex)] = nIntObjID

                    nTypeID = dictCfgInfo.get("类型", nIndex)
                    if nTypeID not in self.m_dictBigID2ItemType[nBigID]:
                        self.m_dictBigID2ItemType[nBigID][nTypeID] = []
                    if dictCfgInfo.get('武装库排序') is not None:
                        self.m_dictBigID2ItemGroupByType[nBigID][nIndex] = dictCfgInfo
                        self.m_dictType2BigSmallID[nTypeID] = (nBigID, nIndex)
                    self.m_dictBigID2ItemType[nBigID][nTypeID].append(nIndex)

                    # 缓存技能ID
                    nSkillID = dictCfgInfo.get("SkillID")
                    if nSkillID:
                        self.m_dictSkillID2ItemID[nSkillID] = (nBigID, nIndex)

                    # 缓存天赋技能ID
                    if nBigID == enum_def.EItemBigID.eTalentSkill:
                        nTalentSkillID = dictCfgInfo.get("天赋技能ID")
                        if nTalentSkillID:
                            self.m_dictTalentSkillID2ItemID[nTalentSkillID] = (nBigID, nIndex)

            self.m_dictSortedDefaultCfgItem[nBigID] = sorted(self.m_dictBigID2ItemGroupByType[nBigID].iteritems(), key=lambda x:x[1].get('武装库排序'))

    def GetBigID2ItemTblCfg(self):
        """返回物品配置表"""
        return self.m_dictBigID2ItemTblCfg

    def CheckItemCfg(self, nBigID, nIndex):
        """检查是否存在对应物品的大类ID和小类"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg is not None

    def GetBigCfgTable(self, nBigID):
        return self.m_dictBigID2ItemTblCfg.get(nBigID)

    def GetItemCfg(self, nBigID, nIndex):
        """返回物品的配置表信息"""
        dictItemTblCfg = self.m_dictBigID2ItemTblCfg.get(nBigID)
        if dictItemTblCfg is None:
            return None

        return dictItemTblCfg.get(nIndex)

    def GetItemPosY(self, nBigID, nIndex):
        """返回武装库展示位置"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('postion_y')

    def GetItemForward(self, nBigID, nIndex):
        """返回武装库展示朝向"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('forward')

    def GetItemUp(self, nBigID, nIndex):
        """返回武装库展示模型上方向"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('up')

    def GetItemLevel(self, nBigID, nIndex):
        """返回物品的等级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('等级', 1)

    def GetItemRarity(self, nBigID, nIndex):
        """稀有度"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('稀有度', 1)

    def GetItemTypeID(self, nBigID, nIndex):
        """返回物品的类型ID"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('类型', nIndex)

    def GetItemName(self, nBigID, nIndex):
        """返回物品的名字"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        nNameID = dictItemCfg.get('Name', "")
        import gac_gas.common_pkg.utils as utils
        if utils.IS_CLIENT_PLATFORM:
            return nNameID
        else:
            return nNameID

    def GetItemDesc(self, nBigID, nIndex):
        """返回物品的描述"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        szVarList = self.GetItemVariable(nBigID, nIndex)

        return T_(dictItemCfg.get('描述', ""), *szVarList)

    def ServerGetItemDesc(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('描述', "")

    def GetItemVariable(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        szVar = str(dictItemCfg.get("Variable", ""))
        szVarList = []
        for szVal in szVar.split(","):
            if not szVal:
                continue

            szVarList.append(json.loads(szVal))
        return szVarList

    def GetFoldLimit(self, nBigID, nIndex):
        """返回物品的叠加上限"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('FoldLimit', 1)

    def GetItemBagSpace(self, nBigID):
        """返回物品背包的空间"""
        return item_table_common.item_table_common[nBigID]['BagSpaceType']

    def GetItemPickItemUI(self, nBigID):
        """返回物品拾取的UI"""
        return item_table_common.item_table_common[nBigID]['PickItemUI']

    def GetAttackRage(self, nBigID, nIndex):
        """攻击评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('攻击评级', "")

    def GetDefenceRage(self, nBigID, nIndex):
        """防御评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('防御评级', "")

    def GetSpecialRage(self, nBigID, nIndex):
        """特殊评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('特殊评级', "")

    def GetAttSpeedRage(self, nBigID, nIndex):
        """速度评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('速度评级', "")

    def GetAssistRage(self, nBigID, nIndex):
        """辅助评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('辅助评级', "")

    def GetControlRage(self, nBigID, nIndex):
        """控制评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('控制评级', "")

    def GetUsabilityRage(self, nBigID, nIndex):
        """易用评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('易用评级', "")

    def GetDistanceRage(self, nBigID, nIndex):
        """距离评级"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('距离评级', "")

    def GetItemIntObjID(self, nBigID, nIndex):
        return self.m_dictCfgInfo2IntObjID.get("{}_{}".format(nBigID, nIndex))

    def GetIntObjItemCfgInfo(self, nIntObjID):
        return self.m_dictIntObjID2ItemInfo.get(nIntObjID)

    def GetItemIcon(self, nBigID, nIndex):
        """获取物品图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('Icon', "")

    def GetSkillIcon(self, nBigID, nIndex):
        """获取物品特技图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('SkillIcon', "")

    def GetItemHeadIcon(self, nBigID, nIndex):
        """获取物品右上角图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('Icon_head', "")

    def GetItemButtonIcon(self, nBigID, nIndex):
        """获取物品Button图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('Button', "")

    def GetItemTileIcon(self, nBigID, nIndex):
        """获取物品Title图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('Title', "")

    def GetItemTypeName(self, nBigID):
        """获取物品类型名"""
        return T_(item_table_common.item_table_common[nBigID]['物品类型名'])

    def GetItemIconOn(self, nBigID, nIndex):
        """获取物品图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('IconOn', "")

    def GetItemWeaponButtonIcon(self, nBigID, nIndex):
        """获取物品武器按钮图标"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('WeaponButtonIcon', "")

    def GetSkillID(self, nBigID, nIndex):
        """获取物品对应的技能"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('SkillID', 0)

    def GetSpSkillID(self, nBigID, nIndex):
        """获取物品对应的特技技能"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('特技ID', 0)

    def GetBufferID(self, nBigID, nIndex):
        # 获取物品持有时的bufferID
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('BuffID', 0)

    def GetWeaponType(self, nBigID, nIndex):
        """获取物品的武器类型"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        if dictItemCfg is None:
            print("error item id:", nBigID, nIndex)
        return dictItemCfg.get('WeaponType', 0)

    def GetExSpaceCount(self, nBigID, nIndex):
        """获取物品的增加的拓展空间"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('ExSpaceCount', 0)

    def GetGridCount(self, nBigID, nIndex):
        """获取物品可以占用的格子数量"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('GridCount', 1)

    def IsAutoUseItem(self, nBigID, nIndex):
        """判断是否是自动使用的物品"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)

        return dictItemCfg.get('CBBigID', 0) == enum_def.ECBBigID.eAutoUseItem

    def IsNeedTipInUse(self, nBigID, nIndex):
        """判断使用时是否需要提示框"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)

        return dictItemCfg.get("UseTip", 0)

    def GetCBID(self, nBigID, nIndex):
        """返回物品的回调"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)

        return dictItemCfg.get('CBBigID', 0), dictItemCfg.get('CBIndex', 0)

    def GetCBArg(self, nBigID, nIndex):
        """返回物品的回调"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)

        return dictItemCfg.get('CBArg', 0)

    def GetGridPos(self, nBigID, nIndex):
        """获取物品可以占用的格子位置"""
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('GridPos', 0)

    def GetCanSell(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("CanSell", 0)

    def GetCanUse(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("CanUse", 1)

    def GetOverdueType(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("OverdueType", 0)

    def GetOverdueTime(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("过期时间", 0)

    def GetOverlayType(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("叠加类型", 0)


    def GetNeedLevel(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("NeedLevel", 0)

    # ********************************************************************************
    # 不同物品类型
    # ********************************************************************************

    def GetResID(self, nBigID, nIndex, szSkinID):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        nResID = dictItemCfg.get("Res" + szSkinID)
        return nResID

    def GetDressResID(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("Res")

    def GetDressName(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("Name")

    def GetDressIcon(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get("Icon")

    def GetWuZhuangKuNormalAniGroup(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        aniGroupID = dictItemCfg.get("wzkNormalSkill")
        return aniGroupID

    def GetWuZhuangKuSpecialAniGroup(self, nBigID, nIndex, nId):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        aniGroupID = dictItemCfg.get("wzkSpecialSkill" + nId)
        return aniGroupID

    def GetEquipEffect(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('效果', None)

    def GetEffectByLevel(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('等级效果'), dictItemCfg.get("等级效果参数")

    def GetPetCfgID(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('宠物')

    def GetMaterial(self, nBigID, nIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('材质', None)

    # ********************************************************************************
    # 获取物品种类接口
    # ********************************************************************************
    def GetAllTypeIDByBigID(self, nBigID):
        """根据大类ID返回全部的物品类型ID"""
        return self.m_dictBigID2ItemType[nBigID].keys()

    def GetAllIndexByBigID(self, nBigID):
        """根据大类ID返回全部的物品小类ID"""
        return self.m_dictBigID2ItemTblCfg[nBigID].keys()

    def GetDefaultIndexByTypeID(self, nBigID, nTypeID):
        """根据类型ID, 返回默认的小类ID"""
        return self.m_dictBigID2ItemType[nBigID][nTypeID][0]

    def GetDefaultBigAndIndexByTypeID(self, nTypeID):
        return self.m_dictType2BigSmallID[nTypeID]

    def GetAllIndexByIndex(self, nBigID, nIndex):
        """根据物品小类ID, 返回这一类型的所有等级IndexID"""
        nTypeID = self.GetItemTypeID(nBigID, nIndex)
        return self.m_dictBigID2ItemType[nBigID][nTypeID]

    def GetAllIndexByTypeID(self, nBigID, nTypeID):
        """根据类型ID, 返回这一类型的所有等级IndexID"""
        return self.m_dictBigID2ItemType[nBigID][nTypeID]

    def GetSortedDefaultCfgItem(self, nBigID):
        return self.m_dictSortedDefaultCfgItem[nBigID]

    def GetAllDefaultCfgByBigID(self, nBigID):
        """
        根据大类ID, 返回某一大类的全部默认属性字典
        @return: {nDefaultIndex: dictInfo}
        """
        return self.m_dictBigID2ItemGroupByType[nBigID]

    # ********************************************************************************
    # 物品个数
    # ********************************************************************************
    def GetBagHoldItemCount(self, nBigID, nIndex):
        """背包能够hold的物品个数"""
        return self.GetFoldLimit(nBigID, nIndex) * self.GetGridCount(nBigID, nIndex)

    def GetSkinName(self, nBigID, nIndex, nSkinIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('Name%d' % nSkinIndex)

    def GetSkinEffectImg(self, nBigID, nIndex, nSkinIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('皮肤%d效果' % nSkinIndex)

    def GetSkinDesc(self, nBigID, nIndex, nSkinIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nIndex)
        return dictItemCfg.get('Desc%d' % nSkinIndex)

    def GetSkinIconID(self, nBigID, nSmallID, nSkinIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nSmallID)
        return dictItemCfg.get('Icon%d' % nSkinIndex)

    def GetSkinResID(self, nBigID, nSmallID, nSkinIndex):
        return self.GetResID(nBigID, nSmallID, str(nSkinIndex))


    def GetItemSkinCost(self, nBigID, nSmallID, nSkinIndex):
        dictItemCfg = self.GetItemCfg(nBigID, nSmallID)
        nCoinCost = dictItemCfg.get('皮肤%d星币' % nSkinIndex)
        if nCoinCost is not None:
            return True, nCoinCost
        nMoneyCost = dictItemCfg.get('皮肤%d晶石' % nSkinIndex)
        if nMoneyCost is not None:
            return False, nMoneyCost
        return None

    def GetItemSkinCantBuy(self, nBigID, nSmallID, nSkinIndex):
        if self.IsItemDress(nBigID):
            return False
        dictItemCfg = self.GetItemCfg(nBigID, nSmallID)
        return bool(dictItemCfg.get('皮肤%d不出售' % nSkinIndex))


g_ItemCfgMgr = ItemCfgMgr()
CheckItemCfg = g_ItemCfgMgr.CheckItemCfg
GetFoldLimit = g_ItemCfgMgr.GetFoldLimit
GetGridCount = g_ItemCfgMgr.GetGridCount
GetItemBagSpace = g_ItemCfgMgr.GetItemBagSpace
IsAutoUseItem = g_ItemCfgMgr.IsAutoUseItem
GetCBID = g_ItemCfgMgr.GetCBID
print g_ItemCfgMgr.m_dictBigID2ItemTblCfg
print "==========================="
