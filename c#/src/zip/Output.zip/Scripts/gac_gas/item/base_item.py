# -*- coding: utf-8 -*-

# desc: 物品的基类

import gac_gas.item.item_cfg_mgr as item_cfg_mgr
import gac_gas.common.enum_def as enum_def
import gac_gas.common_pkg.utils as utils
import math

RECENT_TIME = 24 * 60 * 60


class BaseItem(object):
    """所有物品的基类"""

    def __init__(self, szItemID, nBigID, nIndex, nCount=1, dynamicData=None):
        if nBigID == 101 and nIndex == 591211:
            nIndex = 591801
        assert isinstance(szItemID, str), "szItemID类型错误"
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex), "物品不存在:nBigID=%s, nIndex=%s" % (nBigID, nIndex)
        assert nCount > 0, "物品个数需要大于0:nCount=%s" % nCount

        self.m_szItemID = szItemID          # 物品的唯一ID
        self.m_nBigID = nBigID              # 物品的大类ID
        self.m_nIndex = nIndex              # 物品的小类ID
        self.m_nCount = nCount              # 物品的数量
        self.m_nAddTime = 0                 # 物品获取的时间

        if dynamicData is None:
            dynamicData = {}

        self.InitDynamicData(dynamicData)

    def New(self):
        pass

    def GetItemID(self):
        """返回物品的唯一ID"""
        return self.m_szItemID

    def GetBigID(self):
        """物品的大类ID"""
        return self.m_nBigID

    def GetIndex(self):
        """返回物品的小类ID"""
        return self.m_nIndex

    def SetCount(self, nCount):
        """设置物品的数量"""
        assert nCount >= 0
        self.m_nCount = nCount

    def AddCount(self, nCount):
        """加物品的数量"""
        nNewCount = self.m_nCount + nCount
        assert nNewCount >= 0

        self.m_nCount = nNewCount

        return self.m_nCount

    def GetCount(self):
        """返回物品数量"""
        return self.m_nCount

    def GetName(self):
        """返回物品的名字"""
        return item_cfg_mgr.GetItemName(self.m_nBigID, self.m_nIndex)

    def GetDesc(self):
        """返回物品的描述"""
        return item_cfg_mgr.GetItemDesc(self.m_nBigID, self.m_nIndex)

    def GetLevel(self):
        """返回物品的等级"""
        return item_cfg_mgr.GetItemLevel(self.m_nBigID, self.m_nIndex)

    def GetTypeID(self):
        """返回物品类型ID"""
        return item_cfg_mgr.GetItemTypeID(self.m_nBigID, self.m_nIndex)

    def GetTypeName(self):
        """返回物品的类型名"""
        return item_cfg_mgr.GetItemTypeName(self.m_nBigID)

    def GetFoldLimit(self):
        """返回物品的叠加上限"""
        return item_cfg_mgr.GetFoldLimit(self.m_nBigID, self.m_nIndex)

    def GetItemCfg(self):
        """返回物品的配置表信息"""
        return item_cfg_mgr.GetItemCfg(self.m_nBigID, self.m_nIndex)

    def GetItemSyncData(self):
        """获取同步的数据"""
        return [[self.m_nBigID, self.m_nIndex, self.m_nCount, self.m_szItemID, self.m_nAddTime], self.GetDynamicData()]


    # ********************************************************************************
    # 动态数据
    # ********************************************************************************
    def InitDynamicData(self, dynamicData):
        self.m_DynamicData = dynamicData

    def GetDynamicData(self):
        """
        @return:[nDynamicAttr1, nDynamicAttr2]
        """
        return self.m_DynamicData

    # ********************************************************************************
    # 物品获得/最近增加时间
    # ********************************************************************************
    def UpdateAddTime(self, nAddTime=None):
        """更新获得物品的时间，新获取和增加时更新"""
        if not nAddTime:
            self.m_nAddTime = int(utils.GetCurTime())
        else:
            self.m_nAddTime = nAddTime

    def GetAddTime(self):
        """获取物品新加的时间"""
        return self.m_nAddTime

    def IsRecentItem(self):
        """判断物品是否是最近24小时内获得"""
        nCurTime = int(utils.GetCurTime())
        nTime = nCurTime - self.m_nAddTime
        assert nTime > 0, "记录物品的时间不正常：当前时间{0}, 物品时间：{1}".format(nCurTime, self.m_nAddTime)
        return nTime <= RECENT_TIME

    # ********************************************************************************
    # 物品格式检查
    # ********************************************************************************
    @staticmethod
    def CheckDynamicData(dynamicData):
        """
        检查物品动态属性
        @param dynamicData:[nDynamicAttr1, nDynamicAttr2]
        @return:
        """
        return True, "OK"

    @staticmethod
    def CheckStaticData(staticData):
        """
        检查物品静态属数据
        @param staticData: [nBigID,nIndex,nCount,szItemID,nAddTime]
        @return:
        """
        return True, "OK"
