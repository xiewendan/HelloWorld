# -*- coding: utf-8 -*-

# __author__ = gzxiejinchun@corp.netease.com
# __date__ = 2017/10/10 15:36

# desc: 通用物品


from gac_gas.item.base_item import BaseItem
import gac_gas.item.item_cfg_mgr as item_cfg_mgr


class BaseComItem(BaseItem):
    """通用物品"""

    def __init__(self, szItemID, nBigID, nIndex, nCount=1, dynamicData=None):
        super(BaseComItem, self).__init__(szItemID, nBigID, nIndex, nCount, dynamicData)
