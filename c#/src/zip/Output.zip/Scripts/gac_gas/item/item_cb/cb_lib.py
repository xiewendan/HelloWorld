# -*- coding: utf-8 -*-

# __author__ = gzxiejinchun@corp.netease.com
# __date__ = 2017/6/13 14:20

# desc: 回调库，所有的回调的入口

import gac_gas.item.item_cb.auto_use_item_cb as auto_use_item_cb
import gac_gas.common.enum_def as enum_def

dictCBBigID2CBModule = {}           # 回调大类ID到回调函数


def RegisterCBModule(nCBBigID, ModuleCBObj):
    """
    注册一个回调函数模块
    @param nCBBigID: 大类ID必须在ECBBigID中注册
    @param ModuleCBObj: 模块
    @return:
    """

    assert nCBBigID not in dictCBBigID2CBModule

    dictCBBigID2CBModule[nCBBigID] = ModuleCBObj


def DoCB(nCBBigID, nCBIndex, *tupleCBArg):
    """
    执行回调
    @param nCBBigID: 回调大类ID
    @param nCBIndex: 回调小类ID
    @param tupleCBArg: 动态参数
    @return: 执行是否成功。并且有一个dict作为返回结果
    """
    ModuleCBObj = dictCBBigID2CBModule[nCBBigID]

    szFuncName = 'CB%s' % nCBIndex
    assert hasattr(ModuleCBObj, szFuncName)

    return getattr(ModuleCBObj, szFuncName)(*tupleCBArg)


# ********************************************************************************
# 注册函数，需要放最后，请不要在此之后添加任何与注册无关的代码。Thank you!
# ********************************************************************************
RegisterCBModule(enum_def.ECBBigID.eAutoUseItem, auto_use_item_cb)
