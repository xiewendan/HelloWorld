# -*- coding: utf-8 -*-

# desc: 自动使用物品回调


def CB0(*arg):
    print "test cb 0"
    pass
