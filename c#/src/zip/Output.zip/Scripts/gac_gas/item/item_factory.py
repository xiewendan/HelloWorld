# -*- coding: utf-8 -*-

# desc: 物品创建工厂

from gac_gas.common.idmanager import IdManager

ITEM_STATIC_ATT_NUM = 5


class ItemFactory(object):
    """物品创建工厂"""

    def __init__(self):
        self.m_dictBigID2ItemCls = {}

    def RegisterItemCls(self, nBigID, clsItem):
        """注册一个ItemCls"""
        assert self.m_dictBigID2ItemCls.get(nBigID, None) is None

        self.m_dictBigID2ItemCls[nBigID] = clsItem

    def CreateItem(self, nBigID, nIndex, nCount, szItemID=None, dynamicData=None):
        """创建一个物品"""
        clsItem = self.m_dictBigID2ItemCls[nBigID]
        if szItemID is None:
            szItemID = IdManager.ID2Str(IdManager.GenID())

        if isinstance(szItemID, unicode):
            szItemID = str(szItemID)

        ItemObj = clsItem(szItemID, nBigID, nIndex, nCount, dynamicData)
        ItemObj.New()
        return ItemObj

    def CreateItemByData(self, listItemData):
        """
        加载一个物品
        @param listItemData:[[nBigID,nIndex,nCount,szItemID,nAddTime],[dynamicAttr1,dynamicAttr2..]]
        @return:
        """
        nBigID, nIndex, nCount, szItemID, nAddTime = listItemData[0]
        dynamicData = listItemData[1]
        clsItem = self.m_dictBigID2ItemCls[nBigID]
        if szItemID is None:
            szItemID = IdManager.ID2Str(IdManager.GenID())

        if isinstance(szItemID, unicode):
            szItemID = str(szItemID)

        ItemObj = clsItem(szItemID, nBigID, nIndex, nCount, dynamicData)
        ItemObj.UpdateAddTime(nAddTime)
        return ItemObj

    def CheckItemAcSyncData(self, listItemData):
        """
        检查物品的格式
        @param listItemData:[[nBigID,nIndex,nCount,szItemID,nAddTime],[dynamicAttr1, dynamicAttr2, ..],]
        @return:
        """
        if not isinstance(listItemData, list):
            return False, "must be list"

        if len(listItemData) != 2:
            return False, "list data count is not 2:{}".format(len(listItemData))

        if len(listItemData[0]) != ITEM_STATIC_ATT_NUM:
            return False, "static attr count must be {}".format(ITEM_STATIC_ATT_NUM)

        nBigID, nIndex, nCount, szItemID, nAddTime = listItemData[0]

        import gac_gas.item.item_cfg_mgr as item_cfg_mgr
        if not item_cfg_mgr.CheckItemCfg(nBigID, nIndex):
            return False, "static attr1 and 2 Error:BigID and Index does not match item"

        if nCount < 1:
            return False, "static attr3:count must be greater and equal than 1"

        # if szItemID is not None:
        #     return False, "静态属性4错误：ItemID不存在"

        clsItem = self.m_dictBigID2ItemCls[nBigID]

        # 静态属性
        bStaticOK, szError = clsItem.CheckStaticData(listItemData[0])
        if not bStaticOK:
            return False, szError

        # 动态属性
        bDynamicOK, szError = clsItem.CheckDynamicData(listItemData[1])
        if not bDynamicOK:
            return False, szError

        return True, "succeed"
