# -*- coding: utf-8 -*-


# TODO:目前是一个比较简单的版本,后续需求加上后补充


class CardFactoryBase(object):
    def CreateCardByData(self, szCardID, nCfg, nLevel):
        raise False

    def CraetCardByCfg(self, nCfg):
        raise False
