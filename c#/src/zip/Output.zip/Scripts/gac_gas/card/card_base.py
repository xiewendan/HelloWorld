# -*- coding: utf-8 -*-

import config.setting.card.card_common as card_common

class BaseCard(object):
    def __init__(self, szCardID, nCfg, nLevel):
        # 唯一id
        self.m_szCardID = szCardID
        # 卡片编号
        self.m_nCfg = nCfg
        # 卡片等级
        self.m_nLevel = nLevel

    def GetCardID(self):
        return self.m_szCardID

    def GetCfg(self):
        return self.m_nCfg

    def GetMonsterID(self):
        return card_common.card_common[self.m_nCfg].get("怪物编号", 0)

    def GetSkillID(self):
        return card_common.card_common[self.m_nCfg].get("技能编号", 0)

    def GetMonsterNum(self):
        return card_common.card_common[self.m_nCfg].get("怪物数量", 1)

    def GetPicPath(self):
        return card_common.card_common[self.m_nCfg].get("图片路径", "CommonUI/Icon/Head/img_head_01")

    def GetPutTier(self):
        return card_common.card_common[self.m_nCfg].get("摆放层级", 0)

    def GetCardSyncData(self):
        # 返回一个用于传递的数据,如发给客户端
        return [self.m_szCardID, self.m_nCfg, self.m_nLevel]

    def GetCardSaveData(self):
        # 返回一个用于存盘的数据
        return [self.m_szCardID, self.m_nCfg, self.m_nLevel]

    def GetCardPokemonType(self):
        return card_common.card_common[self.m_nCfg].get("卡牌属性", 0)
