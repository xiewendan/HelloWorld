# -*- coding: utf-8 -*-

import logging

import gac_gas.common.enum_def as enum_def

_logger = logging.getLogger('ComponentScene')

# 场景组件基类
class ComponenetSceneBase(object):
    s_eComponentType = enum_def.EComponentSceneType.eUndefine

    def __init__(self, OwnerObj, tupleArg=None):
        self.m_OwnerObj = OwnerObj
        self.m_bEnable = True
        self.m_bDestroy = False

    def GetComponentType(self):
        return self.s_eComponentType

    def SetOwner(self, OwnerObj):
        self.m_OwnerObj = OwnerObj

    def GetOwner(self):
        return self.m_OwnerObj

    def SetEnable(self, bEnable):
        self.m_bEnable = bEnable

    def IsEnable(self):
        return self.m_bEnable

    def Destroy(self):
        if self.m_bDestroy:
            return

        self.m_bDestroy = True

        self.OnDestroy()
        self.SetEnable(False)
        self.m_OwnerObj = None

    def OnDestroy(self):
        pass
