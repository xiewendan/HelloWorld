# -*- coding: utf-8 -*-

import gac_gas.common.enum_def as enum_def
import gac_gas.component.component_scene.scene_test_component as scene_test_component
import gac_gas.component.component_scene.scene_fire_bullet_component as scene_fire_bullet_component

# 场景组件管理类
class ComponentSceneMgr(object):
    def __init__(self):
        self.m_dictCmpClass = {}

        # 状态类注册
        self.RegisterComponentClass(scene_test_component.SceneTestComponent)
        self.RegisterComponentClass(scene_fire_bullet_component.SceneBulletMgrComponent)


    def RegisterComponentClass(self, ComponentClassObj):
        """
        注册一个场景组件类
        @param ComponentClassObj: 场景组件类，需要继承于ComponenetSceneBase
        @return:
        """
        eComponentType = ComponentClassObj.s_eComponentType

        assert eComponentType is not enum_def.EComponentSceneType.eUndefine,\
            "ComponentSceneMgr RegisterComponentClass Error: [{0}] is undifine!!!".format(ComponentClassObj)

        assert eComponentType not in self.m_dictCmpClass,\
            "ComponentSceneMgr RegisterComponentClass Error: [{0}] is already existed!!!".format(ComponentClassObj)

        self.m_dictCmpClass[eComponentType] = ComponentClassObj

    def UnRegisterComponentClass(self, ComponentClassObj):
        """
        注销一个场景组件类
        @param ComponentClassObj: 场景组件类，需要继承于ComponenetSceneBase
        @return:
        """

        eComponentType = ComponentClassObj.s_eComponentType

        assert eComponentType is not enum_def.EComponentSceneType.eUndefine,\
            "ComponentSceneMgr RegisterComponentClass Error: [{0}] is undifine!!!".format(ComponentClassObj)

        assert eComponentType in self.m_dictCmpClass,\
            "ComponentSceneMgr RegisterComponentClass Error: [{0}] is not existed!!!".format(ComponentClassObj)

        del self.m_dictCmpClass[eComponentType]

    def CreateComponent(self, eComponentType, Scene, tupleArg=None):
        """
        创建一个场景组件
        @param eComponentType: 场景组件类型，EComponentSceneType
        @param Scene: 场景
        @param tupleArg: 参数
        @return: 返回一个创建好的场景组件
        """
        ComponentClassObj = self.m_dictCmpClass.get(eComponentType)
        if ComponentClassObj:
            return ComponentClassObj(Scene, tupleArg)
        else:
            assert False, "不存在指定类型的场景组件%s" % eComponentType

    def HasComponent(self, eComponentType):
        """
        判断是否存在指定类型的组件
        @param eComponentType: 场景组件类型，EComponentSceneType
        @return:
        """
        return eComponentType in self.m_dictCmpClass


g_ComponentSceneMgrObj = ComponentSceneMgr()
CreateComponent = g_ComponentSceneMgrObj.CreateComponent
