# -*- coding: utf-8 -*-
__author__ = 'ywxu'

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType, EHpChangedReason
from gac_gas.common.enum_def import EPokemonType
from gac_gas.common.enum_def import EPropertyType
import gac_gas.common_pkg.platform as platform
import gac_gas.entity.entity_interface as entity_interface
from config.setting.battle.fight_attrs_common import fight_attrs_common
from gac_gas.common.enum_def import EEntityGameMessageType
from gac_gas.skill.class_fight_skill_mgr import GetFightSkillByID

# 调式开关
g_bQcLog = False

IS_CLIENT_PLATFORM = platform.IsClientPlatform()


# 广播
def BroadCastParam(self, szKey, value=0, isRemove=False):
    if isRemove:
        if IS_CLIENT_PLATFORM:
            self.GetEntityObj().Gas2GacSyncDelParam(szKey)
        else:
            self.GetEntityObj().GetGacFollowersAndSelf().Gas2GacSyncDelParam(szKey)
    else:
        if IS_CLIENT_PLATFORM:
            self.GetEntityObj().Gas2GacSyncParam(szKey, value)
        else:
            self.GetEntityObj().GetGacFollowersAndSelf().Gas2GacSyncParam(szKey, value)


# 同步
def SyncParam(self, szKey, value=0, isRemove=False):
    if IS_CLIENT_PLATFORM:
        if isRemove:
            self.GetEntityObj().Gas2GacSyncDelParam(szKey)
        else:
            self.GetEntityObj().Gas2GacSyncParam(szKey, value)
    else:
        gacPlayer = self.GetEntityObj().GetGacPlayer()
        if gacPlayer is None:
            return

        if isRemove:
            gacPlayer.Gas2GacSyncDelParam(szKey)
        else:
            gacPlayer.Gas2GacSyncParam(szKey, value)


# 公式模式下的最大血量
class CFactorMaxValue(object):
    def __init__(self, nBase, nAF=0, nMF=1.0):
        self.m_nBase = nBase  # 基础数值
        self.m_nAF = nAF  # 加法因子, 用途是和乘法因子无关联的附加值
        self.m_nMF = nMF  # 乘法因子, 用途是作用于基础值
        self.m_nValue = None
        self.UpdateValue()

    def UpdateValue(self):
        self.m_nValue = max(1, self.m_nBase * self.m_nMF + self.m_nAF)

    def SetBase(self, nValue):
        self.m_nBase = nValue
        self.UpdateValue()

    def GetBase(self):
        return self.m_nBase

    def GetAF(self):
        return self.m_nAF

    def AddBase(self, nValue):
        self.m_nBase += nValue
        self.UpdateValue()

    def SetAF(self, nValue):
        self.m_nAF = nValue
        self.UpdateValue()

    def AddAF(self, nValue):
        self.m_nAF += nValue
        self.UpdateValue()

    def SetMF(self, nValue):
        self.m_nMF = nValue
        self.UpdateValue()

    def AddMF(self, nValue):
        self.m_nMF += nValue
        self.UpdateValue()

    def GetValue(self):
        return self.m_nValue


# region 战斗属性组件
class EntityFightAttrComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityFightAttr

    # region Description : 初始化和销毁 --------------------------------------------------------------------------------
    # 需要同步的战斗属性
    BROADCAST_FIGHT_ATTR = {
    }

    # 战斗属性
    FIGHT_ATTR = {
        # "攻击": 0,
    }

    def __init__(self, OwnerObj):
        super(EntityFightAttrComponent, self).__init__(OwnerObj)
        # 静态属性, 一定存在,不需要省内存
        self.m_bDead = False
        # 生命值最大值
        self.m_FactorMaxHpValue = CFactorMaxValue(0)
        self.m_nCurHp = 1
        # 战斗关系 :势力
        self.m_nCamp = 0

        # 战斗关系 :是否可战
        self.m_bFightable = True
        # 宝可梦属性
        self.m_ePokemonType = EPokemonType.eNormal
        self.m_nAtk = 0
        self.m_nDef = 0
        self.m_nSkillAtk = 0
        self.m_nSkillDef = 0
        self.m_nLevel = 1
        self.m_nCriticalRate = 0

        # 动态战斗属性, 需要时才存在, 省内存
        self.m_dictFightAttr = {}
        # 状态列表
        self.m_dictStates = {}
        # 需要同步自己的状态列表(同步角色时会同步, 注意是广播)
        self.m_dictBroadCastStates = {}

    def Init(self, dictData):
        nFightAttrsID = dictData.get("战斗属性ID", 0)
        dictFightAttrs = fight_attrs_common.get(nFightAttrsID)
        assert dictFightAttrs, "对象战斗属性ID不存在,请检查是否填错了!"
        self.m_nCamp = dictData.get(EPropertyType.CampID, 0)

        # 静态属性
        self.m_bFightable = dictFightAttrs.get("不可战", 0) == 0
        self.m_FactorMaxHpValue.SetBase(dictFightAttrs.get("生命", 1))
        self.m_ePokemonType = dictFightAttrs.get("属性", EPokemonType.eNormal)
        self.m_nAtk = dictFightAttrs.get("攻击", 0)
        self.m_nDef = dictFightAttrs.get("防御", 0)
        self.m_nSkillAtk = dictFightAttrs.get("特攻", 0)
        self.m_nSkillDef = dictFightAttrs.get("特防", 0)
        self.m_nLevel = dictFightAttrs.get("等级", 0)
        self.m_nCriticalRate = dictFightAttrs.get("暴击率", 0)

        # 动态属性
        # for szAttrs in self.FIGHT_ATTR.iterkeys():
        #     self.SetParamBase(szAttrs, dictFightAttrs.get(szAttrs) or self.FIGHT_ATTR[szAttrs])

        self.m_nCurHp = self.GetMaxHp()

    def GetCreateData(self):
        dictData = super(EntityFightAttrComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.CampID: self.m_nCamp,
            EPropertyType.PokemonType: self.m_ePokemonType,
        })
        return dictData

    # endregion

    # region Description : 静态战斗属性 --------------------------------------------------------------------------------
    def IsCanDoSkill(self):
        return not self.m_bDead

    def IsDead(self):
        return self.m_bDead

    def GetPokemonType(self):
        return self.m_ePokemonType

    def GetAtk(self):
        return self.m_nAtk

    def GetDef(self):
        return self.m_nDef

    def GetSkillAtk(self):
        return self.m_nSkillAtk

    def GetSkillDef(self):
        return self.m_nSkillDef

    def GetLevel(self):
        return self.m_nLevel

    def GetCriticalRate(self):
        return self.m_nCriticalRate

    # endregion

    # region Description : MAX HP --------------------------------------------------------------------------------------
    def SetMaxHp(self, nMaxHp):
        self.m_FactorMaxHpValue.SetBase(nMaxHp)

    def SetAFMaxHp(self, nAFHP):
        self.m_FactorMaxHpValue.SetAF(nAFHP)

    def GetMaxHp(self):
        return self.m_FactorMaxHpValue.GetValue()

    def GetBaseMaxHp(self):
        return self.m_FactorMaxHpValue.GetBase()

    def GetAFMaxHp(self):
        return self.m_FactorMaxHpValue.GetAF()

    # 修改生命最大值, 带同步, 不会添加当前生命值
    def AddMaxHpPercent(self, fPercent):
        self.m_FactorMaxHpValue.AddMF(fPercent)

        if self.m_nCurHp > self.GetMaxHp():
            self.m_nCurHp = self.GetMaxHp()

        # 同步

    # endregion

    # region Description : HP ------------------------------------------------------------------------------------------
    def GetCurHp(self):
        return self.m_nCurHp

    # 伤害扣血
    def AddDamage(self, nDamage, objFrom, nReason=EHpChangedReason.eOtherType):
        if nDamage <= 0 or self.m_bDead:
            return 0

        nMaxHpValue = self.GetMaxHp()

        # 计算当前血量
        nNewHp = self.m_nCurHp - nDamage

        # 计算产生的同步的伤害(整形), 策划需求, 希望内部运行支持浮点, 外部显示整形
        nIntRealDamage = int(nNewHp) - int(self.m_nCurHp)

        # 血量小于0时当前血量为0
        if nNewHp < 0:
            nNewHp = 0

        # 计算真正减少的血量(浮点)
        nRealDamage = nNewHp - self.m_nCurHp

        self.m_nCurHp = nNewHp

        objOwner = self.GetOwner()

        # 血量同步
        objOwner.GetGacEntityRpc().RRpcGetFightCmp().Gas2GacFightAttrAddDamage(nDamage, self.m_nCurHp, self.GetMaxHp())

        # 死亡判断, 内部标记立刻, 外部event延迟到函数最后
        self.m_bDead = self.m_nCurHp <= 0

        # 所有伤害结束后检测是否死亡(是否放到死亡组件, 这里死不一定会播放死亡动画,可能要做技能,发送到技能槽组件(死亡组件),触发技能
        if self.m_bDead:
            objOwner.NotifyEvent(EEntityGameMessageType.Die, objFrom)
            # CR 获取发送给model组件决定?播放动画事件和死亡时间不一样(因为还要广播
            objOwner.GetGacEntityRpc().RRpcGetModelCmp().Gas2GacModelSetTrigger("die")

        return nRealDamage

    # 恢复加血
    def AddCurHp(self, nAddHp, nReason=EHpChangedReason.eOtherType):
        if nAddHp <= 0 or self.m_bDead:
            return 0

        nMaxHpValue = self.GetMaxHp()

        # 已经满血
        if self.m_nCurHp >= nMaxHpValue:
            return 0

        # 计算当前血量
        nNewHp = self.m_nCurHp + nAddHp
        nIntRealAddHp = int(nNewHp) - int(self.m_nCurHp)

        # 当前血量溢出
        if nNewHp > nMaxHpValue:
            nAddHp = nMaxHpValue - self.m_nCurHp
            nNewHp = nMaxHpValue

        # 计算真正减少的血量
        nRealAddHp = nNewHp - self.m_nCurHp

        self.m_nCurHp = nNewHp

        # 同步

        return nRealAddHp

    # endregion

    # region Description : 战斗势力和关系 ------------------------------------------------------------------------------
    def GetCamp(self):
        return self.m_nCamp

    def SetCamp(self, nCamp):
        self.m_nCamp = nCamp

    def IsEnemyCamp(self, nCamp):
        return nCamp != self.m_nCamp

    def IsFightable(self):
        return self.m_bFightable

    def SetFightable(self, bFightable):
        self.m_bFightable = bFightable

    def CanHurt(self, otherObj):
        if not entity_interface.FightCmp_IsFightable(otherObj):
            return False

        if entity_interface.FightCmp_IsEnemyCamp(otherObj, self.GetCamp()):
            return True
        return False

    # endregion

    # region Description : 动态战斗属性 --------------------------------------------------------------------------------
    def SetParamBase(self, szKey, base):
        self.m_dictFightAttr[szKey] = base

        funBroadCast = self.BROADCAST_FIGHT_ATTR.get(szKey)
        if funBroadCast:
            funBroadCast(self, szKey, base)

    def SetParamAdd(self, szKey, add):
        # print ("--------SetParamAdd: key:%s add:%s" % (szKey, add))
        n = self.m_dictFightAttr.get(szKey, self.FIGHT_ATTR.get(szKey))
        n = n + add
        self.m_dictFightAttr[szKey] = n

        funBroadCast = self.BROADCAST_FIGHT_ATTR.get(szKey)
        if funBroadCast:
            funBroadCast(self, szKey, n)

    def GetParamValue(self, szKey):
        return self.m_dictFightAttr.get(szKey, self.FIGHT_ATTR.get(szKey))

    # broadcast_mode: 0 不同步： 1 广播 2 同步给主角
    # 还有一个进入视野是否同步
    def AddParam(self, szKey, default, shouldSync=False):
        # print ("--------AddParam: key:%s default:%s" % (szKey, default))
        self.m_dictFightAttr[szKey] = default

        if shouldSync:
            funBroadCast = self.BROADCAST_FIGHT_ATTR.get(szKey)
            if funBroadCast:
                funBroadCast(self, szKey, default)

    def RemoveParam(self, szKey, shouldSync=False):
        del self.m_dictFightAttr[szKey]

        if shouldSync:
            funBroadCast = self.BROADCAST_FIGHT_ATTR.get(szKey)
            if funBroadCast:
                funBroadCast(self, szKey, isRemove=True)

    def HasParam(self, szKey):
        return szKey in self.m_dictFightAttr

    # endregion

    # region Description : 战斗状态 ------------------------------------------------------------------------------------
    def AddStateCounter(self, szState, OnEnter=None, OnExit=None, listParam=None, bBroadCastSyncMe=False):
        # OnEnter:进入状态回调
        # OnExit:退出状态回调
        # listParam: 状态的参数,可以动态设置
        # bBroadCastSyncMe : 自动同步, 包括对象同步和状态变更同步
        self.m_dictStates[szState] = [0, OnEnter, OnExit, listParam or [], None, bBroadCastSyncMe]

    def IsState(self, szState):
        listCounter = self.m_dictStates.get(szState)
        if listCounter:
            return listCounter[0] > 0
        else:
            return False

    def SetStateParam(self, szState, listParam):
        listCounter = self.m_dictStates[szState]
        listCounter[3] = listParam

    def GetStateParam(self, szState):
        return self.m_dictStates[szState][3]

    # 注意: bCancleBuffer不能被buffer触发,否则同步回调循环回调.
    def AddStateCount(self, szState, nCount, bCancleBuffer=False):
        listCounter = self.m_dictStates[szState]
        nOldCount, OnEnterStateCB, OnExitStateCB, listParam, nBufferID, bBroadCastSyncMe = listCounter
        if nCount < 0 and nOldCount <= 0:
            return
        nNowCount = nOldCount + nCount
        listCounter[0] = nNowCount
        # print("******AddStateCount:%s %d %d %s" % (szState, nCount, nNowCount, nBufferID))

        if nNowCount == 1 and nOldCount == 0:
            if g_bQcLog:
                print ("--------State OnEnter%s----------" % szState)

            if OnEnterStateCB:
                OnEnterStateCB()

            if bBroadCastSyncMe:
                BroadCastParam(self, szState, True)
                self.m_dictBroadCastStates[szState] = True

        elif nNowCount == 0:
            if g_bQcLog:
                print ("--------State OnExit%s----------" % szState)

            if OnExitStateCB:
                OnExitStateCB()

            if bBroadCastSyncMe:
                BroadCastParam(self, szState, False)
                del self.m_dictBroadCastStates[szState]

            # 清理绑定的buffer
            if bCancleBuffer and nBufferID:
                # buffer取消时触发同步AddStateCount一次(无效), DelBuffByBuffID会清掉所有buffer
                self.GetBuffContainer().DelBuffByBuffID(nBufferID)
                listCounter[4] = None

    # 获取状态取消时, 取消的bufferid
    # 应用 = 带时间buffer和带触发器状态之间生命周期绑定:
    # buffer->设置状态, 状态内部带触发器, 触发器触发时状态-1, 状态结束时->清理buffer
    def GetStateBufferID(self, szState):
        return self.m_dictStates[szState][4]

    def SetStateBufferID(self, szState, nBufferID):
        listCounter = self.m_dictStates[szState]
        listCounter[4] = nBufferID

    pass
    # endregion

    def CalcHurt(self, objTarget, nSkillID):
        objOwner = self.GetOwner()

        # 目标战斗属性组件
        ComponentFightAttrTarget = objTarget.GetComponentByName(EComponentEntityType.EntityFightAttr)
        if ComponentFightAttrTarget.IsDead():
            return

        # 当前skill
        curSkill = GetFightSkillByID(nSkillID)

        # 暂时只有属性相克
        Co = 1.0

        # 技能招式威力
        nSkillPower = curSkill.GetPower() / 250.0

        # 攻击方攻击力
        nAtk = self.GetAtk()
        nLevel = self.GetLevel()

        # 目标防御值
        nDefence = ComponentFightAttrTarget.GetDef()

        # 伤害
        nDamage = Co * (nSkillPower * (float(nAtk) / nDefence) * (2 * nLevel + 10) + 2)

        ComponentFightAttrTarget.AddDamage(nDamage, objOwner)

# endregion
