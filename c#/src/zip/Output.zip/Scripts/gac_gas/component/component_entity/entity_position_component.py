# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType


# 游戏对象位置属性
class EntityPositionComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityPosition

    def __init__(self, OwnerObj):
        super(EntityPositionComponent, self).__init__(OwnerObj)
        # 位置
        self.m_listPosition = [0, 0, 0]
        # 朝向
        self.m_nDir = 1

    def Init(self, dictData):
        self.m_listPosition = dictData.get(EPropertyType.Pos, [0, 0, 0])
        self.m_nDir = dictData.get(EPropertyType.Dir, 1)

    def GetCreateData(self):
        dictData = super(EntityPositionComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.Pos: self.m_listPosition,
            EPropertyType.Dir: self.m_nDir,
        })
        return dictData

    # 获取位置点
    def GetPosition(self):
        return list(self.m_listPosition)

    def GetPositionSelf(self):
        return self.m_listPosition

    # 设置位置点
    def SetPosition(self, listPos):
        self.m_listPosition = listPos

    # 获取方向
    def GetDir(self):
        return self.m_nDir

    # 设置方向
    def SetDir(self, nDir):
        self.m_nDir = nDir
