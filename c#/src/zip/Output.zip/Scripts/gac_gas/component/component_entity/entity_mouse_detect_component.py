# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType


# 游戏模型类
class EntityMouseDetectComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityMouseDetect

    def __init__(self, OwnerObj):
        super(EntityMouseDetectComponent, self).__init__(OwnerObj)
        self.m_nMouseDetect = 0

    def Init(self, dictData):
        self.m_nMouseDetect = dictData[EPropertyType.MouseDetect]

    def GetCreateData(self):
        dictData = super(EntityMouseDetectComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.MouseDetect: self.m_nMouseDetect,
        })
        return dictData
