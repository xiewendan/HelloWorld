# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType


# 游戏模型类
class EntityModelComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityModel

    def __init__(self, OwnerObj):
        super(EntityModelComponent, self).__init__(OwnerObj)
        # 模型文件
        self.m_szModelPath = None
        # 模型比例
        self.m_nModelScale = 1.0

    def Init(self, dictData):
        self.m_szModelPath = dictData.get(EPropertyType.ModelPath)
        self.m_szModelPath1 = dictData.get(EPropertyType.ModelPath1)
        self.m_nModelScale = dictData.get(EPropertyType.ModelScale, 1.0)

    def GetCreateData(self):
        dictData = super(EntityModelComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.ModelPath: self.m_szModelPath,
            EPropertyType.ModelPath1: self.m_szModelPath1,
            EPropertyType.ModelScale: self.m_nModelScale,
        })
        return dictData
