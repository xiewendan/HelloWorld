# -*- coding: utf-8 -*-

import gac_gas.component.component_base as component_base
import gac_gas.common.enum_def as enum_def


class EntityUIComponent(component_base.ComponentBase):
    s_eComponentType = enum_def.EComponentEntityType.EntityUI


