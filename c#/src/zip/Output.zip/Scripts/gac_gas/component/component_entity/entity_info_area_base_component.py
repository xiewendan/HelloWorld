# -*- coding: utf-8 -*-

import gac_gas.component.component_entity.entity_info_base_component as entity_info_base_component
from gac_gas.common.enum_def import EInfoType
from gac_gas.common.enum_def import EPropertyType


# Area基本属性
class EntityInfoAreaBaseComponent(entity_info_base_component.EntityInfoBaseComponent):
    s_eComponentSubType = EInfoType.EArea

    def __init__(self, OwnerObj):
        super(EntityInfoAreaBaseComponent, self).__init__(OwnerObj)
        # 区域id
        self.m_nAreaID = None

    def Init(self, dictData):
        super(EntityInfoAreaBaseComponent, self).Init(dictData)
        self.m_nAreaID = dictData.get(EPropertyType.AreaID, 0)

    def GetCreateData(self):
        dictData = super(EntityInfoAreaBaseComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.AreaID: self.m_nAreaID,
        })
        return dictData
