# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType
from gac_gas.common.enum_def import EGameObjType
from gac_gas.common.enum_def import EInfoType


# 游戏对象基本属性
class EntityInfoBaseComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityInfoBase
    s_eComponentSubType = EInfoType.EBase
    s_bSyncBat = True

    def __init__(self, OwnerObj):
        super(EntityInfoBaseComponent, self).__init__(OwnerObj)
        # 类型
        self.m_eGameObjType = None
        # 名称
        self.m_szName = ""
        # 场景
        self.m_nSceneTypeID = None
        self.m_nCopyTypeID = None
        self.m_nSceneID = None
        self.m_Scene = None

        # 死亡回收时间
        self.m_nDieDestory = None

        # 配置id
        self.m_nCfgID = None

    def Init(self, dictData):
        self.m_eGameObjType = dictData.get(EPropertyType.GameObjType, None)
        self.m_szName = dictData.get(EPropertyType.Name, "")
        self.m_nSceneTypeID = dictData.get(EPropertyType.SceneTypeID, None)
        self.m_nCopyTypeID = dictData.get(EPropertyType.SceneCopyID, None)
        self.m_nCfgID = dictData.get(EPropertyType.CfgID, None)
        self.m_nDieDestory = dictData.get(EPropertyType.DieDestory, 3000)

    def GetCreateData(self):
        dictData = super(EntityInfoBaseComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.GameObjType: self.m_eGameObjType,
            EPropertyType.Name: self.m_szName,
            EPropertyType.SceneTypeID: self.m_nSceneTypeID,
            EPropertyType.SceneCopyID: self.m_nCopyTypeID,
            EPropertyType.CfgID: self.m_nCfgID,
        })
        return dictData

    def GetFightData(self, dictData):
        # 更新组件字典
        eComponentType = self.GetType()
        eComponentSubType = self.GetSubType()
        dictData[EPropertyType.ComponentDict][eComponentType] = eComponentSubType
        dictComponentData = self.GetCreateData()
        dictData.update(dictComponentData)

    def GetGameObjType(self):
        return self.m_eGameObjType

    def GetName(self):
        return self.m_szName

    def SetName(self, szName):
        self.m_szName = szName

    def SetScene(self, GasScene):
        if GasScene:
            self.m_Scene = GasScene
            self.m_nSceneTypeID = GasScene.GetSceneTypeID()
            self.m_nCopyTypeID = GasScene.GetSceneTypeID()
            self.m_nSceneID = GasScene.GetSceneID()
        else:
            OldScene = self.m_Scene
            self.m_Scene = None
            self.m_nSceneTypeID = None
            self.m_nCopyTypeID = None
            self.m_nSceneID = None

    def GetScene(self):
        return self.m_Scene

    def IsPlayer(self):
        return self.m_eGameObjType == EGameObjType.Player

    def GetDieDestoryTime(self):
        return self.m_nDieDestory
