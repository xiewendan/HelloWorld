# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import entity_view_base_component as entity_view_base_component
from gac_gas.common.enum_def import EViewType


# 游戏对象圆形视野
class EntityCircleComponent(entity_view_base_component.EntityViewBaseComponent):
    s_eComponentSubType = EViewType.ECircle
