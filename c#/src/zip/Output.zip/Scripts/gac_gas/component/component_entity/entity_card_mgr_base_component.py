# -*- coding: utf-8 -*-

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType


# 游戏对象基本属性
class EntityBaseCardComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityCard

    def __init__(self, OwnerObj):
        super(EntityBaseCardComponent, self).__init__(OwnerObj)
        # 空间大小
        self.m_nSpaceCount = 0
        # 卡排对象列表
        self.m_ListCard = []

    def AddCard(self, CardObj):
        self.m_ListCard.append(CardObj)

    def RemoveCard(self, CardObj):
        self.m_ListCard.remove(CardObj)

    def IsFull(self):
        return len(self.m_ListCard) >= self.m_nSpaceCount

    def FreeSpace(self):
        return self.m_nSpaceCount - len(self.m_ListCard)

    def GetCreateData(self):
        dictData = super(EntityBaseCardComponent, self).GetCreateData()
        listSyncData = []
        for CardObj in self.m_ListCard:
            listSyncData.append(CardObj.GetCardSyncData())
        dictData.update({
            EPropertyType.CardData: listSyncData,
            EPropertyType.CardSpace: self.m_nSpaceCount,
        })
        return dictData

    def Init(self, dictData):
        """
        初始化数据
        :return:
        """
        self.m_nSpaceCount = dictData.get(EPropertyType.CardSpace, 0)
        self.m_ListCard = []
        for CardData in dictData.get(EPropertyType.CardData, []):
            szCardID, szCfg, nLevel = CardData
            CardObj = self.GetCardFactory().CreateCardByData(szCardID, szCfg, nLevel)
            self.m_ListCard.append(CardObj)

    def GetCardFactory(self):
        raise False
