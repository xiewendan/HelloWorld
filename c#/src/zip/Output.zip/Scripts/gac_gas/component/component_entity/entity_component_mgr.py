# -*- coding: utf-8 -*-

import gac_gas.common_pkg.utils as utils
from gac_gas.common.singleton import singleton

if utils.IS_CLIENT_PLATFORM:
    import gac_gas.component.component_entity.entity_info_base_component as entity_info_base_component
    import gac_gas.component.component_entity.entity_info_npc_base_component as entity_info_npc_base_component
    import gac_gas.component.component_entity.entity_ai_component as entity_ai_component
    import logic.component.component_entity.gac_entity_position_component as gac_entity_position_component
    import logic.component.component_entity.gac_entity_model_component as gac_entity_model_component
    import gac_gas.component.component_entity.entity_view_circle_component as entity_view_circle_component
    import gac_gas.component.component_entity.entity_view_sector_component as entity_view_sector_component
    import gac_gas.component.component_mgr_base as component_mgr
    import gac_gas.component.component_entity.entity_card_mgr_base_component as entity_card_mgr_base_component
    import logic.component.component_entity.gac_entity_card_mgr_lobby_component as gac_entity_card_mgr_lobby_component
    import logic.component.component_entity.gac_entity_card_mgr_fight_component as gac_entity_card_mgr_fight_component
    import gac_gas.component.component_entity.entity_info_hero_base_component as entity_info_hero_base_component
    import logic.component.component_entity.gac_entity_do_skill_component as gac_entity_do_skill_component
    import logic.component.component_entity.gac_entity_fight_attr_component as gac_entity_fight_attr_component
    from gac_gas.common.singleton import singleton
    import logic.component.component_entity.gac_entity_mouse_detect_component as gac_entity_mouse_detect_component
    import logic.component.component_entity.gac_entity_ui_component as gac_entity_ui_component
    import logic.component.component_entity.gac_entity_info_area_component as gac_entity_info_area_component
    import logic.component.component_entity.gac_entity_bag_mgr_component as gac_entity_bag_mgr_component
else:
    import gac_gas.component.component_entity.entity_info_base_component as entity_info_base_component
    import gac_gas.component.component_entity.entity_info_npc_base_component as entity_info_npc_base_component
    import gac_gas.component.component_entity.entity_ai_component as entity_ai_component
    import component.component_entity.gas_entity_position_component as gas_position_component
    import gac_gas.component.component_entity.entity_model_component as entity_model_component
    import gac_gas.component.component_entity.entity_view_circle_component as entity_view_circle_component
    import gac_gas.component.component_entity.entity_view_sector_component as entity_view_sector_component
    import gac_gas.component.component_mgr_base as component_mgr
    import component.component_entity.gas_entity_card_mgr_lobby_component as gas_entity_card_mgr_lobby_component
    import component.component_entity.gas_entity_card_mgr_fight_component as gas_entity_card_mgr_fight_component
    import gac_gas.component.component_entity.entity_info_hero_base_component as entity_info_hero_base_component
    import gac_gas.component.component_entity.entity_mouse_detect_component as entity_mouse_detect_component
    import gac_gas.component.component_entity.entity_do_skill_component as entity_do_skill_component
    import gac_gas.component.component_entity.entity_fight_attr_component as entity_fight_attr_component
    import gac_gas.component.component_entity.entity_ui_component as entity_ui_component
    import gac_gas.component.component_entity.entity_info_area_base_component as entity_info_area_base_component
    import component.component_entity.gas_player_base_info_component as gas_player_base_info_component
    import component.component_entity.gas_player_scene_info_component as gas_player_scene_info_component
    import component.component_entity.gas_entity_bag_mgr_component as gas_entity_bag_mgr_component


@singleton
class EntityComponentMgr(component_mgr.ComponentMgrBase):
    def Init(self):
        self.m_dictComponentClass = {}

        if utils.IS_CLIENT_PLATFORM:
            # 客户端请在这里注册组件
            listComponentClass = [
                entity_info_base_component.EntityInfoBaseComponent,
                entity_info_npc_base_component.EntityInfoNpcBaseComponent,
                # entity_ai_component.EntityAIComponent,
                gac_entity_position_component.GacEntityPositionComponent,
                gac_entity_model_component.GacEntityModelComponent,
                entity_view_circle_component.EntityCircleComponent,
                entity_view_sector_component.EntityViewSectorComponent,
                entity_card_mgr_base_component.EntityBaseCardComponent,
                gac_entity_card_mgr_lobby_component.GacEntityCardMgrLobbyComponent,
                gac_entity_card_mgr_fight_component.GacEntityCardMgrFightComponent,
                entity_info_hero_base_component.EntityInfoHeroBaseComponent,
                gac_entity_mouse_detect_component.GacEntityMouseDetectComponent,
                gac_entity_do_skill_component.GacEntitySkillFsmComponent,
                gac_entity_fight_attr_component.GacEntityFightAttrComponent,
                gac_entity_ui_component.GacEntityUIComponent,
                gac_entity_info_area_component.GacEntityInfoAreaComponent,
                gac_entity_bag_mgr_component.GacEntityBagMgrComponent,
            ]
        else:
            # 服务器请在这里注册组件
            listComponentClass = [
                entity_info_base_component.EntityInfoBaseComponent,
                entity_info_npc_base_component.EntityInfoNpcBaseComponent,
                entity_ai_component.EntityAIComponent,
                gas_position_component.EntityPositionComponent,
                entity_model_component.EntityModelComponent,
                entity_view_circle_component.EntityCircleComponent,
                entity_view_sector_component.EntityViewSectorComponent,
                gas_entity_card_mgr_lobby_component.GasEntityCardMgrLobbyComponent,
                entity_info_hero_base_component.EntityInfoHeroBaseComponent,
                gas_entity_card_mgr_fight_component.GasEntityCardMgrFightComponent,
                entity_do_skill_component.EntitySkillFsmComponent,
                entity_mouse_detect_component.EntityMouseDetectComponent,
                entity_fight_attr_component.EntityFightAttrComponent,
                entity_ui_component.EntityUIComponent,
                entity_info_area_base_component.EntityInfoAreaBaseComponent,
                gas_player_base_info_component.PlayerBaseInfoComponent,
                gas_player_scene_info_component.PlayerSceneInfoComponent,
                gas_entity_bag_mgr_component.GasEntityBagMgrComponent,
            ]

        for ComponentClass in listComponentClass:
            self.RegisterComponentType(ComponentClass)


# -----------------------------------------------------------------------------------
EntityComponentMgr = EntityComponentMgr()
CreateComponent = EntityComponentMgr.CreateComponent


# ---------------------------------reload--------------------------------------------
def __onreload__(new_dict):
    global EntityComponentMgr
    EntityComponentMgr = new_dict.get('EntityComponentMgr')
    EntityComponentMgr.Init()
