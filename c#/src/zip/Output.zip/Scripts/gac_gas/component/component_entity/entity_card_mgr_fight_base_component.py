# -*- coding: utf-8 -*-

import gac_gas.component.component_entity.entity_card_mgr_base_component as entity_card_mgr_base_component
import gac_gas.common.enum_def as enum_def
import gac_gas.entity.entity_interface as entity_interface


class EntityCardMgrFightComponent(entity_card_mgr_base_component.EntityBaseCardComponent):
    s_eComponentSubType = enum_def.ECardType.EFight

    def __init__(self, OwnerObj):
        super(EntityCardMgrFightComponent, self).__init__(OwnerObj)
        self.m_HandCard = {}
        self.m_bIsEnable = True

    def GerCreateData(self):
        dictData = super(EntityCardMgrFightComponent, self).GetCreateData()
        listSyncData = []
        for szCardID, CardObj in self.m_HandCard.iteritems():
            listSyncData.append(CardObj.GetCardSyncData())
        dictData.update(
                {enum_def.EPropertyType.HardCard: listSyncData}
        )
        return dictData

    def SetIsEnd(self, bIsEnd):
        self.m_bIsEnd = bIsEnd

    def Init(self, dictData):
        super(EntityCardMgrFightComponent, self).Init(dictData)
        for CardData in dictData.get(enum_def.EPropertyType.HardCard, []):
            szCardID, szCfg, nLevel = CardData
            CardObj = self.GetCardFactory().CreateCardByData(szCardID, szCfg, nLevel)
            self.m_HandCard[CardObj.GetCardID()] = CardObj

    def SetEnable(self, bEnable):
        self.m_bIsEnable = bEnable

    def IsEnable(self):
        return self.m_bIsEnable

    def GetSyncData(self):
        dictData = {}
        dictData[enum_def.EPropertyType.HardCard] = []
        for szCardID, CardObj in self.m_HandCard.iteritems():
            dictData[enum_def.EPropertyType.HardCard].append(CardObj.GetCardSyncData())

        dictData[enum_def.EPropertyType.CardData] = []
        for CardObj in self.m_ListCard:
            dictData[enum_def.EPropertyType.CardData].append(CardObj.GetCardSyncData())

        return dictData

    def GetHandCardByID(self, szCardID):
        return self.m_HandCard.get(szCardID, None)

    def GetNextCard(self):
        if len(self.m_ListCard):
            return self.m_ListCard[-1]
        return None

    # ---------------------------操作-------------------------------------
    def DrawCard(self, nDrawNum):
        """
        抽取卡片到手上
        :param nDrawNum:
        :return:
        """
        bChange = False
        for _ in xrange(nDrawNum):
            if len(self.m_ListCard):
                CardObj = self.m_ListCard.pop()
                self.m_HandCard[CardObj.GetCardID()] = CardObj
                bChange = True

        return bChange

    def UseCard(self, szCardID, listPosition):
        if not self.IsEnable():
            return False
        if szCardID not in self.m_HandCard:
            return False
        CardObj = self.m_HandCard[szCardID]
        del self.m_HandCard[szCardID]
        CardObj.Use(self.GetOwner(), entity_interface.InfoCmp_GetScene(self.GetOwner()), listPosition)
        self.m_ListCard.insert(0, CardObj)
