# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import entity_view_base_component as entity_view_base_component
from gac_gas.common.enum_def import EViewType
from gac_gas.common.enum_def import EPropertyType


# 游戏对象扇形视野
class EntityViewSectorComponent(entity_view_base_component.EntityViewBaseComponent):
    s_eComponentSubType = EViewType.ESector

    def __init__(self, OwnerObj):
        super(EntityViewSectorComponent, self).__init__(OwnerObj)

        # 视野角度
        self.m_nViewAngle = 0

    def Init(self, dictData):
        self.m_nViewAngle = dictData.get(EPropertyType.ViewAngle)

    def GetCreateData(self):
        dictData = super(EntityViewSectorComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.ViewAngle: self.m_nViewAngle,
        })
        return dictData
