# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_entity.entity_info_base_component as entity_info_base_component
from gac_gas.common.enum_def import EPropertyType
from gac_gas.common.enum_def import EInfoType


# Hero基本属性
class EntityInfoHeroBaseComponent(entity_info_base_component.EntityInfoBaseComponent):
    s_eComponentSubType = EInfoType.EHero

    def __init__(self, OwnerObj):
        super(EntityInfoHeroBaseComponent, self).__init__(OwnerObj)
        # 主人id
        self.m_nMasterID = None
        # 阵营
        self.m_nCamp = None

    def Init(self, dictData):
        super(EntityInfoHeroBaseComponent, self).Init(dictData)
        self.m_nMasterID = dictData.get(EPropertyType.MasterID, 0)
        self.m_nCamp = dictData.get(EPropertyType.CampID, 1)

    def GetCreateData(self):
        dictData = super(EntityInfoHeroBaseComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.MasterID: self.m_nMasterID,
            EPropertyType.CampID: self.m_nCamp,
        })
        return dictData

    def GetCamp(self):
        return self.m_nCamp

    def GetMasterID(self):
        return self.m_nMasterID