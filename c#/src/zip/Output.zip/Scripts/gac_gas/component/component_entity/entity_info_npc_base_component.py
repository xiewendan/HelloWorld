# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_entity.entity_info_base_component as entity_info_base_component
from gac_gas.common.enum_def import EInfoType
from gac_gas.common.enum_def import EPropertyType


# NPC基本属性
class EntityInfoNpcBaseComponent(entity_info_base_component.EntityInfoBaseComponent):
    s_eComponentSubType = EInfoType.ENpc

    def __init__(self, OwnerObj):
        super(EntityInfoNpcBaseComponent, self).__init__(OwnerObj)
        # 主动NPC
        self.m_bInitiative = False

    def Init(self, dictData):
        super(EntityInfoNpcBaseComponent, self).Init(dictData)
        self.m_bInitiative = dictData.get(EPropertyType.ViewRadius, 0) > 0

    def GetCreateData(self):
        dictData = super(EntityInfoNpcBaseComponent, self).GetCreateData()
        dictData.update({
        })
        return dictData

    def IsInitiative(self):
        return self.m_bInitiative
