# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType


# 游戏对象视野基类
class EntityViewBaseComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityView

    def __init__(self, OwnerObj):
        super(EntityViewBaseComponent, self).__init__(OwnerObj)
        # 视野半径
        self.m_nViewRadius = 0
        # 脱离半径
        self.m_nLostRadius = 0

    def Init(self, dictData):
        self.m_nViewRadius = dictData.get(EPropertyType.ViewRadius, 0)
        self.m_nLostRadius = dictData.get(EPropertyType.LostRadius, 0)
        assert self.m_nLostRadius >= self.m_nViewRadius, "脱离半径({}) < 视野半径({})".format(self.m_nViewRadius, self.m_nLostRadius)

    def GetCreateData(self):
        dictData = super(EntityViewBaseComponent, self).GetCreateData()
        dictData.update({
            EPropertyType.ViewRadius: self.m_nViewRadius,
            EPropertyType.LostRadius: self.m_nViewRadius,
        })
        return dictData

    def GetViewRadius(self):
        return self.m_nViewRadius

    def GetLostRadius(self):
        return self.m_nLostRadius
