# -*- coding: utf-8 -*-

import gac_gas.component.component_base as component_base
import gac_gas.common.enum_def as enum_def
from gac_gas.common.enum_def import EComponentEntityType
import gac_gas.item.item_cfg_mgr as item_cfg_mgr
from gac_gas.common.table_property_def import PlayerProperty
import gac_gas.common_pkg.utils as utils

# 游戏对象背包组件
class EntityBaseCardComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.EntityBagMgr

    def __init__(self, OwnerObj):
        super(EntityBaseCardComponent, self).__init__(OwnerObj)

        self.m_dictItemBagSpace2Obj = {}
        self.m_bIniting = False

    def Init(self, dictData):
        dictItemBagData = dictData.get(enum_def.EPropertyType.BagData, {})
        dictItemBagData = utils.ConvertKeyStrToInt(dictItemBagData)
        for nItemBagSpace, listSyncData in dictItemBagData.iteritems():
            if not nItemBagSpace in self.m_dictItemBagSpace2Obj:
                continue
            nExSpaceCount = listSyncData[0]
            dictPos2ItemSyncData = listSyncData[1]

            self.SetItemBagSpaceExSpaceCount(nItemBagSpace, nExSpaceCount)

            for nPos, listItemData in dictPos2ItemSyncData.iteritems():
                ItemObj = self.GetItemFactory().CreateItemByData(listItemData)
                if ItemObj:
                    self.SetItemByPos(nItemBagSpace, nPos, ItemObj)

    def OnInitOK(self, dictData):
        self.m_bIniting = True

    def SetItemBagSpaceSpaceCount(self, nItemBagSpace, nExSpaceCount):
        """设置背包空间大小"""

        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]

        ItemBagSpaceObj.SetSpaceCount(nExSpaceCount)

    def SetItemBagSpaceExSpaceCount(self, nItemBagSpace, nExSpaceCount):
        """设置背包拓展空间数量"""

        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]

        ItemBagSpaceObj.SetExSpaceCount(nExSpaceCount)

    def GetCreateData(self):
        dictData = {}
        dictItemBagData = {}
        for nItemBagSpace, ItemBagSpace in self.m_dictItemBagSpace2Obj.iteritems():
            nExSpaceCount = ItemBagSpace.GetExSpaceCount()
            dictPos2ItemSyncData = ItemBagSpace.GetPos2ItemSyncData()

            listSyncData = [nExSpaceCount, dictPos2ItemSyncData]

            dictItemBagData[nItemBagSpace] = listSyncData
        dictData.update({
            enum_def.EPropertyType.BagData: dictItemBagData
        })
        return dictData

    def GetSaveDBData(self):
        dictData = {}
        dictItemBagData = {}
        for nItemBagSpace, ItemBagSpace in self.m_dictItemBagSpace2Obj.iteritems():
            nExSpaceCount = ItemBagSpace.GetExSpaceCount()
            dictPos2ItemSyncData = ItemBagSpace.GetPos2ItemSyncData()

            listSyncData = [nExSpaceCount, dictPos2ItemSyncData]

            dictItemBagData[nItemBagSpace] = listSyncData
        dictData.update({
            PlayerProperty.BAG_DATA: dictItemBagData,
        })
        dictData = utils.ConvertKeyIntToStr(dictData)
        return dictData


    def AddItemBagSpace(self, nItemBagSpace, ItemBagSpaceObj):
        """
        添加背包空间
        @param nItemBagSpace: 背包空空间类型
        @param ItemBagSpaceObj: 背包空间对象
        @return: 无
        """

        assert nItemBagSpace not in self.m_dictItemBagSpace2Obj

        self.m_dictItemBagSpace2Obj[nItemBagSpace] = ItemBagSpaceObj

        ItemBagSpaceObj.SetBagMgr(self)

    def AddItemByType(self, nBigID, nIndex, nCount, szItemID=None, dynamicData=None):
        """
        添加物品，调用的时候确保允许添加nCount个物品
        @param nBigID: 大类ID
        @param nIndex: 小类
        @param nCount: 数量
        @return: [(nItemBagSpace, nPos, nCount)] 加到的位置
        """
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)
        assert nCount > 0

        nCanAddCount = self.CanAddItemCountByType(nBigID, nIndex)
        assert nCanAddCount >= nCount

        nFoldLimit = self.GetItemFoldLimit(nBigID, nIndex)

        nItemBagSpace = item_cfg_mgr.GetItemBagSpace(nBigID)

        assert nItemBagSpace == item_cfg_mgr.GetItemBagSpace(nBigID), "背包空间类型需要一致"

        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]
        assert ItemBagSpaceObj, "需要先调用AddItemBagSpace进行注册"

        nLeftCount = nCount
        listAddItemPos = []

        # 补满还没达到FoldLimit的格子
        listItemPos = ItemBagSpaceObj.GetListItemPosByType(nBigID, nIndex)
        for tupleItemPos in listItemPos:
            if nLeftCount <= 0:
                break

            _, nPos = tupleItemPos

            nItemCount = ItemBagSpaceObj.GetItemCountByPos(nPos)
            if nItemCount < nFoldLimit:
                nAddCountThisGrid = min(nLeftCount, nFoldLimit - nItemCount)
                nLeftCount -= nAddCountThisGrid

                ItemBagSpaceObj.AddItemCountByPos(nPos, nAddCountThisGrid, nFoldLimit)
                ItemBagSpaceObj.GetItemByPos(nPos).UpdateAddTime()
                listAddItemPos.append((nItemBagSpace, nPos, nAddCountThisGrid))

        # 开始填满空格子
        for _ in xrange(1000):
            if nLeftCount <= 0:
                break

            nPos = ItemBagSpaceObj.GetFirstEmptyPos()

            nAddCountThisGrid = min(nLeftCount, nFoldLimit)
            nLeftCount -= nAddCountThisGrid

            ItemObj = self.GetItemFactory().CreateItem(nBigID, nIndex, nAddCountThisGrid, szItemID=szItemID, dynamicData=dynamicData)
            ItemObj.UpdateAddTime()
            ItemBagSpaceObj.AddItemByPos(nPos, ItemObj)

            listAddItemPos.append((nItemBagSpace, nPos, nAddCountThisGrid))

        return listAddItemPos

    def CanAddItemsByDatas(self, listItemObjSyncData):
        """
        判断是否可以添加物品，主要是空间是否足够。
        注意:需要先调用CheckItemObjListSyncData检查格式
        优化建议：在稳定后，可以把dictBigID2Index2Pos2Count中已满的物品清除，这样，可以保证效率和节省内存，但不便于调试

        @param listItemObjSyncData:[[[nBigID,nIndex,nCount,szItemID,nAddTime],[dynamicAttr1, dynamicAttr2, ..]],...]
        @return:
        """
        if len(listItemObjSyncData) == 0:
            return False, "arg is empty list"
        nItemBagSpace = None
        # 必须所有物品都可以放到该空间中
        for itemObjSyncData in listItemObjSyncData:
            nBigID, nIndex, nCount, szItemID, _ = itemObjSyncData[0]

            dynamicData = itemObjSyncData[1]

            nItemBagSpaceT = item_cfg_mgr.GetItemBagSpace(nBigID)

            # 取第一个物品为默认的背包空间
            if not nItemBagSpace:
                nItemBagSpace = nItemBagSpaceT

            if nItemBagSpaceT != nItemBagSpace:
                return False, "some item does match itembagspace:{0},{1}; {2}".format(nItemBagSpace, nItemBagSpaceT, str(itemObjSyncData))

        # 获取空间的大小
        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]
        assert ItemBagSpaceObj, "需要先调用AddItemBagSpace进行注册"

        listEmptyPos, dictBigID2Index2Pos2Count = ItemBagSpaceObj.GetItemTakenInfo()

        # 有格子未满
        for itemObjSyncData in listItemObjSyncData:
            nBigID, nIndex, nCount, szItemID, _ = itemObjSyncData[0]
            nFoldLimit = self.GetItemFoldLimit(nBigID, nIndex)
            nGridCount = item_cfg_mgr.GetGridCount(nBigID, nIndex)

            if nBigID not in dictBigID2Index2Pos2Count:
                dictBigID2Index2Pos2Count[nBigID] = {}

            if nIndex not in dictBigID2Index2Pos2Count[nBigID]:
                dictBigID2Index2Pos2Count[nBigID][nIndex] = {}

            # 先填充未满的格子
            nAddCount = nCount
            for nPos, nTakenCount in dictBigID2Index2Pos2Count[nBigID][nIndex].iteritems():
                nLeftCount = nFoldLimit - nTakenCount
                assert nLeftCount >= 0, "item count is greater than fold limit"

                if nLeftCount == 0:
                    pass
                else:
                    if nLeftCount >= nAddCount:
                        dictBigID2Index2Pos2Count[nBigID][nIndex][nPos] = nTakenCount + nAddCount
                        nAddCount = 0
                        break
                    else:
                        nAddCount = nAddCount - nLeftCount
                        dictBigID2Index2Pos2Count[nBigID][nIndex][nPos] = nFoldLimit

            # 取空格子填充
            while nAddCount > 0 and len(listEmptyPos) > 0:
                nItemBagSpace, nPos = listEmptyPos.pop()
                if nAddCount > nFoldLimit:
                    dictBigID2Index2Pos2Count[nBigID][nIndex][nPos] = nFoldLimit
                    nAddCount = nAddCount - nFoldLimit
                else:
                    dictBigID2Index2Pos2Count[nBigID][nIndex][nPos] = nAddCount
                    nAddCount = 0
                    break

            # 一个物品可以占用的总共大小：<= nGridCount * nFoldLimit
            nCurTotalCount = 0
            for nPos, nCount in dictBigID2Index2Pos2Count[nBigID][nIndex].iteritems():
                nCurTotalCount += nCount

            if nCurTotalCount > nGridCount * nFoldLimit:
                return False, "total count is greater than nGridCount * nFoldLimit"

            # 数量
            if nAddCount > 0:
                return False, "bag is full"
        return True, "OK"

    def SetItemByPos(self, nItemBagSpace, nPos, Item):
        """
        设置指定格子的物品
        @param nItemBagSpace: 空间类型
        @param nPos: 格子位置
        @param Item: Item or None。如果物品不存在，则为None
        @return: 无
        """

        # 判断空间是否一致
        if Item:
            assert item_cfg_mgr.GetItemBagSpace(Item.GetBigID()) == nItemBagSpace

        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]
        ItemBagSpaceObj.SetItemByPos(nPos, Item)

    def CanAddItemCountByType(self, nBigID, nIndex):
        """
        可以加的物品数量。实现方式，查找所有物品占据的格子，统计这些格子还允许加的物品个数，再加上空格允许加的个数
        @param nBigID: 大类ID
        @type nBigID: int
        @param nIndex: 小类
        @type nIndex: int
        @return: 可以加数量，0表示已经不能再加了
        @type: int
        """
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)

        nItemBagSpace = item_cfg_mgr.GetItemBagSpace(nBigID)

        assert nItemBagSpace in self.m_dictItemBagSpace2Obj, "需要先调用AddItemBagSpace进行注册"
        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]

        nEmptyGridNum = ItemBagSpaceObj.GetEmptyGridNum()
        listItemPos = ItemBagSpaceObj.GetListItemPosByType(nBigID, nIndex)

        nFoldLimit = self.GetItemFoldLimit(nBigID, nIndex)
        nGridCount = item_cfg_mgr.GetGridCount(nBigID, nIndex)

        nCanAddItemCount = 0
        for tupleItemPos in listItemPos:
            _, nItemPos = tupleItemPos
            nItemCount = ItemBagSpaceObj.GetItemCountByPos(nItemPos)
            nCanAddItemCount += nFoldLimit - nItemCount

        assert nGridCount >= len(listItemPos)

        nCanAddItemCount += min(nGridCount - len(listItemPos), nEmptyGridNum) * nFoldLimit

        # assert nCanAddItemCount >= 0
        # CR 临时处理场内先加了上限，然后物品满时，上限又改变拾取报错的问题
        nCanAddItemCount = max(nCanAddItemCount, 0)

        return nCanAddItemCount

    def ClearItem(self, nItemBagSpace=0):
        """清除所有物品"""
        if nItemBagSpace == 0:
            for ItemBagSpace in self.m_dictItemBagSpace2Obj.itervalues():
                ItemBagSpace.ClearItem()
        else:
            ItemBagSpace = self.m_dictItemBagSpace2Obj[nItemBagSpace]
            ItemBagSpace.ClearItem()

    def DelItemCountByType(self, nBigID, nIndex, nCount):
        """
        通过类型，删除物品数量
        @param nBigID: 物品大类ID
        @param nIndex: 物品小类
        @param nCount: 物品数量
        @return:(nItemBagSpace, nPos)删除的格子位置
        """
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)
        assert nCount > 0

        nItemBagSpace = item_cfg_mgr.GetItemBagSpace(nBigID)

        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]

        listItemPos = ItemBagSpaceObj.GetListItemPosByType(nBigID, nIndex)

        nLeftCount = nCount
        listDelItemPos = []

        nFoldLimit = self.GetItemFoldLimit(nBigID, nIndex)

        for tupleItemPos in listItemPos:
            if nLeftCount <= 0:
                break

            _, nPos = tupleItemPos
            nItemCount = ItemBagSpaceObj.GetItemCountByPos(nPos)

            nDelItemCountThiGrid = min(nItemCount, nLeftCount)
            nLeftCount -= nDelItemCountThiGrid

            ItemBagSpaceObj.AddItemCountByPos(nPos, -nDelItemCountThiGrid, nFoldLimit)

            listDelItemPos.append((nItemBagSpace, nPos, nDelItemCountThiGrid))

        return listDelItemPos

    def GetListItemPosByItemType(self, nItemBagSpace, nTypeID):
        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]
        return ItemBagSpaceObj.GetListItemPosByItemType(nTypeID)

    def GetItemCountByType(self, nBigID, nIndex):
        """
        返回指定类型物品的数量
        @param nBigID: 物品大类ID
        @param nIndex: 小类
        @return: 返回指定物品的数量，不存在，返回0
        """
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)

        nItemBagSpace = item_cfg_mgr.GetItemBagSpace(nBigID)
        if nItemBagSpace not in self.m_dictItemBagSpace2Obj:
            # 如果不在空间不在,就返回-1
            return -1
        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]

        return ItemBagSpaceObj.GetItemCountByType(nBigID, nIndex)

    def GetItemByType(self, nBigID, nIndex):
        """
        返回指定类型的物品列表
        @param nBigID: 物品大类ID
        @param nIndex: 小类
        @return: 返回指定物品列表
        """
        assert item_cfg_mgr.CheckItemCfg(nBigID, nIndex)

        nItemBagSpace = item_cfg_mgr.GetItemBagSpace(nBigID)

        ItemBagSpaceObj = self.m_dictItemBagSpace2Obj[nItemBagSpace]

        return ItemBagSpaceObj.GetItemByType(nBigID, nIndex)

    # ********************************************************************************
    # Item动态属性
    # ********************************************************************************
    def GetItemFoldLimit(self, nBigID, nIndex):
        """物品叠加上限"""
        return item_cfg_mgr.GetFoldLimit(nBigID, nIndex)

    # ********************************************************************************
    # ItemFactory关联
    # ********************************************************************************
    def GetItemFactory(self):
        """
        @rtype:gac_gas.item.item_factory.ItemFactory
        """
        import gac_gas.common_pkg.utils as utils
        return utils.GetItemFactory()