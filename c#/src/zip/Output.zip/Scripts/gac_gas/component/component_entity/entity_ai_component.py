﻿# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import time
import logging
import gac_gas.common_pkg.tick_mgr as tick_mgr
import gac_gas.entity.entity_interface as entity_interface
import gac_gas.event_system.event_dispatcher as event_dispatcher
from gac_gas.component.component_base import ComponentBase
from gac_gas.event_system.event_def import EEventType
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.common.enum_def import EPropertyType
from gac_gas.common.const_def import sys_const


# AI组件基类
class EntityAIComponent(ComponentBase):
    s_eComponentType = EComponentEntityType.EntityAI
    s_bSyncClient = False

    def __init__(self, OwnerObj):
        super(EntityAIComponent, self).__init__(OwnerObj)
        self.m_Logger = logging.getLogger(self.__class__.__name__)

        # 上次心跳delta时间
        self.m_nDeltaTime = 0
        # 上次心跳时间
        self.m_nLastUpdateTime = 0
        # 心跳Tick
        self.m_TickUpdate = None
        # 心跳时间间隔(单位：毫秒)
        self.m_nAIInterval = sys_const.AI_INTERVAL_DEFAULT
        # AI执行核心
        self.m_AIExecutor = None
        # AI类型
        self.m_eAIType = None
        self.m_szAIArg = None
        # 目标选择器
        self.m_eTargetSelectorType = None
        self.m_listTargetSelectorArg = None
        self.m_TargetSelectorObj = None
        # AI需要记录的信息
        self.m_dictAIData = {}

        # 侦听事件
        self.m_EventObserverID = event_dispatcher.RegisterObserver(EEventType.GameObjAppear, self.OnGameObjAppear)

    def Init(self, dictData):
        self.m_nAIInterval = dictData.get(EPropertyType.AIInterval, sys_const.AI_INTERVAL_DEFAULT)
        self.m_eAIType = dictData.get(EPropertyType.AIType)
        self.m_szAIArg = dictData.get(EPropertyType.AIArg)
        self.m_eTargetSelectorType = dictData.get(EPropertyType.TargetSelectorType)
        self.m_listTargetSelectorArg = dictData.get(EPropertyType.TargetSelectorArg)

    def OnInitOK(self, dictData):
        if self.m_eAIType is not None:
            # TODO 测试
            # from gac_gas.common.enum_def import EAIType
            # self.m_eAIType = EAIType.FSM
            # self.m_szAIArg = "npc_chase_fight_wander"
            # self.m_eAIType = EAIType.BT
            # self.m_szAIArg = "npc_seek_attack_with_fsm"

            # AI执行核心
            import gac_gas.game_ai.ai_excutor_factory as ai_excutor_factory
            self.m_AIExecutor = ai_excutor_factory.GetAIExcutor(self.m_eAIType, self.m_szAIArg)

            # 目标选择器
            import gac_gas.game_ai.target_selector.target_selector_mgr as target_selector_mgr
            self.m_TargetSelectorObj = target_selector_mgr.GetTargetSelector(self.m_eTargetSelectorType)
            assert self.m_TargetSelectorObj is not None, "目标选择器出错:{}".format(self.m_eTargetSelectorType)
            self.m_TargetSelectorObj.Init(self.m_listTargetSelectorArg)

        self.SetEnable(self.m_bEnable)

    def OnDestroy(self):
        self.SetEnable(False)

        if self.m_EventObserverID:
            event_dispatcher.UnRegisterObserver(self.m_EventObserverID)
            self.m_EventObserverID = None

        if self.m_AIExecutor:
            # 注意，这里不能销毁AI执行核心，因为AI执行核心是同类配置对象共用的！！！！！！
            self.m_AIExecutor.Reset(self.m_OwnerObj, self.m_dictAIData)
            self.m_AIExecutor = None

    def CanUpdate(self):
        if not self.m_bEnable:
            return False

        if entity_interface.FightCmp_IsDead(self.m_OwnerObj):
            return False

        nCurTime = tick_mgr.GetFastTimeTickInSecFloat()
        self.m_nDeltaTime = nCurTime - self.m_nLastUpdateTime
        self.m_nLastUpdateTime = nCurTime

        return True

    def Update(self):
        if not self.CanUpdate():
            return

        self.m_AIExecutor.Update(self.m_OwnerObj, self.m_dictAIData)

    def SetEnable(self, bEnable):
        super(EntityAIComponent, self).SetEnable(bEnable)

        if not self.m_OwnerObj.IsInitOK():
            return

        if self.IsEnable():
            self.EnableUpdateTick()
        else:
            self.DisableUpdateTick()

    def EnableUpdateTick(self):
        self.DisableUpdateTick()
        assert self.m_AIExecutor is not None, "没有AI执行核心却有AI组件:{}".format(self.m_OwnerObj)
        self.m_nLastUpdateTime = tick_mgr.GetFastTimeTickInSecFloat()
        self.m_TickUpdate = tick_mgr.RegisterNotFixRandTickEx("component_ai.Update", 300, self.m_nAIInterval, self.Update)
        self.m_AIExecutor.Reset(self.m_OwnerObj, self.m_dictAIData)

    def DisableUpdateTick(self):
        if self.m_TickUpdate:
            tick_mgr.UnRegisterTick(self.m_TickUpdate)
            self.m_TickUpdate = None

    def SetAIInterval(self, nValue):
        self.m_nAIInterval = nValue
        self.SetEnable(self.m_bEnable)

    def GetInterval(self):
        return self.m_nAIInterval

    def GetDeltaTime(self):
        return self.m_nDeltaTime

    def GetAIType(self):
        return self.m_eAIType

    def GetAIExecutor(self):
        return self.m_AIExecutor

    def GetTargetSelector(self):
        return self.m_eTargetSelectorType

    # 获取AI数据
    def GetAIData(self, szKey, default=None):
        return self.m_dictAIData.get(szKey, default)

    # 设置AI数据
    def SetAIData(self, szKey, value):
        self.m_dictAIData[szKey] = value

    def GetTarget(self, nSearchRange=None, bIsFight=True):
        return self.m_TargetSelectorObj.GetTarget(self.m_OwnerObj, nSearchRange, bIsFight)

    def FindTarget(self, nSearchRange=None):
        return self.m_TargetSelectorObj.FindTarget(self.m_OwnerObj, nSearchRange)

    def ResetTarget(self, nSearchRange=None):
        szOldTargetGID = self.GetAIData("target_gid")
        TargetObj = self.FindTarget(nSearchRange)
        if TargetObj:
            if TargetObj.GetGlobalID() == szOldTargetGID:
                return False
            self.SetAIData("target_gid", TargetObj.GetGlobalID())
        else:
            self.SetAIData("target_gid", None)

        return True

    def GetTargetGID(self):
        return self.GetAIData("target_gid")

    def OnGameObjAppear(self, GameObj):
        if GameObj is self.m_OwnerObj:
            return

        self.SetAIData("try_reset_target", time.time() + self.m_nAIInterval)

    def OnEvent(self, eGameMessageType, *args, **kwargs):
        self.m_AIExecutor.NotifyEvent(self.m_OwnerObj, self.m_dictAIData, eGameMessageType, *args, **kwargs)
