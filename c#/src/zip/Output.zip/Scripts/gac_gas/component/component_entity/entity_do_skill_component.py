# -*- coding: utf-8 -*-
__author__ = 'ywxu'

import gac_gas.common_pkg.utils as utils
import gac_gas.entity.entity_interface as entity_interface
import gac_gas.component.component_playmaker_fsm as component_playmaker_fsm
from gac_gas.common.enum_def import EComponentEntityType, EDoSkillFailType
import gac_gas.skill.class_fight_skill_mgr as skill_mgr
import gac_gas.event_system.event_def as event_def


class EntitySkillFsmComponent(component_playmaker_fsm.PlayMakerFsmComponent):
    s_eComponentType = EComponentEntityType.EntityDoSkill

    # region -------------------- 初始化和销毁 --------------------------
    def __init__(self, OwnerObj):
        super(EntitySkillFsmComponent, self).__init__(OwnerObj)

        self.m_nCurSkillID = None
        self.m_szLockID = None
        self.m_posTarget = None

        # 技能槽, 临时
        self.m_objSkill = None

    def OnInitOK(self, dictData):
        nSkillID = dictData.get("技能1", 1)
        self.m_objSkill = skill_mgr.GetFightSkillByID(nSkillID)
        self.SetFsm(self.m_objSkill.GetFsmTemplate().CopyFsm(self.GetOwner()))

    def OnDestroy(self):
        self.m_nCurSkillID = None
        self.m_szLockID = None
        super(EntitySkillFsmComponent, self).OnDestroy()

    def OnEvent(self, eGameMessage, *args, **kwargs):
        if eGameMessage == event_def.EEventType.GameObjBeforeDestroy:
            self.CancelFightSkill()

    # endregion

    # region ------------------------------ 基本接口 ----------------------------
    # 立刻中断,正常结束
    def CancelFightSkill(self):
        Owner = self.GetOwner()

        if not self.IsDoingSkill():
            return

        # print("######omega print CancleFightSkill:", self.m_nCurSkillID, id(self))
        # 高速静态变量,非策划控制
        self.m_nCurSkillID = None
        self.m_szLockID = None
        self.m_posTarget = None

        # 清理fsm的动态变量, 策划业务逻辑动态控制
        self.Stop()

        # 通知客户端打断动画
        Owner.GetGacEntityRpc().RRpcGetModelCmp().Gas2GacModelSetTrigger("interrupt")

        # 广播同步(客户端没状态...)

    def DoSkill2Target(self, nSkillID, objTarget):
        self.SetLockID(objTarget.GetGlobalID())
        self._DoFightSkill(nSkillID)

    def DoSkill2Pos(self, nSkillID, posTarget):
        self.SetLockPos(posTarget)
        self._DoFightSkill(nSkillID)

    def _DoFightSkill(self, nSkillID):
        # print("######omega print DoFightSkill:%s" % nSkillID)
        Owner = self.GetOwner()

        if not self.CanStartSkill(nSkillID):
            return

        # 是否中断当前技能
        if self.IsDoingSkill():
            if self.IsCanDoSkillWhileDoingSkill(nSkillID):
                self.CancelFightSkill()
            else:
                return

        self.m_nCurSkillID = nSkillID

        entity_interface.MoveCmp_StopMove(self.m_OwnerObj)

        # 暂时都是同一个fsm, 外层技能槽管理fsm重用
        self.Start()

    # endregion

    # region -------------------- 目标锁定  ----------------
    def GetLockID(self):
        return self.m_szLockID

    def SetLockID(self, szLockID):
        self.m_szLockID = szLockID

    def GetLockObj(self):
        if self.m_szLockID:
            return utils.GetObjByGlobalID(self.m_szLockID)
        return None

    # 锁定的地点
    def SetLockPos(self, posTarget):
        self.m_posTarget = posTarget

    def GetLockPos(self):
        return self.m_posTarget

    # endregion

    # region ------------------- 状态查询 -----------------------
    def IsDoingSkill(self):
        return self.m_nCurSkillID is not None

    def GetCurSkillID(self):
        return self.m_nCurSkillID

    def GetCurSkill(self):
        return skill_mgr.GetFightSkillByID(self.m_nCurSkillID)

    def IsCanDoSkillWhileDoingSkill(self, nSkillID):
        if not entity_interface.FightCmp_IsCanDoSkill(self.GetOwner()):
            return False
        return True

    def CanStartSkill(self, nSkillID):
        Owner = self.GetOwner()

        # 被控状态不能使用技能(主角)
        if not entity_interface.FightCmp_IsCanDoSkill(Owner):
            # print("DoSkillFail, is ForceControlling or died")
            return False, EDoSkillFailType.eForceControlling

        # 死亡不能使用技能(主角)
        if entity_interface.FightCmp_IsDead(Owner):
            # print ("DoSkillFail, owner is death!")
            return False, EDoSkillFailType.eDead

        # cd中
        # if not skill_cd.CanDoSkill(Owner.GetGlobalID(), nSkillID):
        #     # print("######omega print cding:%s" % nSkillID)
        #     return False, EDoSkillFailType.eCD

        # Warring !!! 为了skill_button能判断只因cd不能使用技能, cd检测需要放最后!
        return True, EDoSkillFailType.eNone

    # endregion

    pass
