# -*- coding: utf-8 -*-
# __author__ = gzxiepeng


# 组件基类
class ComponentBase(object):
    s_eComponentType = None
    s_eComponentSubType = None
    s_bSyncClient = True
    s_bSyncBat = False
    s_bSaveDB = False

    def __init__(self, OwnerObj):
        self.SetOwner(OwnerObj)
        self.m_bEnable = False

    @classmethod
    def GetType(cls):
        return cls.s_eComponentType

    @classmethod
    def GetSubType(cls):
        return cls.s_eComponentSubType

    @classmethod
    def IsSyncClient(cls):
        return cls.s_bSyncClient

    @classmethod
    def IsSyncBat(cls):
        return cls.s_bSyncBat

    @classmethod
    def IsSaveDB(cls):
        return cls.s_bSaveDB

    def Init(self, dictData):
        pass

    def OnInitOK(self, dictData):
        pass

    def GetCreateData(self):
        return {}

    def GetFightData(self, dictData):
        pass

    def GetSaveDBData(self):
        return {}

    def SetOwner(self, OwnerObj):
        self.m_OwnerObj = OwnerObj
        if OwnerObj:
            self.m_szOwnerGID = OwnerObj.GetGlobalID()
            # sunshine 需要的id: 主人id+自己名字
            # ClientObj的id是int的
            self.m_szUUID = str(self.GetOwner().GetGlobalID()) + str(id(self))
        else:
            self.m_szOwnerGID = None
            self.m_szUUID = None

    def GetOwner(self):
        """
        @rtype: logic.game_entity.gac_game_entity.GacGameEntity
        """
        return self.m_OwnerObj

    def GetUUID(self):
        return self.m_szUUID

    def SetEnable(self, bEnable):
        self.m_bEnable = bEnable

    def IsEnable(self):
        return self.m_bEnable

    def OnEvent(self, eGameMessageType, *args, **kwargs):
        pass

    def Destroy(self):
        self.OnDestroy()

        self.SetEnable(False)
        self.m_OwnerObj = None

    # 注册函数到主人身上去
    def RegisterFunc(self, szFuncName, func):
        setattr(self.GetOwner(), szFuncName, func)

    def OnDestroy(self):
        pass

    def Reset(self):
        pass

    def Update(self):
        pass

    def Test(self):
        print("*******************test:{}".format(self.__class__.__name__))
