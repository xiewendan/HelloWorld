# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

import logging
import traceback
import gac_gas.component.component_entity.entity_component_mgr as entity_component_mgr
from gac_gas.common.enum_def import EPropertyType


class ComponentHelper(object):
    def __init__(self, OwnerObj):
        self.m_Logger = logging.getLogger(self.__class__.__name__)
        self.m_OwnerObj = OwnerObj
        self.m_dictAllComponent = {}

    def Destroy(self):
        for szComponentName, objComponent in self.m_dictAllComponent.iteritems():
            objComponent.Destroy()

        self.m_OwnerObj = None

    def AddComponent(self, ComponentObj, bEnable=True):
        szComponentName = ComponentObj.GetType()
        assert szComponentName not in self.m_dictAllComponent,\
            "{0} AddComponent Error: [{1}] is already existed!!!".format(self.__class__, szComponentName)
        self.m_dictAllComponent[szComponentName] = ComponentObj
        ComponentObj.SetEnable(bEnable)
        setattr(self.m_OwnerObj, szComponentName, ComponentObj)

    def ChangeComponent(self, ComponentObj, bEnable=True):
        szComponentName = ComponentObj.GetType()
        self.RemoveComponent(szComponentName)
        self.m_dictAllComponent[szComponentName] = ComponentObj
        ComponentObj.SetEnable(bEnable)

        setattr(self.m_OwnerObj, szComponentName, ComponentObj)

    def GetComponentByName(self, szComponentName):
        """
        @rtype: logic.component.component_entity.gac_entity_model_component.GacEntityModelComponent |
                 logic.component.component_entity.gac_entity_do_skill_component.GacEntitySkillFsmComponent
        """
        return self.m_dictAllComponent.get(szComponentName)

    def RemoveComponent(self, szComponentName):
        if szComponentName in self.m_dictAllComponent:
            ComponentObj = self.m_dictAllComponent[szComponentName]
            szID = ComponentObj.GetUUID()
            ComponentObj.Destroy()
            del self.m_dictAllComponent[szComponentName]
            delattr(self.m_OwnerObj, szComponentName)
            return szID

    def CallComponentFunc(self, szComponentName, szFuncName, *args, **kwargs):
        ComponentObj = self.GetComponentByName(szComponentName)
        if ComponentObj:
            return getattr(ComponentObj, szFuncName)(*args, **kwargs)
        else:
            assert False, "Component is not exist {}".format(szComponentName)

    def GetCreateData(self):
        dictData = {
            EPropertyType.ComponentDict: {},
        }
        for szComponentName, ComponentObj in self.m_dictAllComponent.iteritems():
            if not ComponentObj.IsSyncClient():
                continue

            # 更新组件字典
            eComponentType = ComponentObj.GetType()
            eComponentSubType = ComponentObj.GetSubType()
            dictData[EPropertyType.ComponentDict][eComponentType] = eComponentSubType
            # 更新组件数据
            dictComponentData = ComponentObj.GetCreateData()
            dictData.update(dictComponentData)
        return dictData

    def GetFightData(self):
        dictData = {
            EPropertyType.ComponentDict: {},
        }
        for szComponentName, ComponentObj in self.m_dictAllComponent.iteritems():
            if not ComponentObj.IsSyncBat():
                continue

            # 更新组件数据
            ComponentObj.GetFightData(dictData)
        return dictData

    def GetSaveDBData(self):
        dictData = {}
        for szComponentName, ComponentObj in self.m_dictAllComponent.iteritems():
            if not ComponentObj.IsSaveDB():
                continue

            dictComponentData = ComponentObj.GetSaveDBData()
            for szKey in dictComponentData:
                assert szKey not in dictData, "数据库保存属性存在重复：{}-{}".format(szComponentName, szKey)
            dictData.update(dictComponentData)
        return dictData

    # 初始化组件
    def InitComponents(self, dictData):
        dictCmp = dictData.get(EPropertyType.ComponentDict)
        if not dictCmp:
            return

        for eComponentType, eComponentSubType in dictCmp.iteritems():
            ComponentObj = entity_component_mgr.CreateComponent(eComponentType, eComponentSubType, self.m_OwnerObj)
            if not ComponentObj:
                self.m_Logger.warn("忽略组件:{}-({}-{})".format(self.m_OwnerObj.GetGlobalID(), eComponentType, eComponentSubType))
                continue
            ComponentObj.Init(dictData)
            self.AddComponent(ComponentObj)
            ComponentObj.SetEnable(True)

    def InitOK(self, dictData):
        for ComponentObj in self.m_dictAllComponent.itervalues():
            try:
                ComponentObj.OnInitOK(dictData)
            except Exception, e:
                self.m_Logger.error(e)
                traceback.print_exc()
                continue

    def OnEvent(self, eGameMessage, *args, **kwargs):
        for ComponentObj in self.m_dictAllComponent.itervalues():
            try:
                ComponentObj.OnEvent(eGameMessage, *args, **kwargs)
            except Exception, e:
                self.m_Logger.error(e)
                traceback.print_exc()
                continue
