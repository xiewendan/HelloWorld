# -*- coding: utf-8 -*-
# __author__ = gzxiepeng

class ComponentMgrBase(object):
    def __init__(self):
        self.m_dictComponentClass = {}
        self.Init()

    def Init(self):
        raise NotImplementedError

    def RegisterComponentType(self, ComponentObjClass):
        eComponentType = ComponentObjClass.GetType()
        eComponentSubType = ComponentObjClass.GetSubType()

        print("注册组件:({}-{}):{}".format(eComponentType, eComponentSubType, ComponentObjClass))
        assert eComponentType is not None, "组件类类型不能为None"

        if eComponentSubType is None:
            szKey = str(eComponentType)
        else:
            szKey = "{}_{}".format(eComponentType, eComponentSubType)

        assert szKey not in self.m_dictComponentClass, "组件类重复注册:{}-{}".format(eComponentType, eComponentSubType)

        self.m_dictComponentClass[szKey] = ComponentObjClass

    def CreateComponent(self, eComponentType, eComponentSubType, *args, **kwargs):
        if eComponentSubType is None:
            szKey = str(eComponentType)
        else:
            szKey = "{}_{}".format(eComponentType, eComponentSubType)
        ComponentObjClass = self.m_dictComponentClass.get(szKey)
        if ComponentObjClass:
            return ComponentObjClass(*args, **kwargs)
        return None
