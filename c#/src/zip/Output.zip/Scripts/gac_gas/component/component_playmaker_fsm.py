# -*- coding: utf-8 -*-
__author__ = 'ywxu'

import gac_gas.component.component_base as component_base
from gac_gas.common.enum_def import EComponentEntityType
from gac_gas.playmaker.fsm import Fsm
from gac_gas.playmaker.fsm_event import FsmEvent
from gac_gas.playmaker.fsm_template import FsmTemplateMgr
# fsm id 生成器
g_nFsmCount = 1


# 游戏模型类
class PlayMakerFsmComponent(component_base.ComponentBase):
    s_eComponentType = EComponentEntityType.PlayMakerFSM
    # 所有已创建且enabled的fsm
    FsmList = {}

    # region 初始化
    def __init__(self, OwnerObj):
        super(PlayMakerFsmComponent, self).__init__(OwnerObj)
        global g_nFsmCount
        self.fsm = None  # type:Fsm|None
        self.id = g_nFsmCount
        g_nFsmCount += 1

    # 支持动态换fsm实例
    def SetFsm(self, fsm):
        if self.fsm:
            self.OnDestroy()

        self.fsm = fsm
        self.SetEnable(False)

    # 加载模板by fsmName
    def LoadFsmTemplate(self, fsmTemplateName):
        # PlayMakerGlobals.Initialize()
        fsmTmplate = FsmTemplateMgr().GetFsmTemplate(fsmTemplateName)
        self.fsm = fsmTmplate.CopyFsm(self.GetOwner())
        self.SetEnable(False)

    # endregion

    def OnDestroy(self):
        if self.fsm:
            self.fsm.OnDestroy()

    # 停止时会重置状态机
    def Stop(self):
        if self.fsm.started:
            self.fsm.Stop()

    def Start(self):
        if not self.fsm.started:
            self.fsm.Start()

    # 这里要考虑优化, 注册update事件
    # 技能状态机一般只需要tick, 主要是为了性能, 所以这里服务器版可能不需要
    def Update(self):
        if not self.fsm.finished and not self.fsm.manualUpdate:
            self.fsm.Update()

    def SetEnable(self, bEnable):
        super(PlayMakerFsmComponent, self).SetEnable(bEnable)

        # if bEnable:
        #     self.OnEnable()
        # else:
        #     self.OnDisable()

    def OnEnable(self):
        self.FsmList[self.id] = self
        # 启用时->Fsm->Start()
        self.fsm.OnEnable()

    def OnDisable(self):
        if id in self.FsmList:
            del self.FsmList[self.id]

        self.fsm.Event(FsmEvent.Disable)
        if self.fsm and self.fsm.finished:
            self.fsm.OnDisable()

    def SetState(self, stateName):
        self.fsm.SetState(stateName)

    def ChangeState(self, fsmEventName):
        self.fsm.Event(fsmEventName)

    def SendEvent(self, fsmEventName):
        self.fsm.Event(fsmEventName)

    # 广播所有fsm组件
    def BroadcastEvent(self, fsmEventName):
        if fsmEventName and fsmEventName != "":
            self.BroadcastEvent(fsmEventName)

    def BroadcastEvent(self, fsmEventName):
        for item in self.FsmList.itervalues():
            if item.fsm:
                item.fsm.ProcessEvent(fsmEventName, None)
