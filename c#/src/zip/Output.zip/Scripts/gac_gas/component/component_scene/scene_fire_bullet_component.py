# -*- coding: utf-8 -*-
__author__ = 'ywxu'

import gac_gas.component.component_scene_base as component_scene_base
from gac_gas.common.enum_def import EComponentSceneType
from gac_gas.skill.tick_bullet import TickBullet

# 场景子弹管理
class SceneBulletMgrComponent(component_scene_base.ComponenetSceneBase):
    s_eComponentType = EComponentSceneType.eBulletMgr

    # region -------------------- 初始化和销毁 --------------------------
    def __init__(self, SceneObj, tupleArg=None):
        super(SceneBulletMgrComponent, self).__init__(SceneObj, tupleArg)
        self.m_nMaxBulletID = 0
        self.m_dictBullet = {}

    # 场景销毁
    def OnDestroy(self):
        for objBullet in self.m_dictBullet:
            objBullet.DestoryBullet()
        self.m_dictBullet.clear()

    def OnEvent(self, eGameMessage, *args, **kwargs):
        pass

    # endregion

    def _CreateBulletID(self):
        self.m_nMaxBulletID += 1
        return self.m_nMaxBulletID

    def CreateBullet(self, nBulletCfgID, nSkillID, objOwner):
        nBulletID = self._CreateBulletID()
        objBullet = TickBullet(nBulletID, nBulletCfgID, nSkillID, objOwner, self.DestroyBullet)
        self.m_dictBullet[nBulletID] = objBullet
        return objBullet

    def DestroyBullet(self, nBulletID):
        if self.m_dictBullet.get(nBulletID) is not None:
            del self.m_dictBullet[nBulletID]
