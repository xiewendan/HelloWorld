# -*- coding: utf-8 -*-

import gac_gas.component.component_scene_base as component_scene_base
import gac_gas.common.enum_def as enum_def

class SceneTestComponent(component_scene_base.ComponenetSceneBase):
    s_eComponentType = enum_def.EComponentSceneType.eTest

    def __init__(self, SceneObj, tupleArg=None):
        super(SceneTestComponent, self).__init__(SceneObj, tupleArg)
        print("初始化了")

    def OnDestroy(self):
        print("销毁了")