# -*- coding: utf-8 -*-

import gac_gas.common.idmanager as idmanager
import gac_gas.common_pkg.scene_cfg_mgr as scene_cfg_mgr
import gac_gas.common_pkg.tick_mgr as tick_mgr
import time

SCENE_DIE_LATER_INTERVAL = 33


class BaseSceneObj(object):
    def __init__(self, nSceneTypeID, nSceneID=None):
        self.m_nSceneTypeID = nSceneTypeID
        if nSceneID:
            self.m_nSceneID = nSceneID
        else:
            self.m_nSceneID = idmanager.IdManager.GenID()
        self.m_szSceneName = scene_cfg_mgr.GetSceneTypeName(nSceneTypeID)
        self.m_bDestroy = False

        # 延迟删除
        self.m_ditDelayRemoveObjInfo = {}
        self.m_TickDelayRemoveObj = None

        # 组件
        self.m_dictAllComponent = {}

    # ----------------------------------组件相关----------------------------
    def InitComponents(self):
        pass

    def AddComponent(self, ComponentObj, bEnable=True):
        nComponentName = ComponentObj.GetComponentType()
        assert nComponentName not in self.m_dictAllComponent,\
            "{0} AddComponent Error: [{1}] is already existed!!!".format(self.__class__, nComponentName)
        self.m_dictAllComponent[nComponentName] = ComponentObj
        ComponentObj.SetEnable(bEnable)

    def ChangeComponent(self, ComponentObj, bEnable=True):
        nComponentName = ComponentObj.GetType()
        self.RemoveComponent(nComponentName)
        self.m_dictAllComponent[nComponentName] = ComponentObj
        ComponentObj.SetEnable(bEnable)

    def GetComponentByName(self, nComponentName):
        """
        @rtype: logic.component.component_entity.gac_entity_model_component.GacEntityModelComponent |
                 logic.component.component_entity.gac_entity_do_skill_component.GacEntitySkillFsmComponent
        """
        return self.m_dictAllComponent.get(nComponentName)

    def RemoveComponent(self, nComponentName):
        if nComponentName in self.m_dictAllComponent:
            ComponentObj = self.m_dictAllComponent[nComponentName]
            del self.m_dictAllComponent[nComponentName]

    # 清理场景组件
    def CleanComponent(self):
        for eType, CmpObj in self.m_dictAllComponent.iteritems():
            CmpObj.Destroy()
        self.m_dictAllComponent = {}

    def OnDestroy(self):
        if self.m_bDestroy:
            return
        self.OnBeforeDestroy()

        # 删除延时清理Tick
        if self.m_TickDelayRemoveObj:
            tick_mgr.UnRegisterTick(self.m_TickDelayRemoveObj)
            self.m_TickDelayRemoveObj = None

        self.CleanComponent()

        self.m_bDestroy = True

    def OnBeforeDestroy(self):
        pass

    def GetSceneID(self):
        return self.m_nSceneID

    def GetSceneTypeID(self):
        return self.m_nSceneTypeID

    def GetSceneName(self):
        return self.m_szSceneName

    def GetSceneResPath(self):
        return scene_cfg_mgr.GetSceneResPath(self.m_nSceneTypeID)

    def GetSceneCopyType(self):
        return scene_cfg_mgr.GetCopyTypeID(self.m_nSceneTypeID)

    def CreateFinished(self, dictData):
        pass

    def LateDestroyObj(self, GameObj):
        self.m_ditDelayRemoveObjInfo[GameObj.GetGlobalID()] = time.time()
        if self.m_TickDelayRemoveObj is None:
            self.m_TickDelayRemoveObj = tick_mgr.RegisterNotFixTick("BaseScene LaterDestroyObj",
                                                                    SCENE_DIE_LATER_INTERVAL, self.OnDestroyObj)

    def OnDestroyObj(self):
        self.OnTryToDestroyObj()

        if not self.m_ditDelayRemoveObjInfo and self.m_TickDelayRemoveObj:
            tick_mgr.UnRegisterTick(self.m_TickDelayRemoveObj)
            self.m_TickDelayRemoveObj = None

    def OnTryToDestroyObj(self):
        assert False, "OnTryToDestroyObj 必须被实现"
