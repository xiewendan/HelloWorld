# -*- coding: utf-8 -*-
import encodings
from UnityEngine import Debug


def Init():
    Debug.Log("init.Init...... ")


def Start():
    Debug.Log("init.Start......")
